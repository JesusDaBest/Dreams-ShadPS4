﻿param([ValidateRange(10, 180)][int]$Seconds = 60)
$ErrorActionPreference = 'Stop'
$runtimeRoot = 'D:\CodexData\Workspaces\2026-09-04\usi\work\dispatch-runtime-20260904'
$exePath = Join-Path $runtimeRoot 'shadps4.exe'
$gamePath = 'D:\Emulators\ShadPS4\Games\CUSA04301\CUSA04301\eboot.bin'
if (!(Test-Path -LiteralPath "$runtimeRoot\user" -PathType Container)) { throw 'Portable user directory must already exist.' }
if (!(Test-Path -LiteralPath $exePath -PathType Leaf)) { throw 'Clean core is not ready.' }
if (!(Test-Path -LiteralPath $gamePath -PathType Leaf)) { throw 'Game executable is missing.' }
$existing = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^shadps4.*\.exe$' })
if ($existing.Count) { throw 'An emulator/launcher process already exists. Inspect it before running this test.' }
$gameRoot = Split-Path -Parent $gamePath
foreach ($suffix in @('-mods', '-mods.zar')) {
    if (Test-Path -LiteralPath "$gameRoot$suffix") { throw "Unexpected mods overlay: $gameRoot$suffix" }
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$captureRoot = Join-Path $runtimeRoot "startup-$stamp"
New-Item -ItemType Directory -Path $captureRoot | Out-Null
$priorEnvironment = @{}
foreach ($entry in (Get-ChildItem Env: | Where-Object { $_.Name -like 'SHADPS4_*' -or $_.Name -in @('SDL_WINDOW_ACTIVATE_WHEN_SHOWN','SDL_WINDOW_ACTIVATE_WHEN_RAISED') })) {
    $priorEnvironment[$entry.Name] = $entry.Value
    [Environment]::SetEnvironmentVariable($entry.Name, $null, 'Process')
}
$samples = [System.Collections.Generic.List[object]]::new()
$stopped = [System.Collections.Generic.List[object]]::new()
$startedUtc = [DateTime]::UtcNow
$reason = 'time_limit'
$exitCode = $null
try {
    $env:SDL_WINDOW_ACTIVATE_WHEN_SHOWN = '0'
    $env:SDL_WINDOW_ACTIVATE_WHEN_RAISED = '0'
    $process = Start-Process -FilePath $exePath -ArgumentList @('--game', ('"' + $gamePath + '"'), '--fullscreen', 'false', '--show-fps') -WorkingDirectory $runtimeRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput "$captureRoot\stdout.log" -RedirectStandardError "$captureRoot\stderr.log"
    try { $process.PriorityClass = 'BelowNormal' } catch {}
    Write-Output "Started isolated clean core PID $($process.Id); startup limit ${Seconds}s."
    while (([DateTime]::UtcNow - $startedUtc).TotalSeconds -lt $Seconds) {
        Start-Sleep -Seconds 5
        $matching = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -eq $exePath -and $_.CreationDate.ToUniversalTime() -ge $startedUtc.AddSeconds(-2) })
        if (!$matching.Count) {
            $reason = 'exited'
            $process.Refresh()
            if ($process.HasExited) { $exitCode = $process.ExitCode }
            break
        }
        foreach ($live in $matching) {
            $stats = Get-Process -Id $live.ProcessId -ErrorAction SilentlyContinue
            if ($stats) {
                try { $stats.PriorityClass = 'BelowNormal' } catch {}
                $samples.Add([pscustomobject]@{ elapsed_seconds = [math]::Round(([DateTime]::UtcNow - $startedUtc).TotalSeconds, 1); pid = $live.ProcessId; working_set_bytes = $stats.WorkingSet64; cpu_seconds = $stats.CPU; title = $stats.MainWindowTitle; responding = $stats.Responding })
            }
        }
        Write-Output "Observed $([math]::Round(([DateTime]::UtcNow - $startedUtc).TotalSeconds))s; $($matching.Count) matching core process(es)."
    }
} finally {
    $matching = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -eq $exePath -and $_.CreationDate.ToUniversalTime() -ge $startedUtc.AddSeconds(-2) })
    foreach ($live in $matching) {
        $check = Get-CimInstance Win32_Process -Filter "ProcessId=$($live.ProcessId)"
        if ($check -and $check.ExecutablePath -eq $exePath -and $check.CreationDate -eq $live.CreationDate) {
            Stop-Process -Id $check.ProcessId -Force -ErrorAction SilentlyContinue
            $stopped.Add([pscustomobject]@{ pid = $check.ProcessId; executable = $check.ExecutablePath; created_utc = $check.CreationDate.ToUniversalTime().ToString('o') })
        }
    }
    foreach ($key in @('SDL_WINDOW_ACTIVATE_WHEN_SHOWN','SDL_WINDOW_ACTIVATE_WHEN_RAISED')) { [Environment]::SetEnvironmentVariable($key, $null, 'Process') }
    foreach ($key in $priorEnvironment.Keys) { [Environment]::SetEnvironmentVariable($key, $priorEnvironment[$key], 'Process') }
    [ordered]@{ started_utc = $startedUtc.ToString('o'); duration_seconds = [math]::Round(([DateTime]::UtcNow - $startedUtc).TotalSeconds, 1); reason = $reason; exit_code = $exitCode; executable = $exePath; executable_sha256 = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash; working_directory = $runtimeRoot; game_path = $gamePath; profile = 'isolated diagnostic profile; configuration/default users copied from earlier isolated baseline; no saves copied'; samples = $samples.ToArray(); stopped = $stopped.ToArray() } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$captureRoot\run.json" -Encoding utf8
    if (Test-Path -LiteralPath "$runtimeRoot\user\log") { Copy-Item -LiteralPath "$runtimeRoot\user\log" -Destination "$captureRoot\logs" -Recurse }
    Write-Output "Evidence saved to $captureRoot"
}
