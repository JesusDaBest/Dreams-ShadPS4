"""Extract recorded launch facts, keeping indirect dimensions and hardware behavior unknown."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import sys

WORK = Path(__file__).resolve().parent
RUNTIME = WORK / 'dispatch-runtime-20260904'
CAPTURE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else sorted(RUNTIME.glob('startup-*'))[-1]
OUT = WORK.parent / 'outputs'
TARGET = '0xcbac06d2'
content = (CAPTURE / 'stdout.log').read_text(encoding='utf-8-sig', errors='replace')
content = re.sub(r'\x1b\[[0-9;]*m', '', content)
launch_lines = [line for line in content.splitlines() if 'Compute launch:' in line and f'shader={TARGET} ' in line]
state_lines = [line for line in content.splitlines() if 'Compute dispatch:' in line and f'shader={TARGET} ' in line]
if len(launch_lines) != 1 or len(state_lines) != 1:
    raise SystemExit(f'Need one unambiguous launch/state record, got {len(launch_lines)}/{len(state_lines)}. Inspect capture manually.')

def fields(line):
    result = {}
    for key, value in re.findall(r'(\w+)=([^\s]+)', line):
        if value.startswith('(') and value.endswith(')'):
            result[key] = [int(part, 0) if part not in ('true', 'false') else part == 'true' for part in value[1:-1].split(',')]
        elif value in ('true', 'false'):
            result[key] = value == 'true'
        else:
            try:
                result[key] = int(value, 0)
            except ValueError:
                result[key] = value
    return result

launch = fields(launch_lines[0])
state = fields(state_lines[0])
assert launch['shader'] == state['shader'] == int(TARGET, 16)
assert launch['dispatch_initiator'] == state['dispatch_initiator']
raw = launch['dispatch_initiator']
assert bool(raw & (1 << 3)) == state['ordered_append_enable']
assert bool(raw & (1 << 4)) == state['ordered_append_per_threadgroup']
assert bool(raw & (1 << 6)) == state['dispatch_out_of_order']
tg_info_index = launch['user_sgprs'] + sum(state['tgid_enable']) if state['tg_size_enable'] else None
run = json.loads((CAPTURE / 'run.json').read_text(encoding='utf-8-sig'))
build = json.loads((RUNTIME / 'build-provenance.json').read_text())
shader_file = RUNTIME / 'user/shader/dumps/cs_0x00000000cbac06d2_0.bin'
shader_hash = hashlib.sha256(shader_file.read_bytes()).hexdigest() if shader_file.exists() else None
record = {
    'capture': str(CAPTURE), 'run': run, 'shader': TARGET,
    'observed_launch': launch, 'observed_register_state': state,
    'recorded_lines': launch_lines + state_lines,
    'dispatch_dimensions': state['dimension_registers'] if launch['kind'] == 'direct' else None,
    'expected_tg_info_sgpr_from_enabled_register_layout': tg_info_index,
    'tg_info_emulation': 'Missing from current compute prologue; no measured PS4 TG_INFO value.',
    'shader_dump_sha256': shader_hash,
    'source_commit': build['source_commit'],
    'build_provenance_sha256': hashlib.sha256((RUNTIME / 'build-provenance.json').read_bytes()).hexdigest(),
    'compilation_units': len(build['sources']),
    'frozen_baseline_sha256_after_capture': hashlib.sha256((WORK / 'upstream-core-build/shadps4.exe').read_bytes()).hexdigest(),
    'dumping_disabled_after_capture': not json.loads((RUNTIME / 'user/config.json').read_text(encoding='utf-8-sig'))['GPU']['dump_shaders'],
    'failure_lines': [line for line in content.splitlines() if 'DS_ORDERED_COUNT' in line or 'Shader translation has failed' in line or 'BuildASL' in line],
    'limitations': [
        'These are emulator-observed guest register settings, not a PS4 hardware trace.',
        'No actual initial EXEC, hardware ordered token, returned result lane, or GDS initial contents were measured.',
        'Dimension registers are not actual dimensions for indirect dispatches.',
        'No DS_ORDERED_COUNT execution implementation or full game fix established.',
        'Clean-core startup failure remains distinct from earlier research-build Edit Mode visual defects.',
    ],
}
assert record['frozen_baseline_sha256_after_capture'] == 'f27e15d833b7b3690c4ad4a52dbe111b5df7c9ac552e366e3e08f7212535d05d'
assert record['dumping_disabled_after_capture']
assert shader_hash == '6d024583de0764ebb5eca74772dfca8ff2d460667c39afd844b070cd14f10ce2'
(OUT / 'Dreams-dispatch-capture-20260904.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
(RUNTIME / 'capture-analysis.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps({key: record[key] for key in ('observed_launch', 'observed_register_state', 'dispatch_dimensions', 'expected_tg_info_sgpr_from_enabled_register_layout', 'failure_lines')}, indent=2))
