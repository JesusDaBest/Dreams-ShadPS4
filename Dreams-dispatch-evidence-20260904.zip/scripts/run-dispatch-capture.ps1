param([ValidateRange(10, 180)][int]$Seconds = 30)
$ErrorActionPreference = 'Stop'
$taskWork = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildDir = Join-Path $taskWork 'upstream-core-build'
$runtimeDir = Join-Path $taskWork 'dispatch-runtime-20260904'
$probeExe = Join-Path $buildDir 'shadps4-dispatch-probe.exe'
$provenance = Get-Content -LiteralPath (Join-Path $buildDir 'provenance.json') -Raw | ConvertFrom-Json
$probeHash = (Get-FileHash -LiteralPath $probeExe -Algorithm SHA256).Hash
if ($probeHash -ne $provenance.executable_sha256) { throw 'Probe executable does not match build provenance.' }
Copy-Item -LiteralPath $probeExe -Destination (Join-Path $runtimeDir 'shadps4.exe')
Copy-Item -LiteralPath (Join-Path $buildDir 'provenance.json') -Destination (Join-Path $runtimeDir 'build-provenance.json')
$configPath = Join-Path $runtimeDir 'user\config.json'
$captureConfig = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
if ($captureConfig.GPU.patch_shaders -or $captureConfig.Vulkan.pipeline_cache_enabled -or $captureConfig.General.home_dir) { throw 'Unexpected runtime override.' }
$captureConfig.GPU.dump_shaders = $true
$captureConfig | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $configPath -Encoding utf8
Copy-Item -LiteralPath $configPath -Destination (Join-Path $runtimeDir 'capture-config.json')
try {
    & (Join-Path $taskWork 'run-dispatch-startup.ps1') -Seconds $Seconds
} finally {
    $captureConfig = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    $captureConfig.GPU.dump_shaders = $false
    $captureConfig | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $configPath -Encoding utf8
}
