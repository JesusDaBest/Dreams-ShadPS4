"""Read-only literal search in existing executable analysis copies and shader packs."""
import json
import mmap
from pathlib import Path
import re
import struct

OUT = Path(__file__).parent
INSPECTION = OUT.parents[1] / 'dreams-zip-inspection'
DETAILS = json.loads((INSPECTION / 'shader-audit/shader_pack_details.json').read_text())
KEY = '097df0f5cc4e7df1'
PATTERNS = {
    'table_key_u64_le': struct.pack('<Q', int(KEY, 16)),
    'table_key_u64_be': struct.pack('>Q', int(KEY, 16)),
    'table_key_ascii_lower': KEY.encode(),
    'table_key_ascii_upper': KEY.upper().encode(),
    'table_key_low_u32_le': struct.pack('<I', 0xcc4e7df1),
    'table_key_high_u32_le': struct.pack('<I', 0x097df0f5),
    'installed_shader_hash_u32_le': struct.pack('<I', 0xcbac06d2),
    'installed_shader_hash_u64_le': struct.pack('<Q', 0xcbac06d2),
    'zip_shader_hash_u32_le': struct.pack('<I', 0xfff5a423),
    'zip_shader_hash_u64_le': struct.pack('<Q', 0xfff5a423),
    'pack_filename_ascii': b'dd.shaders',
    'pack_filename_utf16le': 'dd.shaders'.encode('utf-16-le'),
    'pack_extension_ascii': b'.shaders',
    'reflection_dispatch_idx_ascii': b'dispatch_idx',
    'installed_shader_hash_ascii_lower': b'cbac06d2',
    'installed_shader_hash_ascii_upper': b'CBAC06D2',
    'zip_shader_hash_ascii_lower': b'fff5a423',
    'zip_shader_hash_ascii_upper': b'FFF5A423',
}


def elf_segments(data):
    if data[:6] != b'\x7fELF\x02\x01':
        return []
    phoff = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    records = []
    for i in range(count):
        kind, flags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack_from(
            '<IIQQQQQQ', data, phoff + size * i)
        if kind in (1, 0x61000010):
            records.append(dict(index=i, kind=hex(kind), flags=flags,
                                offset=offset, vaddr=vaddr, filesz=filesz))
    return records


def scan(path):
    with path.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        segments = elf_segments(data)
        matches = {}
        for label, pattern in PATTERNS.items():
            found = []
            pos = data.find(pattern)
            total = 0
            while pos >= 0:
                total += 1
                if len(found) < 32:
                    entry = {'file_offset': hex(pos)}
                    for segment in segments:
                        if segment['offset'] <= pos and pos + len(pattern) <= (
                                segment['offset'] + segment['filesz']):
                            entry['virtual_address'] = hex(
                                pos - segment['offset'] + segment['vaddr'])
                            entry['program_header'] = segment['index']
                            entry['segment_flags'] = segment['flags']
                    entry['context_hex'] = data[max(0, pos - 16):pos + len(pattern) + 16].hex()
                    found.append(entry)
                pos = data.find(pattern, pos + 1)
            matches[label] = {'count': total, 'matches': found}
        rip_candidates = []
        string_targets = {}
        for match in matches['pack_extension_ascii']['matches']:
            if 'virtual_address' not in match:
                continue
            offset = int(match['file_offset'], 16)
            if data[max(0, offset - 16):offset] == b'/app0/shaders/%s':
                string_targets[int(match['virtual_address'], 16) - 16] = '/app0/shaders/%s.shaders'
            elif offset and data[offset - 1] == 0:
                string_targets[int(match['virtual_address'], 16)] = '.shaders'
        for segment in segments:
            if not segment['flags'] & 1 or not string_targets:
                continue
            start, end = segment['offset'], segment['offset'] + segment['filesz']
            pattern = re.compile(rb'[\x48\x4c]\x8d[\x05\x0d\x15\x1d\x25\x2d\x35\x3d]')
            for candidate in pattern.finditer(data, start, end):
                offset = candidate.start()
                if offset + 7 > end:
                    continue
                address = offset - start + segment['vaddr']
                destination = address + 7 + struct.unpack_from('<i', data, offset + 3)[0]
                if destination in string_targets:
                    rip_candidates.append(dict(file_offset=hex(offset), virtual_address=hex(address),
                                               bytes=data[offset:offset + 7].hex(),
                                               target_virtual_address=hex(destination),
                                               target_string=string_targets[destination]))
        return dict(path=str(path), bytes=len(data), matches=matches,
                    rip_relative_lea_byte_candidates=rip_candidates)


paths = [INSPECTION / 'decompiler-prep/installed-eboot.elf',
         INSPECTION / 'decompiler-prep/zip-eboot.elf',
         Path(DETAILS['installed']['path']), Path(DETAILS['sample']['path'])]
result = {'searched_literals': {k: v.hex() for k, v in PATTERNS.items()},
          'files': [scan(path) for path in paths], 'target_pack_entries': []}
for label in ('installed', 'sample'):
    record = next(item for item in DETAILS[label]['records'] if item['key'] == KEY)
    with Path(DETAILS[label]['path']).open('rb') as stream:
        stream.seek(record['offset'])
        payload = stream.read(record['size'])
    info = record['binary_infos'][0]
    prefix = payload[:info['code_start']]
    suffix = payload[info['code_start'] + info['code_length']:]
    printable = []
    for region, base, part in [('header', 0, prefix),
                             ('after_code', info['code_start'] + info['code_length'], suffix)]:
        for match in re.finditer(rb'[\x20-\x7e]{4,}', part):
            printable.append(dict(region=region, offset_in_entry=hex(base + match.start()),
                                  text=match.group().decode('ascii')))
    result['target_pack_entries'].append(dict(
        label=label, record=record, header_u32_le=[hex(x[0]) for x in struct.iter_unpack('<I', prefix)],
        after_code_hex=suffix.hex(), printable_runs_outside_code=printable))
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'literal-search.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'files': [{
    'path': row['path'], 'bytes': row['bytes'],
    'matches': {label: {'count': item['count'], 'offsets': [m['file_offset'] for m in item['matches']]}
                for label, item in row['matches'].items() if item['count']}
    , 'rip_relative_lea_byte_candidates': row['rip_relative_lea_byte_candidates']
} for row in result['files']]}, indent=2))
