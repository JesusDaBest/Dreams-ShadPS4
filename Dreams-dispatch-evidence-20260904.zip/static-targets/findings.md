# Bounded static shader lookup targets

Source files were opened read-only. `literal-search.json` records every searched byte sequence, exact counts, and up to 32 occurrence offsets per sequence. `find_dispatch_literals.py` reproduces the scan without executing game code.

## CPU targets

The following are narrow candidates for a subsequent disassembly of shader-pack loading. They are **not established function entrypoints or the failing shader's dispatch caller**. RIP-relative LEA matches are byte-pattern candidates; instruction-boundary validation remains to be done.

| Analysis copy | Candidate instruction VA | File offset | Bytes | Target string VA |
| --- | --- | --- | --- | --- |
| installed-eboot.elf | `0xa6f960` | `0xa73960` | `48 8d 35 6d d8 ca 00` | `0x171d1d4` |
| zip-eboot.elf | `0xa4a9e6` | `0xa4e9e6` | `48 8d 35 de 05 c8 00` | `0x16cafcb` |

Both destinations contain the exact format string `/app0/shaders/%s.shaders`. The nearby bytes at installed VA `0xa6f993` / ZIP VA `0xa4aa16` are `48 b9 2e 73 68 61 64 65 72 73`, the encoding of a 64-bit immediate move containing `.shaders`. A separate NUL-delimited `.shaders` string is at installed VA `0x171d1f2` / ZIP VA `0x16cafe9`.

## Proven literal absence in the two executable analysis copies

In the complete installed copy (41,255,439 bytes) and ZIP copy (40,959,487 bytes), there were zero matches for:

- Table key `097df0f5cc4e7df1`: 64-bit little/big endian, lower/upper ASCII, and its two separate little-endian 32-bit halves.
- Shader hashes `cbac06d2` and `fff5a423`: 32/64-bit little endian and lower/upper ASCII.
- Exact `dd.shaders` as ASCII or UTF-16LE, and `dispatch_idx` as ASCII.

This excludes these literal lookup routes only. It does not exclude computed keys, different representations, or indirect lookup.

## Shader-pack targets

- The 64-bit key occurs once in each `dd.shaders` table, at file offset `0x158` (table record index 21). Its entry is installed file `0x13734` / ZIP file `0x1374c`, each `0xa00` bytes long.
- Declared machine code begins at entry `+0x60`, is `0x904` bytes, and is byte-identical between versions. SHA256: `6d024583de0764ebb5eca74772dfca8ff2d460667c39afd844b070cd14f10ce2`.
- `OrbShdr` begins at entry `+0x9a0`. The recorded hashes are installed `cbac06d2` / ZIP `fff5a423`.
- Both entries contain `dispatch_idx` at `+0x9e8` and `(no_name)` at `+0x9f5`. `dispatch_idx` occurs 162 times in each whole pack, so it is not a unique shader name or CPU-callsite selector.
- Raw little-endian header words at entry offsets `0x48`, `0x4c`, `0x50`, `0x54` are respectively `0x484`, `0x40`, `1`, `1` in both entries. No field meaning is assigned here without a confirmed structure layout. Full 96-byte header words and the post-code trailer are recorded in `literal-search.json`.

No reflection string in the target entry establishes a semantic shader/function name. No direct CPU reference to the target key or hashes was found by the specified literal searches.

## Follow-up: ZIP enclosing unwind record

The valid `PT_GNU_EH_FRAME` header establishes a containing FDE interval for ZIP reference `0xa4a9e6`: **start `0xa45e80`, exclusive end `0xa74324`, size `0x2e4a4` (189,604 bytes)**. The reference is `+0x4b66` inside this interval. It is not the entry.

- Program header 7: file `0x1ac5964`, VA `0x1ac1964`, size 169,308. Prefix `01 1b 03 3b 88 af f4 ff 8e 52 00 00` encodes version 1, PC-relative signed-32 `.eh_frame` pointer, unsigned-32 count 21,134, and data-relative signed-32 table entries. The `.eh_frame` pointer decodes to VA `0x1a0c8f0`.
- Fifteen table comparisons locate row 9801, file `0x1ad8bb8`, bytes `1c 45 f8 fe 5c 0e fa ff`. Adding the header VA to each signed field gives start `0xa45e80` and FDE VA `0x1a627c0`.
- FDE file `0x1a667c0`, raw bytes: `200000004c500400b836fefea4e4020000410e108602430d065083078c068d058e048f03`.
- Its CIE is at VA `0x1a1d778` / file `0x1a21778`, raw bytes: `1400000000000000017a5200017810011b0c070890010000`. Version 1 augmentation `zR` specifies FDE pointer encoding `0x1b` (PC-relative signed-32).
- Independently decoding the FDE initial-location field at VA `0x1a627c8` gives `0xa45e80`; its range field is `0x2e4a4`. The next table entry starts at `0xa74330`, consistent with the interval's exclusive end.
- Entry file offset is `0xa49e80`; its first 24 bytes are `554889e54157415641554154534881ec582408000fb605ad`, including an x86-64 frame prologue.

This supplies an unwind-backed routine start and range, not a semantic name or proof of the shader-specific caller. The interval exceeds the existing 16 KiB probe bound and should not trigger an automatic whole-routine decompilation. `locate_unwind_function.py` and `unwind-target.json` reproduce and record the narrow decode. No game code was executed or broadly disassembled.
