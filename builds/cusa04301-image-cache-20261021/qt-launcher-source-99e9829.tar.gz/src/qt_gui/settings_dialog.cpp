// SPDX-FileCopyrightText: Copyright 2025-2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include <iostream>
#include <vector>
#include <AL/al.h>
#include <AL/alc.h>
#include <QCompleter>
#include <QDesktopServices>
#include <QDirIterator>
#include <QFileDialog>
#include <QHoverEvent>
#include <QMessageBox>
#include <SDL3/SDL.h>
#include <fmt/format.h>

#include "common/assert.h"
#include "common/logging/log.h"
#include "qt_gui/compatibility_info.h"
#ifdef ENABLE_UPDATER
#include "check_update.h"
#endif
#include "background_music_player.h"
#include "common/logging/log.h"
#include "core/emulator_state.h"
#include "log_presets_dialog.h"
#include "sdl_event_wrapper.h"
#include "settings_dialog.h"
#include "ui_settings_dialog.h"

#ifndef __APPLE__
#define VOLK_IMPLEMENTATION
#include "volk.h"
#else
#include "qt_gui/apple.h"
#endif

// extern std::unique_ptr<Vulkan::Presenter> presenter;

QStringList languageNames = {"Arabic",
                             "Czech",
                             "Danish",
                             "Dutch",
                             "English (United Kingdom)",
                             "English (United States)",
                             "Finnish",
                             "French (Canada)",
                             "French (France)",
                             "German",
                             "Greek",
                             "Hungarian",
                             "Indonesian",
                             "Italian",
                             "Japanese",
                             "Korean",
                             "Norwegian (Bokmaal)",
                             "Polish",
                             "Portuguese (Brazil)",
                             "Portuguese (Portugal)",
                             "Romanian",
                             "Russian",
                             "Simplified Chinese",
                             "Spanish (Latin America)",
                             "Spanish (Spain)",
                             "Swedish",
                             "Thai",
                             "Traditional Chinese",
                             "Turkish",
                             "Ukrainian",
                             "Vietnamese"};

const QVector<int> languageIndexes = {21, 23, 14, 6, 18, 1, 12, 22, 2, 4,  25, 24, 29, 5,  0, 9,
                                      15, 16, 17, 7, 26, 8, 11, 20, 3, 13, 27, 10, 19, 30, 28};
QMap<QString, QString> channelMap;
QMap<QString, QString> logTypeMap;
QMap<QString, QString> screenModeMap;
QMap<QString, QString> presentModeMap;
QMap<QString, QString> chooseHomeTabMap;
QMap<QString, QString> micMap;
QMap<int, QString> audioBackendMap;

int backgroundImageOpacitySlider_backup;
int bgm_volume_backup;

static std::vector<QString> m_physical_devices;

void LogUpdateLevels() {
    spdlog::level default_log_level = spdlog::level::info;
    std::unordered_map<std::string, spdlog::level> log_level_per_class;

    if (EmulatorSettings.IsLogEnable()) {
        for (const auto class_level : std::views::split(EmulatorSettings.GetLogFilter(), ' ')) {
            const auto class_level_pair =
                std::views::split(class_level, ':') | std::ranges::to<std::vector<std::string>>();

            if (class_level_pair.size() != 2) {
                std::cerr << "bad log filter provided" << std::endl;
                continue;
            }

            if (class_level_pair.front()[0] == '*') {
                default_log_level = spdlog::level_from_str(class_level_pair.back() |
                                                           std::ranges::to<std::string>());
            } else {
                log_level_per_class[class_level_pair.front() | std::ranges::to<std::string>()] =
                    spdlog::level_from_str(class_level_pair.back() |
                                           std::ranges::to<std::string>());
            }
        }
    }

    for (auto& [name, logger] : Common::Log::ALL_LOGGERS) {
        ASSERT_MSG(logger != nullptr, "logger {} is null", name);

        if (EmulatorSettings.IsLogEnable()) {
            const auto level_it = log_level_per_class.find(std::string(name));

            logger->set_level(level_it != log_level_per_class.end() ? level_it->second
                                                                    : default_log_level);
        } else {
            logger->set_level(spdlog::level::off);
        }
    }
}

SettingsDialog::SettingsDialog(std::shared_ptr<gui_settings> gui_settings,
                               std::shared_ptr<CompatibilityInfoClass> m_compat_info,
                               std::shared_ptr<IpcClient> ipc_client, QWidget* parent,
                               bool is_running, bool is_specific, std::string gsc_serial)
    : QDialog(parent), ui(new Ui::SettingsDialog), m_gui_settings(std::move(gui_settings)),
      m_ipc_client(ipc_client), is_game_running(is_running), is_game_specific(is_specific),
      gs_serial(gsc_serial) {

    ui->setupUi(this);
    ui->tabWidgetSettings->setUsesScrollButtons(false);
    GetPhysicalDevices();

    initialHeight = this->height();

    // Add a small clear "x" button inside the Log Filter input
    ui->logFilterLineEdit->setClearButtonEnabled(true);

    if (is_game_specific) {
        EmulatorSettings.Load(gs_serial);
    } else {
        EmulatorSettings.Load();
    }

    if (is_game_specific) {
        // Paths tab
        ui->tabWidgetSettings->setTabVisible(5, false);
        ui->chooseHomeTabComboBox->removeItem(5);

        // Frontend tab
        ui->tabWidgetSettings->setTabVisible(1, false);
        ui->chooseHomeTabComboBox->removeItem(1);

    } else {
        // Experimental tab
        ui->tabWidgetSettings->setTabVisible(8, false);
        ui->chooseHomeTabComboBox->removeItem(8);
    }

    // to do: unhide when implemented
    ui->homeFolderGroupBox->setVisible(false);

    ui->buttonBox->button(QDialogButtonBox::StandardButton::Close)->setFocus();

    logTypeMap = {{tr("wincolor"), "wincolor"}, {tr("msvc"), "msvc"}};
    screenModeMap = {{tr("Fullscreen (Borderless)"), "Fullscreen (Borderless)"},
                     {tr("Windowed"), "Windowed"},
                     {tr("Fullscreen"), "Fullscreen"}};
    presentModeMap = {{tr("Mailbox (Vsync)"), "Mailbox"},
                      {tr("Fifo (Vsync)"), "Fifo"},
                      {tr("Immediate (No Vsync)"), "Immediate"}};
    chooseHomeTabMap = {{tr("General"), "General"},
                        {tr("Frontend"), "Frontend"},
                        {tr("Graphics"), "Graphics"},
                        {tr("User"), "User"},
                        {tr("Input"), "Input"},
                        {tr("Paths"), "Paths"},
                        {tr("Log"), "Log"},
                        {tr("Debug"), "Debug"},
                        {tr("Experimental"), "Experimental"}};
    micMap = {{tr("None"), "None"}, {tr("Default Device"), "Default Device"}};
    audioBackendMap = {{0, "SDL"}, {1, "OpenAL"}};

    if (m_physical_devices.empty()) {
        // Populate cache of physical devices.
        // Vulkan::Instance instance(false, false);
        /* auto physical_devices = getPhysicalDevices();
        for (const vk::PhysicalDevice physical_device : physical_devices) {
            auto prop = physical_device.getProperties();
            QString name = QString::fromUtf8(prop.deviceName, -1);
            if (prop.apiVersion < Vulkan::TargetVulkanApiVersion) {
                name += tr(" * Unsupported Vulkan Version");
            }
            m_physical_devices.push_back(name);
        }*/
        GetPhysicalDevices();
    }

    // Add list of available GPUs
    ui->graphicsAdapterBox->addItem(tr("Auto Select")); // -1, auto selection
    for (const auto& device : m_physical_devices) {
        ui->graphicsAdapterBox->addItem(device);
    }

    ui->consoleLanguageComboBox->addItems(languageNames);

    QCompleter* completer = new QCompleter(languageNames, this);
    completer->setCaseSensitivity(Qt::CaseInsensitive);
    ui->consoleLanguageComboBox->setCompleter(completer);

    ui->hideCursorComboBox->addItem(tr("Never"));
    ui->hideCursorComboBox->addItem(tr("Idle"));
    ui->hideCursorComboBox->addItem(tr("Always"));

    ui->usbComboBox->addItem(tr("Real USB Device"));
    ui->usbComboBox->addItem(tr("Skylander Portal"));
    ui->usbComboBox->addItem(tr("Infinity Base"));
    ui->usbComboBox->addItem(tr("Dimensions Toypad"));

    ui->cameraComboBox->addItem(tr("None"));

    if (!SDL_Init(SDL_INIT_CAMERA)) {
        LOG_ERROR(Config, "SDL_INIT_CAMERA failed: {}", SDL_GetError());
    }

    int count = 0;
    SDL_CameraID* devices = SDL_GetCameras(&count);
    if (devices) {
        for (int i = 0; i < count; i++) {
            const char* name = SDL_GetCameraName(devices[i]);
            ui->cameraComboBox->addItem(name);
        }
        SDL_free(devices);
    }

    SDL_QuitSubSystem(SDL_INIT_CAMERA);

    if (!SDL_Init(SDL_INIT_AUDIO)) {
        LOG_ERROR(Config, "SDL_INIT_AUDIO failed: {}", SDL_GetError());
    }
    ui->audioBackendComboBox->setCurrentIndex(EmulatorSettings.GetAudioBackend());
    RefreshAudioDevices();

    InitializeEmulatorLanguages();
    LoadValuesFromConfig();

    defaultTextEdit = tr("Point your mouse at an option to display its description.");
    ui->descriptionText->setText(defaultTextEdit);

    connect(ui->buttonBox, &QDialogButtonBox::rejected, this, &QWidget::close);

    connect(ui->buttonBox, &QDialogButtonBox::clicked, this, [this](QAbstractButton* button) {
        if (button == ui->buttonBox->button(QDialogButtonBox::Save)) {
            is_game_saving = true;
            UpdateSettings(is_game_specific);
            SaveSettings();
            QWidget::close();
        } else if (button == ui->buttonBox->button(QDialogButtonBox::Apply)) {
            UpdateSettings(is_game_specific);
            SaveSettings();
        } else if (button == ui->buttonBox->button(QDialogButtonBox::RestoreDefaults)) {
            SetDefaultValues();
            EmulatorSettings.SetDefaultValues();
            SaveSettings();
            LoadValuesFromConfig();
        } else if (button == ui->buttonBox->button(QDialogButtonBox::Close)) {
            ui->backgroundImageOpacitySlider->setValue(backgroundImageOpacitySlider_backup);
            emit BackgroundOpacityChanged(backgroundImageOpacitySlider_backup);
            ui->BGMVolumeSlider->setValue(bgm_volume_backup);
            BackgroundMusicPlayer::getInstance().setVolume(bgm_volume_backup);
            SyncRealTimeWidgetstoConfig();
        }

        LogUpdateLevels();
    });

    ui->buttonBox->button(QDialogButtonBox::Save)->setText(tr("Save"));
    ui->buttonBox->button(QDialogButtonBox::Apply)->setText(tr("Apply"));
    ui->buttonBox->button(QDialogButtonBox::RestoreDefaults)->setText(tr("Restore Defaults"));
    ui->buttonBox->button(QDialogButtonBox::Close)->setText(tr("Close"));

    connect(ui->tabWidgetSettings, &QTabWidget::currentChanged, this,
            [this]() { ui->buttonBox->button(QDialogButtonBox::Close)->setFocus(); });

    // GENERAL TAB
    {
        connect(ui->horizontalVolumeSlider, &QSlider::valueChanged, this, [this](int value) {
            VolumeSliderChange(value);

            if (EmulatorState::GetInstance()->IsGameRunning())
                m_ipc_client->adjustVol(value, is_game_specific);
        });

        connect(ui->audioBackendComboBox, &QComboBox::currentIndexChanged, this,
                &SettingsDialog::RefreshAudioDevices);

#ifdef ENABLE_UPDATER
        connect(ui->updateCheckBox, &QCheckBox::checkStateChanged, this,
                [this](Qt::CheckState state) {
                    m_gui_settings->SetValue(gui::gen_checkForUpdates, state == Qt::Checked);
                });

        connect(ui->changelogCheckBox, &QCheckBox::checkStateChanged, this,
                [this](Qt::CheckState state) {
                    m_gui_settings->SetValue(gui::gen_showChangeLog, state == Qt::Checked);
                });
        connect(ui->checkUpdateButton, &QPushButton::clicked, this, [this]() {
            auto checkUpdate = new CheckUpdate(m_gui_settings, true);
            checkUpdate->exec();
        });
#else
        ui->updaterGroupBox->setVisible(false);
#endif
        connect(ui->updateCompatibilityButton, &QPushButton::clicked, this,
                [this, parent, m_compat_info]() {
                    m_compat_info->UpdateCompatibilityDatabase(this, true);
                    emit CompatibilityChanged();
                });

        connect(ui->enableCompatibilityCheckBox, &QCheckBox::checkStateChanged, this,
                [this, m_compat_info](Qt::CheckState state) {
                    m_gui_settings->SetValue(gui::glc_showCompatibility, state);
                    if (state) {
                        m_compat_info->LoadCompatibilityFile();
                    }
                    emit CompatibilityChanged();
                });
    }

    // GUI TAB
    {
        connect(ui->backgroundImageOpacitySlider, &QSlider::valueChanged, this,
                [this](int value) { emit BackgroundOpacityChanged(value); });

        connect(ui->BGMVolumeSlider, &QSlider::valueChanged, this,
                [](int value) { BackgroundMusicPlayer::getInstance().setVolume(value); });
        connect(ui->showBackgroundImageCheckBox, &QCheckBox::checkStateChanged, this,
                [this](Qt::CheckState state) {
                    m_gui_settings->SetValue(gui::gl_showBackgroundImage, state == Qt::Checked);
                });
    }

    // USER TAB
    {
        connect(ui->OpenCustomTrophyLocationButton, &QPushButton::clicked, this, []() {
            QString userPath;
            Common::FS::PathToQString(userPath,
                                      Common::FS::GetUserPath(Common::FS::PathType::CustomTrophy));
            QDesktopServices::openUrl(QUrl::fromLocalFile(userPath));
        });

        connect(ui->PortableUserButton, &QPushButton::clicked, this, []() {
            QString launcherDir;
            Common::FS::PathToQString(launcherDir, std::filesystem::current_path() / "launcher");
            if (std::filesystem::exists(std::filesystem::current_path() / "launcher")) {
                QMessageBox::information(NULL, tr("Cannot create portable launcher folder"),
                                         tr("%1 already exists").arg(launcherDir));
            } else {
                std::filesystem::copy(Common::FS::GetUserPath(Common::FS::PathType::LauncherDir),
                                      std::filesystem::current_path() / "launcher",
                                      std::filesystem::copy_options::recursive);
                QMessageBox::information(NULL, tr("Portable launcherDir folder created"),
                                         tr("%1 successfully created.").arg(launcherDir));
            }
        });
    }

    // INPUT TAB
    {
        connect(ui->hideCursorComboBox, QOverload<int>::of(&QComboBox::currentIndexChanged), this,
                [this](s16 index) { OnCursorStateChanged(index); });
    }

    // PATH TAB
    {
        connect(ui->addFolderButton, &QPushButton::clicked, this, [this]() {
            QString file_path_string =
                QFileDialog::getExistingDirectory(this, tr("Directory to install games"));
            auto file_path = Common::FS::PathFromQString(file_path_string);
            if (!file_path.empty() && EmulatorSettings.AddGameInstallDir(file_path, true)) {
                QListWidgetItem* item = new QListWidgetItem(file_path_string);
                item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
                item->setCheckState(Qt::Checked);
                ui->gameFoldersListWidget->addItem(item);
            }
        });

        connect(ui->gameFoldersListWidget, &QListWidget::itemSelectionChanged, this, [this]() {
            ui->removeFolderButton->setEnabled(
                !ui->gameFoldersListWidget->selectedItems().isEmpty());
        });

        connect(ui->removeFolderButton, &QPushButton::clicked, this, [this]() {
            QListWidgetItem* selected_item = ui->gameFoldersListWidget->currentItem();
            QString item_path_string = selected_item ? selected_item->text() : QString();
            if (!item_path_string.isEmpty()) {
                auto file_path = Common::FS::PathFromQString(item_path_string);
                EmulatorSettings.RemoveGameInstallDir(file_path);
                delete selected_item;
            }
        });

        connect(ui->homeFolderButton, &QPushButton::clicked, this, [this]() {
            const auto home_path = EmulatorSettings.GetHomeDir();
            QString initial_path;
            Common::FS::PathToQString(initial_path, home_path);

            QString home_path_string = QFileDialog::getExistingDirectory(
                this, tr("Select shadPS4 Home Path"), initial_path);

            auto file_path = Common::FS::PathFromQString(home_path_string);
            if (!file_path.empty()) {
                EmulatorSettings.SetHomeDir(file_path);
                ui->homeFolderPath->setText(home_path_string);
            }
        });

        connect(ui->folderButton, &QPushButton::clicked, this, [this]() {
            const auto dlc_folder_path = EmulatorSettings.GetAddonInstallDir();
            QString initial_path;
            Common::FS::PathToQString(initial_path, dlc_folder_path);

            QString dlc_folder_path_string =
                QFileDialog::getExistingDirectory(this, tr("Select the DLC folder"), initial_path);

            auto file_path = Common::FS::PathFromQString(dlc_folder_path_string);
            if (!file_path.empty()) {
                EmulatorSettings.SetAddonInstallDir(file_path);
                ui->currentDLCFolder->setText(dlc_folder_path_string);
            }
        });

        connect(ui->browse_sysmodules, &QPushButton::clicked, this, [this]() {
            const auto sysmodules_path = EmulatorSettings.GetSysModulesDir();
            QString initial_path;
            Common::FS::PathToQString(initial_path, sysmodules_path);

            QString sysmodules_path_string = QFileDialog::getExistingDirectory(
                this, tr("Select the system modules folder"), initial_path);

            auto file_path = Common::FS::PathFromQString(sysmodules_path_string);
            if (!file_path.empty()) {
                EmulatorSettings.SetSysModulesDir(file_path);
                ui->sysmodulesPath->setText(sysmodules_path_string);
            }
        });
    }

    // LOG TAB
    {
        connect(ui->logOpenLocationButton, &QPushButton::clicked, this, []() {
            QString userPath;
            Common::FS::PathToQString(userPath,
                                      Common::FS::GetUserPath(Common::FS::PathType::LogDir));
            QDesktopServices::openUrl(QUrl::fromLocalFile(userPath));
        });

        // Log presets popup button
        connect(ui->logPresetsButton, &QPushButton::clicked, this, [this]() {
            auto dlg = new LogPresetsDialog(m_gui_settings, this);
            connect(dlg, &LogPresetsDialog::PresetChosen, this,
                    [this](const QString& filter) { ui->logFilterLineEdit->setText(filter); });
            dlg->exec();
        });

        connect(ui->logSkipDuplicateCheckBox, &QPushButton::clicked, this, [this]() {
            ui->logMaxSkipDurationGroupBox->setVisible(
                !ui->logMaxSkipDurationGroupBox->isVisible());
        });
    }

    // DEBUG TAB
    {
        connect(ui->vkValidationCheckBox, &QCheckBox::checkStateChanged, this,
                [this](Qt::CheckState state) {
                    state ? ui->vkLayersGroupBox->setVisible(true)
                          : ui->vkLayersGroupBox->setVisible(false);
                });
    }

    // Experimental
    {
        connect(ui->shaderCaheCheckBox, &QCheckBox::checkStateChanged, this,
                [this](Qt::CheckState state) {
                    state ? ui->shaderCacheArchiveCheckBox->setVisible(true)
                          : ui->shaderCacheArchiveCheckBox->setVisible(false);
                });
    }

    // GRAPHICS TAB
    connect(ui->RCASSlider, &QSlider::valueChanged, this, [this](int value) {
        QString RCASValue = QString::number(value / 1000.0, 'f', 3);
        ui->RCASValue->setText(RCASValue);
    });

    if (EmulatorState::GetInstance()->IsGameRunning()) {
        connect(ui->RCASSlider, &QSlider::valueChanged, this, [this](int value) {
            if (is_game_specific == EmulatorState::GetInstance()->IsGameSpecifigConfigUsed()) {
                m_ipc_client->setRcasAttenuation(value);
            }
        });
        connect(ui->FSRCheckBox, &QCheckBox::checkStateChanged, this, [this](Qt::CheckState state) {
            if (is_game_specific == EmulatorState::GetInstance()->IsGameSpecifigConfigUsed()) {
                m_ipc_client->setFsr(state);
            }
        });

        connect(
            ui->RCASCheckBox, &QCheckBox::checkStateChanged, this, [this](Qt::CheckState state) {
                if (is_game_specific == EmulatorState::GetInstance()->IsGameSpecifigConfigUsed()) {
                    m_ipc_client->setRcas(state);
                }
            });
    }

    // Descriptions
    {
        // General
        ui->consoleLanguageGroupBox->installEventFilter(this);
        ui->emulatorLanguageGroupBox->installEventFilter(this);
        ui->showSplashCheckBox->installEventFilter(this);
        ui->discordRPCCheckbox->installEventFilter(this);
        ui->volumeSliderElement->installEventFilter(this);
#ifdef ENABLE_UPDATER
        ui->updaterGroupBox->installEventFilter(this);
#endif

        // GUI
        ui->GUIBackgroundImageGroupBox->installEventFilter(this);
        ui->GUIMusicGroupBox->installEventFilter(this);
        ui->enableCompatibilityCheckBox->installEventFilter(this);
        ui->checkCompatibilityOnStartupCheckBox->installEventFilter(this);
        ui->updateCompatibilityButton->installEventFilter(this);

        // User
        ui->disableTrophycheckBox->installEventFilter(this);
        ui->OpenCustomTrophyLocationButton->installEventFilter(this);
        ui->PortableUserFolderGroupBox->installEventFilter(this);

        // Input
        ui->hideCursorGroupBox->installEventFilter(this);
        ui->idleTimeoutGroupBox->installEventFilter(this);
        ui->backgroundControllerCheckBox->installEventFilter(this);
        ui->motionControlsCheckBox->installEventFilter(this);
        ui->micComboBox->installEventFilter(this);
        ui->usbComboBox->installEventFilter(this);

        // Graphics
        ui->graphicsAdapterGroupBox->installEventFilter(this);
        ui->windowSizeGroupBox->installEventFilter(this);
        ui->presentModeGroupBox->installEventFilter(this);
        ui->heightDivider->installEventFilter(this);
        ui->nullGpuCheckBox->installEventFilter(this);
        ui->enableHDRCheckBox->installEventFilter(this);
        ui->chooseHomeTabGroupBox->installEventFilter(this);

        // Paths
        ui->gameFoldersGroupBox->installEventFilter(this);
        ui->gameFoldersListWidget->installEventFilter(this);
        ui->addFolderButton->installEventFilter(this);
        ui->removeFolderButton->installEventFilter(this);
        ui->homeFolderGroupBox->installEventFilter(this);
        ui->sysmodulesGroupBox->installEventFilter(this);
        ui->browse_sysmodules->installEventFilter(this);
        ui->homeFolderPath->installEventFilter(this);
        ui->currentDLCFolder->installEventFilter(this);
        ui->homeFolderButton->installEventFilter(this);
        ui->folderButton->installEventFilter(this);

        // Log
        ui->logAppendCheckBox->installEventFilter(this);
        ui->logEnableCheckBox->installEventFilter(this);
        ui->logFilter->installEventFilter(this);
        ui->logMaxSkipDurationLineEdit->installEventFilter(this);
        ui->logOpenLocationButton->installEventFilter(this);
        ui->logSeparateCheckBox->installEventFilter(this);
        ui->logSizeLimitLineEdit->installEventFilter(this);
        ui->logSkipDuplicateCheckBox->installEventFilter(this);
        ui->logSyncCheckBox->installEventFilter(this);
        ui->logTypeGroupBox->installEventFilter(this);

        // Debug
        ui->debugDump->installEventFilter(this);
        ui->vkValidationCheckBox->installEventFilter(this);
        ui->vkSyncValidationCheckBox->installEventFilter(this);
        ui->vkCoreValidationCheckBox->installEventFilter(this);
        ui->vkGpuValidationCheckBox->installEventFilter(this);
        ui->rdocCheckBox->installEventFilter(this);
        ui->crashDiagnosticsCheckBox->installEventFilter(this);
        ui->guestMarkersCheckBox->installEventFilter(this);
        ui->hostMarkersCheckBox->installEventFilter(this);
        ui->collectShaderCheckBox->installEventFilter(this);
        ui->copyGPUBuffersCheckBox->installEventFilter(this);

        // Experimental
        ui->readbacksGroupBox->installEventFilter(this);
        ui->readbackLinearImagesCheckBox->installEventFilter(this);
        ui->dumpShadersCheckBox->installEventFilter(this);
        ui->dmaCheckBox->installEventFilter(this);
        ui->devkitCheckBox->installEventFilter(this);
        ui->neoCheckBox->installEventFilter(this);
        ui->networkConnectedCheckBox->installEventFilter(this);
        ui->shaderCaheCheckBox->installEventFilter(this);
        ui->shaderCacheArchiveCheckBox->installEventFilter(this);
        ui->shadnetCheckBox->installEventFilter(this);
        ui->dmemGroupBox->installEventFilter(this);
    }

    SDL_InitSubSystem(SDL_INIT_EVENTS);
    Polling = QtConcurrent::run(&SettingsDialog::PollSDLevents, this);
}

void SettingsDialog::closeEvent(QCloseEvent* event) {
    if (!is_game_saving) {
        ui->backgroundImageOpacitySlider->setValue(backgroundImageOpacitySlider_backup);
        emit BackgroundOpacityChanged(backgroundImageOpacitySlider_backup);
        ui->BGMVolumeSlider->setValue(bgm_volume_backup);
        BackgroundMusicPlayer::getInstance().setVolume(bgm_volume_backup);
        SyncRealTimeWidgetstoConfig();
    }

    SDL_Event quitLoop{};
    quitLoop.type = SDL_EVENT_QUIT;
    SDL_PushEvent(&quitLoop);
    Polling.waitForFinished();

    SDL_QuitSubSystem(SDL_INIT_EVENTS);
    SDL_QuitSubSystem(SDL_INIT_AUDIO);
    SDL_Quit();

    EmulatorSettings.Load();
    QDialog::closeEvent(event);
}

void SettingsDialog::LoadValuesFromConfig() {
    std::filesystem::path gs_config_file =
        Common::FS::GetUserPath(Common::FS::PathType::CustomConfigs) / (gs_serial);

    std::error_code error;
    bool is_newly_created = false;
    if (is_game_specific) {
        if (!std::filesystem::exists(gs_config_file, error)) {
            EmulatorSettings.Save(gs_serial);
            is_newly_created = true;
        }
    }

    const QVector<int> languageIndexes = {21, 23, 14, 6, 18, 1, 12, 22, 2, 4,  25, 24, 29, 5,  0, 9,
                                          15, 16, 17, 7, 26, 8, 11, 20, 3, 13, 27, 10, 19, 30, 28};

    // Entries with no game-specific settings
    if (!is_game_specific) {
        const auto home_path = EmulatorSettings.GetHomeDir();
        QString home_path_string;
        Common::FS::PathToQString(home_path_string, home_path);
        ui->homeFolderPath->setText(home_path_string);

        const auto dlc_folder_path = EmulatorSettings.GetAddonInstallDir();
        QString dlc_folder_path_string;
        Common::FS::PathToQString(dlc_folder_path_string, dlc_folder_path);
        ui->currentDLCFolder->setText(dlc_folder_path_string);

        const auto sysmodules_path = EmulatorSettings.GetSysModulesDir();
        QString sysmodules_path_string;
        Common::FS::PathToQString(sysmodules_path_string, sysmodules_path);
        ui->sysmodulesPath->setText(sysmodules_path_string);

        ui->emulatorLanguageComboBox->setCurrentIndex(
            languages[m_gui_settings->GetValue(gui::gen_guiLanguage).toString().toStdString()]);

        ui->playBGMCheckBox->setChecked(
            m_gui_settings->GetValue(gui::gl_playBackgroundMusic).toBool());

        ui->BGMVolumeSlider->setValue(
            m_gui_settings->GetValue(gui::gl_backgroundMusicVolume).toInt());
        ui->discordRPCCheckbox->setChecked(EmulatorSettings.IsDiscordRPCEnabled());

        ui->enableCompatibilityCheckBox->setChecked(
            m_gui_settings->GetValue(gui::glc_showCompatibility).toBool());
        ui->checkCompatibilityOnStartupCheckBox->setChecked(
            m_gui_settings->GetValue(gui::gen_checkCompatibilityAtStartup).toBool());

        ui->removeFolderButton->setEnabled(!ui->gameFoldersListWidget->selectedItems().isEmpty());
        ui->backgroundImageOpacitySlider->setValue(
            m_gui_settings->GetValue(gui::gl_backgroundImageOpacity).toInt());
        ui->showBackgroundImageCheckBox->setChecked(
            m_gui_settings->GetValue(gui::gl_showBackgroundImage).toBool());

        backgroundImageOpacitySlider_backup =
            m_gui_settings->GetValue(gui::gl_backgroundImageOpacity).toInt();
        bgm_volume_backup = m_gui_settings->GetValue(gui::gl_backgroundMusicVolume).toInt();

#ifdef ENABLE_UPDATER
        ui->updateCheckBox->setChecked(m_gui_settings->GetValue(gui::gen_checkForUpdates).toBool());
        ui->changelogCheckBox->setChecked(
            m_gui_settings->GetValue(gui::gen_showChangeLog).toBool());
#endif

        SyncRealTimeWidgetstoConfig();
    }

    // Entries with game-specific settings, *load these from toml file, not from Config::get*
    ui->consoleLanguageComboBox->setCurrentIndex(
        std::distance(languageIndexes.begin(),
                      std::find(languageIndexes.begin(), languageIndexes.end(),
                                EmulatorSettings.GetConsoleLanguage())) %
        languageIndexes.size());

    ui->readbacksModeComboBox->setCurrentIndex(EmulatorSettings.GetReadbacksMode());
    ui->readbackLinearImagesCheckBox->setChecked(EmulatorSettings.IsReadbackLinearImagesEnabled());
    ui->dmaCheckBox->setChecked(EmulatorSettings.IsDirectMemoryAccessEnabled());
    ui->neoCheckBox->setChecked(EmulatorSettings.IsNeo());
    ui->devkitCheckBox->setChecked(EmulatorSettings.IsDevKit());
    ui->networkConnectedCheckBox->setChecked(EmulatorSettings.IsConnectedToNetwork());
    ui->shaderCaheCheckBox->setChecked(EmulatorSettings.IsPipelineCacheEnabled());
    ui->shaderCacheArchiveCheckBox->setChecked(EmulatorSettings.IsPipelineCacheArchived());
    ui->shadnetCheckBox->setChecked(EmulatorSettings.IsShadNetEnabled());
    ui->serverLineEdit->setText(QString::fromStdString(EmulatorSettings.GetShadNetServer()));
    ui->servWebApiLineEdit->setText(
        QString::fromStdString(EmulatorSettings.GetShadnetWebapiServer()));
    ui->signalingInfoLineEdit->setText(QString::fromStdString(EmulatorSettings.GetSignalingInfo()));
    ui->upnpCheckBox->setChecked(EmulatorSettings.IsUPnPEnabled());
    ui->vblankSpinBox->setValue(EmulatorSettings.GetVblankFrequency());
    ui->dmemSpinBox->setValue(EmulatorSettings.GetExtraDmemInMBytes());

    // First options is auto selection -1, so gpuId on the GUI will always have to subtract 1
    // when setting and add 1 when getting to select the correct gpu in Qt
    ui->graphicsAdapterBox->setCurrentIndex(EmulatorSettings.GetGpuId() + 1);
    ui->widthSpinBox->setValue(EmulatorSettings.GetWindowWidth());
    ui->heightSpinBox->setValue(EmulatorSettings.GetWindowHeight());
    ui->dumpShadersCheckBox->setChecked(EmulatorSettings.IsDumpShaders());
    ui->nullGpuCheckBox->setChecked(EmulatorSettings.IsNullGPU());
    ui->enableHDRCheckBox->setChecked(EmulatorSettings.IsHdrAllowed());
    ui->FSRCheckBox->setChecked(EmulatorSettings.IsFsrEnabled());
    ui->RCASCheckBox->setChecked(EmulatorSettings.IsRcasEnabled());
    ui->RCASSlider->setValue(EmulatorSettings.GetRcasAttenuation());
    ui->RCASValue->setText(QString::number(ui->RCASSlider->value() / 1000.0, 'f', 3));

    ui->disableTrophycheckBox->setChecked(EmulatorSettings.IsTrophyPopupDisabled());
    ui->popUpDurationSpinBox->setValue(EmulatorSettings.GetTrophyNotificationDuration());
    ui->showSplashCheckBox->setChecked(EmulatorSettings.IsShowSplash());
    ui->hideCursorComboBox->setCurrentIndex(EmulatorSettings.GetCursorState());
    OnCursorStateChanged(EmulatorSettings.GetCursorState());
    ui->idleTimeoutSpinBox->setValue(EmulatorSettings.GetCursorHideTimeout());
    ui->motionControlsCheckBox->setChecked(EmulatorSettings.IsMotionControlsEnabled());
    ui->backgroundControllerCheckBox->setChecked(EmulatorSettings.IsBackgroundControllerInput());
    ui->usbComboBox->setCurrentIndex(EmulatorSettings.GetUsbDeviceBackend());
    ui->cameraComboBox->setCurrentIndex(EmulatorSettings.GetCameraId() + 1);

    std::string sideTrophy = EmulatorSettings.GetTrophyNotificationSide();
    QString side = QString::fromStdString(sideTrophy);
    ui->radioButton_Left->setChecked(side == "left");
    ui->radioButton_Right->setChecked(side == "right");
    ui->radioButton_Top->setChecked(side == "top");
    ui->radioButton_Bottom->setChecked(side == "bottom");

    ui->horizontalVolumeSlider->setValue(EmulatorSettings.GetVolumeSlider());
    ui->volumeText->setText(QString::number(ui->horizontalVolumeSlider->sliderPosition()) + "%");

    std::string fullScreenMode = EmulatorSettings.GetFullScreenMode();
    QString translatedText_FullscreenMode =
        screenModeMap.key(QString::fromStdString(fullScreenMode));
    ui->displayModeComboBox->setCurrentText(translatedText_FullscreenMode);

    std::string presentMode = EmulatorSettings.GetPresentMode();
    QString translatedText_PresentMode = presentModeMap.key(QString::fromStdString(presentMode));
    ui->presentModeComboBox->setCurrentText(translatedText_PresentMode);

    // Log
    ui->logAppendCheckBox->setChecked(EmulatorSettings.IsLogAppend());
    ui->logEnableCheckBox->setChecked(EmulatorSettings.IsLogEnable());
    ui->logFilterLineEdit->setText(QString::fromStdString(EmulatorSettings.GetLogFilter()));
    ui->logMaxSkipDurationLineEdit->setValue(EmulatorSettings.GetLogMaxSkipDuration());
    ui->logSeparateCheckBox->setChecked(EmulatorSettings.IsLogSeparate());
    ui->logSizeLimitLineEdit->setValue(EmulatorSettings.GetLogSizeLimit());
    ui->logSkipDuplicateCheckBox->setChecked(EmulatorSettings.IsLogSkipDuplicate());
    ui->logMaxSkipDurationGroupBox->setVisible(ui->logSkipDuplicateCheckBox->isChecked());
    ui->logSyncCheckBox->setChecked(EmulatorSettings.IsLogSync());
#ifdef _WIN32
    std::string logType = EmulatorSettings.GetLogType();
    QString translatedText_logType = logTypeMap.key(QString::fromStdString(logType));
    if (!translatedText_logType.isEmpty()) {
        ui->logTypeComboBox->setCurrentText(translatedText_logType);
    }
#else
    ui->logTypeGroupBox->setVisible(false);
#endif

    ui->debugDump->setChecked(EmulatorSettings.IsDebugDump());
    ui->vkValidationCheckBox->setChecked(EmulatorSettings.IsVkValidationEnabled());
    ui->vkSyncValidationCheckBox->setChecked(EmulatorSettings.IsVkValidationSyncEnabled());
    ui->vkCoreValidationCheckBox->setChecked(EmulatorSettings.IsVkValidationCoreEnabled());
    ui->vkGpuValidationCheckBox->setChecked(EmulatorSettings.IsVkValidationGpuEnabled());
    ui->vkValidationCheckBox->isChecked() ? ui->vkLayersGroupBox->setVisible(true)
                                          : ui->vkLayersGroupBox->setVisible(false);
    ui->shaderCaheCheckBox->isChecked() ? ui->shaderCacheArchiveCheckBox->setVisible(true)
                                        : ui->shaderCacheArchiveCheckBox->setVisible(false);

    ui->rdocCheckBox->setChecked(EmulatorSettings.IsRenderdocEnabled());
    ui->crashDiagnosticsCheckBox->setChecked(EmulatorSettings.IsVkCrashDiagnosticEnabled());
    ui->guestMarkersCheckBox->setChecked(EmulatorSettings.IsVkGuestMarkersEnabled());
    ui->hostMarkersCheckBox->setChecked(EmulatorSettings.IsVkHostMarkersEnabled());
    ui->copyGPUBuffersCheckBox->setChecked(EmulatorSettings.IsCopyGpuBuffers());
    ui->collectShaderCheckBox->setChecked(EmulatorSettings.IsShaderCollect());

    ui->audioBackendComboBox->setCurrentIndex(EmulatorSettings.GetAudioBackend());
    const QString backend = ui->audioBackendComboBox->currentText();

    if (backend == "SDL") {
        ui->GenAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetSDLMainOutputDevice()));
        ui->DsAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetSDLPadSpkOutputDevice()));
        ui->micComboBox->setCurrentText(QString::fromStdString(EmulatorSettings.GetSDLMicDevice()));
    } else if (backend == "OpenAL") {
        ui->GenAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALMainOutputDevice()));
        ui->DsAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALPadSpkOutputDevice()));
        ui->micComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALMicDevice()));
    }

    QString chooseHomeTab = m_gui_settings->GetValue(gui::gen_homeTab).toString();
    QString translatedText = chooseHomeTabMap.key(chooseHomeTab);
    if (translatedText.isEmpty()) {
        translatedText = tr("General");
    }
    ui->chooseHomeTabComboBox->setCurrentText(translatedText);

    QStringList tabNames = {tr("General"), tr("Frontend"), tr("Graphics"),
                            tr("User"),    tr("Input"),    tr("Paths"),
                            tr("Log"),     tr("Debug"),    tr("Experimental")};
    int indexTab = tabNames.indexOf(translatedText);
    if (indexTab == -1 || !ui->tabWidgetSettings->isTabVisible(indexTab) || is_newly_created)
        indexTab = 0;
    ui->tabWidgetSettings->setCurrentIndex(indexTab);
}

void SettingsDialog::InitializeEmulatorLanguages() {
    QDirIterator it(QStringLiteral(":/translations"), QDirIterator::NoIteratorFlags);

    QVector<QPair<QString, QString>> languagesList;

    while (it.hasNext()) {
        QString locale = it.next();
        locale.truncate(locale.lastIndexOf(QLatin1Char{'.'}));
        locale.remove(0, locale.lastIndexOf(QLatin1Char{'/'}) + 1);
        const QString lang = QLocale::languageToString(QLocale(locale).language());
        const QString country = QLocale::territoryToString(QLocale(locale).territory());

        QString displayName = QStringLiteral("%1 (%2)").arg(lang, country);
        languagesList.append(qMakePair(locale, displayName));
    }

    std::sort(languagesList.begin(), languagesList.end(),
              [](const QPair<QString, QString>& a, const QPair<QString, QString>& b) {
                  return a.second < b.second;
              });

    int idx = 0;
    for (const auto& pair : languagesList) {
        const QString& locale = pair.first;
        const QString& displayName = pair.second;

        ui->emulatorLanguageComboBox->addItem(displayName, locale);
        languages[locale.toStdString()] = idx;
        idx++;
    }

    connect(ui->emulatorLanguageComboBox, &QComboBox::currentIndexChanged, this,
            &SettingsDialog::OnLanguageChanged);
}

void SettingsDialog::OnLanguageChanged(int index) {
    if (index == -1)
        return;

    ui->retranslateUi(this);

    emit LanguageChanged(ui->emulatorLanguageComboBox->itemData(index).toString());
}

void SettingsDialog::OnCursorStateChanged(s16 index) {
    if (index == -1)
        return;
    if (index == HideCursorState::Idle) {
        ui->idleTimeoutGroupBox->show();
    } else {
        if (!ui->idleTimeoutGroupBox->isHidden()) {
            ui->idleTimeoutGroupBox->hide();
        }
    }
}

void SettingsDialog::VolumeSliderChange(int value) {
    ui->volumeText->setText(QString::number(ui->horizontalVolumeSlider->sliderPosition()) + "%");
}

int SettingsDialog::exec() {
    return QDialog::exec();
}

SettingsDialog::~SettingsDialog() {
    EmulatorSettings.Load();
}

void SettingsDialog::updateNoteTextEdit(const QString& elementName) {
    QString text;

    // clang-format off
    // General
    if (elementName == "consoleLanguageGroupBox") {
        text = tr("Console Language:\\nSets the language that the PS4 game uses.\\nIt's recommended to set this to a language the game supports, which will vary by region.");
    } else if (elementName == "emulatorLanguageGroupBox") {
        text = tr("Emulator Language:\\nSets the language of the emulator's user interface.");
    } else if (elementName == "showSplashCheckBox") {
        text = tr("Show Splash Screen:\\nShows the game's splash screen (a special image) while the game is starting.");
    } else if (elementName == "discordRPCCheckbox") {
        text = tr("Enable Discord Rich Presence:\\nDisplays the emulator icon and relevant information on your Discord profile.");
    #ifdef ENABLE_UPDATER
    } else if (elementName == "updaterGroupBox") {
        text = tr("GUI Updates:\\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\\n\\n*This update applies only to the Qt user interface. To update the emulator core, please use the 'Version Manager' menu.");
#endif
    } else if (elementName == "GUIBackgroundImageGroupBox") {
        text = tr("Background Image:\\nControl the opacity of the game background image.");
    } else if (elementName == "GUIMusicGroupBox") {
        text = tr("Play Title Music:\\nIf a game supports it, enable playing special music when selecting the game in the GUI.");
    } else if (elementName == "enableHDRCheckBox") {
        text = tr("Enable HDR:\\nEnables HDR in games that support it.\\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.");
    } else if (elementName == "disableTrophycheckBox") {
        text = tr("Disable Trophy Pop-ups:\\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).");
    } else if (elementName == "enableCompatibilityCheckBox") {
        text = tr("Display Compatibility Data:\\nDisplays game compatibility information in table view. Enable \"Update Compatibility On Startup\" to get up-to-date information.");
    } else if (elementName == "checkCompatibilityOnStartupCheckBox") {
        text = tr("Update Compatibility On Startup:\\nAutomatically update the compatibility database when shadPS4 starts.");
    } else if (elementName == "updateCompatibilityButton") {
        text = tr("Update Compatibility Database:\\nImmediately update the compatibility database.");
    }

    // Log
    if (elementName == "logAppendCheckBox") {
        text = tr("Log Append:\\nAppend to existing logs.");
    } else if (elementName == "logEnableCheckBox") {
        text = tr("Enable Logging:\\nEnables logging.\\nDo not change this if you do not know what you're doing!\\nWhen asking for help, make sure this setting is ENABLED.");
    } else if (elementName == "logFilter") {
        text = tr("Log Filter:\\nFilters the log to only print specific information.\\nExamples: \"Core:Debug\" \"Lib.Pad:Debug Common.Filesystem:Error\" \"*:Critical\"\\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.");
    } else if (elementName == "logMaxSkipDurationLineEdit") {
        text = tr("Log Max Skip Duration:\\nInterval without writing same lines (ms) - only if 'Log Skip Duplicate' enabled."); //TODO grey out if disabled
    } else if (elementName == "logOpenLocationButton") {
        text = tr("Open Log Location:\\nOpen the folder where the log file is saved.");
    } else if (elementName == "logSeparateCheckBox") {
        text = tr("Separate Log Files:\\nWrites a separate logfile for each game.");
    } else if (elementName == "logSizeLimitLineEdit") {
        text = tr("Log Size Limit:\\nMaximum size of log files (bytes).");
    } else if (elementName == "logSkipDuplicateCheckBox") {
        text = tr("Log Skip Duplicate:\\nSave storage by avoiding writing log that is identical.");
    } else if (elementName == "logSyncCheckBox") {
        text = tr("Log Sync:\\nSwitch between sync (order) or async (performance).");
    } else if (elementName == "logTypeGroupBox") {
        text = tr("Log Type:\\nChoose between wincolor or msvc log types.\\nwincolor: Default logging for Windows\\nmsvc: Logging for debugging");
    }

    //User
    if (elementName == "OpenCustomTrophyLocationButton") {
        text = tr("Open the custom trophy images/sounds folder:\\nYou can add custom images to the trophies and an audio.\\nAdd the files to custom_trophy with the following names:\\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\\nNote: The sound will only work in QT versions.");
    }

    // Input
    if (elementName == "hideCursorGroupBox") {
        text = tr("Hide Cursor:\\nChoose when the cursor will disappear:\\nNever: You will always see the mouse.\\nidle: Set a time for it to disappear after being idle.\\nAlways: you will never see the mouse.");
    } else if (elementName == "idleTimeoutGroupBox") {
        text = tr("Hide Idle Cursor Timeout:\\nThe duration (seconds) after which the cursor that has been idle hides itself.");
    } else if (elementName == "backgroundControllerCheckBox") {
        text = tr("Enable Controller Background Input:\\nAllow shadPS4 to detect controller inputs when the game window is not in focus.");
    }

    // Graphics
    if (elementName == "graphicsAdapterGroupBox") {
        text = tr("Graphics Device:\\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\\nor select \"Auto Select\" to automatically determine it.");
    } else if (elementName == "presentModeGroupBox") {
        text = tr("Present Mode:\\nConfigures how video output will be presented to your screen.\\n\\n"
                  "Mailbox: Frames synchronize with your screen's refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\\n"
                  "Fifo: Frames synchronize with your screen's refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\\n"
                  "Immediate: Frames immediately present to your screen when ready. May result in tearing.");
    } else if (elementName == "windowSizeGroupBox") {
        text = tr("Width/Height:\\nSets the size of the emulator window at launch, which can be resized during gameplay.\\nThis is different from the in-game resolution.");
    } else if (elementName == "heightDivider") {
        text = tr("Vblank Frequency:\\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!");
    } else if (elementName == "dumpShadersCheckBox") {
        text = tr("Enable Shaders Dumping:\\nFor the sake of technical debugging, saves the game's shaders to a folder as they render.");
    } else if (elementName == "nullGpuCheckBox") {
        text = tr("Enable Null GPU:\\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.");
    }

    // Path
    if (elementName == "gameFoldersGroupBox" || elementName == "gameFoldersListWidget") {
        text = tr("Game Folders:\\nThe list of folders to check for installed games.");
    } else if (elementName == "addFolderButton") {
        text = tr("Add:\\nAdd a folder to the list.");
    } else if (elementName == "removeFolderButton") {
        text = tr("Remove:\\nRemove a folder from the list.");
    } else if (elementName == "PortableUserFolderGroupBox") {
        text = tr("Portable user folder:\\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.");
    } else if (elementName == "sysmodulesGroupBox") {
        text = tr("PS4 Sysmodules Path:\\nThe folder where PS4 sysmodules are loaded from.");
    } else if (elementName == "browse_sysmodules") {
        text = tr("Browse:\\nBrowse for a folder to set as the sysmodules path.");
    }

    // DLC Folder
    if (elementName == "dlcFolderGroupBox" || elementName == "currentDLCFolder") {
        text = tr("DLC Path:\\nThe folder where game DLC is loaded from.");
    } else if (elementName == "folderButton") {
        text = tr("Browse:\\nBrowse for a folder to set as the DLC path.");
    }

    // Save Data
    if (elementName == "homeFolderGroupBox" || elementName == "homeFolderPath") {
        text = tr("Home Folder Location:\\nThe folder where save data, trophy files, and input configs are stored for all users.");
    } else if (elementName == "homeFolderButton") {
        text = tr("Browse:\\nBrowse for a folder to set as the home folder.");
    }

    // Debug
    if (elementName == "debugDump") {
        text = tr("Enable Debug Dumping:\\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.");
    } else if (elementName == "vkValidationCheckBox") {
        text = tr("Enable Vulkan Validation Layers:\\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\\nThis will reduce performance and likely change the behavior of emulation.\\nYou need the Vulkan SDK for this to work.");
    } else if (elementName == "vkSyncValidationCheckBox") {
        text = tr("Enable Sync Validation:\\nEnables a system that validates the timing of Vulkan rendering tasks.\\nThis will reduce performance and likely change the behavior of emulation.\\nYou need the Vulkan SDK for this to work.");
    } else if (elementName == "vkCoreValidationCheckBox") {
        text = tr("Enable Core Validation:\\nEnables the main API validation functions.\\nThis will reduce performance and likely change the behavior of emulation.\\nYou need the Vulkan SDK for this to work.");
    } else if (elementName == "vkGpuValidationCheckBox") {
        text = tr("Enable GPU-Assisted Validation:\\nInstruments shaders with code that validates if they are behaving correctly.\\nThis will reduce performance and likely change the behavior of emulation.\\nYou need the Vulkan SDK for this to work.");
    } else if (elementName == "rdocCheckBox") {
        text = tr("Enable RenderDoc Debugging:\\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.");
    } else if (elementName == "crashDiagnosticsCheckBox") {
        text = tr("Crash Diagnostics:\\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\\nUseful for debugging 'Device lost' errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.");
    } else if (elementName == "guestMarkersCheckBox") {
        text = tr("Guest Debug Markers:\\nInserts any debug markers the game itself has added to the command buffer.\\nIf you have this enabled, you should enable Crash Diagnostics.\\nUseful for programs like RenderDoc.");
    } else if (elementName == "hostMarkersCheckBox") {
        text = tr("Host Debug Markers:\\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\\nIf you have this enabled, you should enable Crash Diagnostics.\\nUseful for programs like RenderDoc.");
    } else if (elementName == "copyGPUBuffersCheckBox") {
        text = tr("Copy GPU Buffers:\\nGets around race conditions involving GPU submits.\\nMay or may not help with PM4 type 0 crashes.");
    } else if (elementName == "collectShaderCheckBox") {
        text = tr("Collect Shaders:\\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).");
    } else if (elementName == "micComboBox") {
        text = tr("Microphone:\\nNone: Does not use the microphone.\\nDefault Device: Will use the default device defined in the system.\\nOr manually choose the microphone to be used from the list.");
    } else if (elementName == "volumeSliderElement") {
        text = tr("Volume:\\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.");
    } else if (elementName == "chooseHomeTabGroupBox") {
        text = tr("Default tab when opening settings:\\nChoose which tab will open, the default is General.");
    } else if (elementName == "motionControlsCheckBox") {
        text = tr("Enable Motion Controls:\\nWhen enabled it will use the controller's motion control if supported.");
    } else if (elementName == "usbComboBox") {
        text = tr("USB Device:\\nReal USB Device: Use a real USB Device attached to the system.\\nSkylander Portal: Emulate a Skylander Portal of Power.\\nInfinity Base: Emulate a Disney Infinity Base.\\nDimensions Toypad: Emulate a Lego Dimensions Toypad.");
    }

    // Experimental
    if (elementName == "dmaCheckBox") {
        text = tr("Enable Direct Memory Access:\\nEnables arbitrary memory access from the GPU to CPU memory.");
    } else if (elementName == "neoCheckBox") {
        text = tr("Enable PS4 Neo Mode:\\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.");
    } else if (elementName == "devkitCheckBox") {
        text = tr("Enable Devkit Console Mode:\\nAdds support for Devkit console memory size.");
    } else if (elementName == "networkConnectedCheckBox") {
        text = tr("Set Network Connected to True:\\nForces games to detect an active network connection. Actual online capabilities are not yet supported.");
    } else if (elementName == "shaderCaheCheckBox") {
        text = tr("Enable Shader Cache:\\nStoring compiled shaders to avoid recompilations, reduce stuttering.");
    } else if (elementName == "shaderCacheArchiveCheckBox") {
        text = tr("Compress the Shader Cache files into a zip file:\\nThe shader cache files are stored within a single zip file instead of multiple separate files.");
    } else if (elementName == "shadnetCheckBox") {
        text = tr("shadNet:\\nCompatibility is very limited at the moment.\\nYou can register at https://www.shadps4.net/shadnet/register/.");
    } else if (elementName == "readbacksGroupBox") {
        text = tr("Readbacks:\\nEnable GPU memory readbacks and writebacks.\\nThis is required for proper behavior in some games.\\nMight cause stability and/or performance issues.");
    } else if (elementName == "readbackLinearImagesCheckBox") {
        text = tr("Enable Readback Linear Images:\\nEnables async downloading of GPU modified linear images.\\nMight fix issues in some games.");
    } else if (elementName == "dmemGroupBox") {
        text = tr("Additional DMem Allocation:\\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.");
    }

    // clang-format on
    ui->descriptionText->setText(text.replace("\\n", "\n"));
}

bool SettingsDialog::eventFilter(QObject* obj, QEvent* event) {
    if (event->type() == QEvent::Enter || event->type() == QEvent::Leave) {
        if (qobject_cast<QWidget*>(obj)) {
            bool hovered = (event->type() == QEvent::Enter);
            QString elementName = obj->objectName();
            if (hovered) {
                updateNoteTextEdit(elementName);
            } else {
                ui->descriptionText->setText(defaultTextEdit);
            }
            return true;
        }
    }
    return QDialog::eventFilter(obj, event);
}

void SettingsDialog::UpdateSettings(bool is_specific) {
    EmulatorSettings.SetReadbacksMode(ui->readbacksModeComboBox->currentIndex(), is_specific);
    EmulatorSettings.SetReadbackLinearImagesEnabled(ui->readbackLinearImagesCheckBox->isChecked(),
                                                    is_specific);
    EmulatorSettings.SetDirectMemoryAccessEnabled(ui->dmaCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetDevKit(ui->devkitCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetNeo(ui->neoCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetConnectedToNetwork(ui->networkConnectedCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetPipelineCacheEnabled(ui->shaderCaheCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetPipelineCacheArchived(ui->shaderCacheArchiveCheckBox->isChecked(),
                                              is_specific);
    EmulatorSettings.SetShadNetEnabled(ui->shadnetCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetShadNetServer(ui->serverLineEdit->text().toStdString(), is_specific);
    EmulatorSettings.SetSignalingInfo(ui->signalingInfoLineEdit->text().toStdString(), is_specific);
    EmulatorSettings.SetShadnetWebapiServer(ui->servWebApiLineEdit->text().toStdString(),
                                            is_specific);
    EmulatorSettings.SetUPnPEnabled(ui->upnpCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetVblankFrequency(ui->vblankSpinBox->value(), is_specific);
    EmulatorSettings.SetExtraDmemInMBytes(ui->dmemSpinBox->value(), is_specific);

    EmulatorSettings.SetFullScreen(
        screenModeMap.value(ui->displayModeComboBox->currentText()) != "Windowed", is_specific);
    EmulatorSettings.SetFullScreenMode(
        screenModeMap.value(ui->displayModeComboBox->currentText()).toStdString(), is_specific);
    EmulatorSettings.SetPresentMode(
        presentModeMap.value(ui->presentModeComboBox->currentText()).toStdString(), is_specific);
    EmulatorSettings.SetMotionControlsEnabled(ui->motionControlsCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetBackgroundControllerInput(ui->backgroundControllerCheckBox->isChecked(),
                                                  is_specific);
    EmulatorSettings.SetTrophyPopupDisabled(ui->disableTrophycheckBox->isChecked(), is_specific);
    EmulatorSettings.SetTrophyNotificationDuration(ui->popUpDurationSpinBox->value(), is_specific);

    if (ui->radioButton_Top->isChecked()) {
        EmulatorSettings.SetTrophyNotificationSide("top", is_specific);
    } else if (ui->radioButton_Left->isChecked()) {
        EmulatorSettings.SetTrophyNotificationSide("left", is_specific);
    } else if (ui->radioButton_Right->isChecked()) {
        EmulatorSettings.SetTrophyNotificationSide("right", is_specific);
    } else if (ui->radioButton_Bottom->isChecked()) {
        EmulatorSettings.SetTrophyNotificationSide("bottom", is_specific);
    }

    // Log
    EmulatorSettings.SetLogAppend(ui->logAppendCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetLogEnable(ui->logEnableCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetLogFilter(ui->logFilterLineEdit->text().toStdString(), is_specific);
    EmulatorSettings.SetLogMaxSkipDuration(ui->logMaxSkipDurationLineEdit->value(), is_specific);
    EmulatorSettings.SetLogSeparate(ui->logSeparateCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetLogSizeLimit(ui->logSizeLimitLineEdit->value(), is_specific);
    EmulatorSettings.SetLogSkipDuplicate(ui->logSkipDuplicateCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetLogSync(ui->logSyncCheckBox->isChecked(), is_specific);
#ifdef _WIN32
    EmulatorSettings.SetLogType(logTypeMap.value(ui->logTypeComboBox->currentText()).toStdString(),
                                is_specific);
#endif

    EmulatorSettings.SetHdrAllowed(ui->enableHDRCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetCursorState(ui->hideCursorComboBox->currentIndex(), is_specific);
    EmulatorSettings.SetCursorHideTimeout(ui->idleTimeoutSpinBox->value(), is_specific);
    EmulatorSettings.SetGpuId(ui->graphicsAdapterBox->currentIndex() - 1, is_specific);
    EmulatorSettings.SetUsbDeviceBackend(ui->usbComboBox->currentIndex(), is_specific);
    EmulatorSettings.SetCameraId(ui->cameraComboBox->currentIndex() - 1, is_specific);
    EmulatorSettings.SetVolumeSlider(ui->horizontalVolumeSlider->value(), is_specific);
    EmulatorSettings.SetConsoleLanguage(
        languageIndexes[ui->consoleLanguageComboBox->currentIndex()], is_specific);
    EmulatorSettings.SetWindowWidth(ui->widthSpinBox->value(), is_specific);
    EmulatorSettings.SetWindowHeight(ui->heightSpinBox->value(), is_specific);
    EmulatorSettings.SetDumpShaders(ui->dumpShadersCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetNullGPU(ui->nullGpuCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetFsrEnabled(ui->FSRCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetRcasEnabled(ui->RCASCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetRcasAttenuation(ui->RCASSlider->value(), is_specific);
    EmulatorSettings.SetShowSplash(ui->showSplashCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetDebugDump(ui->debugDump->isChecked(), is_specific);
    EmulatorSettings.SetVkValidationEnabled(ui->vkValidationCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetVkValidationSyncEnabled(ui->vkSyncValidationCheckBox->isChecked(),
                                                is_specific);
    EmulatorSettings.SetVkValidationCoreEnabled(ui->vkCoreValidationCheckBox->isChecked(),
                                                is_specific);
    EmulatorSettings.SetVkValidationGpuEnabled(ui->vkGpuValidationCheckBox->isChecked(),
                                               is_specific);
    EmulatorSettings.SetRenderdocEnabled(ui->rdocCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetVkHostMarkersEnabled(ui->hostMarkersCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetVkGuestMarkersEnabled(ui->guestMarkersCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetVkCrashDiagnosticEnabled(ui->crashDiagnosticsCheckBox->isChecked(),
                                                 is_specific);
    EmulatorSettings.SetShaderCollect(ui->collectShaderCheckBox->isChecked(), is_specific);
    EmulatorSettings.SetCopyGpuBuffers(ui->copyGPUBuffersCheckBox->isChecked(), is_specific);

    const std::string backend = ui->audioBackendComboBox->currentText().toStdString();
    EmulatorSettings.SetAudioBackend(ui->audioBackendComboBox->currentIndex(), is_specific);
    if (backend == "SDL") {
        EmulatorSettings.SetSDLMainOutputDevice(
            ui->GenAudioComboBox->currentData().toString().toStdString(), is_specific);
        EmulatorSettings.SetSDLPadSpkOutputDevice(
            ui->DsAudioComboBox->currentData().toString().toStdString(), is_specific);
        EmulatorSettings.SetSDLMicDevice(ui->micComboBox->currentData().toString().toStdString(),
                                         is_specific);
    } else if (backend == "OpenAL") {
        EmulatorSettings.SetOpenALMainOutputDevice(
            ui->GenAudioComboBox->currentData().toString().toStdString(), is_specific);
        EmulatorSettings.SetOpenALPadSpkOutputDevice(
            ui->DsAudioComboBox->currentData().toString().toStdString(), is_specific);
        EmulatorSettings.SetOpenALMicDevice(ui->micComboBox->currentData().toString().toStdString(),
                                            is_specific);
    }

    // Entries with no game-specific settings
    if (!is_game_specific) {
        std::vector<GameInstallDir> dirs_with_states;
        for (int i = 0; i < ui->gameFoldersListWidget->count(); i++) {
            QListWidgetItem* item = ui->gameFoldersListWidget->item(i);
            QString path_string = item->text();
            auto path = Common::FS::PathFromQString(path_string);
            bool enabled = (item->checkState() == Qt::Checked);

            dirs_with_states.push_back({path, enabled});
        }
        EmulatorSettings.SetAllGameInstallDirs(dirs_with_states);

        BackgroundMusicPlayer::getInstance().setVolume(ui->BGMVolumeSlider->value());

        EmulatorSettings.SetDiscordRPCEnabled(ui->discordRPCCheckbox->isChecked());
        m_gui_settings->SetValue(gui::glc_showCompatibility,
                                 ui->enableCompatibilityCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gen_checkCompatibilityAtStartup,
                                 ui->checkCompatibilityOnStartupCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gl_playBackgroundMusic, ui->playBGMCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gl_backgroundMusicVolume, ui->BGMVolumeSlider->value());
        m_gui_settings->SetValue(gui::gen_checkForUpdates, ui->updateCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gen_showChangeLog, ui->changelogCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gl_showBackgroundImage,
                                 ui->showBackgroundImageCheckBox->isChecked());
        m_gui_settings->SetValue(gui::gl_backgroundImageOpacity,
                                 std::clamp(ui->backgroundImageOpacitySlider->value(), 0, 100));
        emit BackgroundOpacityChanged(ui->backgroundImageOpacitySlider->value());
        m_gui_settings->SetValue(gui::gen_homeTab,
                                 chooseHomeTabMap.value(ui->chooseHomeTabComboBox->currentText()));
    }
}

void SettingsDialog::SyncRealTimeWidgetstoConfig() {
    std::filesystem::path userdir = Common::FS::GetUserPath(Common::FS::PathType::UserDir);

    if (!is_game_specific) {
        ui->gameFoldersListWidget->clear();
        std::vector<GameInstallDir> install_dir_array = EmulatorSettings.GetAllGameInstallDirs();
        std::vector<bool> install_dirs_enabled = EmulatorSettings.GetGameInstallDirsEnabled();

        if (install_dirs_enabled.size() < install_dir_array.size()) {
            install_dirs_enabled.resize(install_dir_array.size(), true);
        }

        std::vector<GameInstallDir> settings_install_dirs_config;
        for (size_t i = 0; i < install_dir_array.size(); i++) {
            GameInstallDir dir = install_dir_array[i];
            bool enabled = install_dirs_enabled[i];

            settings_install_dirs_config.push_back(dir);

            QString path_string;
            Common::FS::PathToQString(path_string, dir.path);

            QListWidgetItem* item = new QListWidgetItem(path_string);
            item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
            item->setCheckState(enabled ? Qt::Checked : Qt::Unchecked);
            ui->gameFoldersListWidget->addItem(item);
        }

        EmulatorSettings.SetAllGameInstallDirs(settings_install_dirs_config);
    }

    ui->horizontalVolumeSlider->setValue(EmulatorSettings.GetVolumeSlider());

    if (EmulatorState::GetInstance()->IsGameRunning()) {
        m_ipc_client->setFsr(EmulatorSettings.IsFsrEnabled());
        m_ipc_client->setRcas(EmulatorSettings.IsRcasEnabled());
        m_ipc_client->setRcasAttenuation(EmulatorSettings.GetRcasAttenuation());
    }
}

void SettingsDialog::SetDefaultValues() {
    if (!is_game_specific) {
        m_gui_settings->SetValue(gui::gl_showBackgroundImage, true);
        m_gui_settings->SetValue(gui::gl_backgroundImageOpacity, 50);
        m_gui_settings->SetValue(gui::gl_playBackgroundMusic, false);
        m_gui_settings->SetValue(gui::gl_backgroundMusicVolume, 50);
        m_gui_settings->SetValue(gui::gen_checkForUpdates, false);
        m_gui_settings->SetValue(gui::gen_showChangeLog, false);
        m_gui_settings->SetValue(gui::gen_guiLanguage, "en_US");
        m_gui_settings->SetValue(gui::glc_showLoadGameSizeEnabled, true);
        m_gui_settings->SetValue(gui::glc_showCompatibility, false);
        m_gui_settings->SetValue(gui::gen_checkCompatibilityAtStartup, false);
        m_gui_settings->SetValue(gui::gen_homeTab, "General");
    }
}

void SettingsDialog::SaveSettings() {
    if (is_game_specific) {
        EmulatorSettings.Save(gs_serial);
    } else {
        EmulatorSettings.Save();
    }
};

void SettingsDialog::PollSDLevents() {
    SDL_Event event;
    while (SdlEventWrapper::Wrapper::wrapperActive) {

        if (!SDL_WaitEvent(&event)) {
            return;
        }

        if (event.type == SDL_EVENT_QUIT) {
            return;
        }

        if (event.type == SDL_EVENT_AUDIO_DEVICE_ADDED ||
            event.type == SDL_EVENT_AUDIO_DEVICE_REMOVED) {
            RefreshAudioDevices();
        }
    }
}

void SettingsDialog::RefreshAudioDevices() {
    // prevent device list from refreshing too fast
    QThread::msleep(100);

    ui->GenAudioComboBox->clear();
    ui->DsAudioComboBox->clear();
    ui->micComboBox->clear();

    const QString backend = ui->audioBackendComboBox->currentText();
    int deviceCount;
    QStringList playbackDeviceList;
    QStringList recordingDeviceList;

    ui->micComboBox->addItem(micMap.key("None"), "None");
    ui->micComboBox->addItem(micMap.key("Default Device"), "Default Device");
    ui->GenAudioComboBox->addItem(tr("Default Device"), "Default Device");
    ui->DsAudioComboBox->addItem(tr("Default Device"), "Default Device");

    if (backend == "SDL") {
        // Playback
        SDL_AudioDeviceID* playbackDevices = SDL_GetAudioPlaybackDevices(&deviceCount);

        if (!playbackDevices) {
            LOG_ERROR(Core_Devices, "Unable to retrieve audio device list {}", SDL_GetError());
            return;
        }

        for (int i = 0; i < deviceCount; ++i) {
            const char* name = SDL_GetAudioDeviceName(playbackDevices[i]);
            std::string name_string = std::string(name);
            playbackDeviceList.append(QString::fromStdString(name_string));
        }

        SDL_free(playbackDevices);

        // Mics
        int count = 0;
        SDL_AudioDeviceID* recordingDevices = SDL_GetAudioRecordingDevices(&count);
        if (recordingDevices) {
            for (int i = 0; i < count; ++i) {
                SDL_AudioDeviceID devId = recordingDevices[i];
                const char* name = SDL_GetAudioDeviceName(devId);
                if (name) {
                    QString qname = QString::fromUtf8(name);
                    ui->micComboBox->addItem(qname, QString::number(devId));
                }
            }
            SDL_free(recordingDevices);
        } else {
            qDebug() << "Error SDL_GetAudioRecordingDevices:" << SDL_GetError();
        }
    } else if (backend == "OpenAL") {
        // Playback
        const ALCchar* playbackdevices = alcGetString(NULL, ALC_ALL_DEVICES_SPECIFIER);
        if (playbackdevices) {
            while (*playbackdevices != '\0') {
                playbackDeviceList.append(QString::fromUtf8(playbackdevices));
                playbackdevices += strlen(playbackdevices) + 1;
            }
        }

        // Mics
        if (alcIsExtensionPresent(NULL, "ALC_ENUMERATION_EXT") == AL_TRUE) {
            const ALCchar* recordingDevices = alcGetString(NULL, ALC_CAPTURE_DEVICE_SPECIFIER);

            if (recordingDevices) {
                while (*recordingDevices != '\0') {
                    recordingDeviceList.append(QString::fromUtf8(recordingDevices));
                    recordingDevices += strlen(recordingDevices) + 1;
                }
            }
        }
    }

    for (const QString& name : playbackDeviceList) {
        ui->DsAudioComboBox->addItem(name, name);
        ui->GenAudioComboBox->addItem(name, name);
    }
    for (const QString& name : recordingDeviceList) {
        ui->micComboBox->addItem(name, name);
    }

    if (backend == "SDL") {
        ui->GenAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetSDLMainOutputDevice()));
        ui->DsAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetSDLPadSpkOutputDevice()));
        ui->micComboBox->setCurrentText(QString::fromStdString(EmulatorSettings.GetSDLMicDevice()));
    } else if (backend == "OpenAL") {
        ui->GenAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALMainOutputDevice()));
        ui->DsAudioComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALPadSpkOutputDevice()));
        ui->micComboBox->setCurrentText(
            QString::fromStdString(EmulatorSettings.GetOpenALMicDevice()));
    }
}

void SettingsDialog::GetPhysicalDevices() {
#ifndef __APPLE__
    if (volkInitialize() != VK_SUCCESS) {
        qWarning() << "Failed to initialize Volk.";
        return;
    }

    // Create Vulkan instance
    VkApplicationInfo appInfo{};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "shadPS4QtLauncher";
    appInfo.applicationVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.pEngineName = "No Engine";
    appInfo.engineVersion = VK_MAKE_VERSION(1, 0, 0);
    appInfo.apiVersion = VK_API_VERSION_1_3;

    VkInstanceCreateInfo instInfo{};
    instInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    instInfo.pApplicationInfo = &appInfo;

    VkInstance instance;
    if (vkCreateInstance(&instInfo, nullptr, &instance) != VK_SUCCESS) {
        qWarning() << "Failed to create Vulkan instance.";
        return;
    }

    // Load instance-based function pointers
    volkLoadInstance(instance);

    // Enumerate devices
    uint32_t deviceCount = 0;
    vkEnumeratePhysicalDevices(instance, &deviceCount, nullptr);
    if (deviceCount == 0) {
        qWarning() << "No Vulkan physical devices found.";
        return;
    }

    std::vector<VkPhysicalDevice> devices(deviceCount);
    vkEnumeratePhysicalDevices(instance, &deviceCount, devices.data());

    m_physical_devices.clear();
    for (uint32_t i = 0; i < deviceCount; ++i) {
        VkPhysicalDeviceProperties props;
        vkGetPhysicalDeviceProperties(devices[i], &props);
        QString name = QString::fromUtf8(props.deviceName, -1);
        m_physical_devices.push_back(name);
    }

    vkDestroyInstance(instance, nullptr);
#else
    // Apple devices have a single GPU, query its name.
    std::string gpuName = GetAppleGpuName();
    m_physical_devices.push_back(QString::fromStdString(gpuName));
#endif
}
