// SPDX-FileCopyrightText: Copyright 2026 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include <QDir>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFileDialog>
#include <QInputDialog>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageBox>
#include <QMimeData>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QProcess>
#include <QProgressBar>
#include <QRegularExpression>
#include <QTextBrowser>
#include <QTextStream>
#include <QTimer>
#include <QVBoxLayout>
#include <common/path_util.h>
#include <common/versions.h>

#include "gui_settings.h"
#include "qt_gui/main_window.h"
#include "ui_version_dialog.h"
#include "version_dialog.h"

VersionDialog::VersionDialog(std::shared_ptr<gui_settings> gui_settings, QWidget* parent)
    : QDialog(parent), ui(new Ui::VersionDialog), m_gui_settings(std::move(gui_settings)) {
    ui->setupUi(this);
    this->setMinimumSize(670, 350);
    setAcceptDrops(true);

    ui->checkOnStartupCheckBox->setChecked(
        m_gui_settings->GetValue(gui::vm_checkOnStartup).toBool());
    ui->showChangelogCheckBox->setChecked(m_gui_settings->GetValue(gui::vm_showChangeLog).toBool());

    connect(ui->checkOnStartupCheckBox, &QCheckBox::toggled, this,
            [this](bool checked) { m_gui_settings->SetValue(gui::vm_checkOnStartup, checked); });
    connect(ui->showChangelogCheckBox, &QCheckBox::toggled, this,
            [this](bool checked) { m_gui_settings->SetValue(gui::vm_showChangeLog, checked); });

    connect(this, &VersionDialog::WindowResized, this, &VersionDialog::HandleResize);

    networkManager = new QNetworkAccessManager(this);

    if (m_gui_settings->GetValue(gui::vm_versionPath).toString() == "") {
        QString versionDir = QString::fromStdString(
            Common::FS::GetUserPath(Common::FS::PathType::VersionDir).string());
        QDir dir(versionDir);
        if (!dir.exists()) {
            dir.mkpath(".");
        }
        m_gui_settings->SetValue(gui::vm_versionPath, versionDir);
    }

    ui->currentVersionPath->setText(m_gui_settings->GetValue(gui::vm_versionPath).toString());

    LoadInstalledList();

    QStringList cachedVersions = LoadDownloadCache();
    if (!cachedVersions.isEmpty()) {
        PopulateDownloadTree(cachedVersions);
    } else {
        DownloadListVersion();
    }

    connect(ui->browse_versionPath, &QPushButton::clicked, this, [this]() {
        const auto shad_exe_path = m_gui_settings->GetValue(gui::vm_versionPath).toString();
        QString initial_path = shad_exe_path;

        QString shad_folder_path_string = QFileDialog::getExistingDirectory(
            this, tr("Select the folder where the emulator versions will be installed"),
            initial_path);

        auto folder_path = Common::FS::PathFromQString(shad_folder_path_string);
        if (!folder_path.empty()) {
            ui->currentVersionPath->setText(shad_folder_path_string);
            m_gui_settings->SetValue(gui::vm_versionPath, shad_folder_path_string);
            m_gui_settings->SetValue(gui::vm_versionSelected, "");
            LoadInstalledList();
        }
    });

    connect(ui->checkChangesVersionButton, &QPushButton::clicked, this,
            [this]() { LoadInstalledList(); });

    connect(ui->addCustomVersionButton, &QPushButton::clicked, this, [this]() {
        QString exePath;

#ifdef Q_OS_WIN
        exePath = QFileDialog::getOpenFileName(this, tr("Select executable"), QDir::rootPath(),
                                               tr("Executable (*.exe)"));
#elif defined(Q_OS_LINUX) || defined(Q_OS_MACOS)
        exePath = QFileDialog::getOpenFileName(this, tr("Select executable"), QDir::rootPath(),
                                               "Executable (*)");
#endif

        AddCustomExecutable(exePath);
    });

    connect(ui->deleteVersionButton, &QPushButton::clicked, this, [this]() {
        QTreeWidgetItem* selectedItem = ui->installedTreeWidget->currentItem();
        if (!selectedItem) {
            QMessageBox::warning(
                this, tr("Error"),
                tr("No version selected. Please choose one from the list to delete."));
            return;
        }

        QString versionName = selectedItem->text(1);
        QString fullPath = selectedItem->text(4);

        if (fullPath.isEmpty()) {
            QMessageBox::critical(this, tr("Error"), tr("Failed to determine the folder path."));
            return;
        }
        auto reply = QMessageBox::question(this, tr("Delete version"),
                                           tr("Do you want to delete the version") +
                                               QString(" \"%1\" ?").arg(versionName),
                                           QMessageBox::Yes | QMessageBox::No);
        if (reply == QMessageBox::No)
            return;

        // Check if it is of type Local (type == 2)
        auto versions = VersionManager::GetVersionList({});
        int versionType = 2;
        for (const auto& v : versions) {
            if (v.name == versionName.toStdString()) {
                versionType = static_cast<int>(v.type);
                break;
            }
        }

        if (versionType == 2) {
            VersionManager::RemoveVersion(versionName.toStdString());
            LoadInstalledList();
            return;
        }

        QFileInfo info(fullPath);
        QString folderPath;
        if (info.exists() && info.isDir()) {
            folderPath = info.absoluteFilePath();
        } else {
            folderPath = info.absolutePath();
        }

        if (folderPath.isEmpty()) {
            QMessageBox::critical(this, tr("Error"),
                                  tr("Failed to determine the folder to remove.") +
                                      QString("\n \"%1\"").arg(fullPath));
            return;
        }

        QDir dirToRemove(folderPath);
        if (dirToRemove.exists()) {
            if (!dirToRemove.removeRecursively()) {
                QMessageBox::critical(this, tr("Error"),
                                      tr("Failed to delete folder.") +
                                          QString("\n \"%1\"").arg(folderPath));
                return;
            }
        }

        VersionManager::RemoveVersion(versionName.toStdString());
        LoadInstalledList();
    });

    connect(ui->checkVersionDownloadButton, &QPushButton::clicked, this,
            [this]() { DownloadListVersion(); });

    connect(ui->installedTreeWidget, &QTreeWidget::itemChanged, this,
            &VersionDialog::onItemChanged);

    connect(ui->updatePreButton, &QPushButton::clicked, this, [this]() { checkUpdatePre(true); });
};

VersionDialog::~VersionDialog() {
    delete ui;
}

void VersionDialog::addExecutableFromDrop(const QString& exePath) {
    m_pendingExecutablePath = exePath;
}

void VersionDialog::showEvent(QShowEvent* event) {
    QDialog::showEvent(event);
    if (!m_pendingExecutablePath.isEmpty()) {
        QString path = m_pendingExecutablePath;
        m_pendingExecutablePath.clear();
        // Defer one event-loop tick so the dialog is fully painted before the prompt appears
        QTimer::singleShot(0, this, [this, path]() { AddCustomExecutable(path); });
    }
}

void VersionDialog::resizeEvent(QResizeEvent* event) {
    emit WindowResized(event);
    QDialog::resizeEvent(event);
}

void VersionDialog::HandleResize(QResizeEvent* event) {
    this->ui->versionTab->resize(this->size());
}

void VersionDialog::onItemChanged(QTreeWidgetItem* item, int column) {
    if (column == 0) {
        if (item->checkState(0) == Qt::Checked) {
            for (int row = 0; row < ui->installedTreeWidget->topLevelItemCount(); ++row) {
                QTreeWidgetItem* topItem = ui->installedTreeWidget->topLevelItem(row);
                if (topItem != item) {
                    topItem->setCheckState(0, Qt::Unchecked);
                    topItem->setSelected(false);
                }
            }
            QString fullPath = item->text(4);
            m_gui_settings->SetValue(gui::vm_versionSelected, fullPath);

            item->setSelected(true);
        } else {
            item->setSelected(false);
        }
    }
}
void VersionDialog::dragEnterEvent(QDragEnterEvent* event) {
    if (event->mimeData()->hasUrls()) {

        const auto urls = event->mimeData()->urls();

        if (!urls.isEmpty()) {

            QString filePath = urls.first().toLocalFile();

#ifdef Q_OS_WIN
            if (filePath.endsWith(".exe", Qt::CaseInsensitive)) {
                event->acceptProposedAction();
            }
#else
            QFileInfo info(filePath);

            if (info.isExecutable()) {
                event->acceptProposedAction();
            }
#endif
        }
    }
}

void VersionDialog::dropEvent(QDropEvent* event) {
    const auto urls = event->mimeData()->urls();

    if (urls.isEmpty())
        return;

    QString exePath = urls.first().toLocalFile();
    AddCustomExecutable(exePath);
    event->acceptProposedAction();
}

void VersionDialog::AddCustomExecutable(const QString& exePath) {
    if (exePath.isEmpty())
        return;

    bool ok;
    QString version_name = QInputDialog::getText(
        this, tr("Version name"), tr("Enter the name of this version as it appears in the list."),
        QLineEdit::Normal, "", &ok);

    if (!ok || version_name.trimmed().isEmpty())
        return;

    version_name = version_name.trimmed();

    auto version_list = VersionManager::GetVersionList();

    if (std::find_if(version_list.cbegin(), version_list.cend(), [version_name](auto i) {
            return i.name == version_name.toStdString();
        }) != version_list.cend()) {

        QMessageBox::warning(this, tr("Error"), tr("A version with that name already exists."));
        return;
    }

    VersionManager::Version new_version = {
        .name = version_name.toStdString(),
        .path = exePath.toStdString(),
        .date = QDateTime::currentDateTime().toString("yyyy-MM-dd").toStdString(),
        .codename = tr("Local").toStdString(),
        .type = VersionManager::VersionType::Custom,
    };

    VersionManager::AddNewVersion(new_version);
    m_gui_settings->SetValue(gui::vm_versionSelected, QString::fromStdString(new_version.path));
    QMessageBox::information(this, tr("Success"), tr("Version added successfully."));
    LoadInstalledList();
}

void VersionDialog::DownloadListVersion() {
    QNetworkAccessManager* manager = new QNetworkAccessManager(this);
    QUrl url("https://api.github.com/repos/shadps4-emu/shadPS4/tags");
    QNetworkRequest request(url);
    QNetworkReply* reply = manager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        if (reply->error() == QNetworkReply::NoError) {
            QByteArray response = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(response);
            if (doc.isArray()) {
                QJsonArray tags = doc.array();
                ui->downloadTreeWidget->clear();

                QTreeWidgetItem* preReleaseItem = nullptr;
                QList<QTreeWidgetItem*> otherItems;
                bool foundPreRelease = false;

                //  > v.0.16.0
                auto isVersionGreaterThan_0_16_0 = [](const QString& tagName) -> bool {
                    QRegularExpression versionRegex(R"(v\.?(\d+)\.(\d+)\.(\d+))");
                    QRegularExpressionMatch match = versionRegex.match(tagName);
                    if (match.hasMatch()) {
                        int major = match.captured(1).toInt();
                        int minor = match.captured(2).toInt();
                        int patch = match.captured(3).toInt();

                        if (major > 0)
                            return true;
                        if (major == 0 && minor >= 16)
                            return true;
                        if (major == 0 && minor == 16 && patch > 0)
                            return true;
                    }
                    return false;
                };

                for (const QJsonValue& value : tags) {
                    QJsonObject tagObj = value.toObject();
                    QString tagName = tagObj["name"].toString();

                    if (tagName.startsWith("Pre-release", Qt::CaseInsensitive)) {
                        if (!foundPreRelease) {
                            preReleaseItem = new QTreeWidgetItem();
                            preReleaseItem->setText(0, "Pre-release (Nightly)");
                            foundPreRelease = true;
                        }
                        continue;
                    }
                    if (!isVersionGreaterThan_0_16_0(tagName)) {
                        continue;
                    }

                    QTreeWidgetItem* item = new QTreeWidgetItem();
                    item->setText(0, tagName);
                    otherItems.append(item);
                }

                // If you didn't find Pre-release, add it manually
                if (!foundPreRelease) {
                    preReleaseItem = new QTreeWidgetItem();
                    preReleaseItem->setText(0, "Pre-release (Nightly)");
                }

                // Add Pre-release first
                if (preReleaseItem) {
                    ui->downloadTreeWidget->addTopLevelItem(preReleaseItem);
                }

                // Add the others
                for (QTreeWidgetItem* item : otherItems) {
                    ui->downloadTreeWidget->addTopLevelItem(item);
                }

                // Assemble the current list
                QStringList versionList;
                for (int i = 0; i < ui->downloadTreeWidget->topLevelItemCount(); ++i) {
                    QTreeWidgetItem* item = ui->downloadTreeWidget->topLevelItem(i);
                    if (item)
                        versionList.append(item->text(0));
                }

                QStringList cachedVersions = LoadDownloadCache();
                if (cachedVersions == versionList) {
                    QMessageBox::information(this, tr("Version list update"),
                                             tr("No news, the version list is already updated."));
                } else {
                    SaveDownloadCache(versionList);
                    QMessageBox::information(
                        this, tr("Version list update"),
                        tr("The latest versions have been added to the list for download."));
                }

                // selects a version in downloadTreeWidget calls the download stream
                InstallSelectedVersion();
            }
        } else {
            QMessageBox::warning(this, tr("Error"),
                                 tr("Error accessing GitHub API") +
                                     QString(":\n%1").arg(reply->errorString()));
        }
        reply->deleteLater();
    });
}

void VersionDialog::InstallSelectedVersion() {
    disconnect(ui->downloadTreeWidget, &QTreeWidget::itemClicked, nullptr, nullptr);
    connect(
        ui->downloadTreeWidget, &QTreeWidget::itemClicked, this,
        [this](QTreeWidgetItem* item, int) {
            if (m_gui_settings->GetValue(gui::vm_versionPath).toString() == "") {

                QMessageBox::StandardButton reply;
                reply = QMessageBox::warning(
                    this, tr("Select the folder where the emulator versions will be installed"),
                    // clang-format off
tr("First you need to choose a location to save the versions in\n'Path to save versions'"));
                // clang-format on
                return;
            }
            QString versionName = item->text(0);
            QString apiUrl;
            QString platform;

#ifdef Q_OS_WIN
            platform = "win64-sdl";
#elif defined(Q_OS_LINUX)
            platform = "linux-sdl";
#elif defined(Q_OS_MAC)
            platform = "macos-sdl";
#endif
            if (versionName.contains("Pre-release", Qt::CaseInsensitive)) {
                apiUrl = "https://api.github.com/repos/shadps4-emu/shadPS4/releases";
            } else {
                apiUrl = QString("https://api.github.com/repos/shadps4-emu/"
                                 "shadPS4/releases/tags/%1")
                             .arg(versionName);
            }

            { // Message yes/no
                QMessageBox::StandardButton reply;
                reply = QMessageBox::question(this, tr("Confirm Download"),
                                              tr("Do you want to download the version") +
                                                  QString(": %1 ?").arg(versionName),
                                              QMessageBox::Yes | QMessageBox::No);
                if (reply == QMessageBox::No)
                    return;
            }

            QNetworkAccessManager* manager = new QNetworkAccessManager(this);
            QNetworkRequest request(apiUrl);
            QNetworkReply* reply = manager->get(request);

            connect(reply, &QNetworkReply::finished, this, [this, reply, platform, versionName]() {
                if (reply->error() != QNetworkReply::NoError) {
                    QMessageBox::warning(this, tr("Error"), reply->errorString());
                    reply->deleteLater();
                    return;
                }
                QByteArray response = reply->readAll();
                QJsonDocument doc = QJsonDocument::fromJson(response);

                QJsonArray assets;
                QJsonObject release;

                if (versionName.contains("Pre-release", Qt::CaseInsensitive)) {
                    QJsonArray releases = doc.array();
                    for (const QJsonValue& val : releases) {
                        QJsonObject obj = val.toObject();
                        if (obj["prerelease"].toBool()) {
                            release = obj;
                            assets = obj["assets"].toArray();
                            break;
                        }
                    }
                } else {
                    release = doc.object();
                    assets = release["assets"].toArray();
                }

                QString downloadUrl;
                for (const QJsonValue& val : assets) {
                    QJsonObject obj = val.toObject();
                    QString name = obj["name"].toString();
                    if (name.contains(platform)) {
                        downloadUrl = obj["browser_download_url"].toString();
                        break;
                    }
                }
                if (downloadUrl.isEmpty()) {
                    QMessageBox::warning(this, tr("Error"),
                                         tr("No files available for this platform."));
                    reply->deleteLater();
                    return;
                }

                QString userPath = m_gui_settings->GetValue(gui::vm_versionPath).toString();
                QString fileName = "temp_download_update.zip";
                QString destinationPath = userPath + "/" + fileName;

                QNetworkAccessManager* downloadManager = new QNetworkAccessManager(this);
                QNetworkRequest downloadRequest(downloadUrl);
                QNetworkReply* downloadReply = downloadManager->get(downloadRequest);

                QDialog* progressDialog = new QDialog(this);
                progressDialog->setWindowTitle(
                    tr("Downloading %1 , please wait...").arg(versionName));
                progressDialog->setFixedSize(400, 80);
                progressDialog->setWindowFlags(progressDialog->windowFlags() &
                                               ~Qt::WindowCloseButtonHint);
                QVBoxLayout* layout = new QVBoxLayout(progressDialog);
                QProgressBar* progressBar = new QProgressBar(progressDialog);
                progressBar->setRange(0, 100);
                layout->addWidget(progressBar);
                progressDialog->setLayout(layout);
                progressDialog->show();

                connect(downloadReply, &QNetworkReply::downloadProgress, this,
                        [progressBar](qint64 bytesReceived, qint64 bytesTotal) {
                            if (bytesTotal > 0)
                                progressBar->setValue(
                                    static_cast<int>((bytesReceived * 100) / bytesTotal));
                        });

                QFile* file = new QFile(destinationPath);
                if (!file->open(QIODevice::WriteOnly)) {
                    QMessageBox::warning(this, tr("Error"), tr("Could not save file."));
                    file->deleteLater();
                    downloadReply->deleteLater();
                    return;
                }

                connect(downloadReply, &QNetworkReply::readyRead, this,
                        [file, downloadReply]() { file->write(downloadReply->readAll()); });

                connect(
                    downloadReply, &QNetworkReply::finished, this,
                    [this, file, downloadReply, progressDialog, release, userPath, versionName]() {
                        file->flush();
                        file->close();
                        file->deleteLater();
                        downloadReply->deleteLater();

                        QString releaseName = release["name"].toString();

                        // Remove "shadPS4 " from the beginning, if it exists
                        if (releaseName.startsWith("shadps4 ", Qt::CaseInsensitive)) {
                            releaseName = releaseName.mid(8);
                        }

                        // Remove "codename" if it exists
                        releaseName.replace(QRegularExpression("\\b[Cc]odename\\s+"), "");

                        QString folderName;
                        if (versionName.contains("Pre-release", Qt::CaseInsensitive)) {
                            folderName = "Pre-release";
                        } else {
                            QString datePart = release["published_at"].toString().left(10);
                            folderName = QString("%1 - %2").arg(releaseName, datePart);
                        }

                        QString destFolder = QDir(userPath).filePath(folderName);

                        // extract ZIP
                        QString scriptFilePath;
                        QString scriptContent;
                        QStringList args;
                        QString process;

#ifdef Q_OS_WIN
                        scriptFilePath = userPath + "/extract_update.ps1";
                        scriptContent = QString("New-Item -ItemType Directory -Path \"%1\" "
                                                "-Force\n"
                                                "Expand-Archive -Path \"%2\" "
                                                "-DestinationPath \"%1\" -Force\n"
                                                "Remove-Item -Force \"%2\"\n"
                                                "Remove-Item -Force \"%3\"\n"
                                                "cls\n")
                                            .arg(destFolder)
                                            .arg(userPath + "/temp_download_update.zip")
                                            .arg(scriptFilePath);
                        process = "powershell.exe";
                        args << "-ExecutionPolicy" << "Bypass" << "-File" << scriptFilePath;
#else
                    scriptFilePath = userPath + "/extract_update.sh";
                    scriptContent = QString(
                                        "#!/bin/bash\n"
                                        "mkdir -p \"%1\"\n"
                                        "unzip -o \"%2\" -d \"%1\"\n"
                                        "rm \"%2\"\n"
                                        "rm \"%3\"\n"
                                        "clear\n")
                                        .arg(destFolder)
                                        .arg(userPath + "/temp_download_update.zip")
                                        .arg(scriptFilePath);
                    process = "bash";
                    args << scriptFilePath;
#endif

                        QFile scriptFile(scriptFilePath);
                        if (scriptFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
                            QTextStream out(&scriptFile);
#ifdef Q_OS_WIN
                            scriptFile.write("\xEF\xBB\xBF"); // BOM
#endif
                            out << scriptContent;
                            scriptFile.close();
#if defined(Q_OS_LINUX) || defined(Q_OS_MACOS)
                            scriptFile.setPermissions(QFile::ExeUser | QFile::ReadUser |
                                                      QFile::WriteUser);
#endif
                            QProcess::startDetached(process, args);

                            QTimer::singleShot(
                                4000, this,
                                [this, folderName, progressDialog, versionName, release]() {
                                    progressDialog->close();
                                    progressDialog->deleteLater();

                                    QString userPath =
                                        m_gui_settings->GetValue(gui::vm_versionPath).toString();
                                    QString executablePath =
                                        m_gui_settings->GetVersionExecutablePath(folderName);

                                    QMessageBox::information(
                                        this, tr("Confirm Download"),
                                        tr("Version %1 has been downloaded and selected.")
                                            .arg(versionName));

                                    bool is_release = !versionName.contains("Pre-release");
                                    auto release_name = release["name"].toString();
                                    QString code_name = "";

                                    if (is_release) {
                                        static constexpr QStringView marker = u" - codename ";
                                        int idx = release_name.indexOf(marker);
                                        if (idx != -1)
                                            code_name = release_name.mid(idx + marker.size());
                                    } else {
                                        QRegularExpression re("-([a-fA-F0-9]{7,})$");
                                        QRegularExpressionMatch match =
                                            re.match(release["tag_name"].toString());
                                        if (match.hasMatch()) {
                                            code_name = match.captured(1);
                                        } else {
                                            code_name = "unknown";
                                        }
                                    }
                                    std::filesystem::path exe_path =
                                        Common::FS::PathFromQString(executablePath);

                                    VersionManager::Version new_version{
                                        .name = (is_release ? versionName.toStdString()
                                                            : std::string("Pre-release (Nightly)")),
                                        .path = exe_path.generic_string(),
                                        .date = release["published_at"]
                                                    .toString()
                                                    .left(10)
                                                    .toStdString(),
                                        .codename = code_name.toStdString(),
                                        .type = is_release ? VersionManager::VersionType::Release
                                                           : VersionManager::VersionType::Nightly,
                                    };

                                    if (!is_release) {
                                        auto version_list = VersionManager::GetVersionList({});
                                        for (const auto& installedVersion : version_list) {
                                            if (installedVersion.type ==
                                                    VersionManager::VersionType::Nightly ||
                                                QString::fromStdString(installedVersion.name)
                                                    .contains("Pre-release", Qt::CaseInsensitive)) {
                                                VersionManager::RemoveVersion(
                                                    installedVersion.name);
                                            }
                                        }
                                        VersionManager::AddNewVersion(new_version);
                                    } else {
                                        VersionManager::AddNewVersion(new_version);
                                    }

                                    m_gui_settings->SetValue(
                                        gui::vm_versionSelected,
                                        QString::fromStdString(new_version.path));
                                    LoadInstalledList();
                                });
                        } else {
                            QMessageBox::warning(this, tr("Error"),
                                                 tr("Failed to create zip extraction script") +
                                                     QString(":\n%1").arg(scriptFilePath));
                        }
                    });
                reply->deleteLater();
            });
        });
}

void VersionDialog::LoadInstalledList() {
    const auto path = Common::FS::GetUserPath(Common::FS::PathType::LauncherDir) / "versions.json";
    auto versions = VersionManager::GetVersionList(path);
    const auto& selected_version =
        m_gui_settings->GetValue(gui::vm_versionSelected).toString().toStdString();

    std::sort(versions.begin(), versions.end(), [](const auto& a, const auto& b) {
        auto getOrder = [](int type) {
            switch (type) {
            case 1: // Pre-release
                return 0;
            case 0: // Release
                return 1;
            case 2: // Local
                return 2;
            default:
                return 3;
            }
        };

        int orderA = getOrder(static_cast<int>(a.type));
        int orderB = getOrder(static_cast<int>(b.type));

        if (orderA != orderB)
            return orderA < orderB;

        if (a.type == VersionManager::VersionType::Release) {
            static QRegularExpression versionRegex("^v\\.([0-9]+)\\.([0-9]+)\\.([0-9]+)$");
            QRegularExpressionMatch matchA = versionRegex.match(QString::fromStdString(a.name));
            QRegularExpressionMatch matchB = versionRegex.match(QString::fromStdString(b.name));

            if (matchA.hasMatch() && matchB.hasMatch()) {
                int majorA = matchA.captured(1).toInt();
                int minorA = matchA.captured(2).toInt();
                int patchA = matchA.captured(3).toInt();
                int majorB = matchB.captured(1).toInt();
                int minorB = matchB.captured(2).toInt();
                int patchB = matchB.captured(3).toInt();

                if (majorA != majorB)
                    return majorA > majorB;
                if (minorA != minorB)
                    return minorA > minorB;
                return patchA > patchB;
            }
        }

        return QString::fromStdString(a.name).compare(QString::fromStdString(b.name),
                                                      Qt::CaseInsensitive) < 0;
    });

    ui->installedTreeWidget->clear();
    ui->installedTreeWidget->setColumnCount(5);
    ui->installedTreeWidget->setColumnHidden(4, true);

    for (const auto& v : versions) {
        QTreeWidgetItem* item = new QTreeWidgetItem(ui->installedTreeWidget);
        item->setText(1, QString::fromStdString(v.name));

        QString codename = QString::fromStdString(v.codename);
        if (v.type == VersionManager::VersionType::Nightly) {
            if (codename.length() > 7) {
                codename = codename.left(7);
            }
        }
        item->setText(2, codename);

        item->setText(3, QString::fromStdString(v.date));
        item->setText(4, QString::fromStdString(v.path));
        item->setCheckState(0, (selected_version == v.path) ? Qt::Checked : Qt::Unchecked);
    }

    ui->installedTreeWidget->resizeColumnToContents(0);
    ui->installedTreeWidget->resizeColumnToContents(1);
    ui->installedTreeWidget->resizeColumnToContents(2);
    ui->installedTreeWidget->setColumnWidth(1, ui->installedTreeWidget->columnWidth(1) + 10);
    ui->installedTreeWidget->setColumnWidth(2, ui->installedTreeWidget->columnWidth(2) + 20);
}

QStringList VersionDialog::LoadDownloadCache() {
    QString cachePath =
        QDir(m_gui_settings->GetValue(gui::vm_versionPath).toString()).filePath("cache.version");
    QStringList cachedVersions;
    QFile file(cachePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd())
            cachedVersions.append(in.readLine().trimmed());
    }
    return cachedVersions;
}

void VersionDialog::SaveDownloadCache(const QStringList& versions) {
    QString cachePath =
        QDir(m_gui_settings->GetValue(gui::vm_versionPath).toString()).filePath("cache.version");
    QFile file(cachePath);
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        for (const QString& v : versions)
            out << v << "\n";
    }
}

void VersionDialog::PopulateDownloadTree(const QStringList& versions) {
    ui->downloadTreeWidget->clear();

    QTreeWidgetItem* preReleaseItem = nullptr;
    QList<QTreeWidgetItem*> otherItems;
    bool foundPreRelease = false;

    for (const QString& tagName : versions) {
        if (tagName.startsWith("Pre-release", Qt::CaseInsensitive)) {
            if (!foundPreRelease) {
                preReleaseItem = new QTreeWidgetItem();
                preReleaseItem->setText(0, "Pre-release (Nightly)");
                foundPreRelease = true;
            }
            continue;
        }
        QTreeWidgetItem* item = new QTreeWidgetItem();
        item->setText(0, tagName);
        otherItems.append(item);
    }

    if (!foundPreRelease) {
        preReleaseItem = new QTreeWidgetItem();
        preReleaseItem->setText(0, "Pre-release (Nightly)");
    }

    if (preReleaseItem)
        ui->downloadTreeWidget->addTopLevelItem(preReleaseItem);
    for (QTreeWidgetItem* item : otherItems)
        ui->downloadTreeWidget->addTopLevelItem(item);

    InstallSelectedVersion();
}

void VersionDialog::checkUpdatePre(const bool showMessage) {
    QString versionPath = m_gui_settings->GetValue(gui::vm_versionPath).toString();
    if (versionPath.isEmpty() || !QDir(versionPath).exists()) {
        return;
    }

    auto versions = VersionManager::GetVersionList({});

    QString localHash;
    QString localFolderPath;
    QString localTag;

    for (const auto& v : versions) {
        if (v.type == VersionManager::VersionType::Nightly) {
            localHash = QString::fromStdString(v.codename);
            localFolderPath = QString::fromStdString(v.path);
            localTag = QString::fromStdString(v.name);
            break;
        }
    }

    if (localHash.isEmpty()) {
        auto* tree = ui->downloadTreeWidget;
        int topCount = tree->topLevelItemCount();

        for (int i = 0; i < topCount; ++i) {
            QTreeWidgetItem* item = tree->topLevelItem(i);
            if (item && item->text(0).contains("Pre-release", Qt::CaseInsensitive)) {
                tree->setCurrentItem(item);
                tree->scrollToItem(item);
                tree->setFocus();
                emit tree->itemClicked(item, 0);
                break;
            }
        }
        return;
    }

    QNetworkAccessManager* manager = new QNetworkAccessManager(this);
    QNetworkRequest request(QUrl("https://api.github.com/repos/shadps4-emu/shadPS4/releases"));
    QNetworkReply* reply = manager->get(request);

    connect(reply, &QNetworkReply::finished, this, [this, reply, localHash, showMessage]() {
        if (reply->error() != QNetworkReply::NoError) {
            QMessageBox::warning(this, tr("Error"), reply->errorString());
            reply->deleteLater();
            return;
        }

        QByteArray resp = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(resp);

        if (!doc.isArray()) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("The GitHub API response is not a valid JSON array."));
            reply->deleteLater();
            return;
        }

        QJsonArray arr = doc.array();
        QString latestHash;
        QString latestTag;

        for (const QJsonValue& val : arr) {
            QJsonObject obj = val.toObject();
            if (obj["prerelease"].toBool()) {

                latestTag = obj["tag_name"].toString();

                int idx = latestTag.lastIndexOf('-');
                if (idx != -1 && idx + 1 < latestTag.length()) {
                    latestHash = latestTag.mid(idx + 1);
                }

                break;
            }
        }

        if (latestHash.isEmpty()) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("Unable to get hash of latest pre-release."));
            reply->deleteLater();
            return;
        }

        if (latestHash == localHash) {
            if (showMessage) {
                QMessageBox::information(this, tr("Auto Updater - Emulator"),
                                         tr("You already have the latest pre-release version."));
            }
        } else {
            showPreReleaseUpdateDialog(localHash, latestHash, latestTag);
        }

        reply->deleteLater();
    });
}

void VersionDialog::showPreReleaseUpdateDialog(const QString& localHash, const QString& latestHash,
                                               const QString& latestTag) {
    if (localHash == "") {
        return;
    }
    QDialog dialog(this);
    dialog.setWindowTitle(tr("Auto Updater - Emulator"));

    QVBoxLayout* mainLayout = new QVBoxLayout(&dialog);

    QHBoxLayout* headerLayout = new QHBoxLayout();
    QLabel* imageLabel = new QLabel(&dialog);
    QPixmap pixmap(":/images/shadps4.png");
    imageLabel->setPixmap(pixmap);
    imageLabel->setScaledContents(true);
    imageLabel->setFixedSize(50, 50);

    QLabel* titleLabel = new QLabel("<h2>" + tr("Update Available (Emulator)") + "</h2>", &dialog);

    headerLayout->addWidget(imageLabel);
    headerLayout->addWidget(titleLabel);
    headerLayout->addStretch(1);

    mainLayout->addLayout(headerLayout);

    QString labelText = QString("<table>"
                                "<tr><td><b>%1:</b></td><td>%2</td></tr>"
                                "<tr><td><b>%3:</b></td><td>%4</td></tr>"
                                "</table>")
                            .arg(tr("Current Version"), localHash.left(7), tr("Latest Version"),
                                 latestHash.left(7));
    QLabel* infoLabel = new QLabel(labelText, &dialog);
    mainLayout->addWidget(infoLabel);

    QHBoxLayout* btnLayout = new QHBoxLayout();
    QLabel* questionLabel = new QLabel(tr("Do you want to update?"), &dialog);
    QPushButton* btnUpdate = new QPushButton(tr("Update"), &dialog);
    QPushButton* btnCancel = new QPushButton(tr("No"), &dialog);

    btnLayout->addWidget(questionLabel);
    btnLayout->addStretch(1);
    btnLayout->addWidget(btnUpdate);
    btnLayout->addWidget(btnCancel);
    mainLayout->addLayout(btnLayout);

    // Changelog
    QTextBrowser* changelogView = new QTextBrowser(&dialog);
    changelogView->setReadOnly(true);
    changelogView->setVisible(false);
    changelogView->setFixedWidth(500);
    changelogView->setFixedHeight(200);
    mainLayout->addWidget(changelogView);

    QPushButton* toggleButton = new QPushButton(tr("Show Changelog"), &dialog);
    mainLayout->addWidget(toggleButton);

    connect(btnCancel, &QPushButton::clicked, &dialog, &QDialog::reject);

    connect(btnUpdate, &QPushButton::clicked, this, [this, &dialog, latestTag]() {
        installPreReleaseByTag(latestTag);
        dialog.accept();
    });

    connect(toggleButton, &QPushButton::clicked, this,
            [this, changelogView, toggleButton, &dialog, localHash, latestHash, latestTag]() {
                if (!changelogView->isVisible()) {
                    requestChangelog(localHash, latestHash, latestTag, changelogView);
                    changelogView->setVisible(true);
                    toggleButton->setText(tr("Hide Changelog"));
                    dialog.adjustSize();
                } else {
                    changelogView->setVisible(false);
                    toggleButton->setText(tr("Show Changelog"));
                    dialog.adjustSize();
                }
            });
    if (m_gui_settings->GetValue(gui::vm_showChangeLog).toBool()) {
        requestChangelog(localHash, latestHash, latestTag, changelogView);
        changelogView->setVisible(true);
        toggleButton->setText(tr("Hide Changelog"));
        dialog.adjustSize();
    }

    dialog.exec();
}

void VersionDialog::requestChangelog(const QString& localHash, const QString& latestHash,
                                     const QString& latestTag, QTextBrowser* outputView) {
    QString compareUrlString =
        QString("https://api.github.com/repos/shadps4-emu/shadPS4/compare/%1...%2")
            .arg(localHash, latestHash);

    QUrl compareUrl(compareUrlString);
    QNetworkRequest req(compareUrl);
    QNetworkReply* reply = networkManager->get(req);

    connect(
        reply, &QNetworkReply::finished, this, [this, reply, localHash, latestHash, outputView]() {
            if (reply->error() != QNetworkReply::NoError) {
                QMessageBox::warning(this, tr("Error"),
                                     tr("Network error while fetching changelog") + ":\n" +
                                         reply->errorString());
                reply->deleteLater();
                return;
            }
            QByteArray resp = reply->readAll();
            QJsonDocument doc = QJsonDocument::fromJson(resp);
            QJsonObject obj = doc.object();
            QJsonArray commits = obj["commits"].toArray();

            QString changesHtml;
            for (const QJsonValue& cval : commits) {
                QJsonObject cobj = cval.toObject();
                QString msg = cobj["commit"].toObject()["message"].toString();
                int newlinePos = msg.indexOf('\n');
                if (newlinePos != -1) {
                    msg = msg.left(newlinePos);
                }
                if (!changesHtml.isEmpty()) {
                    changesHtml += "<br>";
                }
                changesHtml += "&nbsp;&nbsp;&nbsp;&nbsp;• " + msg;
            }

            // PR number as link ( #123 )
            QRegularExpression re("\\(\\#(\\d+)\\)");
            QString newText;
            int last = 0;
            auto it = re.globalMatch(changesHtml);
            while (it.hasNext()) {
                QRegularExpressionMatch m = it.next();
                newText += changesHtml.mid(last, m.capturedStart() - last);
                QString num = m.captured(1);
                newText +=
                    QString("(<a href=\"https://github.com/shadps4-emu/shadPS4/pull/%1\">#%1</a>)")
                        .arg(num);
                last = m.capturedEnd();
            }
            newText += changesHtml.mid(last);
            changesHtml = newText;

            outputView->setOpenExternalLinks(true);
            outputView->setHtml("<h3>" + tr("Changes") + ":</h3>" + changesHtml);
            reply->deleteLater();
        });
}

void VersionDialog::installPreReleaseByTag(const QString& tagName) {
    QString apiUrl =
        QString("https://api.github.com/repos/shadps4-emu/shadPS4/releases/tags/%1").arg(tagName);

    QNetworkAccessManager* mgr = new QNetworkAccessManager(this);
    QNetworkRequest req(apiUrl);
    QNetworkReply* reply = mgr->get(req);

    connect(reply, &QNetworkReply::finished, this, [this, reply, tagName]() {
        if (reply->error() != QNetworkReply::NoError) {
            QMessageBox::warning(this, tr("Error"), reply->errorString());
            reply->deleteLater();
            return;
        }

        QByteArray bytes = reply->readAll();
        QJsonDocument doc = QJsonDocument::fromJson(bytes);
        QJsonObject obj = doc.object();
        QJsonArray assets = obj["assets"].toArray();

        QString downloadUrl;
        QString platformStr;
#ifdef Q_OS_WIN
        platformStr = "win64-sdl";
#elif defined(Q_OS_LINUX)
        platformStr = "linux-sdl";
#elif defined(Q_OS_MAC)
        platformStr = "macos-sdl";
#endif
        for (const QJsonValue& av : assets) {
            QJsonObject aobj = av.toObject();
            if (aobj["name"].toString().contains(platformStr)) {
                downloadUrl = aobj["browser_download_url"].toString();
                break;
            }
        }
        if (downloadUrl.isEmpty()) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("No download URL found for the specified asset."));
            reply->deleteLater();
            return;
        }
        showDownloadDialog(tagName, downloadUrl);

        reply->deleteLater();
    });
}

void VersionDialog::showDownloadDialog(const QString& tagName, const QString& downloadUrl) {
    QDialog* dlg = new QDialog(this);
    dlg->setWindowTitle(tr("Downloading Pre-release (Nightly), please wait..."));

    QVBoxLayout* lay = new QVBoxLayout(dlg);

    QProgressBar* progressBar = new QProgressBar(dlg);
    progressBar->setRange(0, 100);
    lay->addWidget(progressBar);

    dlg->setLayout(lay);
    dlg->resize(400, 80);
    dlg->setWindowFlags(dlg->windowFlags() & ~Qt::WindowCloseButtonHint);
    dlg->show();

    QNetworkRequest req(downloadUrl);
    QNetworkAccessManager* mgr = new QNetworkAccessManager(dlg);
    QNetworkReply* reply = mgr->get(req);

    connect(reply, &QNetworkReply::downloadProgress, this, [progressBar](qint64 rec, qint64 tot) {
        if (tot > 0) {
            int perc = static_cast<int>((rec * 100) / tot);
            progressBar->setValue(perc);
        }
    });

    connect(reply, &QNetworkReply::finished, this, [=, this]() {
        if (reply->error() != QNetworkReply::NoError) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("Network error while downloading") + ":\n" +
                                     reply->errorString());
            reply->deleteLater();
            dlg->close();
            dlg->deleteLater();
            return;
        }

        QByteArray data = reply->readAll();
        QString userPath = m_gui_settings->GetValue(gui::vm_versionPath).toString();
        QString zipPath = QDir(userPath).filePath("temp_pre_release_download.zip");

        QDir dir(userPath);
        QStringList entries = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);

        QFile zipFile(zipPath);
        if (!zipFile.open(QIODevice::WriteOnly)) {
            QMessageBox::warning(this, tr("Error"),
                                 tr("Failed to save download file") + ":\n" + zipPath);
            reply->deleteLater();
            return;
        }
        zipFile.write(data);
        zipFile.close();

        QString destFolder = QDir(userPath).filePath("Pre-release");
        QString scriptFilePath;
        QString scriptContent;
        QStringList args;
        QString process;

#ifdef Q_OS_WIN
        scriptFilePath = userPath + "/extract_pre_release.ps1";
        scriptContent = QString("New-Item -ItemType Directory -Path \"%1\" -Force\n"
                                "Expand-Archive -Path \"%2\" -DestinationPath \"%1\" -Force\n"
                                "Remove-Item -Force \"%2\"\n"
                                "Remove-Item -Force \"%3\"\n"
                                "cls\n")
                            .arg(destFolder)      // %1 - new destination folder
                            .arg(zipPath)         // %2 - zip path
                            .arg(scriptFilePath); // %3 - script
        process = "powershell.exe";
        args << "-ExecutionPolicy" << "Bypass" << "-File" << scriptFilePath;
#elif defined(Q_OS_LINUX) || defined(Q_OS_MACOS)
        scriptFilePath = userPath + "/extract_pre_release.sh";
        scriptContent = QString("#!/bin/bash\n"
                                "mkdir -p \"%1\"\n"
                                "unzip -o \"%2\" -d \"%1\"\n"
                                "rm \"%2\"\n"
                                "rm \"%3\"\n"
                                "clear\n")
                            .arg(destFolder)
                            .arg(zipPath)
                            .arg(scriptFilePath);
        process = "bash";
        args << scriptFilePath;
#endif

        QFile scriptFile(scriptFilePath);
        if (scriptFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QTextStream out(&scriptFile);
#ifdef Q_OS_WIN
            scriptFile.write("\xEF\xBB\xBF"); // BOM
#endif
            out << scriptContent;
            scriptFile.close();

#if defined(Q_OS_LINUX) || defined(Q_OS_MACOS)
            scriptFile.setPermissions(QFile::ExeUser | QFile::ReadUser | QFile::WriteUser);
#endif
            QProcess::startDetached(process, args);

            QTimer::singleShot(4000, this, [=, this]() {
                progressBar->setValue(100);
                dlg->close();
                dlg->deleteLater();

                if (!QDir(destFolder).exists()) {
                    QMessageBox::critical(this, tr("Error"), tr("Extraction failure."));
                    return;
                }

                QString codename;
                QRegularExpression re("-([a-fA-F0-9]{7,})$");
                QRegularExpressionMatch match = re.match(tagName);
                if (match.hasMatch()) {
                    codename = match.captured(1);
                } else {
                    codename = "unknown";
                }

                auto const exe = m_gui_settings->GetVersionExecutablePath(destFolder);
                VersionManager::Version new_version = {
                    .name = "Pre-release (Nightly)",
                    .path = exe.toStdString(),
                    .date = QDateTime::currentDateTime().toString("yyyy-MM-dd").toStdString(),
                    .codename = codename.toStdString(),
                    .type = VersionManager::VersionType::Nightly,
                };
                VersionManager::UpdatePrerelease(new_version);

                // Only auto-select if no version was previously selected.
                // Preserve the user's existing selection (e.g. a custom build).
                if (m_gui_settings->GetValue(gui::vm_versionSelected).toString().isEmpty()) {
                    m_gui_settings->SetValue(gui::vm_versionSelected, exe);
                }

                QMessageBox::information(this, tr("Complete installation"),
                                         tr("Pre-release updated successfully") + ":\n" + tagName);

                LoadInstalledList();
            });
        } else {
            QMessageBox::warning(this, tr("Error"),
                                 tr("Failed to create the update script file") + ":\n" +
                                     scriptFilePath);
        }

        reply->deleteLater();
    });
}
