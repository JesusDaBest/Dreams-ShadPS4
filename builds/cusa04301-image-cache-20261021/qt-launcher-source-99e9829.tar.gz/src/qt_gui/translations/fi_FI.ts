<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="fi_FI" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>Tietoa shadPS4:sta</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 on kokeellinen avoimen lähdekoodin PlayStation 4 emulaattori.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Tätä ohjelmistoa ei saa käyttää pelien pelaamiseen, joita et ole hankkinut laillisesti.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Huijaukset/paikkaukset pelille </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Huijaukset/paikkaukset ovat kokeellisia.\nKäytä varoen.\n\nLataa huijaukset yksitellen valitsemalla repositorion ja napsauttamalla latauspainiketta.\nPaikkaukset-sivulla voit ladata kaikki paikkaukset kerralla, valita mitä haluat käyttää ja tallentaa valinnan.\n\nKoska me emme kehitä huijauksia/paikkauksia,\nilmoita ongelmista huijauksen tekijälle.\n\nLoitko uuden huijauksen? Käy osoitteessa:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Kuvaa ei saatavilla</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Sarjanumero: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Versio: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Koko: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Valitse huijaustiedosto:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Repositorio:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Lataa huijaukset</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Poista tiedosto</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Tiedostoja ei ole valittuna.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Voit poistaa ei-toivomasi huijaukset lataamisen jälkeen.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Haluatko poistaa valitun tiedoston?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Valitse paikkaustiedosto:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Lataa paikkaukset</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Tallenna</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Huijaukset</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Paikkaukset</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Paikkausta ei ole valittuna.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Tiedostoa files.json ei voitu avata lukemista varten.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Nykyiselle sarjanumerolle ei löytynyt paikkaustiedostoa.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Tiedostoa ei voitu avata lukemista varten.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Tiedostoa ei voitu avata kirjoittamista varten.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>XML:n jäsentäminen epäonnistui: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Onnistui</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Vaihtoehdot tallennettu onnistuneesti.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Virheellinen lähde</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>Valittu lähde on virheellinen.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Olemassa oleva tiedosto</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Tiedosto on jo olemassa. Haluatko korvata sen?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Tiedoston tallentaminen epäonnistui:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Tiedoston lataaminen epäonnistui:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Huijauksia ei löytynyt</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Huijauksia ei löytynyt tälle pelin versiolle valitusta repositoriosta. Kokeile toista repositoriota tai eri versiota pelistä.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Huijausten lataus onnistui</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Olet ladannut huijaukset onnistuneesti valitusta repositoriosta tälle pelin versiolle. Voit yrittää ladata toisesta repositoriosta. Jos se on saatavilla, voit myös käyttää sitä valitsemalla tiedoston listasta.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Tallentaminen epäonnistui:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Lataus epäonnistui:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Lataus valmis</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Paikkaukset ladattu onnistuneesti! Kaikki saatavilla olevat paikkaukset kaikille peleille on ladattu, eikä niitä tarvitse ladata yksittäin jokaiselle pelille, kuten huijausten kohdalla. Jos paikkausta ei näy, saattaa olla, että sitä ei ole saatavilla kyseiselle sarjanumerolle ja peliversiolle.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>JSON-tietojen jäsentäminen HTML:stä epäonnistui.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>HTML-sivun hakeminen epäonnistui.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Peli on versiossa: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>Ladattu paikkaus toimii vain versiossa: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Sinun on ehkä päivitettävä pelisi.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Yhteensopivuusilmoitus</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Tiedoston avaaminen epäonnistui:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>XML VIRHE:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Tiedostoa files.json ei voitu avata kirjoittamista varten</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Tekijä: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Hakemistoa ei ole olemassa:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Tiedostoa files.json ei voitu avata lukemista varten.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nimi:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Huijauksia ei voi käyttää ennen kuin peli on käynnissä.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Sulje</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Automaattinen päivitys</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Verkkovirhe:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Automaattinen päivitys sallii enintään 60 päivitystarkistusta tunnissa.\nOlet saavuttanut tämän rajan. Yritä myöhemmin uudelleen.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Päivitystietojen jäsentäminen epäonnistui.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Ennakkojulkaisuja ei löytynyt.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Lataus-URL-osoitetta ei löytynyt määritetylle omaisuudelle.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Versiosi on jo ajan tasalla!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Nykyinen versio</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Uusin versio</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Haluatko päivittää?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Näytä muutoshistoria</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Tarkista päivitykset käynnistettäessä</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Päivitä</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Ei</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Piilota muutoshistoria</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Muutokset</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>URL-osoitteeseen yhdistettäessä tapahtui verkkovirhe</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Lataus valmis</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>Päivitys on ladattu, paina OK asentaaksesi.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Päivitystiedoston tallentaminen epäonnistui sijaintiin</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Aloitetaan päivitystä...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Päivitysskriptitiedoston luominen epäonnistui</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Automaattinen päivitys - Käyttöliittymä</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Päivitys saatavilla - Käyttöliittymä</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Haetaan yhteensopivuustietoja, odota hetki</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Ladataan...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Yhteensopivuustietoja ei voitu päivittää! Yritä myöhemmin uudelleen.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Ei voitu avata compatibility_data.json-tiedostoa kirjoittamista varten.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Tuntematon</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Käynnistyy</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Valikot</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>Pelin aikana</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Pelattava</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Määritä ohjainkomennot</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Ristiohjain</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Ylös</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Vasen</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Oikea</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Alas</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Vasen sauva</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Kokoonpanon valinta</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Yleinen kokoonpano</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Käytä pelikohtaisia kokoonpanoja</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Toimintonäppäimet</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Oikea sauva</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Värinhallinta</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Korvaa ohjaimen valopalkin väri</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Korvaava väri</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Tallentaminen epäonnistui</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Akseliarvoja ei voi määrittää kertaa useammin</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Tallenna</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Käytä</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Palauta oletusarvot</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ei määritetty</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>OPTIONS</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Kosketuslevyn vasen puoli</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Kosketuslevyn keskikohta</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Kosketuslevyn oikea puoli</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Kolmio</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Neliö</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Ympyrä</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Risti</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Yksittäisiä syötteitä ei voi määrittää useammin kuin kerran. Kaksoiskappaleet on määritetty seuraaviin painikkeisiin:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Paina painiketta</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Liikuta ohjaussauvaa</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 ja L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Aktiivinen peliohjain</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>Peliohjaimen ID</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Oletuspeliohjain</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Oletusta ei ole valittu</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>--</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Aseta aktiivinen peliohjain oletukseksi</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Poista oletuspeliohjain</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 ja R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Oletusohjain valittu</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Aktiivinen ohjain asetettu oletukseksi</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Oletusohjain poistettu</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Oletusohjainasetus poistettu</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>Punainen</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>Vihreä</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>Sininen</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Vasemman sauvan katvealue</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Katvealueen minimi (oletus: 2, max: 127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Katvealueen maksimi (oletus: 127, max: 127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Oikean sauvan katvealue</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Vihje: Tyhjennä syöte hiiren oikealla painikkeella</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Salausavainten hallinta</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Trophy-avain: Käytetään trophyjen salauksen purkuun.
On oltava kelvollinen, parillisen pituuden heksadesimaalimerkkijono.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Syötä trophy-avain</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Trophy-avain:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Tila: ei ladattuna</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Trophy-avain</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Syötä %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Eksponentti1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Eksponentti2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Julkinen eksponentti</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Kerroin</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Modulo</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Alkuluku 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Alkuluku 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Yksityinen eksponentti</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Väärennetty avainsarja</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-avainkomponentit väärennettyihin allekirjoituksiin.
Kaikissa kentissä on oltava kelvollinen, parillisen pituuden heksadesimaalimerkkijono.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>RIF-avainsarja vianetsintään</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-avainkomponentit RIF-tiedostoille vianetsintää varten.
Kaikissa kentissä on oltava kelvollinen, parillisen pituuden heksadesimaalimerkkijono.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Paketista (pkg) johdettu avain 3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-avainkomponentit pakettien salauksen purkuun.
Kaikissa kentissä on oltava kelvollinen, parillisen pituuden heksadesimaalimerkkijono.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Sulje</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Varoitus</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>Avaintiedostoa ei löytynyt tai sitä ei voitu ladata.
Syötä avaimet ja tallenna ne.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Vahvistusvirhe</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Onnistui</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Avaimet tallennettu!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Avaimien tallennus epäonnistui!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Tila: kaikki kentät tyhjiä</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Tila: virheelliset heksadesimaaliarvot</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Tila: keskeneräinen</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Tila: voimassa</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Virheellinen tiedosto</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Vain JSON-tiedostoja tuetaan.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Tiedoston avaaminen epäonnistui.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>JSON-virhe</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Virheellinen JSON-muoto.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Avaimet ladattu JSONista!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>Trophy-avain sisältää virheellisen heksadesimaalin tai parittoman pituuden.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 sisältää virheellisen heksadesimaalin tai parittoman pituuden.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Lataa avain</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Tallenna avain</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Muokkaa Näppäimistön + Hiiren ja Ohjaimen näppäinasetuksia</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Käytä pelikohtaisia kokoonpanoja</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Tiedostoa ei voitu avata luettavaksi</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Tiedostoa ei voitu avata kirjoitettavaksi</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Tallenna muutokset</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Haluatko tallentaa muutokset?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Tietoa</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Haluatko palauttaa tekemäsi muutokset oletusasetuksiin?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Haluato palauttaa nämä asetukset takaisin määrittämiisi oletuksiin?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Palauta oletusarvoon</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Avaa kansio</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Ladataan peliluetteloa, odota hetki :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Ladataan...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Valitse hakemisto</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Selaa</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Emulaattoriversioiden kansio</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Pelivedosten kansio</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>DLC-vedosten kansio</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Pelikansio</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>DLC-kansio</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Kuvake</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nimi</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Sarjanumero</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Yhteensopivuus</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Alue</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Ohjelmisto</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Koko</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versio</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Polku</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Pelattu aika</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Pelaamaton</translation>
    </message>
    <message>
      <source>h</source>
      <translation>t</translation>
    </message>
    <message>
      <source>m</source>
      <translation>min</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Yhteensopivuutta ei ole testattu</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Peli ei alustaudu kunnolla / kaataa emulaattorin</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Peli käynnistyy, mutta näyttää vain tyhjän ruudun</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Peli näyttää kuvan mutta ei mene valikosta eteenpäin</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Pelissä on pelikokemusta rikkovia häiriöitä tai kelvoton suorituskyky</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Peli voidaan läpäistä hyväksyttävällä suorituskyvyllä ilman suuria häiriöitä</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Napsauta nähdäksesi lisätiedot GitHubissa</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Viimeksi päivitetty</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Suosikki</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>t</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>kt</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>Mt</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>Gt</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>Tt</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Huijaukset/paikkaukset</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>SFO-selain</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Trophy-selain</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Avaa kansio...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Avaa pelikansio</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Avaa tallennustietokansio</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Avaa lokikansio</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Kopioi tietoja...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Kopioi nimi</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Kopioi sarjanumero</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Kopioi versio</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Kopioi koko</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Kopioi kaikki</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Poista...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Poista peli</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Poista päivitys</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Poista DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Poista trophy</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Yhteensopivuus...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Peli</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Tällä pelillä ei ole poistettavaa päivitystä!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Päivitä</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Tällä pelillä ei ole poistettavaa lisäsisältöä!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>Lisäsisältö (DLC)</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Poista %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Haluatko varmasti poistaa pelin %1 hakemiston %2?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Avaa päivityskansio</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Poista tallennustiedot</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Tällä pelillä ei ole avattavaa päivityskansiota!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Tälle pelille ei löytynyt lokitiedostoa!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Tällä pelillä ei ole poistettavia tallennustietoja!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Tällä pelillä ei ole poistettavia tallennettuja trophyjä!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Tallennustiedot</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trophy</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>SFO-selain kohteelle </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Poista suosikeista</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Lisää suosikkeihin</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Pelikohtaiset asetukset...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Muokkaa pelikohtaisia asetuksia</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Luo pelikohtaiset asetukset yleisasetuksista</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Poista pelikohtaiset asetukset</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Päivitä tietokanta</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Näytä raportti</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Lähetä raportti</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Vahvista poisto</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Poistetaanko pelikohtaiset asetukset?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Käynnistä...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Käynnistä pelikohtaisilla asetuksilla (oletus)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Käynnistä yleisasetuksilla</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Käynnistä oletusasetuksilla</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Raporttia ei voitu lähettää, koska pelin viimeisin loki epäonnistui seuraavassa tarkastuksessa, mikä tekisi raportista virheellisen:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>OK</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Tiedot</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Luo pikakuvake valitulle emulaattoriversiolle</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Luo pikakuvake määritellylle emulaattoriversiolle</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Luo pikakuvake</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Pikakuvakkeen luonti</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Pikakuvakkeen luonti onnistui!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Virhe pikakuvakkeen luonnissa!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Kuvakkeen muuntaminen epäonnistui.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Poista varjostinvälimuisti</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Tällä pelillä ei ole poistettavaa varjostinvälimuistia!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Varjostinvälimuisti</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Tällä pelillä ei ole avattavaa tallennuskansiota!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>Trophy-avain vaaditaan trophy-hallinnan käyttöön. Sen voi syöttää napsauttamalla Asetukset > Hallitse salausavaimia.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Pikaopas</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Usein kysyttyä</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Syntaksi</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Erityissidokset</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Näppäinsidokset</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Pikanäppäimet</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Näytä FPS-laskuri</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ei määritetty</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Lopeta emulaatio</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Lataa näppäinmääritykset uudelleen</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Vaihda koko näytön tilaa</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Pysäytä/Jatka</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Hiiren emulointi ohjaussauvana päälle/pois</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Hiiren emulointi gyroskooppina päälle/pois</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Vihje: Pikanäppäimelle voidaan määrittää jopa kolme eri syötettä</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Tallenna</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Käytä</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Palauta oletusarvot</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Tallentaminen epäonnistui</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Yksittäisiä syötteitä ei voi määrittää useammin kuin kerran. Kaksoiskappaleet on määritetty seuraaviin painikkeisiin:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Odotetaan syötettä</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Vihje: Tyhjennä syöte hiiren oikealla painikkeella</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Suurenna äänenvoimakkuutta</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Pienennä äänenvoimakkuutta</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Pikanäppäimet</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Paikanpitäjä</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Ota kuvakaappaus</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Ota kuvakaappaus peittokuvien kanssa</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Avaa emulaattorin asetukset</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Emulaattorin suoritustiedostoa ei löytynyt</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>Peliä ei ole käynnissä</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Muokkaa ohjainasetuksia</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ei määritetty</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Vasemman sauvan puolitila</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Kokonpanon valinta</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Yleinen kokoonpano</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Käytä pelikohtaisia kokoonpanoja</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Tekstieditori</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ohje</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Hiiri ohjaussauvana</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*paina F7 pelissä aktivoidaksesi</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>OPTIONS</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Hiiren liikkeen parametrit</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>Huomio: Lisätietoa saat osiosta Ohje -> Erityisnäppäinsidokset</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Kolmio</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Neliö</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Ympyrä</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Risti</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Oikean sauvan puolitila</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Nopeuden poikkeama (oletus: 0.125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Kopioi yleisestä kokoonpanosta</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Katvealueen poikkeama (oletus: 0.50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Nopeuskerroin (oletus: 1.0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Kopioi arvot yleisestä kokoonpanosta</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Haluatko korvata olemassa olevat määritykset yleisen kokoonpanon määrityksillä?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Tallentaminen epäonnistui</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Paina näppäintä</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Ei voida määrittää</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>Hiiren rullaa ei voi määrittää sauvan ulostuloon</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Tallenna</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Käytä</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Palauta oletusarvot</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Yksittäisiä syötteitä ei voi määrittää useammin kuin kerran. Kaksoiskappaleet on määritetty seuraaviin painikkeisiin:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Kosketuslevyn vasen puoli</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Kosketuslevyn keskikohta</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Kosketuslevyn oikea puoli</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Vihje: Tyhjennä syöte hiiren oikealla painikkeella</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Lähtö</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Syöte</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Vaihtoehtoinen syöte 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Vaihtoehtoinen syöte 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Ristiohjain ylös</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Ristiohjain alas</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Ristiohjain vasen</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Ristiohjain oikea</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Vasen sauva ylös</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Vasen sauva alas</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Vasen sauva vasen</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Vasen sauva oikea</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Oikea sauva ylös</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Oikea sauva alas</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Oikea sauva vasen</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Oikea sauva oikea</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Lokisuodattimen esiasetukset</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Kommentti</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Suodatin</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Lataa</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Sulje</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Lisää uusi esiasetus valitun rivin jälkeen</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Poista valitut esiasetukset</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Lataa valittu esiasetus</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Avaa/Lisää ELF-kansio</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Käynnistä peli</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Tarkista päivitykset</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>Tietoa shadPS4:sta</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Asetukset...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Viimeisimmät pelit</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Avaa shadPS4-kansio</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Sulje</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Sulje shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Sulje sovellus.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Avaa peliluettelo</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Päivitä peliluettelo</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Hyvin pieni</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Pieni</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Keskikokoinen</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Suuri</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Listanäkymä</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Ruudukkonäkymä</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>ELF-selain</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Peliasennushakemisto</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Lataa huijaukset/paikkaukaset</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Kirjoita peliluettelo tiedostoon</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Trophy-selain</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Pelejä ei löytynyt. Ole hyvä ja lisää pelisi kirjastoon ensin.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Hae...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Tiedosto</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Näkymä</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Peliluettelon kuvakkeet</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Peliluettelon tila</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Asetukset</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Työkalut</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Teemat</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ohje</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Tumma</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Vaalea</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Vihreä</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Sininen</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Violetti</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Työkalupalkki</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Peliluettelo</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Lataa huijaukset kaikille asennetuille peleille</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Lataa paikkaukset kaikille peleille</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Lataus valmis</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Olet ladannut huijaukset kaikkiin asennettuihin peleihin.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Paikkausten lataus onnistui!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Kaikki saatavilla olevat paikkaukset kaikille peleille on ladattu.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Pelit: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>ELF-tiedostot (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Pelin käynnistys</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Vain yksi tiedosto voi olla valittuna!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Käynnistä peli</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Eboot.bin-tiedostoa ei löytynyt</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Peli on jo käynnissä!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Pelaa</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pysäytä</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Lopeta</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Käynnistä uudelleen</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Koko näyttö</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Ohjaimet</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Näppäimistö</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Päivitä luettelo</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Jatka</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Näytä nimet kuvakkeiden alla</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Pikanäppäimet</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Versiohallinta</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Ei valittua versiota</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Emulaattorin versiota ei valittu.
Versiohallinnan valikko avataan.
Valitse emulaattorin versio oikeanpuoleisesta paneelista.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Emulaattorin suoritustiedostoa ei löytynyt</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Käynnistä emulaattori</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>Emulaattori on jo käynnissä!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Virheellinen annettu peliargumentti</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Skylanders-hallinta</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Infinity-hahmojen hallinta</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Dimensions Toypad -hallinta</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Pelin loki</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Näytä pelin loki</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Hallinnoi salausavaimia</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Hallinnoi käyttäjiä</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Asema lukittu</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>Asema %1: on lukittu. Syötä BitLocker-avain käyttääksesi sitä:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>Virheellinen palautusavain. Yritä uudelleen.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Asetukset</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Yleiset</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Järjestelmä</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Konsolin kieli</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Asetusten oletusvälilehti</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trophyt</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Avaa omien trophy-kuvien/-äänien kansio</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Lokinkerääjä</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Lokityyppi</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Lokisuodatin</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Avaa lokisijainti</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Syöte</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Osoitin</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Piilota hiiren osoitin</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Osoittimen toimettomuuden aikaraja</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Oletuslaite</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Ohjain</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafiikka</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Käyttäjä</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Näytönohjain</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Lisäasetukset</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Varjostimien vedostus</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Käytä HDR:ää</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Polut</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Pelikansiot</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Lisää...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Poista</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Virheenkorjaus</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Virheenkorjausvedostus</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Vulkan-validointikerrokset</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>RenderDoc-debuggaus</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Kaatumisdiagnostiikka</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Kerää varjostimet</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Kopioi näytönohjainpuskurit</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Isännän virheenkorjausmerkit</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Vieraan virheenkorjausmerkit</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Takaisinlue lineaariset kuvat</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Tarkista päivitykset käynnistettäessä</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Näytä muutoshistoria aina</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Tarkista päivitykset</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Pelin musiikki</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Poista trophy-ilmoitukset</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Taustakuva</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Näytä taustakuva</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Peittävyys</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Soita pelin taustamusiikki</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Päivitä yhteensopivuustietokanta käynnistettäessä</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Pelin yhteensopivuus</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Näytä yhteensopivuustiedot</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Päivitä yhteensopivuustietokanta</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Äänenvoimakkuus</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Tallenna</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Käytä</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Palauta oletusarvot</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Sulje</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Vie hiiren osoitin asetuksen päälle saadaksesi lisätietoja.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Konsolin kieli:\nMäärittää PS4-pelin käyttämän kielen.\nOn suositeltavaa valita kieli, jota peli tukee, mikä voi vaihdella alueittain.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Emulaattorin kieli:\nMäärittää emulaattorin käyttöliittymän kielen.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Näytä aloitusnäyttö:\nNäyttää pelin aloitusnäytön (erikoiskuvan) pelin käynnistyessä.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Discord Rich Presence:\nNäyttää emulaattorin kuvakkeen ja olennaiset tiedot Discord-profiilissasi.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Taustakuva:\nMäärittää pelin taustakuvan läpinäkyvyyden.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Soita pelin taustamusiikki:\nSoittaa taustamusiikkia valitessa peliä käyttöliittymässä, jos peli tukee sitä.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Poista trophy-ilmoitukset:\nPoistaa trophy-ilmoitukset käytöstä pelin aikana. Trophyjen edistystä voi silti seurata Trophy-selaimella (napsauta peliä hiiren oikealla painikkella pääikkunassa).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Piilota hiiren osoitin:\nValitse, milloin hiiren osoitin piilotetaan:\nEi koskaan: Osoitin näkyy aina.\nToimettomana: Määritä toimettomuuden aika, jonka jälkeen osoitin piilotetaan.\nAina: Osoitin ei näy koskaan.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Osoittimen toimettomuuden aikaraja:\nMääritä toimettomuuden aika (sekunteina), jonka jälkeen osoitin piilotetaan.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Näytä yhteensopivuustiedot:\nNäyttää pelien yhteensopivuustiedot listanäkymässä. Ota käyttöön &quot;Päivitä yhteensopivuustietokanta käynnistettäessä&quot; saadaksesi ajantasaiset tiedot.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Päivitä yhteensopivuustiedot käynnistettäessä:\nPäivittää yhteensopivuustiedot automaattisesti shadPS4:n käynnistyessä.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Päivitä yhteensopivuustietokanta:\nPäivittää yhteensopivuustietokannan heti.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Ei koskaan</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Toimettomana</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Aina</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Näytönohjain:\nValitse, mitä näytönohjainta emulaattori käyttää useamman näytönohjaimen järjestelmissa, tai valitse &quot;Automaattinen&quot; määrittääksesi sen automaattisesti.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Leveys/Korkeus:\nAsettaa käynnistetyn emulaattori-ikkunan koon, jota voidaan muuttaa pelin aikana.\nTämä on eri, kuin pelin sisäinen resoluutio.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Käytä HDR:ää:\nOttaa HDR:n käyttöön peleissä, jotka tukevat sitä.\nNäyttösi tulee tukea BT2020 PQ -väriavaruutta ja RGB10A2 swapchain-muotoa.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Pelikansiot:\nLista hakemistoista, joista pelejä haetaan.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Lisää:\nLisää hakemisto listalle.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Poista:\nPoista hakemisto listalta.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Virheenkorjausvedostus:\nTallentaa käynnissä olevan PS4-ohjelman tuonti- ja vientisymbolit sekä tiedoston otsikkotiedot hakemistoon.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>RenderDoc-debuggaus:\nKun tämä on käytössä, emulaattori tarjoaa RenderDoc-yhteensopivuuden, mikä mahdollistaa renderöidyn kuvan tallennuksen ja analysoinnin.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Kerää varjostimet:\nOta käyttöön, jos aiot muokata varjostimia virheenkorjausvalikossa (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Takaisinlue lineaariset kuvat:\nSallii GPU-muunnettujen lineaaristen kuvien asynkronisen lataamisen.\nSaattaa korjata ongelmia joissakin peleissä.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Kopioi näytönohjainpuskurit:\nKiertää GPU-lähetyksiin liittyvät kilpailuolosuhteet.\nVoi auttaa tai ei auta PM4 tyypin 0 kaatumisissa.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Isännän virheenkorjausmerkit:\nLisää emulaattoripuolen tietoja, kuten merkkejä, tiettyihin AMDGPU-komentoihin Vulkan-komentojen ympärillä sekä antaa resursseille virheenjäljitysnimiä.\nJos tämä on käytössä, Kaatumisdiagnostiikka tulisi ottaa myös käyttöön.\nHyödyllinen esimerkiksi RenderDocille.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Vieraan virheenkorjausmerkit:\nLisää kaikki virheenkorjausmerkit komentopuskuriin, jotka peli itse on lisännyt.\nJos tämä on käytössä, Kaatumisdiagnostiikka tulisi ottaa myös käyttöön.\nHyödyllinen esimerkiksi RenderDocille.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Aseta taustamusiikin äänenvoimakkuus.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Liikeohjaus</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Selaa</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Automaattinen</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Pelien asennushakemisto</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Video</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Näyttötila</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>Ikkunoitu</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Koko näyttö</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Koko näyttö (reunaton)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Ikkunan koko</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>Leveys:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>Korkeus:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Erilliset lokitiedostot</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Erilliset lokitiedostot:\nKirjaa jokaiselle pelille erillisen lokitiedoston.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Trophy-ilmoitusten sijainti</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Vasen</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Oikea</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Ylhäällä</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Alhaalla</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Ilmoituksen kestoaika</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Kannettava käyttäjäkansio</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Luo kannettava käyttäjäkansio yleisestä käyttäjäkansiosta</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Kannettava käyttäjäkansio:\nTallentaa shadPS4-asetukset ja tiedot, joita käytetään vain nykyiseen kansioon sijoitetussa shadPS4-versiossa. Käynnistä sovellus uudelleen kannettavan käyttäjäkansion luomisen jälkeen aloittaaksesi sen käytön.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 on jo olemassa</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>Kohteen %1 luonti onnistui.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Avaa omien trophy-kuvien/-äänien kansio:\nVoit lisätä mukautettuja kuvia ja ääniä trophyihin.\nLisää tiedostot custom_trophy-kansioon nimettynä seuraavasti:\ntrophy.wav / trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nHuomautus: Ääni toimii vain QT-versioissa.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Kokeelliset ominaisuudet</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>VAROITUS: Nämä ominaisuudet ovat kokeellisia, eikä niitä pitäisi ottaa käyttöön, ellei sinua kehoteta tai ellei peli sitä vaadi. Ole hyvä ja kysy shadPS4 Discord-palvelimella, jos sinulla on kysyttävää.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Ohjainsyöte taustalla</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Ohjainsyöte taustalla:\nSallii shadPS4:n tunnistaa ohjainsyötteet, kun peli-ikkuna ei ole kohdistettuna.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Kaatumisdiagnostiikka:\nLuo .yaml-tiedoston, joka sisältää tietoja Vulkanin tilasta kaatumisen aikana.\nHyödyllinen laitteiden katoamisvirheiden debuggaamisessa. Jos tämä on käytössä, Isännän ja Vieraan virheenkorjausmerkit tulisi otta myös käyttöön.\nTarvitset Vulkan-validointikerrokset käyttöön ja Vulkan SDK:n tämän toimintaan.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Lokitus</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Lokitus:\nOttaa lokituksen käyttöön.\nÄlä muuta tätä, jos et tiedä mitä teet!\nKun pyydät apua, varmista, että tämä asetus on käytössä.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Esitystila</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>Mailbox (pystytahdistus)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>FIFO (pystytahdistus)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Välitön (ei pystytahdistusta)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Valitse DLC-kansio</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Esitystila:\nMäärittää, kuinka videon ulostulo esitetään näytölle.\n\nMailbox: Kuvat synkronoidaan näytön virkistystaajuudella. Uudet kuvat korvaavat odottavat kuvat. Vähentää viivettä, mutta voi ohittaa kuvia jäädessä jälkeen.\nFIFO: Kuvat synkronoidaan näytön virkistystaajuudella. Uudet kuvat jonotetaan odottavien kuvien taakse. Varmistaa, että kaikki kuvat esitetään, mutta voi lisätä viivettä.\nVälitön: Kuvat esitetään näytölle heti kun mahdollista, mutta voi aiheuttaa kuvan pilkkoutumista (tearing).</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Selaa:\nSelaa kansiota, jonka haluat asettaa lisäsisällön poluksi.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>FSR-asetukset</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Käytä FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>RCAS-terävöitys</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>RCAS-vaimennus:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Lataa esiasetuksia...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Loki</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Avaa lokisijainti:\nAvaa kansion, johon lokitiedosto on tallennettu.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Mikrofoni:\nEi mitään: Mikrofonia ei käytetä.\nOletuslaite: Käyttää järjestelmässä määriteltyä oletuslaitetta.\nTai valitse käytettävä mikrofoni listasta.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Äänenvoimakkuus:\nSäätää pelien yleistä äänenvoimakkuutta. Vaihteluväli on 0–500 % ja oletusarvo on 100 %.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Asetusten oletusvälilehti:\nMäärittää oletusvälilehden, jossa asetukset avataan. Oletusarvo on Yleiset.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Liikeohjaus:\nOttaa käyttöön ohjaimen liikeohjauksen, jos sitä tuetaan.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Vblank-taajuus</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Vblank-taajuus:\nKuvataajuus, jolla emulaattori päivittyy (60 Hz on lähtötaso, vaikka peli toimisi nopeudella 30 tai 60 FPS). Tämän muuttaminen voi vaikuttaa haitallisesti, kuten lisätä pelin nopeutta tai rikkoa kriittisiä pelitoimintoja, jotka eivät odota tämän muuttuvan!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Oikosiirto (DMA)</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Devkit-konsolitila</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Pakota PSN-kirjautuminen</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Pakota verkkoyhteys</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Sekalaiset</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Käyttöliittymä</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Kokeelliset</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Näytä aloitusnäyttö pelin käynnistyksessä</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Yleiset käyttöliittymäasetukset</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>PS4 Neo-tila</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Oikosiirto (DMA):\nMahdollistaa sattumanvaraisen muistin pääsyn näytönohjaimelta suorittimen muistiin.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>PS4 Neo-tila:\nLisää tuen PS4 Pro -emulaatiolle ja muistikoolle. Tällä hetkellä aiheuttaa epävakautta monissa testatuissa peleissä.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Devkit-konsolitila:\nLisää tuen Devkit-konsolin muistikoolle.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Pakota verkkoyhteys:\nPakottaa pelit havaitsemaan aktiivisen verkkoyhteyden. Todellisia verkkoyhteysominaisuuksia ei vielä tueta.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Pakota PSN-kirjautuminen:\nPakottaa pelit havaitsemaan aktiivisen PSN-kirjautumisen. Todellisia PSN-ominaisuuksia ei tueta.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Vulkan-validointikerrokset:\nAktivoi järjestelmän, joka validoi Vulkan-renderöijän tilan ja kirjaa tietoa sen sisäisestä tilasta. Heikentää suorituskykyä ja todennäköisesti muuttaa emulaation käyttäytymistä.\nTarvitset Vulkan SDK:n tämän toimintaan.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Äänilaite (yleinen)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Äänilaite (DS4-kaiutin)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Varjostimien vedostus:\nTeknistä vianetsintää varten pelin varjostimia tallennetaan hakemistoon niiden renderöityessä.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>NULL GPU:\nTeknistä vianetsintää varten. Pelin renderöinti estetään, ikään kuin näytönohjainta ei olisi. Ruutu näkyy mustana.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>DLC-polku:\nHakemisto, mistä pelin lisäsisältö ladataan.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Ylimääräinen DMem-allokointi</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Ylimääräinen DMem-allokointi:\nPakottaa määrätyn määrän ylimääräistä DMem allokoitavaksi. Aiheuttaa kaatumista tai ongelmia joissakin peleissä.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>PS4-järjestelmämoduulien polku:\nHakemisto, mistä PS4-järjestelmämoduulit ladataan.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Selaa:\nSelaa kansiota, jonka haluat asettaa järjestelmämoduulien poluksi.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Vulkan-validointi (vaatii Vulkan SDK:n)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Validointikerrokset</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Ydinvalidointi</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Synkronointivalidointi</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Näytönohjainavusteinen validointi</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Synkronointivalidointi:\nAktivoi järjestelmän, joka validoi Vulkan-renderöintitehtävien ajoituksen.\nHeikentää suorituskykyä ja todennäköisesti muuttaa emuloinnin käyttäytymistä.\nTarvitset Vulkan SDK:n tämän toimintaan.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Ydinvalidointi:\nMahdollistaa API:n päävalidointitoiminnot.\nHeikentää suorituskykyä ja todennäköisesti muuttaa emuloinnin käyttäytymistä.\nTarvitset Vulkan SDK:n tämän toimintaan.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Näytönohjainavusteinen validointi:\nOhjaa varjostimia koodilla, joka validoi niiden oikeanlaisen toiminnan.\nHeikentää suorituskykyä ja todennäköisesti muuttaa emuloinnin käyttäytymistä.\nTarvitset Vulkan SDK:n tämän toimintaan.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Käyttöliittymän kieli</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Käyttöliittymän päivitykset</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>DLC-polku</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>PS4-järjestelmämoduulien polku</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Käyttöliittymän päivitykset:\nJulkaisu: Viralliset versiot, jotka julkaistaan kuukausittain ja saattavat olla hyvin vanhoja, mutta ovat luotettavampia ja testatumpia.\nNightly: Kehitysversiot, joissa on kaikki uusimmat ominaisuudet ja korjaukset, mutta ne saattavat sisältää virheitä ja ovat vähemmän vakaita.\n\nTämä päivitys koskee vain Qt-käyttöliittymää. Päivittääksesi emulaattoriytimen, käytä versiohallintaa.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>Kannettavan käynnistyskansion luominen ei onnistunut</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>Kannettava launcherDir-kansio luotu</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>USB-laite</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Aito USB-laite</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>USB-laite:\nAito USB-laite: Käytä todellista USB-laitetta, joka on liitetty järjestelmään.\nSkylander Portal: Emuloi Skylander Portal of Power.\nInfinity Base: Emuloi Disney Infinity Base.\nDimensions Toypad: Emuloi Lego Dimensions Toypad.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Varjostinvälimuisti</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Pakkaa varjostinvälimuistitiedostot ZIP-kansioon</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Varjostinvälimuisti:\nTallentaa käännetyt varjostimet uudelleenkääntämisen välttämiseksi. Vähentää pätkimistä.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Pakkaa varjostinvälimuistitiedostot ZIP-kansioon:\nVarjostinvälimuistitiedostot tallennetaan samaan ZIP-tiedostoon useiden eri tiedostojen sijasta.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Takaisinluvun tila</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Ei käytössä</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Takaisinluvut:\nOttaa käyttöön GPU-muistin takaisinluvun ja -kirjoituksen.\nTämä on tarpeen joissakin peleissä.\nSaattaa aiheuttaa ongelmia vakaudssa tai suorituskykvyssä.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Rento</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Tarkka</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Valitse shadPS4:n kotipolku</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Valitse järjestelmämoduulien kansio</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Kotihakemiston sijainti (tallennukset, syötteet, trophy-tiedot)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Kotihakemiston sijainti:\nKansio, johon tallennustiedot, trophy-tiedostot ja syöteasetukset tallennetaan kaikille käyttäjille.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Selaa:\nSelaa kansiota, jonka haluat asettaa kotihakemistoksi.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Ääni</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Äänen taustajärjestelmä</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Mikrofonilaite</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Laitteet</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Kamera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Lokin synkronointi</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Ohita kaksoiskappaleet lokista</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Lokin ohitusten enimmäiskesto</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Lokin kokorajoitus</translation>
    </message>
    <message>
      <source> B</source>
      <translation> t</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Lokiin lisäys</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Lokiin lisäys:\nLisää olemassa oleviin lokeihin.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Lokin ohitusten enimmäiskesto:\nIdenttisten rivien kirjoittamisen välillä odotettava aikaväli (ms). Aktiivinen vain jos &apos;Ohita kaksoiskappaleet lokista&apos; on käytössä.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Lokin kokorajoitus:\nLokitiedostojen enimmäiskoko (tavuina).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Ohita kaksoiskappaleet lokista:\nSäästä tallennustilaa välttämällä identtisen lokin kirjoittamista.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Lokin synkronointi:\nVaihda synkronoidun (parempi järjestys) tai asynkronisen (parempi suorituskyky) tilan välillä.</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Lokityyppi:\nValitse lokityypiksi wincolor tai msvc.\nwincolor: Oletuslokitus Windowsille\nmsvc: Lokitus vianetsintää varten</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Lokisuodatin:\nSuodattaa lokia tulostamaan vain määrättyä tietoa.\nEsimerkkejä: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nTasot: trace, debug, info, warning, error, critical - tässä järjestyksessä. Valittu taso vaientaa kaikki edeltävät tasot luettelossa ja kirjaa kaikki tasot sen jälkeen.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Valitse versio</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Valitse versio pikakuvakkeen luomiselle</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Ei valittua versiota</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Valitse ensin versio</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Trophy-selain</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Valitse peli:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Edistyminen</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Näytä ansaitut trophyt</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Näytä ansaitsemattomat trophyt</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Näytä piilotetut trophyt</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Valitse käyttäjä:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Käyttäjähallinta</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>&amp;Luo käyttäjä</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>&amp;Poista käyttäjä</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>&amp;Nimeä uudelleen</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Aseta oletuskäyttäjä</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>&amp;Aseta väri</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Aseta ohjainportti</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Sulje</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>Uusia käyttäjiä ei voi lisätä.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Luo uusi käyttäjä</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>Uusi käyttäjätunnus: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Käyttäjänimi (3–16 merkkiä, kirjainta, numeroa, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Virheellinen käyttäjänimi</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>Käyttäjänimen on oltava 3–16 merkkiä ja kelvollinen.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Poiston vahvistus</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Poistetaanko käyttäjätunnus %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Nimeä uudelleen</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Vanha käyttäjänimi: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Aseta käyttäjän väri</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Valitse väri:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Aseta ohjainportti</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Määritä portti (1–4) tälle käyttäjälle:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Avaa käyttäjän hakemisto</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Versiohallinta</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Tallennettujen versioiden polku</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Selaa</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Asennettu</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Valittu</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versio</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Koodinimi</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Päivämäärä</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Lisää oma</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Poista</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Päivitä luettelo</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Lataa</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Tarkista esijulkaisujen päivitykset käynnistettäessä</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Tarkista esijulkaisujen päivitykset</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Valitse kansio, johon emulaattorin versiot asennetaan</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Valitse suoritustiedosto</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Suoritustiedosto (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Version nimi</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Kirjoita version nimi sellaisena kuin se on luettelossa.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Virhe</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Onnistui</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>Version lisäys onnistui.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Kansion polkua ei voitu määrittää.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Poista versio</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Haluatko poistaa version</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Versioluettelon päivitys</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>Ei mitään uutta, versioluettelo on jo päivitetty.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>Uusimmat versiot on lisätty luetteloon ladattavaksi.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Virhe GitHub API:n noutamisessa</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Valitse ensin sijainti, johon versiot tallennetaan kohteessa
&apos;Tallennettujen versioiden polku&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Haluatko ladata version</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Ei tiedostoja saatavilla tälle alustalle.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Ladataan %1, odota hetki...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Tiedostoa ei voitu tallentaa.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>Versio %1 on ladattu ja valittu.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>ZIP-purkuskriptin luominen epäonnistui</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>GitHub API-vastaus ei ole kelvollinen JSON-taulukko.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Automaattinen päivitys - Emulaattori</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>Sinulla on jo uusin esijulkaisuversio.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Päivitys saatavilla (emulaattori)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Nykyinen Versio</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Uusin versio</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Haluatko päivittää?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Päivitä</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Ei</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Näytä muutoshistoria</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Piilota muutoshistoria</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Muutoshistorian noutamisessa tapahtui verkkovirhe</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Muutokset</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Lataus-URL-osoitetta ei löytynyt määritetylle omaisuudelle.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Lataamisessa tapahtui verkkovirhe</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Lataustiedoston tallentaminen epäonnistui</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Viimeistele asennus</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>Esijulkaisun päivitys onnistui</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Päivitysskripttitiedoston luominen epäonnistui</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Näytä muutoshistoria aina</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Versiota ei ole valittuna. Valitse yksi luettelosta poistaaksesi.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Vahvista lataaminen</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Purkaminen epäonnistui.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Samanniminen versio on jo olemassa.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Paikallinen</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Poistettavaa kansiota ei voitu määrittää.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Kansion poistaminen epäonnistui.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>Uusimman esijulkaisun hashin nouto epäonnistui.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Ladataan esijulkaisua (Nightly), odota hetki...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Dimensions-hallinta</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Aktiiviset Dimensions-hahmot:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tyhjennä</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Lataa</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Siirrä</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Tuntematon hahmo</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Valitse Dimensions-tiedosto</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Dimensions-hahmo (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Hahmotiedoston avaus epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Hahmotiedoston (%1) avaus epäonnistui!
Tiedosto saattaa olla jo käytössä alustalla.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Hahmotiedoston lukeminen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Hahmotiedoston (%1) lukeminen epäonnistui!
Tiedosto on liian pieni.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Hahmon luoja</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Suodata sarjojen mukaan:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Kaikki</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Tuntematon--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Hahmon numero:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Sarja:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Virhe arvon muuntamisessa</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Annettu hahmon numero on virheellinen!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>Annettu sarjan numero on virheellinen!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Luo hahmotiedosto</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Infinity-hahmo (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Hahmotiedoston luominen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Hahmotiedoston luominen epäonnistui:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Infinity-hallinta</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Aktiiviset Infinity-hahmot:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>Pelisetti/Voimalevy</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>Voimalevy 2</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>Voimalevy 3</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Pelaaja 1</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Pelaajan 1 toiminto 1</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Pelaajan 1 toiminto 2</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Pelaaja 2</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Pelaajan 2 toiminto 1</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Pelaajan 2 toiminto 2</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tyhjennä</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Lataa</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Tuntematon hahmo</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Valitse Infinity-tiedosto</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Infinity-hahmo (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Hahmotiedoston avaus epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Hahmotiedoston (%1) avaus epäonnistui!
Tiedosto saattaa olla jo käytössä alustalla.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Hahmotiedoston lukeminen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Hahmotiedoston (%1) lukeminen epäonnistui!
Tiedosto on liian pieni.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Hahmon luoja</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Tuntematon--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Hahmon numero:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Virhe arvon muuntamisessa</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Annettu hahmon numero on virheellinen!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Luo hahmotiedosto</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Dimensions-hahmo (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Hahmotiedoston luominen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Hahmotiedoston luominen epäonnistui:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Hahmon siirtäjä</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Siirrä tähän</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Poimi ja aseta</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Skylander-luoja</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Tuntematon--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Variantti:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Peruuta</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Virhe arvon muuntamisessa</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>Annettu ID on virheellinen!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>Annettu variantti on virheellinen!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Luo Skylander-tiedosto</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Skylander-objekti (*.sky);;Kaikki tiedostot (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Skylander-tiedoston luominen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Skylander-tiedoston luominen epäonnistui:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Skylanders-hallinta</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Aktiiviset portaalin Skylanderit:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tyhjennä</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Luo</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Lataa</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Valitse Skylander-tiedosto</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Kaikki tiedostot (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Skylander-tiedoston avaus epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Skylander-tiedoston (%1) avaus epäonnistui!
Tiedosto saattaa olla jo käytössä portaalissa.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Skylander-tiedoston lukeminen epäonnistui!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Skylander-tiedoston (%1) lukeminen epäonnistui!
Tiedosto on liian pieni.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Tuntematon (ID:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ei mitään</translation>
    </message>
  </context>
</TS>
