<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="cs_CZ" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>O shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 je experimentální open-source emulátor pro PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Tento software by neměl být používán k hraní her, které jste nezískali legálně.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Cheaty / Patche pro </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Cheaty/Patche jsou experimentální.\nPoužívejte s opatrností.\n\nStáhněte si cheaty jednotlivě výběrem repozitáře a kliknutím na tlačítko Stáhnout.\nV záložce Patche si můžete stáhnout všechny patche najednou, zvolte které chcete použít a uložte svůj výběr.\n\nProtože nevyvíjíme Cheaty/Patche,\nprosím nahlaste problémy jeho autorovi.\n\nVytvořily jste nový cheat? Navštivte:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Obrázek není k dispozici</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Serial: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Verze: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Velikost: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Vybrat soubor Cheatu:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Repozitář:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Stáhnout Cheaty</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Odstranit soubor</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Nebyly vybrány žádné soubory.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Cheaty, které po stažení nechcete, můžete odstranit.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Chcete odstranit vybraný soubor?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Vybrat soubor Patche:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Stáhnout Patche</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Uložit</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Cheaty</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Patche</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Nebyl vybrán žádný Patch.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Nelze otevřít files.json pro čtení.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Žádný soubor Patche nenalezen pro aktuální serial.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Soubor nelze otevřít pro čtení.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Soubor nelze otevřít pro zápis.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Nepodařilo se zpracovat XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Úspěšně dokončeno</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Nastavení byla úspěšně uložena.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Neplatný zdroj</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>Vybraný zdroj je neplatný.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Soubor existuje </translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Soubor již existuje. Chcete ho nahradit?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Uložení souboru se nezdařilo:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Stažení souboru se nezdařilo:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Cheaty nenalezeny</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Žádné Cheaty této verze hry v tomto repozitáři nebyly nalezeny, zkuste jiný repozitář nebo jinou verzi hry.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Cheaty úspěšně staženy</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Úspěšně jste si stáhli cheaty pro tuto verzi hry z vybraného repozitáře. Můžete zkusit stažení z jiného repozitáře. Pokud je k dispozici, bude možné jej použít výběrem souboru ze seznamu.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Nepodařilo se uložit:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Nepodařilo se stáhnout:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Stahování dokončeno</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Patche úspěšně staženy! Všechny patche dostupné pro všechny hry byly staženy, není třeba je stahovat jednotlivě pro každou hru, jako se to děje u Cheatů. Pokud se patch neobjeví, může to být to, že neexistuje pro konkrétní sériové číslo a verzi hry.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Nepodařilo se zpracovat JSON data z HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Nepodařilo se načíst HTML stránku.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Hra je ve verzi: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>Stažený patch funguje pouze na verzi: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Možná budete muset aktualizovat hru.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Oznámení o nekompatibilitě</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Nepodařilo se otevřít soubor:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>XML CHYBA:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Nepodařilo se otevřít files.json pro zápis.</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Autor:</translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Adresář neexistuje:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Nepodařilo se otevřít files.json pro čtení.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Název:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Nelze použít cheaty před spuštěním hry</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zavřít</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Automatické aktualizace</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Chyba sítě:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Automatická aktualizace umožňuje až 60 kontrol aktualizace za hodinu.\nDosáhli jste tohoto limitu. Opakujte akci později.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Nepodařilo se zpracovat informace o aktualizaci.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Nebyly nalezeny žádné předběžné verze.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation type="unfinished">No download URL found for the specified asset.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Vaše verze je již aktuální!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Aktuální verze</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Nejnovější verze</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Přejete si aktualizovat?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Zobrazit seznam změn</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Zkontrolovat aktualizace při spuštění</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aktualizovat</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Ne</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Skrýt seznam změn</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Změny</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Při pokusu o přístup k URL došlo k chybě sítě</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Stahování dokončeno</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>Aktualizace byla stažena, pro instalaci stiskněte tlačítko OK.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Nepodařilo se uložit soubor aktualizace do</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Spouštění aktualizace...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Nepodařilo se vytvořit soubor aktualizačního skriptu</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Automatická aktualizace - GUI</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Dostupná aktualizace - GUI</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Načítání dat o kompatibilitě, prosím čekejte</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Zrušit</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Načítání…</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Nelze aktualizovat data o kompatibilitě! Opakujte akci později.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Nelze otevřít compatibility_data.json pro zápis.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Neznámo</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Nic</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Lze načíst</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>V menu</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>Ve hře</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Hratelné</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Nastavení ovládání</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Směrová tlačítka</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Nahoru</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Vlevo</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Vpravo</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Dolů</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Levá analogová páčka</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Výběr nastavení</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Běžné nastavení</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Použít nastavení pro hru</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Akční tlačítka</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Pravá analogová páčka</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Úprava barev</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Přepsat barvu Lightbar</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Přepsat barvu</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Nelze uložit</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Hodnoty osy nelze spojit více než jednou</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Uložit</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Použít</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Obnovit výchozí</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Zrušit</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nemapováno</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad vlevo</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Střed Touchpadu</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad vpravo</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Trojúhelník</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Čtverec</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Kolečko</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Křížek</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Nelze spojit unikátní vstup více než jednou. Duplikujte vstupy mapované na následující tlačítka:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Stiskněte tlačítko</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Pohněte s analogovou páčkou</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 a L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Aktivní ovladač</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>ID ovladače</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Výchozí ovladač</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Není vybrán žádný výchozí</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>Není k dispozici</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Nastavit aktivní gamepad jako výchozí</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Odstranit výchozí ovladač</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 a R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Výchozí ovladač vybrán</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Aktivní ovladač nastaven jako výchozí</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Výchozí ovladač odstraněn</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Výchozí nastavení ovladače odstraněno</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>Červená</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>Zelená</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>Modrá</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Mrtvá zóna levé analogové páčky</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Min mrtvá zóna (výchozí:2 max:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Max mrtvá zóna (výchozí:127 max:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Mrtvá zóna pravé analogové páčky</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tip: Odmapovat vstupy kliknutím pravým tlačítkem myši</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Správce šifrovacích klíčů</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Klíč trofeje: Používá se pro dešifrování trofeje.
Musí být platný hexadecimální řetězec se správnou délkou.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Zadejte klíč trofeje</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Klíč trofeje:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Stav: Nenačteno</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Klíč trofeje</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Zadejte %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Exponent1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Exponent2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Public Exponent</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Coefficient</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Modulus</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Prime 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Prime 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Private Exponent</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Falešná sada klíčů</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for fake signing.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Debug Rif Keyset</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>Komponenty RSA klíče pro debug RIF souborů.
Všechna pole musí mít platné hexadecimální řetězce se sudou délkou.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation type="unfinished">Pkg Derived Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for package decryption.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zavřít</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Upozornění</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation type="unfinished">No key file found or failed to load.
Please enter your keys and save them.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Chyba ověření</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Dokončeno</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Klíče úspěšně uloženy!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Nepodařilo se uložit klíče!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Stav: Všechna pole jsou prázdná</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation type="unfinished">Status: Invalid hex values</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Stav: Nedokončeno</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Stav: Platný</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Neplatný soubor</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Jsou podporovány pouze soubory JSON.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Neschopný otevřít soubor.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Chyba JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Neplatný formát JSON</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Klíče úspěšně načteny z JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>Klíč trofeje obsahuje neplatný hexadecimální znak nebo má nesprávnou délku.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation type="unfinished">%1 contains invalid hex or has odd length.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Načíst klíč</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Uložit klíč</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation type="unfinished">Edit Keyboard + Mouse and Controller input bindings</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Použít nastavení pro hru</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Soubor nelze otevřít pro čtení</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Soubor nelze otevřít pro zápis</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Uložit změny</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Chcete uložit změny?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Pomoc</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation type="unfinished">Do you want to reset your custom default config to the original default config?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Chcete obnovit toto nastavení na vlastní výchozí nastavení?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Obnovit výchozí</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Otevřít složku</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Načítání seznamu her, čekejte prosím :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Zrušit</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Načítání…</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Vybrat adresář</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Procházet</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Adresář pro instalaci verzí emulátoru</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Adresář s vašimi kopiemi her</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Adresář s vašimi kopiemi DLC</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Adresář s hrami</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Adresář s DLC</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Ikona</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Název</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Sériové číslo</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Kompatibilita</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Region</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Firmware</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Velikost</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Verze</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Umístění</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Odehraný čas</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Nikdy nehráno</translation>
    </message>
    <message>
      <source>h</source>
      <translation>h</translation>
    </message>
    <message>
      <source>m</source>
      <translation>min</translation>
    </message>
    <message>
      <source>s</source>
      <translation>sec</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Kompatibilita není otestována</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Hra se nespustí / emulátor padá</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Hra se spustí, ale zobrazuje černou obrazovku</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Hra zobrazuje obraz, ale nedostane se přes menu</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Hra má velké chyby v grafice, nebo nehratelný výkon</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Hra se dá dohrát s dobrým výkonem a nemá velké chyby v grafice</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Klikněte pro zobrazení detailů na github</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Naposledy aktualizováno</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Oblíbené</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Cheaty / Patche</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>SFO prohlížeč</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Prohlížeč trofejí</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Otevřít složku...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Otevřít složku hry</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Otevřít složku se savy</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Otevřít složku s logy</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Kopírovat informace...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Kopírovat název</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Kopírovat sériové číslo</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Kopírovat verzi</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Kopírovat velikost</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Kopírovat vše</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Odstranit...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Odstranit hru</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Odstranit aktualizaci</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Odstranit DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Odstranit trofeje</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Kompatibilita...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Chyba</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Hra</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Tato hra nemá žádnou aktualizaci k odstranění!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aktualizace</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Tato hra nemá žádné DLC k odstranění!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Odstranit %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Opravdu chcete odstranit složku %1, %2?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Otevřít složku aktualizace</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Odstranit savy</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Tato hra nemá žádnou složku aktualizace pro otevření!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Pro tuto hru nebyl nalezen žádný log soubor!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Tato hra nemá žádné savy k odstranění!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Tato hra nemá žádné uložené trofeje k odstranění!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Savy</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofeje</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>SFO prohlížeč pro </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Odebrat z oblíbených</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Přidat do oblíbených</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Nastavení konkrétní hry...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Nastavení konkrétní hry</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Vytvořit nastavení konkrétní hry z globálního nastavení</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Odstranit nastavení konkrétní hry</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Aktualizovat databázi</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Zobrazit report</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Odeslat report</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Potvrdit odstranění</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Odstranit nastavení konkrétní hry?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Spustit...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Spustit s nastavením konkrétním hry (výchozí)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Spustit pouze s globálním nastavením</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Spustit s výchozím nastavením</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation type="unfinished">Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Vytvořit zástupce hry pro aktuálně vybranou verzi emulátoru</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Vytvořit zástupce pro určitou verzi emulátoru</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Vytvořit zástupce</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Vytvoření zástupce</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Zástupce úspěšně vytvořen!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Chyba při vytváření zástupce!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Nepodařilo se převést ikonu.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Odstranit mezipaměť Shaderů</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Tato hra nemá žádnou uloženou mezipaměť Shaderů k odstranění!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Mezipaměť Shaderů</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Tato hra nemá žádnou složku se savy pro otevření!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>K použití prohlížeče trofejí je nutný klíč trofeje. Lze jej zadat kliknutím na tlačítko Nastavení - Správa kryptografických klíčů.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Průvodce začátky</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Časté dotazy</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Syntax</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Speciální klávesové zkratky</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Klávesové zkratky</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Přizpůsobit klávesové zkratky</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Zobrazit počet FPS</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nemapováno</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Ukončit emulaci</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Znovunačtení mapování tlačítek při emulaci</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Přepnutí režimu celé obrazovky</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Pauza</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Přepnout myš na emulaci Joysticku</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Přepnout myš na emulaci Gyroskopu</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation type="unfinished">Tip: Up to three simultaneous inputs can be assigned for each hotkey</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Uložit</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Použít</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Zrušit</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Obnovit výchozí</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Nelze uložit</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation type="unfinished">Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Čekání na vstup</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tip: Odmapovat vstupy kliknutím pravým tlačítkem myši</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Zvýšit hlasitost</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Snížit hlasitost</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation type="unfinished">Hotkeys</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation type="unfinished">Placeholder</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation type="unfinished">Capture Screenshot</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation type="unfinished">Capture Screenshot w/ Overlays</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation type="unfinished">Open Emulator Settings</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Nelze najít spustitelný soubor emulátoru</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation type="unfinished">No game is running</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Nastavení ovládání</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nemapováno</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Půlrežim levé analogové páčky</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Výběr nastavení</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Běžné nastavení</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Použít nastavení pro hru</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Textový editor</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Nápověda</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation type="unfinished">Mouse to Joystick</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*ve hře stisknutím klávesy F7 aktivujete</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation type="unfinished">Mouse Movement Parameters</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation type="unfinished">note: click Help Button/Special Keybindings for more information</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Trojúhelník</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Čtverec</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Kolečko</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Křížek</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation type="unfinished">Right Analog Halfmode</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Odsazení rychlosti (def 0.125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Kopírovat z běžného nastavení</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation type="unfinished">Deadzone Offset (def 0.50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation type="unfinished">Speed Multiplier (def 1.0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Kopírovat hodnoty z běžného nastavení</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation type="unfinished">Do you want to overwrite existing mappings with the mappings from the Common Config?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Nelze uložit</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Stiskněte klávesu</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation type="unfinished">Cannot set mapping</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation type="unfinished">Mousewheel cannot be mapped to stick outputs</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Uložit</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Použít</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Obnovit výchozí</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Zrušit</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Nelze spojit unikátní vstup více než jednou. Duplikujte vstupy mapované na následující tlačítka:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad vlevo</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Střed Touchpadu</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad vpravo</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tip: Odmapovat vstupy kliknutím pravým tlačítkem myši</translation>
    </message>
    <message>
      <source>Output</source>
      <translation type="unfinished">Output</translation>
    </message>
    <message>
      <source>Input</source>
      <translation type="unfinished">Input</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation type="unfinished">Alternate Input 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation type="unfinished">Alternate Input 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation type="unfinished">Dpad Up</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation type="unfinished">Dpad Down</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation type="unfinished">Dpad Left</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation type="unfinished">Dpad Right</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation type="unfinished">Left Stick Up</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation type="unfinished">Left Stick Down</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation type="unfinished">Left Stick Left</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation type="unfinished">Left Stick Right</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation type="unfinished">Right Stick Up</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation type="unfinished">Right Stick Down</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation type="unfinished">Right Stick Left</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation type="unfinished">Right Stick Right</translation>
    </message>
    <message>
      <source>L1</source>
      <translation type="unfinished">L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation type="unfinished">R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation type="unfinished">L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation type="unfinished">R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation type="unfinished">L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation type="unfinished">R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Předvolba přednastavení logů</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Poznámka</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtr</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Nahrát</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zavřít</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation type="unfinished">Add a new preset after the selected row</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Odstranit vybrané předvolby</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Načíst vybranou předvolbu</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Otevřít/Přidat složku Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Spustit hru</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Kontrola aktualizací</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>O shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Nastavení...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Nedávné hry</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Otevřít složku shadPS4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Ukončit</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Ukončit shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Ukončit aplikaci</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Zobrazit seznam her</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Obnovit seznam her</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Drobné</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Malé</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Střední</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Velké</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Zobrazit seznam</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Zobrazit mřížku</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Elf Prohlížeč</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Složka pro instalaci hry</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Stáhnout Cheaty/Patche</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Vypsat seznam her</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Prohlížeč trofejí</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Nebyly nalezeny žádné hry. Nejprve přidejte své hry do knihovny.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Hledat...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Soubor</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Zobrazit</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Ikony v seznamu her</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Režim seznamu her</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Nastavení</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Nástroje</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Motivy vzhledu</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Nápověda</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Tmavý</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Světlý</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Zelený</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Modrý</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Fialový</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Panel nástrojů</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Herní seznam</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Stáhnout cheaty pro všechny nainstalované hry</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Stáhnout patche pro všechny hry</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Stahování dokončeno</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation type="unfinished">You have downloaded cheats for all the games you have installed.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Patche úspěšně staženy!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Všechny patche k dispozici pro všechny hry byly staženy.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Hry: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>Soubory ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Spuštění hry</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Lze vybrat pouze jeden soubor!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Spustit hru</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Eboot.bin soubor nebyl nalezen</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Hra je již spuštěna!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Hrát</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pozastavit</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Zastavit</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Restartovat</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Celá obrazovka</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Ovladače</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Klávesnice</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Obnovit seznam</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Pokračovat</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Zobrazit popisky pod ikonami</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Přizpůsobit klávesové zkratky</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Správa verzí emulátoru</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nebyla vybrána žádná verze</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Nebyla vybrána žádná verze emulátoru.
Nabídka Správce verzí se pak otevře.
Vyberte verzi emulátoru z nabídky pravého panelu.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Nelze najít spustitelný soubor emulátoru</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Spustit emulátor</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>Emulátor již běží!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Poskytnut neplatný herní argument</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Žádné</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Správa Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Správa Infinity Figurky</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Správa Dimensions Toy pad</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Protokol hry</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Zobrazit protokol hry</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Správa kryptografických klíčů</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Správa uživatelů</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation type="unfinished">Drive Locked</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation type="unfinished">Drive %1: is locked. Please enter the BitLocker key to access it:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation type="unfinished">Incorrect recovery key. Please try again.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Nastavení</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Obecné</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Systém</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Jazyk konzole</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Výchozí karta při otevření nastavení</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Zapnout Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofeje</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Otevřít složku s vlastními obrázky/zvuky pro trofeje</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Záznamník logů</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Typ logu</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Filtr logů</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Otevřít umístění logu</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Vstup</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Kurzor</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Skrýt kurzor</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Prodleva automatického skrytí kurzoru</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Žádné</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Výchozí zařízení</translation>
    </message>
    <message>
      <source>s</source>
      <translation>sekund</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Ovladač</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafika</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Uživatel</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Grafické zařízení</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Pokročilé</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Zapnout dumping shaderů</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Zapnout NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Zapnout HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Umístění</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Herní složky</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation type="unfinished">Add...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation type="unfinished">Remove</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Debug</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Zapnout debug dumping</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Zapnout validační vrstvy Vulkanu</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Zapnout RenderDoc debugging</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation type="unfinished">Enable Crash Diagnostics</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation type="unfinished">Collect Shaders</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation type="unfinished">Copy GPU Buffers</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Host Debug Markers</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Guest Debug Markers</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation type="unfinished">Enable Readback Linear Images</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation type="unfinished">Check for Updates at Startup</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation type="unfinished">Always Show Changelog</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation type="unfinished">Check for Updates</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation type="unfinished">Title Music</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Vypnout oznámení trofeje</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation type="unfinished">Background Image</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation type="unfinished">Show Background Image</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation type="unfinished">Opacity</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation type="unfinished">Play title music</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation type="unfinished">Update Compatibility Database On Startup</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation type="unfinished">Game Compatibility</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation type="unfinished">Display Compatibility Data</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation type="unfinished">Update Compatibility Database</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation type="unfinished">Volume</translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished">Save</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation type="unfinished">Apply</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished">Close</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation type="unfinished">Point your mouse at an option to display its description.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation type="unfinished">Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation type="unfinished">Emulator Language:\nSets the language of the emulator&apos;s user interface.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation type="unfinished">Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation type="unfinished">Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation type="unfinished">Background Image:\nControl the opacity of the game background image.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation type="unfinished">Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Zakázat vyskakovací okno trofeje:\nZakázat oznámení o trofeji ve hře. Průběh trofeje může být stále sledován pomocí prohlížeče trofejí (klepněte pravým tlačítkem myši na hru v hlavním okně).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation type="unfinished">Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation type="unfinished">Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation type="unfinished">Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation type="unfinished">Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation type="unfinished">Update Compatibility Database:\nImmediately update the compatibility database.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation type="unfinished">Never</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation type="unfinished">Idle</translation>
    </message>
    <message>
      <source>Always</source>
      <translation type="unfinished">Always</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation type="unfinished">Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation type="unfinished">Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation type="unfinished">Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation type="unfinished">Game Folders:\nThe list of folders to check for installed games.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation type="unfinished">Add:\nAdd a folder to the list.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation type="unfinished">Remove:\nRemove a folder from the list.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Povolit debug Dumping:\nUloží importy a export symbolů a informací hlavičky souboru aktuálně spuštěného programu PS4 do adresáře.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation type="unfinished">Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation type="unfinished">Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation type="unfinished">Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation type="unfinished">Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Hostitel chybových značek:\nNa straně emulátoru vloží informace, jako jsou značky pro specifické AMDGPU příkazy kolem Vulkan příkazů, a také přiděluje prostředkům ladicí názvy.\n
Pokud máte tuto funkci zapnutou, měli byste povolit i Diagnostiku pádů.\n
Užitečné pro programy jako RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation type="unfinished">Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation type="unfinished">Set the volume of the background music.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation type="unfinished">Enable Motion Controls</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation type="unfinished">Browse</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation type="unfinished">Auto Select</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Adresář pro instalaci her</translation>
    </message>
    <message>
      <source>Video</source>
      <translation type="unfinished">Video</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation type="unfinished">Display Mode</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation type="unfinished">Windowed</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation type="unfinished">Fullscreen</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation type="unfinished">Fullscreen (Borderless)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation type="unfinished">Window Size</translation>
    </message>
    <message>
      <source>W:</source>
      <translation type="unfinished">W:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation type="unfinished">H:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation type="unfinished">Separate Log Files</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation type="unfinished">Separate Log Files:\nWrites a separate logfile for each game.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Pozice oznámení trofeje</translation>
    </message>
    <message>
      <source>Left</source>
      <translation type="unfinished">Left</translation>
    </message>
    <message>
      <source>Right</source>
      <translation type="unfinished">Right</translation>
    </message>
    <message>
      <source>Top</source>
      <translation type="unfinished">Top</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation type="unfinished">Bottom</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation type="unfinished">Notification Duration</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation type="unfinished">Portable User Folder</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation type="unfinished">Create Portable User Folder from Common User Folder</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation type="unfinished">Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation type="unfinished">%1 already exists</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation type="unfinished">%1 successfully created.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Otevřít složku s vlastními obrázky/zvuky pro trofeje:\nMůžete přidat vlastní obrázky a zvuky do trofejí.\nPřidejte soubory do custom_trophy s následujícími názvy:\ntrophy.wav nebo trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nPoznámka: Zvuk bude fungovat pouze v QT verzích.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation type="unfinished">Experimental Features</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation type="unfinished">WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation type="unfinished">Enable Background Controller Input</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation type="unfinished">Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation type="unfinished">Enable Logging</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation type="unfinished">Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation type="unfinished">Present Mode</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation type="unfinished">Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation type="unfinished">Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation type="unfinished">Immediate (No Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation type="unfinished">Select the DLC folder</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation type="unfinished">Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the DLC path.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation type="unfinished">FSR Settings</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation type="unfinished">Enable FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation type="unfinished">Enable RCAS (sharpening)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation type="unfinished">RCAS Attenuation:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation type="unfinished">Load Presets...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation type="unfinished">Log</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation type="unfinished">Open Log Location:\nOpen the folder where the log file is saved.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation type="unfinished">Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation type="unfinished">Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation type="unfinished">Default tab when opening settings:\nChoose which tab will open, the default is General.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation type="unfinished">Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation type="unfinished">Vblank Frequency</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation type="unfinished">Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation type="unfinished">Enable Direct Memory Access</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation type="unfinished">Enable Devkit Console Mode</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation type="unfinished">Set &quot;PSN signed-in&quot; to True</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation type="unfinished">Set &quot;Network Connected&quot; to True</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation type="unfinished">Miscellaneous</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation type="unfinished">Frontend</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation type="unfinished">Experimental</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation type="unfinished">Show Splash Screen When Launching Game</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation type="unfinished">General Frontend Settings</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation type="unfinished">Enable PS4 Neo Mode</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation type="unfinished">Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation type="unfinished">Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation type="unfinished">Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation type="unfinished">Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation type="unfinished">Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation type="unfinished">Audio Device (general)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation type="unfinished">Audio Device (DS4 speaker)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Zapnout dumping shaderů:\nShadery hry se pro debugging uloží do složky, jak se vykreslí.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation type="unfinished">Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation type="unfinished">DLC Path:\nThe folder where game DLC is loaded from.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation type="unfinished">Additional DMem Allocation</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation type="unfinished">Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation type="unfinished">PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the sysmodules path.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation type="unfinished">Vulkan Validation (Requires Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation type="unfinished">Validation Layers</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation type="unfinished">Enable Core Validation</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation type="unfinished">Enable Sync Validation</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation type="unfinished">Enable GPU-Assisted Validation</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation type="unfinished">GUI Language</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation type="unfinished">GUI Updates</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation type="unfinished">DLC Path</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation type="unfinished">PS4 Sysmodules Path</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation type="unfinished">GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation type="unfinished">Cannot create portable launcher folder</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation type="unfinished">Portable launcherDir folder created</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation type="unfinished">USB Device</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation type="unfinished">Real USB Device</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation type="unfinished">Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation type="unfinished">Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation type="unfinished">Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation type="unfinished">USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation type="unfinished">Enable Shader Cache</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation type="unfinished">Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation type="unfinished">Readbacks Mode</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation type="unfinished">Disabled</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation type="unfinished">Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation type="unfinished">Relaxed</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation type="unfinished">Precise</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation type="unfinished">Select shadPS4 Home Path</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation type="unfinished">Select the system modules folder</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Umístění domovské složky (savy, vstupy, data trofejí)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Umístění domovské složky:\nSložka, ve které jsou uloženy savy, soubory trofejí a nastavení vstupů pro všechny uživatele.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the home folder.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation type="unfinished">Audio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation type="unfinished">Audio Backend</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation type="unfinished">Mic Device</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation type="unfinished">Devices</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation type="unfinished">Camera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation type="unfinished">Log Sync</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation type="unfinished">Log Skip Duplicate</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation type="unfinished">Log Max Skip Duration</translation>
    </message>
    <message>
      <source> ms</source>
      <translation type="unfinished"> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation type="unfinished">Log Size Limit</translation>
    </message>
    <message>
      <source> B</source>
      <translation type="unfinished"> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation type="unfinished">Log Append</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation type="unfinished">wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation type="unfinished">msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation type="unfinished">Log Append:\nAppend to existing logs.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation type="unfinished">Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation type="unfinished">Log Size Limit:\nMaximum size of log files (bytes).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation type="unfinished">Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation type="unfinished">Log Sync:\nSwitch between sync (order) or async (performance).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation type="unfinished">Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation type="unfinished">Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation type="unfinished">Select Version</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation type="unfinished">Select version for shortcut creation</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation type="unfinished">No Version Selected</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation type="unfinished">Select a version first</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Prohlížeč trofejí</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Vybrat hru:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Postup</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Zobrazit získané trofeje</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Zobrazit nezískané trofeje</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Zobrazit skryté trofeje</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Vybrat uživatele:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation type="unfinished">User Manager</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation type="unfinished">&amp;Create User</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation type="unfinished">&amp;Delete User</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation type="unfinished">&amp;Rename User</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation type="unfinished">&amp;Set Default User</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation type="unfinished">&amp;Set Color</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation type="unfinished">&amp;Set Controller Port</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation type="unfinished">&amp;Close</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation type="unfinished">Cannot add more users.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation type="unfinished">Create New User</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation type="unfinished">New User ID: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation type="unfinished">Username (3–16 chars, letters, numbers, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation type="unfinished">Invalid Username</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation type="unfinished">Username must be 3–16 chars and valid.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation type="unfinished">Delete Confirmation</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation type="unfinished">Delete user ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation type="unfinished">Rename User</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation type="unfinished">Old Username: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation type="unfinished">Set User Color</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation type="unfinished">Select color:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation type="unfinished">Set Controller Port</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation type="unfinished">Assign port (1-4) to this user:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Otevřít uživatelský adresář</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation type="unfinished">Version Manager</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation type="unfinished">Path to save versions</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation type="unfinished">Browse</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation type="unfinished">Installed</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation type="unfinished">Selected</translation>
    </message>
    <message>
      <source>Version</source>
      <translation type="unfinished">Version</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation type="unfinished">Codename</translation>
    </message>
    <message>
      <source>Date</source>
      <translation type="unfinished">Date</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation type="unfinished">Add Custom</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation type="unfinished">Delete</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation type="unfinished">Refresh List</translation>
    </message>
    <message>
      <source>Download</source>
      <translation type="unfinished">Download</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation type="unfinished">Check for Pre-release updates at startup</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation type="unfinished">Check for Pre-release Updates</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation type="unfinished">Select the folder where the emulator versions will be installed</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation type="unfinished">Select executable</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation type="unfinished">Executable (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation type="unfinished">Version name</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation type="unfinished">Enter the name of this version as it appears in the list.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Success</source>
      <translation type="unfinished">Success</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation type="unfinished">Version added successfully.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation type="unfinished">Failed to determine the folder path.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation type="unfinished">Delete version</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation type="unfinished">Do you want to delete the version</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation type="unfinished">Version list update</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation type="unfinished">No news, the version list is already updated.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation type="unfinished">The latest versions have been added to the list for download.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation type="unfinished">Error accessing GitHub API</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation type="unfinished">First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation type="unfinished">Do you want to download the version</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation type="unfinished">No files available for this platform.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation type="unfinished">Downloading %1 , please wait...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation type="unfinished">Could not save file.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation type="unfinished">Version %1 has been downloaded and selected.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation type="unfinished">Failed to create zip extraction script</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation type="unfinished">The GitHub API response is not a valid JSON array.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation type="unfinished">Auto Updater - Emulator</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation type="unfinished">You already have the latest pre-release version.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation type="unfinished">Update Available (Emulator)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation type="unfinished">Current Version</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation type="unfinished">Latest Version</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation type="unfinished">Do you want to update?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="unfinished">Update</translation>
    </message>
    <message>
      <source>No</source>
      <translation type="unfinished">No</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation type="unfinished">Show Changelog</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation type="unfinished">Hide Changelog</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation type="unfinished">Network error while fetching changelog</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation type="unfinished">Changes</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation type="unfinished">No download URL found for the specified asset.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation type="unfinished">Network error while downloading</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation type="unfinished">Failed to save download file</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation type="unfinished">Complete installation</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation type="unfinished">Pre-release updated successfully</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation type="unfinished">Failed to create the update script file</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation type="unfinished">Always Show Changelog</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation type="unfinished">No version selected. Please choose one from the list to delete.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation type="unfinished">Confirm Download</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation type="unfinished">Extraction failure.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation type="unfinished">A version with that name already exists.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation type="unfinished">Local</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation type="unfinished">Failed to determine the folder to remove.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation type="unfinished">Failed to delete folder.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation type="unfinished">Unable to get hash of latest pre-release.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation type="unfinished">Downloading Pre-release (Nightly), please wait...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation type="unfinished">Dimensions Manager</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation type="unfinished">Active Dimensions Figures:</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Move</source>
      <translation type="unfinished">Move</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation type="unfinished">Select Dimensions File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation type="unfinished">Filter by Series:</translation>
    </message>
    <message>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation type="unfinished">Series:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation type="unfinished">Series number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation type="unfinished">Failed to create figure file!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation type="unfinished">Failed to create figure file:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation type="unfinished">Infinity Manager</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation type="unfinished">Active Infinity Figures:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation type="unfinished">Play Set/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation type="unfinished">Power Disc Two</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation type="unfinished">Power Disc Three</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation type="unfinished">Player One</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation type="unfinished">Player One Ability One</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation type="unfinished">Player One Ability Two</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation type="unfinished">Player Two</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation type="unfinished">Player Two Ability One</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation type="unfinished">Player Two Ability Two</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation type="unfinished">Select Infinity File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation type="unfinished">Failed to create minifig file!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation type="unfinished">Failed to create minifig file:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation type="unfinished">Figure Mover</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation type="unfinished">Move Here</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation type="unfinished">Pick up and Place</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation type="unfinished">Skylander Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation type="unfinished">ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation type="unfinished">Variant:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation type="unfinished">ID entered is invalid!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation type="unfinished">Variant entered is invalid!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation type="unfinished">Create Skylander File</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation type="unfinished">Skylander Object (*.sky);;All Files (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation type="unfinished">Failed to create skylander file!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation type="unfinished">Failed to create skylander file:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation type="unfinished">Skylanders Manager</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation type="unfinished">Active Portal Skylanders:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation type="unfinished">Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation type="unfinished">Select Skylander File</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Všechny soubory (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation type="unfinished">Failed to open the skylander file!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation type="unfinished">Failed to open the skylander file(%1)!
File may already be in use on the portal.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation type="unfinished">Failed to read the skylander file!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the skylander file(%1)!
File was too small.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation type="unfinished">Unknown (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
  </context>
</TS>
