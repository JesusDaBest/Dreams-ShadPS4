<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="it_IT" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>Riguardo shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 è un emulatore sperimentale open-source per PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Questo programma non dovrebbe essere utilizzato per riprodurre giochi che non vengono ottenuti legalmente.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Cheats / Patch per </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>I trucchi e le patch sono sperimentali.\nUtilizzali con cautela.\n\nScarica i trucchi singolarmente selezionando l&apos;archivio e cliccando sul pulsante di download.\nNella scheda Patch, puoi scaricare tutte le patch in una volta sola, scegliere quali vuoi utilizzare e salvare la tua selezione.\n\nPoiché non sviluppiamo i trucchi e le patch,\nper favore segnala i problemi all&apos;autore dei trucchi.\n\nHai creato un nuovo trucco? Visita:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Nessuna immagine disponibile</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Seriale: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Versione: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Dimensione: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Seleziona File Trucchi:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Archivio:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Scarica trucchi</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Cancella File</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Nessun file selezionato.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Puoi cancellare i trucchi che non vuoi utilizzare dopo averli scaricati.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Vuoi cancellare il file selezionato?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Seleziona File Patch:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Scarica Patch</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Trucchi</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Patch</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Nessuna patch selezionata.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Impossibile aprire il file .json per la lettura.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Nessun file patch trovato per il seriale selezionato.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Impossibile aprire il file per la lettura.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Impossibile aprire il file per la scrittura.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Analisi XML fallita: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Opzioni salvate con successo.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Fonte non valida</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>La fonte selezionata non è valida.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Il file esiste già </translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Il file è già presente. Vuoi sostituirlo?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Salvataggio file fallito:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Scaricamento file fallito:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Trucchi non trovati</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Non sono stati trovati trucchi per questa versione del gioco nell&apos;archivio selezionato, prova un altro archivio o una versione diversa del gioco.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Trucchi scaricati con successo!</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Hai scaricato con successo i trucchi per questa versione del gioco dall&apos;archivio selezionato. Puoi provare a scaricare da un altro archivio, se disponibile, puoi anche utilizzarlo selezionando il file dall&apos;elenco.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Salvataggio fallito:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Impossibile scaricare:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Scaricamento completo</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Patch scaricata con successo! Vengono scaricate tutte le patch disponibili per tutti i giochi, non è necessario scaricarle singolarmente per ogni gioco come nel caso dei trucchi. Se la patch non appare, potrebbe essere che non esista per il numero di serie e la versione specifica del gioco.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Impossibile analizzare i dati JSON dall&apos;HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Impossibile recuperare la pagina HTML.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Il gioco è nella versione: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>La patch scaricata funziona solo sulla versione: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Potresti aver bisogno di aggiornare il tuo gioco.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Avviso di incompatibilità</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Impossibile aprire file:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>ERRORE XML:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Impossibile aprire i file .json per la scrittura</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Autore: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>La cartella non esiste:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Impossibile aprire i file .json per la lettura.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nome:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Non è possibile applicare i trucchi prima dell&apos;inizio del gioco.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Aggiornamento automatico</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Errore di rete:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>L&apos;Aggiornamento Automatico consente fino a 60 controlli di aggiornamento all&apos;ora.\nHai raggiunto questo limite. Riprova più tardi.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Impossibile analizzare le informazioni di aggiornamento.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Nessuna anteprima trovata.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nessun URL di download trovato per l&apos;asset specificato.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>La tua versione è già aggiornata!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versione attuale</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Ultima versione</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Vuoi aggiornare?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostra il Changelog</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Controlla aggiornamenti all’avvio</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aggiorna</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Nascondi il Changelog</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Modifiche</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Si è verificato un errore di rete durante il tentativo di accesso all&apos;URL</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Download Completato</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>L&apos;aggiornamento è stato scaricato, premi OK per installare.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Impossibile salvare il file di aggiornamento in</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Inizio Aggiornamento...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Impossibile creare il file di script di aggiornamento</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Aggiornamento Automatico - Interfaccia</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Aggiornamento Disponibile - Interfaccia</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Recuperando dati di compatibilità, per favore attendere</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Caricamento...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Impossibile aggiornare i dati di compatibilità! Riprova più tardi.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Impossibile aprire compatibility_data.json per la scrittura.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Sconosciuto</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Niente</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Si Avvia</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menu</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>In gioco</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Giocabile</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configura Comandi</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Croce direzionale</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Su</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Sinistra</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Destra</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Giù</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Levetta Sinistra</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Selezione Configurazione</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configurazione Comune</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Usa configurazioni per gioco</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Pulsanti Frontali</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Levetta Destra</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Regolazione Colore</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Sostituisci Colore Lightbar</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Sostituisci Colore</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Impossibile Salvare</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Impossibile associare i valori degli assi più di una volta</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Ripristina Impostazioni Predefinite</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>non mappato</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opzioni</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad Sinistra</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Touchpad Centrale</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad Destra</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangolo</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrato</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Cerchio</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Croce</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Non è possibile associare più di una volta qualsiasi input univoco. Sono presenti input duplicati mappati ai seguenti pulsanti:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Premi un pulsante</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Muovi levetta analogica</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 e L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Gamepad Attivo</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>ID Gamepad</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Gamepad Predefinito</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Nessun predefinito selezionato</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>n/a</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Imposta Gamepad Attivo come Predefinito</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Rimuovi Gamepad Predefinito</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 e R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Controller Predefinito Selezionato</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Controller attivo impostato come predefinito</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Controller Predefinito Rimosso</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Impostazione predefinita del controller rimossa</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>ROSSO</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>VERDE</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>BLU</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Zona Morta Levetta Sinistra</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Minimo Zona Morta (def:2 max:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Massimo Zona Morta (def:127 max:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Zona Morta Levetta Destra</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Suggerimento: Rimuovi le mappature con il tasto destro del mouse</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Gestore Chiavi Crittografiche</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Chiave Trofei: Usata per decrittare i trofei.
Deve essere una stringa esadecimale valida con lunghezza pari.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Inserisci Chiave Trofei</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Chiave Trofei:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Stato: non caricato</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Chiave Trofei</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Inserisci %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Esponente1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Esponente2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Esponente Pubblico</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Coefficiente</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Modulo</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Prime 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Prime 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Esponente Privato</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Simula Keyset</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>Componenti chiave RSA per la simulazione della firma.
Tutti i campi devono essere stringhe esadecimali valide con lunghezza uniforme.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Debug Rif Keyset</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>Componenti chiave RSA per il debug dei file RIF.
Tutti i campi devono essere stringhe esadecimali valide con lunghezza uniforme.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Pkg Derivato Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>Componenti chiave RSA per la decrittazione dei pacchetti.
Tutti i campi devono essere stringhe esadecimali valide con lunghezza uniforme.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Attenzione</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>Nessun file chiave trovato o caricamento fallito.
Inserisci le chiavi e salvale.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Errore di Validazione</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Chiavi salvate con successo!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Impossibile salvare le chiavi!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Stato: Tutti i campi vuoti</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Stato: valori esadecimali non validi</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Stato: Incompleto</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Status: Valid</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>File non valido</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Sono supportati solo i file JSON.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Impossibile aprire il file.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Errore JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Formato JSON non valido.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Chiavi caricate con successo dal JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>La chiave dei trofei contiene un esadecimale non valido o con una lunghezza dispari.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 contiene esadecimale non valido o ha una lunghezza dispari.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Carica Chiave</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Salva Chiave</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Modifica le associazioni di input di tastiera + mouse e controller</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Usa Configurazioni Per Gioco</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Impossibile aprire il file per la lettura</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Impossibile aprire il file per la scrittura</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Salva Modifiche</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Vuoi salvare le modifiche?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Aiuto</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Vuoi reimpostare la configurazione predefinita personalizzata alla configurazione predefinita originale?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Vuoi reimpostare questa configurazione alla configurazione predefinita personalizzata?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Ripristina a Predefinito</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Apri Cartella</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Caricamento lista giochi, attendere :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Caricamento...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Scegli cartella</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Sfoglia</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Cartella per installare le versioni dell'emulatore</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Cartella con i tuoi giochi scaricati</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Cartella con i tuoi DLC scaricati</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Cartella con giochi</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Cartella con DLC</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Icona</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Seriale</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Compatibilità</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Regione</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Firmware</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Dimensione</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versione</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Percorso</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Tempo di Gioco</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Mai Giocato</translation>
    </message>
    <message>
      <source>h</source>
      <translation>o</translation>
    </message>
    <message>
      <source>m</source>
      <translation>m</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Nessuna informazione sulla compatibilità</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Il gioco non si avvia in modo corretto / forza chiusura dell&apos;emulatore</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Il gioco si avvia, ma mostra solo una schermata nera</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Il gioco mostra immagini ma non va oltre il menu</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Il gioco ha problemi gravi di emulazione oppure framerate troppo basso</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Il gioco può essere completato con buone prestazioni e senza problemi gravi</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Fai clic per vedere i dettagli su GitHub</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Ultimo aggiornamento</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Preferiti</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Trucchi / Patch</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>Visualizzatore SFO</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizzatore Trofei</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Apri Cartella...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Apri Cartella del Gioco</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Apri Cartella dei Dati di Salvataggio</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Apri Cartella dei Log</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Copia informazioni...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Copia Nome</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Copia Seriale</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Copia Versione</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Copia Dimensione</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Copia Tutto</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Elimina...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Elimina Gioco</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Elimina Aggiornamento</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Elimina DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Elimina Trofei</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Compatibilità...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Gioco</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Questo gioco non ha alcun aggiornamento da eliminare!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aggiornamento</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Questo gioco non ha alcun DLC da eliminare!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Elimina %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Sei sicuro di eliminale la cartella %2 di %1?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Apri Cartella Aggiornamento</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Elimina Dati Salvataggio</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Questo gioco non ha nessuna cartella di aggiornamento da aprire!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Nessun file di log trovato per questo gioco!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Questo gioco non ha alcun salvataggio dati da eliminare!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Questo gioco non ha nessun trofeo salvato da eliminare!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Dati Salvataggio</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofei</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>Visualizzatore SFO per </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Rimuovi dai Preferiti</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Aggiungi ai preferiti</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Impostazioni specifiche del gioco...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Configura Impostazioni Specifiche del Gioco</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Crea impostazioni specifiche per il gioco dalle Impostazioni Globali</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Cancella Impostazioni Specifiche del Gioco</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Aggiorna Database</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Visualizza Rapporto</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Invia Rapporto</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Conferma eliminazione</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Cancella Impostazioni Specifiche del Gioco?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Avvia...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Avvia con configurazioni specifiche del gioco (predefinito)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Avvia solo con configurazione globale</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Avvia con le impostazioni predefinite</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Impossibile inviare un rapporto, perché l'ultimo log per il gioco non ha superato il controllo seguente, e quindi genererebbe un rapporto non valido:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Crea Scorciatoia per la Versione dell'Emulatore Selezionato</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Crea Scorciatoia per la Versione dell'Emulatore Specificato</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Crea scorciatoia</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Creazione scorciatoia</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Scorciatoia creata con successo!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Errore nella creazione della scorciatoia!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Impossibile convertire l'icona.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Elimina Cache degli Shader</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Questo gioco non ha alcuna Cache Shader salvata da eliminare!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Cache Shader</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Questo gioco non ha alcuna cartella di dati di salvataggio da aprire!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>È necessaria una chiave trofei per utilizzare il Visualizzatore Trofei. La chiave può essere inserita facendo clic su Impostazioni - Gestisci Chiavi Crittografiche.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Avvio rapido</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>FAQ</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Sintassi</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Associazioni Speciali</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Associazioni dei pulsanti</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalizza Scorciatoie</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Mostra Contatore FPS</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>non mappato</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Abbandona Emulazione</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Ricarica Mappatura Pulsanti</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Attiva/Disattiva Schermo Intero</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Attiva/Disattiva Pausa</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Attiva/disattiva l'emulazione dal Mouse al Joystick</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Attiva/disattiva l'emulazione dal Mouse al Giroscopio</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Suggerimento: Per ogni scorciatoia possono essere assegnati fino a tre comandi contemporaneamente</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Ripristina Impostazioni Predefinite</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Impossibile Salvare</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Non è possibile associare più di una volta qualsiasi input univoco. Sono presenti input duplicati mappati ai seguenti pulsanti:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>In attesa di input</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Suggerimento: Rimuovi le mappature con il tasto destro del mouse</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Alza Volume</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Abbassa volume</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Scorciatoie</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Nome Provvisorio</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Cattura Screenshot</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Cattura Screenshot con Sovrimpressioni</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Apri Impostazioni Emulatore</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Impossibile trovare l'eseguibile dell'emulatore</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>Nessun gioco in esecuzione</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configura Comandi</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>non mappato</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Modalità Mezzo Analogico Sinistra</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Selezione Configurazione</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configurazione Comune</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Usa configurazioni per gioco</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Editor Testuale</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Aiuto</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Mouse a Joystick</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*premere F7 in gioco per attivare</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opzioni</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Parametri Movimento Del Mouse</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>nota: cliccare sul Pulsante Aiuto/Associazioni Speciali dei Tasti per maggiori informazioni</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangolo</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrato</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Cerchio</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Croce</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Modalità Mezzo Analogico Destra</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Scostamento Velocità (def 0,125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Copia da Configurazione Comune</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Scostamento Zona Morta (def 0,50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Moltiplicatore Di Velocità (def 1,0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Copia valori da Configurazione Comune</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Vuoi sovrascrivere le mappature esistenti con le mappature dalla Configurazione Comune?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Impossibile Salvare</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Premi un tasto</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Impossibile impostare la mappatura</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>La rotella del mouse non può essere associata ai comandi della levetta analogica</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Ripristina Impostazioni Predefinite</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Non è possibile associare più di una volta qualsiasi input univoco. Sono presenti input duplicati mappati ai seguenti pulsanti:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad Sinistra</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Touchpad Centrale</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad Destra</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Suggerimento: Rimuovi le mappature con il tasto destro del mouse</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Uscita</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Input</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Input Alternativo 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Input Alternativo 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Croce Direz. Su</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Croce Direz. Giù</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Croce Direz. Sinistra</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Croce Direz. Destra</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Levetta Sinistra Su</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Levetta Sinistra Giù</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Levetta Sinistra  Sinistra</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Levetta Sinistra Destra</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Levetta Destra Su</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Levetta Destra Giù</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Levetta Destra Sinistra</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Levetta Destra Destra</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Preimpostazioni Filtro del Log</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Commento</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtro</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Aggiunge una nuova preimpostazione dopo la riga selezionata</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Rimuovi la preimpostazione selezionata</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Carica la preimpostazione selezionata</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Apri/Aggiungi cartella Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Avvia Gioco</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Controlla aggiornamenti</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>Riguardo a shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Configura...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Giochi Recenti</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Apri Cartella shadps4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Uscita</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Esci da shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Esci dall&apos;applicazione.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Mostra Lista Giochi</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Aggiorna Lista Giochi</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Minuscolo</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Piccolo</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Medio</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Grande</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Visualizzazione Lista</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Visualizzazione Griglia</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Visualizzatore Elf</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Cartella Installazione Giochi</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Scarica Trucchi/Patch</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Scarica Lista Giochi</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizzatore Trofei</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Nessun gioco trovato. Aggiungi prima i tuoi giochi alla tua libreria.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Cerca...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>File</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Visualizza</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Icone Lista Giochi</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Modalità Lista Giochi</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Utilità</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Temi</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Aiuto</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Scuro</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Chiaro</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blu</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Viola</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Barra strumenti</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Elenco giochi</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Scarica Trucchi per tutti i giochi installati</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Scarica Patch per tutti i giochi</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Download completato</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Hai scaricato trucchi per tutti i giochi installati.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Patch scaricate con successo!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Tutte le patch disponibili per tutti i giochi sono state scaricate.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Giochi: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>File ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Avvia Gioco</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Si può selezionare solo un file!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Esegui Gioco</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>File Eboot.bin non trovato</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Il gioco è già in esecuzione!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Riproduci</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausa</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Arresta</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Riavvia</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Schermo Intero</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Controller</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Tastiera</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Aggiorna Lista</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Riprendi</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Mostra Etichette Sotto Icone</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalizza Scorciatoie</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Gestore Versione</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nessuna Versione Selezionata</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Non è stata selezionata nessuna versione di emulatore.
Il menu Gestione Versioni verrà aperto ora.
Seleziona una versione di emulatore dal pannello a destra.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Impossibile trovare l'eseguibile dell'emulatore</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Esegui Emulatore</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>L'emulatore è già in esecuzione!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Argomento di gioco fornito non valido</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Gestisci Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Gestisci Statuette Infinity</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Gestisci Toy Pad Dimensions</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Registro di gioco</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Mostra Registro Di Gioco</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Gestisci Chiavi Crittografiche</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Gestione utenti</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Unità Bloccata</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>L' unità %1: è bloccata. Inserisci la chiave BitLocker per accedervi:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>Chiave di recupero errata. Per favore riprova.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Impostazioni</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Generale</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Sistema</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Lingua della console</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Scheda predefinita all&apos;apertura delle impostazioni</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Abilita Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofei</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Apri la cartella personalizzata delle immagini/suoni dei trofei</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Registro</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Tipo di Log</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Filtro Log</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Apri posizione del registro</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Input</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Cursore</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Nascondi Cursore</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Timeout inattività per nascondere il cursore</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Periferica Predefinita</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Controller</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafica</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Utente</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Scheda Grafica</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Avanzate</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Abilita Dump Shader</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Abilita NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Abilita HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Percorsi</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Cartelle di gioco</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Aggiungi...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Rimuovi</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Debug</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Abilita Debug Dumping</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Abilita Vulkan Validation Layers</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Abilita RenderDoc Debugging</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Abilita Diagnostica Crash</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Raccogli Shaders</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Copia Buffer GPU </translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Marcatori di Debug dell&apos;Host </translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Marcatori di Debug del Guest </translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Abilita Immagini Lineari Di Readback</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Verifica aggiornamenti all’avvio</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Mostra sempre il changelog</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Controlla aggiornamenti</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Musica del Titolo</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Disabilita Notifiche Trofei</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Immagine di Sfondo</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Mostra l'Immagine dello Sfondo</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Opacità</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Riproduci musica del titolo</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Aggiorna Database Compatibilità all&apos;Avvio</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Compatibilità Gioco</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Mostra Dati Compatibilità</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Aggiorna Database Compatibilità</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Volume</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salva</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Applica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Ripristina Impostazioni Predefinite</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Chiudi</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Sposta il mouse su un&apos;opzione per visualizzarne la descrizione.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Lingua della Console:\nImposta la lingua utilizzata dal gioco PS4.\nÈ consigliabile impostare questa su una lingua supportata dal gioco, che può variare a seconda della regione.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Lingua dell&apos;Emulatore:\nImposta la lingua dell&apos;interfaccia utente dell&apos;emulatore.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Mostra Schermata di Avvio:\nMostra la schermata di avvio del gioco (un&apos;immagine speciale) mentre il gioco si sta avviando.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Abilita Discord Rich Presence:\nMostra l&apos;icona dell&apos;emulatore e informazioni pertinenti sul tuo profilo Discord.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Immagine di sfondo:\nControlla l'opacità dell'immagine di sfondo del gioco.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Riproduci Musica del Titolo:\nSe un gioco lo supporta, attiva la riproduzione di musica speciale quando selezioni il gioco nell&apos;interfaccia grafica.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Disabilita Notifica Trofei:\nDisabilita notifiche in gioco dei trofei. Il progresso dei Trofei può ancora essere controllato con il Visualizzatore Trofei (clicca tasto destro sul gioco nella finestra principale).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Nascondi cursore:\nScegli quando il cursore scomparirà:\nMai: Vedrai sempre il mouse.\nInattivo: Imposta un tempo per farlo scomparire dopo essere stato inattivo.\nSempre: non vedrai mai il mouse.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Imposta un tempo affinché il mouse scompaia dopo essere stato inattivo.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Mostra Dati Compatibilità:\nMostra informazioni sulla compatibilità del gioco nella visualizzazione lista. Abilita &quot;Aggiorna Compatiblità all&apos;Avvio&quot; per ottenere informazioni aggiornate.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Aggiorna Compatibilità all&apos;Avvio:\nAggiorna automaticamente il database della compatibilità quando si avvia shadps4.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Aggiorna Database Compatibilità:\nAggiorna immediatamente il database di compatibilità.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Mai</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Inattivo</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Sempre</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Dispositivo Grafico:\nIn sistemi con più GPU, seleziona la GPU che l&apos;emulatore utilizzerà dall&apos;elenco a discesa,\no seleziona &quot;Selezione Automatica&quot; per determinarlo automaticamente.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Larghezza/Altezza:\nImposta la dimensione della finestra dell&apos;emulatore all&apos;avvio, che può essere ridimensionata durante il gioco.\nQuesto è diverso dalla risoluzione in gioco.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Abilita HDR:\nAbilita HDR nei giochi che lo supportano.\nIl tuo monitor deve avere il supporto per lo spazio colore BT2020 PQ e il formato swapchain RGB10A2.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Cartelle di Gioco:\nL&apos;elenco delle cartelle da controllare per i giochi installati.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Aggiungi:\nAggiungi una cartella all&apos;elenco.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Rimuovi:\nRimuovi una cartella dall&apos;elenco.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Abilita Pompaggio di Debug:\nSalva i simboli di importazione ed esportazione e le informazioni sull&apos;intestazione del file del programma PS4 attualmente in esecuzione in una directory.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Abilita Debugging RenderDoc:\nSe abilitato, l&apos;emulatore fornirà compatibilità con Renderdoc per consentire la cattura e l&apos;analisi del frame attualmente reso.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Raccogli Shader:\nBisogna attivare questa opzione per poter modificare gli shader nel menu di debug (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Abilita le immagini lineari di Readback:\nConsente il download asincronico delle immagini lineari modificate dalla GPU.\nPotrebbe risolvere problemi grafici in alcuni giochi.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Copia Buffer GPU:\nCerca di aggirare le race conditions che riguardano gli invii alla GPU.\nPotrebbe aiutare ad evitare crash che riguardano i PM4 di tipo 0.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcatori di Debug dell&apos;Host:\nInserisce nel log informazioni ottenute dall&apos;emulatore come ad esempio marcatori per comandi specifici AMDGPU quando si hanno comandi Vulkan e associa nomi di debug per le risorse.\nSe hai questa opzione abilitata dovresti abilitare anche Diagnostica Crash.\nUtile per programmi come RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcatori di Debug del Guest:\nInserisce nel log marcatori di debug che il gioco stesso ha aggiunto al buffer dei comandi.\nSe hai abilitato questa opzione dovresti abilitare anche Diagnostica Crash.\nUtile per programmi come RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Imposta il volume della musica di sottofondo.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Abilita Controlli Di Movimento</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Sfoglia</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Selezione Automatica</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Cartella di installazione dei giochi</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Video</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Modalità di visualizzazione</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>In finestra</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Schermo Intero</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Schermo Intero (Senza Bordi)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Dimensione Finestra</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>L:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>A:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>File Di Registro Separati</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>File di registro separati:\nScrive un file di registro separato per ogni gioco.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Posizione Notifica Trofei</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Sinistra</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Destra</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>In alto</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>In basso</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Durata Notifica</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Cartella Utente Portatile</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Crea una Cartella Utente Portatile dalla Cartella Comune Utente</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Cartella utente portatile:\nMemorizza le impostazioni e i dati shadPS4 che saranno applicati solo alla build shadPS4 situata nella cartella attuale. Riavviare l'applicazione dopo aver creato la cartella utente portatile per iniziare a usarla.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1: esiste già</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 creato con successo.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Apri la cartella personalizzata delle immagini/suoni trofei:\nÈ possibile aggiungere immagini personalizzate ai trofei e un audio.\nAggiungi i file a custom_trophy con i seguenti nomi:\ntrophy.wav OPPURE trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNota: Il suono funzionerà solo nelle versioni QT.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Funzionalità Sperimentali</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>ATTENZIONE: Queste funzionalità sono sperimentali e non dovrebbero essere abilitate a meno che non sia stato indicato o che un gioco lo richieda. Si prega di chiedere informazioni nel server Discord shadPS4 se si è in dubbio.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Abilita Input del Controller in Secondo Piano</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Abilita Input del Controller in Secondo Piano:\nPermette a shadPS4 di ricevere comandi dal controller quando la finestra di gioco non è in primo piano.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Diagnostica Crash:\nCrea un file .yaml che contiene informazioni riguardo lo stato del renderer Vulkan nel momento in cui si verifica un crash.\nUtile per poter effettuare il debug degli errori di tipo &apos;Device Lost&apos;. Se hai questa opzione attiva dovresti abilitare anche Marcatori di Debug Host e Guest. \nVulkan Validation Layers deve essere abilitato e bisogna aver installato l&apos;SDK Vulkan per poter utilizzare questa funzione.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Abilita Logging</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Abilita Logginge:\nAbilita il log.\nNon cambiarlo se non sai cosa stai facendo!\nQuando chiedi supporto, assicurati che questa impostazione sia abilitata.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Modalità Presentazione</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Immediato (Vsync Disabilitato)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Seleziona la cartella DLC</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Modalità presentazione:\nConfigura come sarà presentato l'output video a schermo.\n\nMailbox: i frame si sincronizzano con la frequenza di aggiornamento dello schermo. I nuovi frame sostituiranno tutti i frame in sospeso. Riduce la latenza, ma può saltare frame se l'esecuzione del rendering è lenta.\nFifo: i frame si sincronizzano con la frequenza di aggiornamento del tuo schermo. I nuovi frame saranno accodati dietro i frame in sospeso. Assicura che tutti i fotogrammi siano presentati, ma potrebbe aumentare la latenza.\nImmediato: i fotogrammi sono immediatamente presentati sullo schermo quando sono pronti. Può causare tearing.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Esplora:\nEsplora una cartella da impostare come percorso dati DLC.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>Impostazioni FSR</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Abilita FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>Abilita RCAS (nitidezza)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>Attenuazione RCAS:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Carica preimpostazione...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Log</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Apri la posizione del Log:\nApri la cartella in cui viene salvato il file di registro.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Microfono:\nNessuno: Non utilizza il microfono.\nDispositivo predefinito: Utilizzerà il dispositivo predefinito del sistema.\nO scegli manualmente il microfono da usare dall'elenco.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Volume:\nRegola il volume dei giochi a livello globale, il valore va dallo 0-500% con valore predefinito al 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Scheda predefinita quando si aprono le impostazioni:\nScegli quale scheda verrà aperta, il valore predefinito è Generale.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Abilita Motion Control:\nQuando abilitato utilizzerà il Motion Control del controller se supportato dal gioco.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Frequenza Vblank</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Frequenza Vblank:\nIl frame rate col quale l'emulatore si aggiorna (60 Hz è l'impostazione predefinita, sia che il gioco giri a 30 o 60 fps). Cambiare questa impostazione potrebbe avere effetti avversi, come aumento della velocità del gioco o malfunzionamento di funzionalità critiche dei giochi che non prevedono questa modifica!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Abilita Accesso Diretto Alla Memoria</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Abilita Modalità Console Devkit</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Imposta &quot;accesso PSN&quot; come Abilitato</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Imposta &quot;Connessione di Rete&quot; come Abilitato</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Varie</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Interfaccia</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Sperimentale</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Mostra Schermata Iniziale quando si Avvia un Gioco</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Impostazioni Generali Interfaccia</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>Abilita Modalità PS4 Pro</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Abilita Accesso Diretto alla Memoria:\nConsente l'accesso arbitrario alla memoria dalla GPU a quella della CPU.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>Abilita la modalità Ps4 Pro:\nAggiunge il supporto per l'emulazione di PS4 Pro e della memoria della stessa modalità. Attualmente causa instabilità in un gran numero di giochi testati.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Abilita Modalità Console Devkit:\nAggiunge il supporto per la dimensione della memoria console Devkit.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Imposta Connessione alla Rete come Abilitata:\nForza i giochi a rilevare una connessione di rete attiva. Le funzionalità online non sono ancora supportate.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Imposta Connessione al PSN come Abilitata:\nForza i giochi a rilevare una connessione al PSN attiva. Le funzionalità PSN non sono ancora supportate.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Abilita Livelli di Validazione Vulkan:\nAbilita un sistema che convalida lo stato del renderer Vulkan e registra le informazioni sul suo stato interno.\nQuesto ridurrà le prestazioni e probabilmente cambierà il comportamento dell'emulazione.\nHa bisogno dell'SDK Vulkan per funzionare.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Dispositivo Audio (Generale)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Dispositivo Audio (altoparlante DS4)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Abilita Scaricamento Shader:\nPer scopi di debug tecnico, salva gli shader dei giochi in una cartella mentre vengono renderizzati.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>Abilita GPU Null:\nPer scopi di debug tecnico, disabilita il rendering del gioco come se non ci fosse alcuna scheda grafica. La schermata non mostrerà nessun elemento grafico.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>Percorso DLC:\nLa cartella da cui sono caricati i dati DLC.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Assegnazione DMem Aggiuntiva</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Allocazione DMem aggiuntiva:\nForza l'allocazione della quantità specificata di DMem. Può causare blocchi o problemi in alcuni giochi.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>Percorso Moduli di Sistema PS4:\nLa cartella da cui vengono caricati i moduli di sistema PS4.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Esplora:\nEsplora una cartella da impostare come percorso dei moduli di sistema.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Validazione Vulkan (Richiede Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Validazione Livelli</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Abilita Validazione di Base</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Abilita Validazione Sincronizzata</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Abilita Validazione Assistita dalla GPU</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Abilita Validazione Sincronizzata Vulkan:\nAbilita un sistema che convalida il timing delle attività di rendering Vulkan.\n Ciò ridurrà le prestazioni e probabilmente cambierà il comportamento dell' emulazione.\n Ha bisogno dell'SDK Vulkan per funzionare.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Abilita Validazione di Base:\nAbilita le principali funzioni di convalida API.\nQuesto ridurrà le prestazioni e probabilmente cambierà il comportamento dell'emulazione.\nHai bisogno dell'SDK Vulkan per funzionare.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Abilita Validazione Assistita dalla GPU:\nFornisce agli shader codici di funzionalità per validare se gli shader stanno funzionando correttamente.\nQuesto ridurrà le prestazioni e potrebbe influire sul comportamento dell'emulazione. \nHa bisogno del SDK Vulkan per poter funzionare.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Lingua Interfaccia</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Aggiornamenti Interfaccia</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>Percorso DLC</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>Percorso Moduli di Sistema PS4</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Aggiornamenti Interfaccia:\nRilascio: Versioni ufficiali rilasciate ogni mese che possono essere molto obsolete, ma sono più affidabili e testate.\nNotturno: Le versioni di sviluppo che hanno tutte le ultime funzionalità e correzioni, ma possono contenere bug e sono meno stabili.\n\n*Questo aggiornamento si applica solo all'interfaccia utente Qt. Per aggiornare il nucleo dell'emulatore, utilizzare il menu &apos;Gestore Versione&apos;.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>Impossibile creare la cartella di lancio portatile</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>Cartella di lancio portatile creata</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>Dispositivo USB</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Dispositivo Usb Reale</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Portale Skylander</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Base Infinity</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Toy Pad Dimensions</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>Dispositivo USB:\nDispositivo USB reale: Usa un vero Dispositivo USB collegato al sistema.\nPortale Skylander: Emula un Portale del Potere Skylander.\n Base Infinity: Emula una Base Disney Infinity.\nToy Pad Dimensions: Emula un Toy Pad Lego Dimensions.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Abilita Cache Shader</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Comprimi i file della Cache Shader in un file zip</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Abilita Cache Shader:\nArchivia gli shader compilati per evitare le ricompilazioni, riduce gli scatti.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Comprimi i file della Cache Shader in un file zip:\nI file della cache shader sono memorizzati in un singolo file zip invece di più file separati.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Modalità Readback</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Disabilitato</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Abilita Readback:\nAbilita letture di memoria GPU e riscritture.\nQuesta impostazione è necessaria per un comportamento corretto in alcuni giochi.\nPotrebbe causare problemi di stabilità e/o prestazioni.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Rilassata</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Accurata</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Seleziona il Percorso Principale di shadPS4</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Seleziona la cartella dei moduli di sistema</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Posizione Cartella Principale (Salvataggi, Comandi, Dati Trofei)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Posizione Cartella Principale:\nLa cartella dove i salvataggi dei dati, i file trofei e le configurazioni di input sono memorizzati per tutti gli utenti.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Esplora:\nEsplora una cartella da impostare come percorso principale.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Audio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Backend Audio</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Dispositivo Mic</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Dispositivi</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Camera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Sincronizzazione Registro</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Salta Duplicato Registro</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Durata Massima Salto Registro</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Limite Dimensione Registro</translation>
    </message>
    <message>
      <source> B</source>
      <translation> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Aggiungi Al Registro</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Aggiungi al Registro:\nAggiungi ai registri esistenti.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Durata Massima Salto Registro:\nIntervallo senza scrivere le stesse righe (in ms) - solo se &apos; Salta Duplicato Registro&apos; è abilitato.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Limite Dimensione Registro:\nDimensione massima dei file di registro (in byte).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Salta Duplicato Registro:\nRisparmia spazio evitando di scrivere linee di registro identiche.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Sincronizzazione Registro:\n Cambia tra sincrono (ordine) o asincrono (prestazioni).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Tipo di Registro:\nScegli tra i tipi di registro wincolor o msvc.\nwincolor: Registrazione predefinita per Windows\nmsvc: Registrazione per il debug</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Filtro Registro:\nFiltra il registro per stampare solo informazioni specifiche.\nEsempi: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\n Livelli: trace, debug, info, warning, error, critical - in questo ordine, un livello specifico silenzia tutti i livelli precedenti nell'elenco e registra ogni livello successivo.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Seleziona Versione</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Seleziona la versione per la creazione della scorciatoia</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nessuna Versione Selezionata</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Seleziona prima una versione</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizzatore Trofei</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Seleziona Gioco:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Progresso</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Mostra Trofei Guadagnati</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Mostra Trofei Non Guadagnati</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Mostra Trofei Nascosti</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Seleziona Utente:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Gestore utenti</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>&amp;Crea Utente</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>&amp;Elimina Utente</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>&amp;Rinomina Utente</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Imposta Utente Predefinito</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>&amp;Imposta Colore</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Imposta Porta Controller</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Chiudi</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>Impossibile aggiungere ulteriori utenti.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Crea Nuovo Utente</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>Nuovo ID Utente: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Nome utente (3–16 caratteri, lettere, numeri, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Nome utente non valido</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>Il nome utente deve contenere 3-16 caratteri validi.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Conferma Cancellazione</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Eliminare l'ID utente %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Rinomina Utente</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Vecchio Nome Utente: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Imposta Colore Utente</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Seleziona colore:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Imposta Porta Controller</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Assegna la porta (1-4) a questo utente:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Apri Cartella Utente</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Gestore Versione</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Percorso per salvare le versioni</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Sfoglia</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Installato</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Selezionato</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versione</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Nome in codice</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Aggiungi Personalizzato</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Elimina</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Aggiorna Lista</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Scarica</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Controlla gli aggiornamenti Pre-rilascio all'avvio</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Controlla Aggiornamenti Pre-rilascio</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Selezionare la cartella in cui verranno installate le versioni dell'emulatore</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Seleziona eseguibile</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Eseguibile (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Nome della versione</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Inserisci il nome di questa versione come appare nella lista.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Errore</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Successo</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>Versione aggiunta con successo.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Impossibile determinare il percorso della cartella.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Elimina versione</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Vuoi eliminare la versione</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Aggiornamento elenco versioni</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>Nessuna novità, l'elenco delle versioni è già aggiornato.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>Le ultime versioni sono state aggiunte alla lista per il download.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Errore di accesso all'API GitHub</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Per prima cosa è necessario scegliere una posizione dove salvare le versioni
&apos;Percorso per salvare le versioni&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Vuoi scaricare la versione</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Nessun file disponibile per questa piattaforma.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Scaricamento %1 , attendere prego...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Impossibile salvare il file.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>La versione %1 è stata scaricata e selezionata.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Creazione dello script di estrazione zip non riuscita</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>La risposta dell'API GitHub non è un array JSON valido.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Aggiornamento Automatico - Emulatore</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>Hai già l'ultima versione pre-rilascio.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Aggiornamento Disponibile (Emulatore)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versione Attuale</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Ultima Versione</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Vuoi aggiornare?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aggiornamento</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostra il Changelog</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Nascondi il Changelog</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Errore di rete durante il recupero del changelog</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Modifiche</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nessun URL di download trovato per l'asset specificato.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Errore di rete durante il download</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Impossibile salvare il file di download</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Installazione completa</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>Versione Pre-rilascio aggiornata con successo</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Impossibile creare il file di script di aggiornamento</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Mostra sempre il changelog</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Nessuna versione selezionata. Si prega di sceglierne una da eliminare dall'elenco.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Conferma Download</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Errore di estrazione.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Esiste già una versione con questo nome.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Locale</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Impossibile determinare la cartella da rimuovere.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Impossibile eliminare la cartella.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>Impossibile ottenere l'hash dell'ultima versione pre-rilascio.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Scaricamento versione Pre-rilascio (Nightly), attendere prego...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Gestore Dimensions</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Statuette Dimensions Attive:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Sposta</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Statuetta Sconosciuta</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Seleziona File Dimensions</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Statuetta Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Impossibile aprire il file statuetta!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Apertura del file statuetta (%1) non riuscita!
Il file potrebbe essere già in uso sulla base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Lettura del file statuetta non riuscita!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Lettura del file statuetta (%1) non riuscita!
Il file è troppo piccolo.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Creatore Statuette</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Filtra per Serie:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Tutti</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Sconosciuto--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Numero Statuetta:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Serie:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Errore nella conversione del valore</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Il numero della statuetta inserito non è valido!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>Il numero di serie inserito non è valido!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Crea File Statuetta</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Statuetta Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Creazione del file statuetta non riuscita!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Creazione del file statuetta non riuscita:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Gestore Infinity</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Statuette Infinity Attive:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>Riproduci Set/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>Power Disc Due</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>Power Disc Tre</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Giocatore Uno</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Giocatore Uno Abilità Uno</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Giocatore Uno Abilità Due</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Giocatore Due</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Giocatore Due Abilità Uno</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Giocatore Due Abilità Due</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Statuetta Sconosciuta</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Seleziona File Infinity</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Statuetta Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Impossibile aprire il file statuetta!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Apertura del file statuetta (%1) non riuscita!
Il file potrebbe essere già in uso sulla base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Lettura del file statuetta non riuscita!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Lettura del file statuetta (%1) non riuscita!
Il file è troppo piccolo.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Creatore Statuette</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Sconosciuto--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Numero Statuetta:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Errore nella conversione del valore</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Il numero della statuetta inserito non è valido!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Crea File Statuetta</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Statuetta Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Creazione file minifig non riuscita!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Impossibile Creare file minifig:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Spostamento Statuetta</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Sposta qui</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Prendi e Posiziona</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Creatore Skylander</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Sconosciuto--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Variante:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Annulla</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Errore nella conversione del valore</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>ID inserito non valido!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>La variante inserita non è valida!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Crea File Skylander</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Oggetto Skylander (*.sky);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Creazione del file skylander fallita!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Creazione del file skylander non riuscita:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Gestore Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Portali Skylanders Attivo:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Cancella</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carica</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Seleziona File Skylander</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Tutti i File (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Impossibile aprire il file skylander!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Apertura del file Skylander (%1) non riuscita!
Il file potrebbe essere già in uso sul portale.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Lettura del file skylander fallita!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Lettura del file Skylander (%1) non riuscita!
Il file è troppo piccolo.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Sconosciuto (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nessuno</translation>
    </message>
  </context>
</TS>
