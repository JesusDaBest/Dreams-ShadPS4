<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="ca_ES" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>Sobre shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 és un emulador experimental de codi obert de la PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Aquest programari no s'hauria de fer servir per jugar jocs que no has obtingut legalment.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Trucs / Correccions per </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Els trucs i les correccions són experimentals.\nFes-les servir amb precaució.\n\nDescarrega trucs individualment seleccionant el repositori i clicant al botó de baixada.\nA la pestanya de correccions, et pots descarregar totes les correccions de cop, escull quines vols fer servir i desa la selecció.\n\nCom que no desenvolupem ni els trucs ni les correccions,\nhas d'informar de qualsevol problema als seus autors corresponents.\n\nHas creat un nou truc? Visita:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>No hi ha imatge disponible</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Número de sèrie: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Versió: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Mida: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Selecciona el fitxer de trucs:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Repositori:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Descarrega els trucs</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Elimina el fitxer</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>No hi ha cap fitxer seleccionat.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Pots suprimir trucs que no vols abans de descarregar-los.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Estàs segur que vols esborrar el fitxer seleccionat?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Selecciona un fitxer de correcció:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Descarrega les correccions</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Desa</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Trucs</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Correccions</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>No s'ha seleccionat cap correcció.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Error en obrir fitxers .json per modificar-los.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>No s'ha trobat fitxer de correccions pel número de sèrie actual.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>No es pot obrir el fitxer per llegir-lo.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>No es pot obrir el fitxer per modificar-lo.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Error en analitzar XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Realitzat amb èxit</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Opcions desades correctament.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Font no vàlida</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>La font seleccionada no és vàlida.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>El fitxer ja existeix</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Aquest fitxer ja existeix. Estàs segur que el vols reemplaçar?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Error en desar el fitxer:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Error en descarregar el fitxer:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>No s'han trobat els trucs</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>No s'han trobat trucs per aquest joc en aquesta versió del repositori seleccionat, prova-ho amb un altre repositori o amb una versió diferent del joc.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>S'han descarregat els trucs correctament</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Has descarregat correctament els trucs per aquesta versió del joc des d'aquest repositori. Pots provar de descarregar des d'un altre repositori; si està disponible, també pots seleccionar el fitxer des d'una llista.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Error en desar:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Error en la descàrrega:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Descàrrega completa</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Has descarregat les correccions correctament! Totes les correccions disponibles per tots els jocs s'han descarregat, no cal descarregar-les individualment com passa amb els trucs. Si una correcció no apareix, pot ser que no existeixi per aquesta versió o per aquest número de sèrie del joc.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Error en analitzar les dades JSON del HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Error en recuperar la pàgina HTML.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>La versió del joc és: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>La correcció descarregada només funció amb la versió: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Cal actualitzar el joc.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Avís d'incompatibilitat</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Error en obrir el fitxer:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>Error XML:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Error en obrir fitxers .json per modificar-los</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Autor: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Aquesta carpeta no existeix:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Error en obrir fitxers .json per llegir-los.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nom:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>No es poden aplicar trucs abans que s'iniciï el joc</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Tanca</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Actualització automàtica</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Error de xarxa:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>L'actualització automàtica permet fer 60 comprovacions cada hora.\nTu has arribat a aquest límit. Torna a intentar-ho més tard.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Error en analitzar la informació de l'actualització.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>No s'han trobat llançaments previs.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>No s'ha trobat la direcció web de descàrrega.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>La teva versió ja és la més actualitzada!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versió actual</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Última versió</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Estàs segur que vols actualitzar?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostra el registre de canvis</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Comprova les actualitzacions a l'inici</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Actualitza</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Oculta el registre de canvis</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Canvis</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>S'ha produït un error de xarxa en intentar connectar a l'adreça web</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Descàrrega completa</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>S'ha baixat l'actualització, clica OK per instal·lar-la.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Error en desar el fitxer d'actualització a</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Iniciant l'actualització...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Error en crear el fitxer de script d'actualització</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Actualització automàtica - Interfície d'usuari</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Hi ha una actulització disponible - Interfície d'usuari</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Obtenint dades de compatibilitat, espera si us plau</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·la</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Carregant...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>No s'ha pogut actualitzar les dades de compatibilitat! Prova-ho més tard.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>No es pot obrir el fitxer compatibility_data.json per modificar-lo.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Desconegut</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Res</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Executa</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menús</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>En joc</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Jugable</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configura els controladors</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Botons de direcció</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Amunt</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Esquerra</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Dreta</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Avall</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Palanca esquerra</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Configura la selecció</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configuració estàndard</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Fes servir configuracions per cada joc</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Botons d'acció</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Palanca dreta</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Ajust del color</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Canvia el color de la barra de llum</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Reemplaça el color</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>No s'ha pogut desar</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>No es pot vincular els valors de l'eix més d'una vegada</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Desa</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaura als valors predeterminats</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·la</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>sense assignar</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opcions</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad esquerra</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Touchpad centre</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad dreta</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangle</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrat</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Cercle</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Creu</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>No es pot assignar una entrada més d'una vegada. S'han assignat de manera duplicada pels següents botons:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Clica un botó</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Mou la palanca</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 i L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Controlador actiu</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>ID del controlador</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Controlador per defecte</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>No hi ha cap seleccionat per defecte</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>n/a</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Estableix el controlador actual per defecte</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Elimina el controlador per defecte</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 i R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Seleccionat el controlador per defecte</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>El controlador actiu per defecte</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Eliminat el controlador per defecte</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>S'ha eliminat el controlador per defecte</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>VERMELL</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>VERD</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>BLAU</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Zona morta de la palanca esquerra</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Valor mínim de la zona morta (definit:2 màxim:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Valor màxim de la zona morta (definit:127 màxim:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Zona morta de la palanca dreta</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Ajuda: Desassigna les entrades amb el clic dret</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Administrador de claus de criptografia</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Clau de trofeus: Es fa servir per la descripció de trofeus.
Ha de ser un valor hexadecimal amb una longitud parell.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Introdueix una clau de trofeus</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Clau dels trofeus:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Estat: no carregat</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Clau dels trofeus</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Nombre enter %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Exponent1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Exponent2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Exponent públic</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Coeficient</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Mòduls</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Primer 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Primer 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Exponent privat</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Conjunt de claus falses</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>Components de la clau RSA per signatures falses.
Tots els camps han de tenir una cadena hexadecimal vàlida amb una longitud parell.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Depura un conjunt de claus Rif</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>Components de la clau RSA per depurar fitxers RIF.
Tots els camps han de tenir una cadena hexadecimal vàlida amb una longitud parell.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Pkg derivat Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>Components de la clau RSA pel desxifratge de paquets.
Tots els camps han de tenir una cadena hexadecimal vàlida amb longitud parell.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Tanca</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Avís</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>No s'ha trobat el fitxer de claus o hi ha hagut un error en carregar.
Si us plau, introdueix les teves claus per desar-les.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Error de validació</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Realitzat amb èxit</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>S'han desat les claus correctament!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Error en desar les claus!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Estat: Tots els camps buits</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Estat: Valors hexadecimals no vàlids</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Estat: incomplert</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Estatus: Vàlid</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Fitxer invàlid</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Només se suporta els fitxers JSON.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>No s'ha pogut obrir el fitxer.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Error JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Format JSON no vàlid.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Les claus s'han carregat correctament des del fitxer JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>La clau de trofeus conté valors hexadecimals o té una longitud senar.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 conté valors hexadecimals no vàlids o té una longitud senar.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Carrega la clau</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Desa la clau</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Edita les assignacions del teclat, ratolí i controlador</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Fes servir configuracions per cada joc</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>No es pot obrir el fitxer per llegir-lo</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>No es pot obrir el fitxer per modificar-lo</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Desa els canvis</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Voleu desar els canvis?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Vols reiniciar la configuració personalitzada a la configuració original per defecte?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Vols reiniciar aquesta configuració a la configuració personalitzada per defecte?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Reinicia ala valors predeterminats</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Obre la carpeta</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Carregant la llista de jocs, espera si us plau :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·la</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Carregant...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Selecciona carpeta</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Cercart</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Carpeta per instal·lar les versions de l'emulador</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Carpeta amb els jocs descarregats</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Carpeta amb els DLC descarregats</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Carpeta amb jocs</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Carpeta amb els DLC</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Icona</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nom</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Número de sèrie</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Compatibilitat</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Regió</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Firmware</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Mida</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versió</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Camí</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Temps de joc</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Mai jugat</translation>
    </message>
    <message>
      <source>h</source>
      <translation>h</translation>
    </message>
    <message>
      <source>m</source>
      <translation>m</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>No s'ha provat la compatibilitat</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>El joc no s'inicialitza correctament / l'emulador fa fallida</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>El joc s'inicia, però es queda en blanc</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>El joc mostra imatges, però no es pot anar més enllà dels menús</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>El joc té errors greus o un rendiment que no el fa jugable</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>El joc pot ser completat amb un rendiment jugable i amb pocs errors greus</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Clica per veure els detalls a github</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Darrera actualització</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Preferit</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Trucs / Correccions</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>Visualitzador SFO</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualitzador de trofeus</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Obre la carpeta...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Obre la carpeta de jocs</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Obre la carpeta de dades desades</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Obre la carpeta de registres</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Copia la informació...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Copia el nom</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Copia el número de sèrie</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Copia la versió</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Copia la mida</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Copia tot</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Esborra...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Esborra el joc</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Suprimeix l'actualització</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Esborra el DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Suprimeix el trofeu</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Compatibilitat...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Joc</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Aquest joc no té una actualització per esborrar!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Actualitza</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Aquest joc no té un DLC per esborrar!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Esborra %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Estàs segur que vols eliminar la carpeta %1 de %2?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Obre la carpeta d'actualitzacions</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Elimina les dades desades</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Aquest joc no té carpeta d'actualització per obrir!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>No s'ha trobat fitxer de registre per aquest joc!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Aquest joc no té dades desades per esborrar!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Aquest joc no té trofeus desats per esborrar!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Desa les dades</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofeu</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>Visualitzador SFO per </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Esborra dels preferits</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Afegeix a preferits</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Configuració específica del joc...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Configuració específica del joc</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Crea una configuració específica del joc des de la configuració global</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Esborra la configuració específica del joc</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Actualitza la base de dades</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Visualitza l'informe</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Envia un informe</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Confirma la supressió</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Vols esborrar la configuració específica del joc?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Executant...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Executa amb la configuració específica del joc (per defecte)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Executa només amb la configuració global</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Executa amb la configuració per defecte</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>No s'ha pogut enviar l'informe, perquè l'últim registre del joc ha fallat en la següent comprovació, i per tant seria un informe no vàlid:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Informació</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Crea una drecera per la versió seleccionada de l'emulador</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Crea una drecera per una versió específica de l'emulador</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Crea una drecera</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Drecera creada</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>S'ha creat la drecera correctament!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Error en crear la drecera!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Error en convertir la icona.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Esborra la memòria cau de shaders</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Aquest joc no té memòria cau que es pugui esborrar!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Memòria cau de shaders</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Aquest joc no té carpeta de desats per obrir!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>Es necessita una clau de trofeu per fer servir el visualitzador de trofeus. Pot introduir la clau clicant a Configuració - Administrar claus criptogràfiques.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Inici ràpid</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Preguntes freqüents</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Sintaxi</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Assignació de tecles especials</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Dreceres de teclat</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalitza les dreceres de teclat</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Mostra el comptador de fotogrames per segon</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>sense assignar</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Tanca l'emulació</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Recarrega les assignacions de botons</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Commuta pantalla completa</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Commuta la pausa</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Alterna el ratolí com a emulador del joystick</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Alterna el ratolí com a emulador de giroscopi</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Ajuda: Fins a 3 entrades simultànies poden ser assignades per cada drecera de teclat</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Desa</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplicar</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·lar</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaura els valors per defecte</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>No s'ha pogut desar</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>No es pot assignar una entrada més d'una vegada. S'han assignat de manera duplicada pels següents botons:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Esperant per alguna entrada</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Ajuda: Desassigna les entrades amb el clic dret</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Apuja el volum</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Abaixa el volum</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Dreceres de teclat</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Referència</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Captura de pantalla</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Captura de pantalla amb superposicions</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Obre la configuració de l'emulador</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>No s'ha pogut trobar l'executable de l'emulador</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>No hi ha joc en funcionament</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configura els controladors</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>sense assignar</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Mode reduït de la palanca esquerra</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Configura la selecció</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configuració estàndard</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Fes servir configuracions per cada joc</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Editor de text</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Ratolí a palanca</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>Pressiona F7 durant el joc per activar</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opcions</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Paràmetres de moviment del ratolí</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>nota: clica al botó Ajuda/Assignació de tecles especials per més informació</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangle</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrat</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Cercle</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Creu</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Mode reduït de la palanca dreta</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Compensació de velocitat (0,125 per defecte):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Copia de la configuració estàndard</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Desplaçament de zona morta (0,50 per defecte):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Multiplicador de velocitat (1,0 per defecte):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Copia els valors de la configuració estàndard</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Vols sobreescriure l'assignació actual amb l'assignació de la configuració comuna?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>No s'ha pogut desar</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Premeu una tecla</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>No s'ha pogut fer l'assignació</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>La roda del ratolí no es pot assignar a les palanques</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Desa</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaura els valors per defecte</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·la</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>No es pot assignar una entrada més d'una vegada. S'han assignat de manera duplicada pels següents botons:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad esquerra</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Touchpad centre</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad dreta</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Ajuda: Desassigna les entrades amb el clic dret</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Sortida</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Entrada</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Entrada alternativa 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Entrada alternativa 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Creu direccional: amunt</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Creu direccional: avall</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Creu direccional: esquerra</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Creu direccional: dreta</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Palanca esquerra amunt</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Palanca esquerra avall</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Palanca esquerra esquerra</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Palanca esquerra dreta</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Palanca dreta amunt</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Palanca dreta avall</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Palanca dreta a l'esquerra</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Palanca dreta a la dreta</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Filtre de registre predeterminat</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comentari</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtre</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carregar</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Tanca</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Afegeix una nova configuració preseleccionada després de la fila seleccionada</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Elimina les configuracions predeterminades seleccionades</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Carrega la configuració predeterminada seleccionada</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Obre/Afegeix la carpeta Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Executa el joc</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Comprova si hi ha actualitzacions</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>Sobre shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Configura...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Jocs recents</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Obre la carpeta de shadPS4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Sortida</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Surt de shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Surt de l'aplicació.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Mostra la llista de jocs</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Actualitza la llista de jocs</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Molt petita</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Petita</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Mitjà</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Gran</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Visualització en llista</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Visualització en graella</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Visualitzador Elf</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Carpeta d'instal·lació de jocs</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Descarrega Trucs/Correccions</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Aboca la llista de jocs</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualitzador de trofeus</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>No s'han trobat jocs. Primer afegeix els teus jocs a la llibreria, si us plau.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Cerca...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Fitxer</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Visualitza</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Icones de la llista de jocs</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Mode de la llista de jocs</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Configuració</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Útils</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Temes</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Fosc</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Clar</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verd</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blau</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Violeta</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Barra d'eines</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Llista de jocs</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Descarrega els trucs per tots els jocs instal·lats</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Descarrega les correccions per tots els jocs</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Descàrrega completa</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Has descarregat trucs per tots els jocs que tens instal·lats.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>S'han descarregat les correccions correctament!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>S'han descarregat totes les correccions disponibles de tots els jocs.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Jocs: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>Fitxers ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Executa el joc</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Només es pot seleccionar un fitxer!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Executa el joc</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>No s'ha trobat el fitxer Eboot.bin</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>El joc ja està en funcionament!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Reprodueix</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausa</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Atura</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Reinicia</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Pantalla completa</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Controladors</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Teclat</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Actualitza la llista</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Reprendre</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Mostra les etiquetes sota les icones</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalitza les dreceres de teclat</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Administrador de la versió</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>No hi ha cap versió seleccionada</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>No hi ha cap versió de l'emulador seleccionada.
S'obrirà l'administrador de versions.
Selecciona una versió del panell dret.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>No s'ha pogut trobar l'executable de l'emulador</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Executa l'emulador</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>L'emulador ja està en funcionament!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>S'ha donat un argument de joc invàlid</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Administra Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Administrador de figures de Infinity</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Administrador del Toypad de Dimensions</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Registre de jocs</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Registre de la llista de jocs</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Administrador de claus criptogràfiques</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Gestiona els usuaris</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Unitat bloquejada</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>Unitat %1: està bloquejada. Cal que introdueixis la clau de BitLocker per accedir-hi:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>La clau de recuperació no és correcte. Torneu-ho a provar.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Configuració</translation>
    </message>
    <message>
      <source>General</source>
      <translation>General</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Sistema</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Idioma de la consola</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Pestanya predeterminada en obrir la configuració</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Activa la Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofeu</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Obre la carpeta de trofeus/sons personalitzats</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Registre</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Registre de tipus</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Filtre del registre</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Obre la ubicació del registre</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Entrada</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Cursor</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Amaga el ratolí</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Temps d'espera per ocultar el ratolí</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Dispositiu per defecte</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Controlador</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Gràfics</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Usuari</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Dispositiu de gràfics</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Avançat</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Habilita l'abocat de shaders</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Activa NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Activa el HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Camins</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Carpetes dels jocs</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Afegir...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Suprimeix</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Depuració</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Activa l'abocat de depuració</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Activa les capes de validació de Vulkan</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Habilita la depuració de RenderDoc</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Habilita el diagnòstic d'errors</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Recopila Shaders</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Copia la memòria intermèdia de la GPU</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Marcardors de depuració</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Marcadors de depuració</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Activa imatges lineals de Readback</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Comprova les actualitzacions a l'inici</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Mostra sempre el registre de canvis</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Comprova si hi ha actualitzacions</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Música de títol</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Desactiva les notificacions de trofeus</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Imatge de fons</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Mostra imatge de fons</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Opacitat</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Reprodueix la música del títol</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Actualitza la base de dades de compatibilitat a l'inici</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Compatibilitat dels jocs</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Mostra les dades de compatibilitat</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>S'ha actualitzat la base de dades de compatibilitat</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Volum</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Desa</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplica</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaura els valors per defecte</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Tanca</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Mou el ratolí sobre una opció per mostrar una descripció.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Idioma de la consola:\nEstableix l'idioma que la consola PS4 fa servir.\nEs recomana seleccionar un idioma que el joc suporti, que pot variar en funció de la regió.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Idioma de l'emulador:\nSelecciona l'idioma de l'interfície d'usuari de l'emulador.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Mostra la pantalla d'inici:\nMostra la pantalla d'inici del joc (una imatge especial) mentre el joc s'està iniciant.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Activa Discord Rich Presence:\nMostra la icona de l'emulador i informació rellevant en el teu perfil de Discord.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Imatge de fons:\nControla la opacitat de la imatge de fons del joc.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Reprodueix música del títol:\nSi el joc la conté, reprodueix la música del títol si es selecciona el joc a l'interfície gràfica.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Desactiva les notificacions de trofeus:\nDesactiva les notificacions de trofeus en el joc. El progrés en els trofeus es pot seguir en el visualitzador de trofeus (clicant botó dret del ratolí a la finestra principal).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Oculta el ratolí:\nSelecciona quan s'ocultarà el ratolí.\nMai: El ratolí serà sempre visible.\nInactiu: Estableix un temps perquè s'oculti el ratolí si està inactiu.\nSempre: El ratolí estarà sempre ocult.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Temps d'espera per ocultar el ratolí:\nLa duració (en segons) després de la qual el ratolí s'amaga si es troba inactiu.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Mostra les dades de compatibilitat:\nMostra informació sobre la compatibilitat a la vista de graella. Pots activar l'actualització de compatibilitat a l'inici per obtenir més informació actualitzada.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Actualitza la compatibilitat a l'inici:\nActualitza automàticament la base de dades de compatibilitat quan s'inicia shadPS4.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Base de dades de compatibilitat:\nActualitza immediatament la base de dades de compatibilitat.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Mai</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Inactiu</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Sempre</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Dispositiu de gràfics:\nEn sistemes amb múltiples targetes gràfiques, selecciona la targeta gràfica que farà servir l'emulador de la llista,\n o clica a "Selecció automàtica" per determinar-la automàticament.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Amplada/Alçada:\nEstableix les mides de la finestra de l'emulador quan s'inicia, durant el joc es pot canviar la mida.\nAixò és diferent que la resolució del joc.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Activa HDR:\nActiva HDR els jocs que ho suporten.\nEl teu monitor ha de donar suport a l'espai de color BT2020 PQ i al format de cadena d'intercanvi RGB10A2.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Carpetes de joc:\nLa llista de carpetes on comprovar si hi ha jocs instal·lats.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Afegeix:\nAfegeix una carpeta a la llista.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Elimina:\nElimina la carpeta de la llista.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Activa l'abocat de depuració:\nDesa els símbols d'importació i exportació i la informació de l'encapçalament del fitxer de programa de PS4 que s'està executant ara mateix.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Activa la depuració RenderDoc:\nSi aquesta opció està activada, l'emulador tindrà compatibilitat amb RenderDoc per permetre capturar i analitzar els fotogrames renderitzats.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Recopilar shaders:\nHas de tenir activada aquesta opció per editar els shaders amb el menú de depurador (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Activa imatges lineals de Readback:\nActiva la descàrrega asíncrona d'imatges lineals modificades de la targeta gràfica:\nPot corregir errors en alguns jocs.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Copia la memòria intermèdia de la GPU:\nEvita les condicions de carrera que impliquen més enviaments a la targeta gràfica.\nPot ajudar o no amb fer fallida del tipus 0 de PM4.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcadors de depuració de convidat:\nInsereix informació des de l'emulador com marcadors específics de les targetes gràfiques AMB sobre les comandes Vulkan, així com proporcionar noms de depuració.\nSi aquesta opció està activada, caldria activar el diagnòstic d'errors.\nÉs útil per aplicacions com RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcadors de depuració de convidat:\nInsereix qualsevol marcador que el joc ha afegit a la memòria intermèdia de les comandes.\nSi està activada aquesta opció, caldria activar el diagnòstic d'errors.\nÉs útil per aplicacions com RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Selecciona el volum de la música de fons.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Habilita els controls de moviment</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Navega</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Selecciona automàticament</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Carpeta per instal·lar jocs</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Vídeo</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Mode de visualització</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>En finestra</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Pantalla completa</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Pantalla completa (Sense vores)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Mida de la finestra</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>W:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>H:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Fitxers de registre independents</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Fitxers de registre independents:\nFes servir un fitxer de registre separat per cada joc.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Posició de les notificacions de trofeus</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Esquerra</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Dreta</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Amunt</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Sota</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Duració de les notificacions</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Carpeta de l'usuari portàtil</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Crea la carpeta d'usuari portàtil a partir de la carpeta d'usuari estàndard</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Carpeta d'usuari portàtil:\nDesa la configuració i les dades de shadPS4 en la carpeta actual. Reinicia shadPS4 després de crear la carpeta d'usuari portàtil per començar a fer-la servir.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 ja existeix</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 s'ha creat correctament.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Obre la carpeta de trofeus/sons personalitzats.\nPots afegir imatges i sons personalitzats als trofeus.\nAfeigeix els fitxers com custom_trophy amb els següents noms:\ntrophy.wav o trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNota: El so només funcionarà en les versions QT.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Funcions experimentals</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>AVÍS: Aquestes funcions son experimentals i no haurien de ser activades a no ser que t'ho demanin, o que el joc ho necessiti. Pregunta en el Discord de shadPS4 si tens dubtes.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Activa l'entrada del controlador en segon pla</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Activa l'entrada del controlador en segon pla:\nPermet a shadPS4 per detectar l'entrada del controlador quan la finestra del joc ja no té el focus.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Diagnòstiques de fallides:\nCrea un fitxer .yaml amb informació sobre l'estat de Vulkan en el moment de fer fallida.\nÉs útil per depurar errors del tipus 'Dispositiu perdut'. Si aquesta opció està activada, caldria activar els marcadors de depuració de convidat.\nCal activar la validació de capes de Vulkan i el SDK de Vulkan perquè funcioni.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Habilita el registre</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Habilita el registre:\nHabilita el registre.\nNo canviïs aquesta opció si no saps que estàs fent!\nSi demanes ajuda, assegura't que aquesta opció està ACTIVADA.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Mode presentació</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>Bústia de correu (Sincronització vertical)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>Fifo (Sincronització vertical)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Immediat (Sense sincronització vertical)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Selecciona la carpeta DLC</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Mode Presentació:\nConfigura com es presenta la sortida de vídeo a la teva pantalla.\n\nBústia de correu: Sincronitza els fotogrames amb la taxa de refresc de la teva pantalla. Els nous fotogrames reemplacen qualsevol fotograma pendent. Redueix la latència però pot provocar salts de fotogrames si es queden enrere.\nFifo: Els fotogrames es sincronitzen amb la taxa de refresc de la teva pantalla. Els nous fotogrames es posaran en cua darrere els fotogrames pendents. Assegura mostrar tots els fotogrames però augmenta la latència.\nImmediat: Els fotogrames es presenten immediatament a la teva pantalla quan estan disponibles. Pot provocar errors gràfics.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Navegador:\nCerca una carpeta per establir com a ruta DLC.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>Configuració FSR</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Activa el FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>Activa RCAS (esmolat)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>Afeblir RCAS:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Carrega els valors predeterminats...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Registre</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Obre la ubicació del registre:\nObre la carpeta en la qual es desa el fitxer de registre.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Micròfon:\nCap: No fa servir el micròfon.\nDispositiu per defecte: Farà servir el dispositiu definit pel sistema operatiu.\nO selecciona manualment el micròfon de la llista.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Volum:\nAjusta el volum per jocs globalment, el rang va del 0-500% amb 100% com a valor per defecte.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Pestanya per defecte en obrir la configuració:\nSelecciona quina pestanya es veurà primer, per defecte és la pestanya General.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Activa els controls de moviment:\nQuan està activat, farà servir els controls de moviment del controlador si en té.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Freqüència de Vblank</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Freqüència Vblank:\nLa taxa de fotogrames a la qual l'emulador es refresca (60 Hz és el valor base, quan el joc s'executa a 30 o 60 fps). Canviar aquest valor pot tenir efectes adversos, com augmentar la velocitat del joc, o trencar la funcionalitat del joc de forma no esperada!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Activa l'accés directe a memòria</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Activa el mode consola de desenvolupador</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Estableix l'inici de sessió de PSN a cert</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Estableix la connexió a xarxa com a certa</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Miscel·lània</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Frontend</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Experimental</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Mostra pantalla inicial en inicar el joc</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Configuració general del frontend</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>Activa el mode PS4 Neo</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Activa l'accés directe a memòria:\nActiva l'accés arbitrari de memòria des de la targeta gràfica a la memòria del procesador.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>Activa el mode Neo de PS4:\nAfegeix suport a l'emulació de PS4 Pro i la mida de memòria. Actualment causa inestabilitat en un gran nombre de jocs que s'han provat.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Activa el mode de consola de desenvolupament:\nAfegeix suport per la mida de memòria de la consola de desenvolupament.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Estableix la connexió a xarxa com a certa:\nForça els jocs a detectar una connexió a xarxa activa. Les funcions de connexió a xarxa no estan implementades actualment.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Estableix l'inici de sessió a PSN com a cert:\nForça els jocs a detectar un inici de sessió a PSN actiu. Les funcions de PSN no estan implementades actualment.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Activa les capes de validació de Vulkan:\nActiva un sistema que valida l'estat del renderitzador de Vulkan i registra informació sobre el seu ús intern.\nAixò redueix el rendiment i pot canviar el comportament de l'emulador.\nCal tenir el SDK de Vulkan perquè funcioni.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Dispositiu d'àudio (general)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Dispositiu d'àudio (altaveu DS4)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Activa els abocats de shaders:\nPer la millora de la depuració tècnica, desa els shaders del joc en una carpeta mentre es renderitzen.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>Habilita GPU Nul·la:\nPer la millora de la depuració tècnica, desactiva el renderitzat del joc si no hi ha una targeta gràfica. La pantalla es tornarà negra.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>Ruta DLC:\nLa carpeta des d'on es carrega el contingut DLC.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Ubicació addicional DMem</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Ubicació addicional DMem:\nForça la ubicació d'una determinada quantitat de DMem. Pot provocar errors en alguns jocs.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>Ruta de sysmodules de PS4:\nLa carpeta des de la qual sysmodules de PS4 es carrega.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Cercar:\nCerca per una carpeta per establir com la ruta de sysmodules.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Validació Vulkan (Requereix el SDK de Vulkan)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Capes de validació</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Activa la validació del nucli</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Activa la sincronització del nucli</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Activa la validació d'assistència de targeta gràfica</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Activa la validació de sincronització:\nActiva un sistema que valida la sincronització de les tasques de renderització de Vulkan.\nAixò pot reduir el rendiment i canviar el comportament de l'emulador.\nCal tenir el SDK de Vulkan perquè funcioni.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Activa la validació de nucli:\nActiva les funcions principals de validació de la API.\nAixò redueix el rendiment i pot canviar el comportament de l'emulació.\nÉs necessari el SDK de Vulkan perquè funcioni.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Activa la validació assistida per la targeta gràfica:\nEls shaders d'instruments amb codi que validen si s'estan comportant correctament.\nAixò pot reduir el rendiment i canviar el comportament de l'emulador.\nCal tenir el SDK de Vulkan perquè funcioni.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Idioma de la interfície d'usuari</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Actualitzacions de la interfície d'usuari</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>Ruta del DLC</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>Carpeta de PS4 de Sysmodules</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Actualitzacions de la interfície d'usuari:\nRelease: Les versions oficials publicades cada mes que potser no estan tan actualitzades, però són més estables i han estat més provades.\nNightly: Versions en desenvolupament que tenen totes les últimes novetats i correccions, però poden contenir errors i són menys estables.\n\n*Aquesta actualització s'aplica només a la interfície d'usuari Qt. Per actualitzar el nucli de l'emulador, fes servir el &apos;Administrador de versions&apos; del menú.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>No s'ha pogut crear la carpeta d'usuari portàtil</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>S'ha creat la carpeta launcherDir portàtil</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>Dispositiu USB</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Dispositiu USB real</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Portal de Skylanders</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Base de Infinity</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Toypad de Dimensions</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>Dispositiu USB:\nDispositiu USB real: Fes servir un dispositiu USB enllaçat al sistema.\nPortal Skylander: Emula un portal Skylander.\nBase Infinity: Emula una base de Disney Infinity.\nDimensions Toypad: Emula un Toypad de Lego Dimensions.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Activa la memòria cau de shaders</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Comprimeix la memòria cau de shaders en un fitxer zip</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Activa la memòria cau de shaders:\nEmmagatzemar la memòria cau de shaders per evitar recompilacions, reduint les estrebades.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Comprimeix els fitxers de la memòria cau de shaders en un fitxer zip:\nEls fitxers de la memòria cau de shaders s'emmagatzemen en un sol fitxer zip en compte de fer-ho en diferents fitxers separats.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Mode de lectura</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Deshabilitat</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Lectura:\nActiva la lectura i escriptura a la memòria de la targeta gràfica.\nAixò és necessari pe comportament correcte en alguns jocs.\nPot causar problemes d'estabilitat o rendiment.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Relaxat</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Precís</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Selecciona la ruta a la carpeta Home de shadPS4</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Selecciona la carpeta del sistema de mòduls</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Ubicació de la carpeta Home (Desats, entrades i dades de trofeu)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Ubicació de la carpeta Home:\nLa carpeta on es desen les dades, fitxers de trofeus i la configuració d'entrada per tots els usuaris.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Navegador:\nNavega per una carpeta per escollir-la com a carpeta home.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Àudio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Motor d'àudio</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Dispositiu de micròfon</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Dispositius</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Càmera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Sincronització del registre</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Ignora registres duplicats</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Duració màxima per ignorar registres</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Límit de la mida del registre</translation>
    </message>
    <message>
      <source> B</source>
      <translation> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Annexar al registre</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Annexar al registre:\nAnnexar als registres actuals.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Duració màxima per ignorar registres:\nInterval sense escriure les mateixes línies (ms) - només si està activada l'opció Ignora els registres duplicats.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Límit de la mida del registre:\nMida màxima dels fitxers del registre (bytes).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Ignora els registres duplicats:\nEstalvia emmagatzematge evitant desar registres idèntics.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Sincronització del registre:\nAlterna entre sincronització (ordre) o asíncron (rendiment).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Tipus de registre:\nSelecciona entre els tipus de registre wincolor o msvc.\nwincolor: Registre per defecte a Windows\nmsvc: Registre per depuració</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Filtre del registre:\nFiltra el registre per mostrar només la informació especificada.\nExemples: &quot;Core:Trace&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nNivells: Trace, Debug, Info, Warning, Error, Critical - en aquest ordre, un nivell específic silencia tots els nivells precedents de la llista i mostra només els nivells posteriors.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Selecciona la versió</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Selecciona la versió amb la qual crear una drecera</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>No hi ha cap versió seleccionada</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Selecciona primer una versió</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualitzador de trofeus</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Selecciona un joc:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Progrés</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Mostra els trofeus aconseguits</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Mostra els trofeus no aconseguits</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Mostra els trofeus ocults</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Selecciona usuari:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Administrador d'usuaris</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>Creació d'usuari</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>Suprimeix l'usuari</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>Reanomena l'usuari</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Estableix l'usuari per defecte</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>Estableix el color</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Selecciona el port del controlador</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Tanca</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>No es poden afegir més usuaris.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Crea un nou usuari</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>Nou ID d'usuari: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Nom d'usuari (entre 3 i 16 caràcters, lletres, nombres, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Nom d'usuari incorrecte</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>El nom d'usuari ha de tenir entre 3 i 16 caràcters vàlids.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Confirmació de l'eliminació</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Vols eliminar l'usuari amb ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Reanomena l'usuari</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Nom d'usuari anterior: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Selecciona el color d'usuari</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Seleccioneu el color:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Selecciona el port del controlador</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Assigna el port (1-4) a aquest usuari:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Obre la carpeta d'usuari</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Administrador de la versió</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Ruta a les versions desades</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Cerca</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Instal·lat</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Seleccionat</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versió</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Nom en clau</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Afegeix personalitzat</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Esborra</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Actualitza la llista</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Descarrega</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Comprovar si hi ha actualitzacions prèvies a l'inici</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Comprovar si hi ha actualitzacions prèvies</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Selecciona la carpeta on s'instal·laran les versions de l'emulador</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Selecciona l'executable</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Executable (*.*)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Nom de la versió</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Introdueix el nom de la versió tal com apareix a la llista.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Error</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Realitzat amb èxit</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>S'ha afegit la versió correctament.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Error en determinar la ruta de la carpeta.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Elimina la versió</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Estàs segur que vols esborrar aquesta versió</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Actualitza la llista de versions</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>No hi ha novetats, la llista de versions ja està actualitzada.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>S'han afegit les últimes versions a la llista per descarregar.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Error en accedir a la API de GitHub</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Primer has de seleccionar una ubicació per desar les versions. Carpeta on desar les versions</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Estàs segur que vols descarregar aquesta versió</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>No hi ha fitxers disponibles per aquesta plataforma.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Descarregant %1, si us plau, espera...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>No s'ha pogut desar el fitxer.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>La versió %1 ha sigut descarregada i seleccionada.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Error en extreure el fitxer zip</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>La resposta de la API de GitHub no és un valor JSON vàlid.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Actualització automàtica - Emulador</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>Ja tens l'última versió prèvia.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Hi ha una actualització disponible (Emulador)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versió actual</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Última versió</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Estàs segur que vols actualitzar?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Actualitza</translation>
    </message>
    <message>
      <source>No</source>
      <translation>No</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostra el registre de canvis</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Oculta el registre de canvis</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Error de xarxa durant la recuperació del registre de canvis</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Canvis</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>No s'ha trobat la direcció web de descàrrega.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Error de xarxa durant la descarrega</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Error en desar el fitxer descarregat</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Completa la instal·lació</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>S'ha instal·lat una actualització prèvia correctament</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Error en crear el fitxer de script d'actualització</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Mostra sempre el registre de canvis</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>No s'ha seleccionat cap versió. Escull-ne una de la llista per esborrar-la.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Voleu confirmar la descàrrega</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Error en l'extracció.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Ja existeix una versió amb aquest nom.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Local</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Error en determinar la carpeta a eliminar.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Error en eliminar la carpeta.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>No es pot obtenir el hash de l'última versió prèvia.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Descarregant versió prèvia, si us plau, espera...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Administrador de Dimensions</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Figures de Dimensions actives:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Netejar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carrega</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Mou</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Figura desconeguda</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Selecciona el fitxer de Dimensions</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Figura de Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Error en obrir el fitxer de figura!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Error en obrir el fitxer de figura(%1)!
El fitxer podria estar en ús per la base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Error en llegir el fitxer de figura!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Error en llegir el fitxer de la figura (%1)!
El fitxer és massa petit.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Creador de figures</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Filtra per sèries:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Tot</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconegut--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Nombre de figura:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Sèries:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·lar</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Error en convertir el valor</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>El nombre de la figura no és vàlid!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>El nombre de sèrie no és vàlid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Crear un fitxer de figura</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Figura de Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Error en crear el fitxer de figura!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Error en crear el fitxer de figura:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Administrador de Infinity</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Figures de Infinity actives:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>Set de joc/Disc de poder</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>Disc de poder 2</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>Disc de poder 3</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Jugador 1</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Habilitat 1 del jugador 1</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Habilitat 2 del jugador 1</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Jugador 2</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Habilitat 1 del jugador 2</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Habilitat 2 del jugador 2</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Netejar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carrega</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Figura desconeguda</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Selecciona el fitxer de Infinity</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Figura de Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Error en obrir el fitxer de figura!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Error en obrir el fitxer de figura(%1)!
El fitxer podria estar en ús per la base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Error en llegir el fitxer de figura!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Error en llegir el fitxer de la figura (%1)!
El fitxer és massa petit.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Creador de figures</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconegut--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Nombre de figura:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·lar</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Error en convertir el valor</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>El nombre de la figura no és vàlid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Crear un fitxer de figura</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Figura de Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Error en crear el fitxer minifig!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Error en crear el fitxer minifig:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Trasllada la figura</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Mou aquí</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Recollir i col·locar</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Creador de Skylanders</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconegut--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Variant:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancel·la</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Error en convertir el valor</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>La ID no és vàlida!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>La variant introduïda no és vàlida!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Crea fitxer de Skylander</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Objecte de Skylander (*.sky);;Tots els fitxers(*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Error en crear el fitxer de Skylander!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Error en crear el fitxer de Skylander:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Administrador de Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Activa el Portal Skylanders:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Netejar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Crea</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carrega</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Selecciona fitxer de Skylander</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Tots els fitxers (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Error en obrir el fitxer Skylander!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Error en obrir el fitxer de Skylander(%1)!
El fitxer ja estaria en ús en el portal.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Error en llegir el fitxer Skylander!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Error en llegir el fitxer skylander(%1)!
El fitxer és massa petit.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Desconegut (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Cap</translation>
    </message>
  </context>
</TS>
