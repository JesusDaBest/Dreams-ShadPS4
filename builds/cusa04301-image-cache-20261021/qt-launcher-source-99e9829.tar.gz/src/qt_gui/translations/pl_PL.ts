<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>O programie</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 to eksperymentalny otwartoźródłowy emulator konsoli PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>To oprogramowanie nie służy do grania w gry pochodzące z nielegalnego źródła.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Kody / Poprawki dla </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Cheaty/Patche są eksperymentalne.\nUżywaj ich ostrożnie.\n\nPobierz cheaty pojedynczo, wybierając repozytorium i klikając przycisk pobierania.\nNa zakładce Patches możesz pobrać wszystkie patche jednocześnie, wybrać, które chcesz używać, i zapisać wybór.\n\nPonieważ nie rozwijamy Cheats/Patches,\nproszę zgłosić problemy do autora cheatu.\n\nStworzyłeś nowy cheat? Odwiedź:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Brak dostępnego obrazu</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Numer seryjny: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Wersja: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Rozmiar: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Wybierz plik kodu:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Repozytorium:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Pobierz kody</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Usuń plik</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Nie wybrano pliku.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Możesz usunąć kody, których nie chcesz po ich pobraniu.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Czy chcesz usunąć wybrany plik?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Wybierz plik poprawki:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Pobierz poprawki</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Zapisz</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Kody</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Poprawki</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Nie wybrano poprawki.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Nie można otworzyć pliku files.json do odczytu.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Nie znaleziono pliku poprawki dla bieżącego numeru seryjnego.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Nie można otworzyć pliku do odczytu.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Nie można otworzyć pliku do zapisu.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Nie udało się przeanalizować XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Sukces</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Opcje zostały pomyślnie zapisane.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Nieprawidłowe źródło</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>Wybrane źródło jest nieprawidłowe.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Plik istnieje</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Plik już istnieje. Czy chcesz go zastąpić?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Nie udało się zapisać pliku:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Nie udało się pobrać pliku:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Nie znaleziono kodów</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Nie znaleziono kodów do tej gry w tej wersji wybranego repozytorium. Spróbuj innego repozytorium lub innej wersji gry.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Kody pobrane pomyślnie</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Pomyślnie pobrano kody dla tej wersji gry z wybranego repozytorium. Możesz spróbować pobrać z innego repozytorium. Jeśli jest dostępne, możesz również użyć go, wybierając plik z listy.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Nie udało się zapisać:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Nie udało się pobrać:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Pobieranie zakończone</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Poprawki zostały pomyślnie pobrane! Wszystkie dostępne poprawki dla wszystkich gier zostały pobrane. Nie ma potrzeby pobierania ich osobno dla każdej gry, która ma kody. Jeśli poprawka się nie pojawia, możliwe, że nie istnieje dla konkretnego numeru seryjnego i wersji gry.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Nie udało się przeanalizować danych JSON z HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Nie udało się pobrać strony HTML.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Gra jest w wersji: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>Pobrana łatka działa tylko w wersji: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Może być konieczne uaktualnienie gry.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Powiadomienie o niezgodności</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Nie udało się otworzyć pliku:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>BŁĄD XML:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Nie udało się otworzyć pliku files.json do zapisu</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Autor: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Katalog nie istnieje:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Nie można otworzyć pliku files.json do odczytu.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nazwa:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Nie można zastosować kodów przed uruchomieniem gry.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zamknij</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Asystent aktualizacji</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Błąd sieci:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Automatyczna aktualizacja umożliwia maksymalnie 60 sprawdzeń aktualizacji na godzinę.\nOsiągnąłeś ten limit. Spróbuj ponownie później.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Nie udało się sparsować informacji o aktualizacji.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Nie znaleziono wersji przedpremierowych.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nie znaleziono adresu URL do pobrania dla określonego zasobu.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Twoja wersja jest już aktualna!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Aktualna wersja</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Najnowsza wersja</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Czy chcesz zaktualizować?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Pokaż zmiany</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Sprawdź aktualizacje przy starcie</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aktualizuj</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Nie</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Ukryj zmiany</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Zmiany</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Błąd sieci wystąpił podczas próby uzyskania dostępu do URL</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Pobieranie zakończone</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>Aktualizacja została pobrana, naciśnij OK, aby zainstalować.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Nie udało się zapisać pliku aktualizacji w</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Rozpoczynanie aktualizacji...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Nie udało się utworzyć pliku skryptu aktualizacji</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Asystent aktualizacji - GUI</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Dostępna aktualizacja - GUI</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Pobieranie danych o kompatybilności, proszę czekać</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Ładowanie...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Nie można zaktualizować danych o kompatybilności! Spróbuj ponownie później.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Nie można otworzyć pliku compatibility_data.json do zapisu.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Nieznany</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Nic</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Uruchamia się</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menu</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>W grze</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Grywalne</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Skonfiguruj sterowanie</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Krzyżak</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Góra</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Lewo</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Prawo</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Dół</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Lewy drążek</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Wybór konfiguracji</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Wspólna konfiguracja</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Użyj osobnej konfiguracji dla każdej gry</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Przyciski akcji</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Prawy drążek</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Dostosowanie koloru</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Zastąp kolor paska świetlnego</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Zastąp kolor</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Zapisywanie nie powiodło się</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Nie można powiązać wartości osi więcej niż raz</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Zapisz</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Zastosuj</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Przywróć ustawienia domyślne</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nieprzypisane</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Lewy Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Środkowy Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Prawy Touchpad</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Trójkąt</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Kwadrat</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Kółko</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Krzyżyk</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Nie można zbindować unikalnych akcji więcej niż raz. Zduplikowane akcje są przepisane do następujących przycisków:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Naciśnij przycisk</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Rusz gałką analogową</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 i L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Aktywny kontroler</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>Identyfikator kontrolera</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Domyślny kontroler</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Brak domyślnego kontrolera</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>n/d</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Ustaw jako domyślny</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Usuń domyślny kontroler</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 i R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Wybrano domyślny kontroler</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Aktywny kontroler ustawiono jako domyślny</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Usunięto domyślny kontroler</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Usunięto ustawienia domyślnego kontrolera</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>CZERWONY</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>ZIELONY</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>NIEBIESKI</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Martwa strefa lewego drążka</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Minimalna martwa strefa (def:2 max:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Maksymalna martwa strefa (def:127 max:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Martwa strefa prawego drążka</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation type="unfinished">Crypto Key Manager</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation type="unfinished">Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation type="unfinished">Enter Trophy Key</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation type="unfinished">Trophy Key:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation type="unfinished">Status: Not loaded</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation type="unfinished">Trophy Key</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation type="unfinished">Enter %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation type="unfinished">Exponent1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation type="unfinished">Exponent2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation type="unfinished">Public Exponent</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation type="unfinished">Coefficient</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation type="unfinished">Modulus</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation type="unfinished">Prime 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation type="unfinished">Prime 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation type="unfinished">Private Exponent</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation type="unfinished">Fake Keyset</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for fake signing.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation type="unfinished">Debug Rif Keyset</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation type="unfinished">Pkg Derived Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for package decryption.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished">Close</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation type="unfinished">Warning</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation type="unfinished">No key file found or failed to load.
Please enter your keys and save them.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation type="unfinished">Validation Error</translation>
    </message>
    <message>
      <source>Success</source>
      <translation type="unfinished">Success</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation type="unfinished">Keys saved successfully!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation type="unfinished">Failed to save keys!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation type="unfinished">Status: All fields empty</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation type="unfinished">Status: Invalid hex values</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation type="unfinished">Status: Incomplete</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation type="unfinished">Status: Valid</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation type="unfinished">Invalid File</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation type="unfinished">Only JSON files are supported.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation type="unfinished">Unable to open file.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation type="unfinished">JSON Error</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation type="unfinished">Invalid JSON format.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation type="unfinished">Keys successfully loaded from JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation type="unfinished">Trophy Key contains invalid hex or has odd length.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation type="unfinished">%1 contains invalid hex or has odd length.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation type="unfinished">Load Key</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation type="unfinished">Save Key</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Edytuj przypisanie klawiszy klawiatury + myszy oraz kontrolera</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Użyj osobnej konfiguracji dla każdej gry</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Nie można otworzyć pliku do odczytu</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Nie można otworzyć pliku do zapisu</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Zapisać zmiany</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Czy chcesz zapisać zmiany?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Pomóc</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Czy chcesz zresetować Twoją domyślną konfigurację do oryginalnej domyślnej konfiguracji?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Czy chcesz zresetować tę konfigurację do Twojej domyślnej konfiguracji?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Zresetować do domyślnych</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Otwórz folder</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Ładowanie listy gier, proszę poczekaj :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Ładowanie...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Wybierz katalog</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Przeglądaj</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Katalog do instalacji poszczególnych wersji emulatora</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Katalog ze zgranymi grami</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Katalog z twoją zawartością dodatkową</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Katalog gier</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation type="unfinished">Directory with DLC&apos;s</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Ikona</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nazwa</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Numer seryjny</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Kompatybilność</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Region</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Oprogramowanie</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Rozmiar</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Wersja</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Ścieżka</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Czas gry</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Nigdy nie grane</translation>
    </message>
    <message>
      <source>h</source>
      <translation>godz.</translation>
    </message>
    <message>
      <source>m</source>
      <translation>min</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Kompatybilność nie została przetestowana</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Gra nie inicjuje się poprawnie / zawiesza się emulator</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Gra uruchamia się, ale wyświetla tylko pusty ekran</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Gra wyświetla obraz, ale nie przechodzi do menu</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Gra ma usterki przerywające rozgrywkę lub niegrywalną wydajność</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Grę można ukończyć z grywalną wydajnością i bez większych usterek</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Kliknij, aby zobaczyć szczegóły na GitHub</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Ostatnia aktualizacja</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Ulubione</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Kody / poprawki</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>Menedżer plików SFO</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Menedżer trofeów</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Otwórz Folder...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Otwórz Katalog Gry</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Otwórz folder zapisanych danych</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Otwórz Folder Dziennika</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Kopiuj informacje...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Kopiuj nazwę</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Kopiuj numer seryjny</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Kopiuj wersję</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Kopiuj rozmiar</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Kopiuj wszystko</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Usuń...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Usuń grę</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Usuń aktualizację</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Usuń dodatkową zawartość (DLC)</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Usuń trofeum</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Kompatybilność...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Gra</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Ta gra nie ma aktualizacji do usunięcia!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aktualizacja</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Ta gra nie ma dodatkowej zawartości (DLC) do usunięcia!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>Dodatkowa zawartość (DLC)</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Usuń %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Czy na pewno chcesz usunąć katalog %1 z %2?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Otwórz folder aktualizacji</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Usuń zapisane dane</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Ta gra nie ma folderu aktualizacji do otwarcia!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Nie znaleziono pliku dziennika dla tej gry!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Ta gra nie ma zapisów do usunięcia!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Ta gra nie ma zapisanych trofeuów do usunięcia!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Zapisane dane</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofeum</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>Menedżer plików SFO dla </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Usuń z Ulubionych</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Dodaj do Ulubionych</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Ustawienia specyficzne dla gry...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Konfiguruj ustawienia specyficzne dla gry</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Utwórz ustawienia specyficzne dla gry z ustawień globalnych</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Usuń ustawienia specyficzne dla gry</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Zaktualizuj bazę danych</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Zobacz raport</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Prześlij raport</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Potwierdź usunięcie</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Usunąć ustawienia specyficzne dla gry?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Uruchom...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Uruchom za pomocą specyficznej konfiguracji (domyślnie)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Uruchom tylko za pomocą globalną konfiguracją</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Uruchom z domyślnymi ustawieniami</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Nie udało się wysłać raportu, ponieważ w najnowszym pliku dzienika dla tej gry wystąpił błąd konfiguracji i klasyfikuje go jako niewłaściwy:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Informacje</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Utwórz skrót dla wybranej wersji emulatora</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation type="unfinished">Create Shortcut for Specified Emulator Version</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Utwórz skrót</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Tworzenie skrótu</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Utworzenie skrótu zakończone pomyślnie!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Utworzenie skrótu zakończone niepowodzeniem!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Nie udało się przekonwertować ikony.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Usuń pamięć podręczną cieni</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation type="unfinished">This game does not have any saved Shader Cache to delete!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Pamięć podręczna cieni</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation type="unfinished">This game has no save folder to open!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation type="unfinished">A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Szybki start</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Najczęściej zadawane pytania</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Składnia</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Specjalne wiązania</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Przypisanie klawiszy</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Dostosuj skróty klawiszowe</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Pokaż licznik FPS</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nieprzypisane</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Zakończ emmulację</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Odśwież przypisanie przycisków</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation type="unfinished">Toggle Fullscreen</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation type="unfinished">Toggle Pause</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation type="unfinished">Toggle Mouse to Joystick Emulation</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation type="unfinished">Toggle Mouse to Gyro Emulation</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation type="unfinished">Tip: Up to three simultaneous inputs can be assigned for each hotkey</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Zapisz</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Zastosuj</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Przywróć ustawienia domyślne</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Zapisywanie nie powiodło się</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation type="unfinished">Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Oczekiwanie na dane wejściowe</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation type="unfinished">Volume Up</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation type="unfinished">Volume Down</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation type="unfinished">Hotkeys</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation type="unfinished">Placeholder</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation type="unfinished">Capture Screenshot</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation type="unfinished">Capture Screenshot w/ Overlays</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation type="unfinished">Open Emulator Settings</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation type="unfinished">Could not find the emulator executable</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation type="unfinished">No game is running</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Skonfiguruj sterowanie</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>nieprzypisane</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Połowiczny tryb lewego drążka</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Wybór konfiguracji</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Wspólna konfiguracja</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Użyj osobnej konfiguracji dla każdej gry</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Edytor tekstu</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Pomoc</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Mysz na Joystick</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*naciśnij F7 w grze aby aktywować</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opcje</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Parametry ruchu myszy</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>uwaga: kliknij przycisk Pomoc/Specjalne skróty klawiszowe, aby uzyskać więcej informacji</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Trójkąt</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Kwadrat</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Kółko</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Krzyżyk</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Połowiczny tryb prawego drążka</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Offset prędkości (def 0,125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Kopiuj ze wspólnej konfiguracji</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Offset martwych stref (def 0,50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Mnożnik prędkości (def1.0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Kopiuj ze wspólnej konfiguracji</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Czy chcesz nadpisać istniejące mapowania mapowaniem ze wspólnej konfiguracji?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Zapisywanie nie powiodło się</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Naciśnij klawisz</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Nie można ustawić mapowania</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>Kółko myszy nie może być przypisane do sterowania drążkiem</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Zapisz</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Zastosuj</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Przywróć ustawienia domyślne</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Nie można zbindować unikalnych akcji więcej niż raz. Zduplikowane akcje są przepisane do następujących przycisków:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Lewy Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Środkowy Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Prawy Touchpad</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
    <message>
      <source>Output</source>
      <translation type="unfinished">Output</translation>
    </message>
    <message>
      <source>Input</source>
      <translation type="unfinished">Input</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation type="unfinished">Alternate Input 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation type="unfinished">Alternate Input 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation type="unfinished">Dpad Up</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation type="unfinished">Dpad Down</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation type="unfinished">Dpad Left</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation type="unfinished">Dpad Right</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation type="unfinished">Left Stick Up</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation type="unfinished">Left Stick Down</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation type="unfinished">Left Stick Left</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation type="unfinished">Left Stick Right</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation type="unfinished">Right Stick Up</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation type="unfinished">Right Stick Down</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation type="unfinished">Right Stick Left</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation type="unfinished">Right Stick Right</translation>
    </message>
    <message>
      <source>L1</source>
      <translation type="unfinished">L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation type="unfinished">R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation type="unfinished">L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation type="unfinished">R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation type="unfinished">L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation type="unfinished">R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation type="unfinished">Log Filter Presets</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Komentarz</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtruj</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Wczytaj</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zamknij</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation type="unfinished">Add a new preset after the selected row</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation type="unfinished">Remove selected presets</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation type="unfinished">Load the selected preset</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Otwórz/Dodaj folder Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Uruchom grę</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Sprawdź aktualizacje</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>O programie</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Konfiguruj...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Ostatnie gry</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Otwórz folder shadPS4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Wyjdź</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Wyjdź z shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Wyjdź z aplikacji.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Pokaż listę gier</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Odśwież listę gier</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Malutkie</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Małe</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Średnie</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Wielkie</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Widok listy</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Widok siatki</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Menedżer plików ELF</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Katalog zainstalowanych gier</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Pobierz kody / poprawki</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Zgraj listę gier</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Menedżer trofeów</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Nie znaleziono gier. Najpierw dodaj swoje gry do swojej biblioteki.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Szukaj...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Plik</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Widok</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Ikony w widoku listy</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Tryb listy gier</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Ustawienia</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Narzędzia</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Motywy</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Pomoc</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Ciemny</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Jasny</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Zielony</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Niebieski</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Fioletowy</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Pasek narzędzi</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Lista gier</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Pobierz kody do wszystkich zainstalowanych gier</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Pobierz poprawki do wszystkich gier</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Pobieranie zakończone</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Pobrałeś kody do wszystkich zainstalowanych gier.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Poprawki pobrane pomyślnie!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Wszystkie poprawki dostępne dla wszystkich gier zostały pobrane.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Gry: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>Pliki ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Uruchomienie gry</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Można wybrać tylko jeden plik!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Uruchom grę</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Nie znaleziono pliku EBOOT.BIN</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Gra jest już uruchomiona!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Graj</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pauza</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Stop</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Restart</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Pełny ekran</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Kontrolery</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Klawiatura</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Odśwież Listę</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Wznów</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Pokaż etykiety pod ikonami</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Dostosuj skróty klawiszowe</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Menedżer wersji</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nie wybrano wersji</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation type="unfinished">No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation type="unfinished">Could not find the emulator executable</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Uruchom emulator</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>Emulator jest już uruchomiony!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Podano nieprawidłowy argument gry</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Brak</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation type="unfinished">Manage Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation type="unfinished">Manage Infinity Figures</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation type="unfinished">Manage Dimensions Toypad</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Dziennik zdarzeń gry</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Pokaż dziennik zdarzeń gier</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation type="unfinished">Manage Cryptographic Keys</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation type="unfinished">Manage Users</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation type="unfinished">Drive Locked</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation type="unfinished">Drive %1: is locked. Please enter the BitLocker key to access it:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation type="unfinished">Incorrect recovery key. Please try again.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Ustawienia</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Ogólne</translation>
    </message>
    <message>
      <source>System</source>
      <translation>System</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Język konsoli</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Domyślna zakładka podczas otwierania ustawień</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Włącz Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofea</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Otwórz niestandardowy folder obrazów/dźwięków trofeów</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Dziennik zdarzeń</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Typ dziennika</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Filtrowanie dziennika</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Otwórz lokalizację dziennika</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Sterowanie</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Kursor</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Ukryj kursor</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Czas oczekiwania na ukrycie kursora przy bezczynności</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Brak</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Urządzenie domyślne</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Kontroler</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafika</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Użytkownik</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Karta graficzna</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Zaawansowane</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Włącz zgrywanie shaderów</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Wyłącz kartę graficzną</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Włącz HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Ścieżki</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Foldery gier</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Dodaj...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Usuń</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Debugowanie</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Włącz zgrywanie debugowania</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Włącz warstwy walidacji Vulkan</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Włącz debugowanie RenderDoc</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Włącz diagnostykę awarii</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Zbieraj shadery</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Kopiuj bufory GPU</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Znaczniki diagnostyczne gospodarza</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Znaczniki diagnostyczne gościa</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Włącz odczyt zwrotny obrazów liniowych</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Sprawdź aktualizacje przy starcie</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Zawsze pokazuj dziennik zmian</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Sprawdź aktualizacje</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Muzyka tytułowa</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Wyłącz powiadomienia o trofeach</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Obraz tła</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Pokaż obraz tła</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Przezroczystość</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Odtwórz muzykę tytułową</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Aktualizuj bazę danych zgodności podczas uruchamiania</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Kompatybilność gier</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Wyświetl dane zgodności</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Aktualizuj bazę danych zgodności</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Głośność</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Zapisz</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Zastosuj</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Przywróć ustawienia domyślne</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Zamknij</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Najedź kursorem na opcję, aby wyświetlić jej opis.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Język konsoli:\nUstala język, który używa gra PS4.\nZaleca się ustawienie tego na język, który obsługuje gra, co może się różnić w zależności od regionu.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Język emulatora:\nUstala język interfejsu użytkownika emulatora.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Wyświetl ekran powitalny:\nPodczas uruchamiania gry wyświetla ekran powitalny (specjalny obraz).</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Włącz Discord Rich Presence:\nWyświetla ikonę emulatora i odpowiednie informacje na twoim profilu Discord.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Obraz tła:\nKontroluj przezroczystość obrazu tła gry.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Odtwórz muzykę tytułową:\nJeśli gra to obsługuje, aktywuje odtwarzanie specjalnej muzyki podczas wybierania gry w GUI.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Wyłącz wyskakujące okienka trofeów:\nWyłącz powiadomienia o trofeach w grze. Postępy w zdobywaniu trofeów można nadal śledzić za pomocą przeglądarki trofeów (kliknij prawym przyciskiem myszy grę w oknie głównym).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Ukryj kursor:\nWybierz, kiedy kursor zniknie:\nNigdy: Zawsze będziesz widział myszkę.\nNieaktywny: Ustaw czas, po którym zniknie po bezczynności.\nZawsze: nigdy nie zobaczysz myszki.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Ustaw czas, po którym mysz zniknie po bezczynności.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Wyświetl dane zgodności:\nWyświetla informacje o kompatybilności gry w widoku tabeli. Włącz opcję „Aktualizuj zgodność przy uruchomieniu”, aby uzyskać aktualne informacje.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Aktualizuj zgodność przy uruchomieniu:\nAutomatycznie aktualizuj bazę danych kompatybilności podczas uruchamiania shadPS4.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Zaktualizuj bazę danych zgodności:\nNatychmiast zaktualizuj bazę danych zgodności.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Nigdy</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Bezczynny</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Zawsze</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Urządzenie graficzne:\nW systemach z wieloma GPU, wybierz GPU, który emulator ma używać z rozwijanego menu,\n lub wybierz &quot;Auto Select&quot;, aby ustawić go automatycznie.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Szerokość/Wysokość:\nUstala rozmiar okna emulatora podczas uruchamiania, który może być zmieniany w trakcie gry.\nTo różni się od rozdzielczości w grze.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Włącz HDR:\nWłącza HDR w grach, które go wspierają.\nTwój monitor musi mieć wsparcie dla przestrzeni kolorów BT2020 PQ oraz formatu RGB10A2 swapchain.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Foldery gier:\nLista folderów do sprawdzenia zainstalowanych gier.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Dodaj:\nDodaj folder do listy.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Usuń:\nUsuń folder z listy.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Włącz zrzut debugowania:\nZapisuje symbole importu i eksportu oraz informacje nagłówkowe pliku dla aktualnie działającej aplikacji PS4 w katalogu.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Włącz debugowanie RenderDoc:\nJeśli włączone, emulator zapewnia kompatybilność z Renderdoc, aby umożliwić nagrywanie i analizowanie aktualnie renderowanej klatki.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Zbieranie shaderów:\nPotrzebujesz tej opcji aby edytować shadery za pomocą menu debugowania (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Odczyt zwrotny obrazów liniowych:\nWłącza asynchroniczne pobieranie obrazów liniowych zmodyfikowanych przez GPU.\nMoże naprawić błędy w niektórych grach.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Kopiowanie buforów karty graficznej:\nOmija problemy wyścigów związane z przesyłaniem danych do karty graficznej.\nMoże, ale nie musi, pomóc w przypadku awarii typu PM4 0.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Wskaźniki debugowania gospodarza:\nWstawia informacje emulatora, takie jak znaczniki dla konkretnych poleceń AMDGPU wokół poleceń Vulkan, a także nadaje nazwy debugowania zasobów.\nJeśli ta opcja jest włączona, powinieneś włączyć diagnostykę awarii.\nPrzydatne dla programów takich jak RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Znaczniki debugowania gościa:\nWstawia wszystkie znaczniki debugowania, które gra dodała do buforu poleceń.\nJeśli ta opcja jest włączona, powinieneś włączyć diagnostykę awarii.\nPrzydatne dla programów takich jak RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Wybierz poziom głośności muzyki w tle.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Włącz sterowanie ruchem</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Przeglądaj</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Wybór automatyczny</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Katalog do instalacji gier</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Wyświetlanie</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Tryb wyświetlania</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>Tryb okna</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Tryb pełnoekranowy</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Tryb pełnoekranowy (bez obramowania)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Rozmiar okna</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>Szerokość:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>Wysokość:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Oddzielne pliki dziennika</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Oddzielne pliki dziennika:\nZapisuje oddzielny plik dziennika dla każdej gry.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Pozycja powiadomień trofeów</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Z lewej</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Z prawej</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Z góry</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Z dołu</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Czas trwania powiadomienia</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Przenośny folder użytkownika</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Utwórz przenośny folder użytkownika ze folderu użytkownika udostępnianego</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Przenośny folder użytkownika:\nPrzechowuje ustawienia shadPS4 i dane, które zostaną zastosowane tylko do kompilacji shadPS4 znajdującej się w bieżącym folderze. Uruchom ponownie aplikację po utworzeniu przenośnego folderu użytkownika, aby zacząć z niego korzystać.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 już istnieje</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 prawidłowo utworzony.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Otwórz niestandardowy folder obrazów/dźwięków:\nMożesz dodać własne obrazy dla trofeów i ich dźwięki.\nDodaj pliki do custom_trophy o następujących nazwach:\ntrophy.wav LUB trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nUwaga: Dźwięki działają tylko w wersji QT.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Funkcje eksperymentalne</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>UWAGA: Te funkcje są eksperymentalne. Nie włączaj ich, jeśli członek zespołu nie dał Ci takiej instrukcji, lub jeśli gra tego nie wymaga. Jeśli masz pytania, dołącz do naszego serwera na Discordzie.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Używaj kontrolera w tle</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Używaj kontrolera w tle:\nPozwól na rejestrację wejścia z kontrolera, kiedy okno nie jest aktywne.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Diagnostyka awarii:\nTworzy plik .yaml z informacjami o stanie Vulkan w momencie awarii.\nPrzydatne do debugowania błędów &apos;DEVICE LOST&apos;. Jeśli ta opcja jest włączona, powinieneś włączyć "Znaczniki błędów gospodarza" oraz "Znaczniki błędów gościa".\nOpcja "Włącz warstwy walidacji Vulkan" i Vulkan SDK jest wymagana do działania.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Włącz rejestrowanie</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Włącz rejestrowanie:\nWłącza rejestrowanie.\nNie zmieniaj tego, jeśli nie wiesz co robisz&apos;!\nKiedy prosisz o pomoc, upewnij się, że to ustawienie jest WŁĄCZONE.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation type="unfinished">Present Mode</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation type="unfinished">Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation type="unfinished">Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation type="unfinished">Immediate (No Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation type="unfinished">Select the DLC folder</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation type="unfinished">Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the DLC path.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>Ustawienia FSR</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Włącz FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation type="unfinished">Enable RCAS (sharpening)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation type="unfinished">RCAS Attenuation:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation type="unfinished">Load Presets...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Dzienniki zdarzeń</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation type="unfinished">Open Log Location:\nOpen the folder where the log file is saved.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation type="unfinished">Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation type="unfinished">Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation type="unfinished">Default tab when opening settings:\nChoose which tab will open, the default is General.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation type="unfinished">Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation type="unfinished">Vblank Frequency</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation type="unfinished">Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation type="unfinished">Enable Direct Memory Access</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation type="unfinished">Enable Devkit Console Mode</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation type="unfinished">Set &quot;PSN signed-in&quot; to True</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation type="unfinished">Set &quot;Network Connected&quot; to True</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Pozostałe</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Interfejs</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Eksperymentalne</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation type="unfinished">Show Splash Screen When Launching Game</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Ogólne ustawienia interfejsu</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation type="unfinished">Enable PS4 Neo Mode</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation type="unfinished">Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation type="unfinished">Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation type="unfinished">Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation type="unfinished">Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation type="unfinished">Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Urządzenie dźwiękowe (ogólne)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Urządzenie dziękowe (Głośnik DualShock 4)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation type="unfinished">Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation type="unfinished">Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation type="unfinished">DLC Path:\nThe folder where game DLC is loaded from.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation type="unfinished">Additional DMem Allocation</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation type="unfinished">Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>Ścieżka modułów systemowych PS4:\nFolder, z którego są wczytywane moduły systemowe PS4.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Przeglądaj:\nPrzeglądaj folder, aby ustawić ścieżkę modułów systemowych (sys_modules).</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation type="unfinished">Vulkan Validation (Requires Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Warstwy walidacji</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Włącz weryfikację rdzenia</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Włącz weryfikację synchronizacji</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Włącz weryfikacje wspomaganą przez kartę graficzną</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Język interfejsu graficznego</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Aktualizacje interfejsu użytkownika</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation type="unfinished">DLC Path</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>Ścieżka do modułów systemowych PS4 (sys_modules)</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Aktualizacje GUI:\nWydanie: Oficjalne wersje wydawane każdego miesiąca, które mogą być bardzo nieaktualne, ale są bardziej wiarygodne i przetestowane.\nR: Wersje programistyczne, które mają wszystkie najnowsze funkcje i poprawki, ale mogą zawierać błędy i są mniej stabilne.\n\n*Ta aktualizacja dotyczy tylko interfejsu użytkownika Qt. Aby zaktualizować rdzeń emulatora, użyj menedżera wersji.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation type="unfinished">Cannot create portable launcher folder</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation type="unfinished">Portable launcherDir folder created</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>Urządzenie USB</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation type="unfinished">Real USB Device</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation type="unfinished">Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation type="unfinished">Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation type="unfinished">Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation type="unfinished">USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Włącz pamięć podręczną cieni</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Włącz pamięć podręczną cieni:\nPrzechowywanie skompilowanych cieni, aby uniknąć ponownych kompilacji, redukując przycinki.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation type="unfinished">Readbacks Mode</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation type="unfinished">Disabled</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation type="unfinished">Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation type="unfinished">Relaxed</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation type="unfinished">Precise</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation type="unfinished">Select shadPS4 Home Path</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation type="unfinished">Select the system modules folder</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation type="unfinished">Home Folder Location (Saves, Inputs, Trophy Data)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation type="unfinished">Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the home folder.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation type="unfinished">Audio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation type="unfinished">Audio Backend</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation type="unfinished">Mic Device</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation type="unfinished">Devices</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation type="unfinished">Camera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation type="unfinished">Log Sync</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation type="unfinished">Log Skip Duplicate</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation type="unfinished">Log Max Skip Duration</translation>
    </message>
    <message>
      <source> ms</source>
      <translation type="unfinished"> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation type="unfinished">Log Size Limit</translation>
    </message>
    <message>
      <source> B</source>
      <translation type="unfinished"> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation type="unfinished">Log Append</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation type="unfinished">wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation type="unfinished">msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation type="unfinished">Log Append:\nAppend to existing logs.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation type="unfinished">Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation type="unfinished">Log Size Limit:\nMaximum size of log files (bytes).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation type="unfinished">Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation type="unfinished">Log Sync:\nSwitch between sync (order) or async (performance).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation type="unfinished">Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation type="unfinished">Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Wybierz wersje</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Wybierz wersję do utworzenia skrótu</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nie wybrano wersji</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Najpierw wybierz wersję</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Menedżer trofeów</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Wybierz grę:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Postęp</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Pokaż zdobyte trofea</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Pokaż niezdobyte trofea</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Pokaż ukryte trofea</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation type="unfinished">Select User:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation type="unfinished">User Manager</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation type="unfinished">&amp;Create User</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation type="unfinished">&amp;Delete User</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation type="unfinished">&amp;Rename User</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation type="unfinished">&amp;Set Default User</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation type="unfinished">&amp;Set Color</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation type="unfinished">&amp;Set Controller Port</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation type="unfinished">&amp;Close</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation type="unfinished">Cannot add more users.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation type="unfinished">Create New User</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation type="unfinished">New User ID: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation type="unfinished">Username (3–16 chars, letters, numbers, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation type="unfinished">Invalid Username</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation type="unfinished">Username must be 3–16 chars and valid.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation type="unfinished">Delete Confirmation</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation type="unfinished">Delete user ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation type="unfinished">Rename User</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation type="unfinished">Old Username: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation type="unfinished">Set User Color</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation type="unfinished">Select color:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation type="unfinished">Set Controller Port</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation type="unfinished">Assign port (1-4) to this user:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation type="unfinished">&amp;Open User Directory</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Menedżer wersji</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Ścieżka do zapisywania wersji</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Przeglądaj</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Zainstalowano</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Wybrano</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Wersja</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Nazwa kodowa</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Dodaj niestandardowe</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Usuń</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Odśwież listę</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Pobierz</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation type="unfinished">Check for Pre-release updates at startup</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation type="unfinished">Check for Pre-release Updates</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation type="unfinished">Select the folder where the emulator versions will be installed</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Wybierz plik wykonywalny</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Plik wykonywalny (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Nazwa wersji</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation type="unfinished">Enter the name of this version as it appears in the list.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Błąd</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Sukces</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>Wesja została dodana pomyślnie.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Nie udało się określić ścieżki folderu.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Usuń wersję</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Czy chcesz usunąć wersję</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation type="unfinished">Version list update</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation type="unfinished">No news, the version list is already updated.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>Najnowsze wersje zostały dodane do listy do pobrania.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Wystąpił błąd podczas próby nawiązania połączenia z GitHub API</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation type="unfinished">First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Czy chcesz pobrać wersję</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Brak dostępnych plików dla tej platformy.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Pobieranie %1 , proszę czekać...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Nie można zapisać pliku.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>Wersja %1 została pobrana i wybrana.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Nie udało się utworzyć skryptu wypakowywującego plik zip</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>Odpowiedź API GitHub nie jest prawidłową tablicą JSON.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Asystent aktualizacji - Emulator</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation type="unfinished">You already have the latest pre-release version.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Dostępna aktualizacja (Emulator)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Obecna wersja</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Najnowsza wersja</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Czy chcesz zaktualizować?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Aktualizuj</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Nie</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Pokaż zmiany</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Ukryj zmiany</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Błąd sieciowy podczas pobierania listy zmian</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Zmiany</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nie znaleziono adresu URL do pobrania dla określonego zasobu.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Wystąpił błąd sieci podczas pobierania</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation type="unfinished">Failed to save download file</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation type="unfinished">Complete installation</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation type="unfinished">Pre-release updated successfully</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation type="unfinished">Failed to create the update script file</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Zawsze wyświetlaj listę zmian</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Nie wybrano wersji. Proszę wybrać jedną z listy do usunięcia.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Potwierdź pobieranie</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Błąd wypakowywania.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Wersja o tej nazwie już istnieje.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation type="unfinished">Local</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation type="unfinished">Failed to determine the folder to remove.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Nie udało się usunąć folderu.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation type="unfinished">Unable to get hash of latest pre-release.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation type="unfinished">Downloading Pre-release (Nightly), please wait...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation type="unfinished">Dimensions Manager</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation type="unfinished">Active Dimensions Figures:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Brak</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Wyczyść</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Wczytaj</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Przenieś</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation type="unfinished">Select Dimensions File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation type="unfinished">Filter by Series:</translation>
    </message>
    <message>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation type="unfinished">Series:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation type="unfinished">Series number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation type="unfinished">Failed to create figure file!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation type="unfinished">Failed to create figure file:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation type="unfinished">Infinity Manager</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation type="unfinished">Active Infinity Figures:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation type="unfinished">Play Set/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation type="unfinished">Power Disc Two</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation type="unfinished">Power Disc Three</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation type="unfinished">Player One</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation type="unfinished">Player One Ability One</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation type="unfinished">Player One Ability Two</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation type="unfinished">Player Two</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation type="unfinished">Player Two Ability One</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation type="unfinished">Player Two Ability Two</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Wyczyść</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Wczytaj</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation type="unfinished">Select Infinity File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation type="unfinished">Failed to create minifig file!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation type="unfinished">Failed to create minifig file:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation type="unfinished">Figure Mover</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Brak</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation type="unfinished">Move Here</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation type="unfinished">Pick up and Place</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Kreator Skylander</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Wariant:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Anuluj</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>Wprowadzony identyfikator jest nieprawidłowy!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>Wprowadzony wariant jest nieprawidłowy!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Utwórz plik Skylander</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Obiekt Skylander (*.sky);;Wszystkie pliki (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Nie udało się utworzyć pliku Skylander!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Nie udało się utworzyć pliku Skylander:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Menedżer Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation type="unfinished">Active Portal Skylanders:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Wyczyść</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Utwórz</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Wczytaj</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Wybierz plik Skylander</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);Wszystkie pliki (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Nie udało się otworzyć pliku Skylander!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Nie udało się otworzyć pliku skylander (%1)!
Plik może być już używany na portalu.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Nie udało się odczytać pliku Skylander!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Nie udało się odczytać pliku Skylander (%1)!
Plik jest zbyt mały.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Nieznany (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Brak</translation>
    </message>
  </context>
</TS>
