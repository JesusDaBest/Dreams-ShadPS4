<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>A shadPS4-ről</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>A shadPS4 egy kezdetleges, open-source PlayStation 4 emulátor.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Ne használja ezt a szoftvert olyan játékokkal, amelyeket nem legális módon szerzett be.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation type="unfinished">Cheats / Patches for </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>A csalások/javítások kísérleti jellegűek.\nHasználja őket óvatosan.\n\nTöltse le a csalásokat egyesével a tároló kiválasztásával és a letöltés gombra kattintással.\nA Javítások fül alatt egyszerre letöltheti az összes javítást, majd választhat, melyeket szeretné használni, és elmentheti a választását.\n\nMivel nem mi fejlesztjük a csalásokat/patch-eket,\nkérjük, jelentse a problémákat a csalás szerzőjének.\n\nKészített egy új csalást? Látogasson el ide:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Nincs elérhető kép</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Sorozatszám: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Verzió: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Méret: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Válaszd ki a csalás fájlt:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Tároló:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Csalások letöltése</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Fájl törlése</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Nincsenek kiválasztott fájlok.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Törölheted a nem kívánt csalásokat a letöltés után.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Szeretnéd törölni a kiválasztott fájlt?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Válaszd ki a javítás fájlt:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Javítások letöltése</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Mentés</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Csalások</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Javítások</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Hiba</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Nincs kiválasztva javítás.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Nem sikerült megnyitni a files.json fájlt olvasásra.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Nincs található javítási fájl a jelenlegi sorozatszámhoz.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Nem sikerült megnyitni a fájlt olvasásra.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Nem sikerült megnyitni a fájlt írásra.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>XML elemzési hiba: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Siker</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>A beállítások sikeresen elmentve.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Érvénytelen forrás</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>A kiválasztott forrás érvénytelen.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>A fájl létezik</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>A fájl már létezik. Szeretnéd helyettesíteni?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Nem sikerült elmenteni a fájlt:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Nem sikerült letölteni a fájlt:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Csalások nem találhatóak</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Nincs található csalás ezen a játékverzión ebben a kiválasztott tárolóban, próbálj meg egy másik tárolót vagy a játék egy másik verzióját.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Csalások sikeresen letöltve</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Sikeresen letöltötted a csalásokat ennek a játéknak a verziójához a kiválasztott tárolóból. Próbálhatsz letölteni egy másik tárolóból is, ha az elérhető, akkor a fájl kiválasztásával az is használható lesz.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Nem sikerült menteni:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Nem sikerült letölteni:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Letöltés befejezve</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Frissítések sikeresen letöltve! Minden elérhető frissítés letöltésre került, nem szükséges egyesével letölteni őket minden játékhoz, mint a csalások esetében. Ha a javítások nem jelennek meg, lehet, hogy nem léteznek a játék adott sorozatszámához és verziójához.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Nem sikerült az JSON adatok elemzése HTML-ből.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Nem sikerült HTML oldal lekérése.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>A játék verziója: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>A letöltött javításhoz a(z) %1 verzió működik</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Lehet, hogy frissítened kell a játékodat.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Inkompatibilitási értesítés</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Nem sikerült megnyitni a fájlt:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>XML HIBA:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Nem sikerült megnyitni a files.json fájlt írásra</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Szerző: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>A mappa nem létezik:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Nem sikerült megnyitni a files.json fájlt olvasásra.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Név:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Nem lehet csalásokat alkalmazni, mielőtt a játék elindul.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Bezárás</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Automatikus frissítő</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Hiba</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Hálózati hiba:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Az automatikus frissítő óránként legfeljebb 60 frissítésellenőrzést engedélyez.\nElérte ezt a korlátot. Kérjük, próbálja újra később.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>A frissítési információk elemzése sikertelen.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Nem található előzetes kiadás.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nincs letöltési URL a megadott eszközhöz.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>A verziód már naprakész!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Jelenlegi verzió</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Új verzió</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Szeretnéd frissíteni?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Változások megjelenítése</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Frissítések keresése indításkor</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Frissítés</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Mégse</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Változások elrejtése</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Változások</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Hálózati hiba történt az URL elérésekor</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Letöltés kész</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>A frissítés letöltődött, nyomja meg az OK gombot az telepítéshez.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>A frissítési fájl mentése nem sikerült a következő helyre</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Frissítés indítása...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>A frissítési szkript fájl létrehozása nem sikerült</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation type="unfinished">Auto Updater - GUI</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation type="unfinished">Update Available - GUI</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Kompatibilitási adatok betöltése, kérem várjon</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Megszakítás</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Betöltés...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Hiba</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Nem sikerült frissíteni a kompatibilitási adatokat! Kérem próbálja újra később.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Nem sikerült megnyitni a compatibility_data.json fájlt írásra.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Ismeretlen</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Semmi</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Csizmák</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menük</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>Játékban</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Játszható</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation type="unfinished">Configure Controls</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation type="unfinished">D-Pad</translation>
    </message>
    <message>
      <source>Up</source>
      <translation type="unfinished">Up</translation>
    </message>
    <message>
      <source>Left</source>
      <translation type="unfinished">Left</translation>
    </message>
    <message>
      <source>Right</source>
      <translation type="unfinished">Right</translation>
    </message>
    <message>
      <source>Down</source>
      <translation type="unfinished">Down</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation type="unfinished">Left Stick</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation type="unfinished">Config Selection</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation type="unfinished">Common Config</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation type="unfinished">Use per-game configs</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation type="unfinished">Face Buttons</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation type="unfinished">Right Stick</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation type="unfinished">Color Adjustment</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation type="unfinished">Override Lightbar Color</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation type="unfinished">Override Color</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation type="unfinished">Unable to Save</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation type="unfinished">Cannot bind axis values more than once</translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished">Save</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation type="unfinished">Apply</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation type="unfinished">unmapped</translation>
    </message>
    <message>
      <source>Options</source>
      <translation type="unfinished">Options</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation type="unfinished">Touchpad Left</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation type="unfinished">Touchpad Center</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation type="unfinished">Touchpad Right</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation type="unfinished">Triangle</translation>
    </message>
    <message>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation type="unfinished">Circle</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation type="unfinished">Cross</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation type="unfinished">Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation type="unfinished">Press a button</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation type="unfinished">Move analog stick</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation type="unfinished">L1 and L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation type="unfinished">Active Gamepad</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation type="unfinished">Gamepad ID</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation type="unfinished">Default Gamepad</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation type="unfinished">No default selected</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation type="unfinished">n/a</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation type="unfinished">Set Active Gamepad as Default</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation type="unfinished">Remove Default Gamepad</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation type="unfinished">R1 and R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation type="unfinished">ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation type="unfinished">Default Controller Selected</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation type="unfinished">Active controller set as default</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation type="unfinished">Default Controller Removed</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation type="unfinished">Default controller setting removed</translation>
    </message>
    <message>
      <source>RED</source>
      <translation type="unfinished">RED</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation type="unfinished">GREEN</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation type="unfinished">BLUE</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation type="unfinished">Left Stick Deadzone</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation type="unfinished">Min Deadzone (def:2 max:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation type="unfinished">Max Deadzone (def:127 max:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation type="unfinished">Right Stick Deadzone</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation type="unfinished">Crypto Key Manager</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation type="unfinished">Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation type="unfinished">Enter Trophy Key</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation type="unfinished">Trophy Key:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation type="unfinished">Status: Not loaded</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation type="unfinished">Trophy Key</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation type="unfinished">Enter %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation type="unfinished">Exponent1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation type="unfinished">Exponent2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation type="unfinished">Public Exponent</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation type="unfinished">Coefficient</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation type="unfinished">Modulus</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation type="unfinished">Prime 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation type="unfinished">Prime 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation type="unfinished">Private Exponent</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation type="unfinished">Fake Keyset</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for fake signing.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation type="unfinished">Debug Rif Keyset</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation type="unfinished">Pkg Derived Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation type="unfinished">RSA key components for package decryption.
All fields must be valid hex strings with even length.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished">Close</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation type="unfinished">Warning</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation type="unfinished">No key file found or failed to load.
Please enter your keys and save them.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation type="unfinished">Validation Error</translation>
    </message>
    <message>
      <source>Success</source>
      <translation type="unfinished">Success</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation type="unfinished">Keys saved successfully!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation type="unfinished">Failed to save keys!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation type="unfinished">Status: All fields empty</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation type="unfinished">Status: Invalid hex values</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation type="unfinished">Status: Incomplete</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation type="unfinished">Status: Valid</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation type="unfinished">Invalid File</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation type="unfinished">Only JSON files are supported.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation type="unfinished">Unable to open file.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation type="unfinished">JSON Error</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation type="unfinished">Invalid JSON format.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation type="unfinished">Keys successfully loaded from JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation type="unfinished">Trophy Key contains invalid hex or has odd length.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation type="unfinished">%1 contains invalid hex or has odd length.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation type="unfinished">Load Key</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation type="unfinished">Save Key</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation type="unfinished">Edit Keyboard + Mouse and Controller input bindings</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation type="unfinished">Use Per-Game configs</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation type="unfinished">Could not open the file for reading</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation type="unfinished">Could not open the file for writing</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation type="unfinished">Save Changes</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation type="unfinished">Do you want to save changes?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation type="unfinished">Help</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation type="unfinished">Do you want to reset your custom default config to the original default config?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation type="unfinished">Do you want to reset this config to your custom default config?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation type="unfinished">Reset to Default</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Mappa megnyitása</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Játék könyvtár betöltése, kérjük várjon :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Megszakítás</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Betöltés..</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Mappa kiválasztása</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Böngészés</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Hiba</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation type="unfinished">Directory to install emulator versions</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation type="unfinished">Directory with your dumped games</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation type="unfinished">Directory with your dumped DLC&apos;s</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation type="unfinished">Directory with games</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation type="unfinished">Directory with DLC&apos;s</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Ikon</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Név</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Sorozatszám</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation type="unfinished">Compatibility</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Régió</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation type="unfinished">Firmware</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Méret</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Verzió</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Útvonal</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Játékidő</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation type="unfinished">Never Played</translation>
    </message>
    <message>
      <source>h</source>
      <translation type="unfinished">h</translation>
    </message>
    <message>
      <source>m</source>
      <translation type="unfinished">m</translation>
    </message>
    <message>
      <source>s</source>
      <translation type="unfinished">s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation type="unfinished">Compatibility is untested</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation type="unfinished">Game does not initialize properly / crashes the emulator</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation type="unfinished">Game boots, but only displays a blank screen</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation type="unfinished">Game displays an image but does not go past the menu</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation type="unfinished">Game has game-breaking glitches or unplayable performance</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation type="unfinished">Game can be completed with playable performance and no major glitches</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Kattintson a részletek megtekintéséhez a GitHubon</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Utoljára frissítve</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation type="unfinished">Favorite</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation type="unfinished">B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation type="unfinished">KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation type="unfinished">MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation type="unfinished">GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation type="unfinished">TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Csalások / Javítások</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>SFO Nézegető</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Trófeák Megtekintése</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Mappa megnyitása...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Játék Mappa Megnyitása</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Mentési adatok mappa megnyitása</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Napló mappa megnyitása</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Információ Másolása...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Név Másolása</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Széria Másolása</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation type="unfinished">Copy Version</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation type="unfinished">Copy Size</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Összes Másolása</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Törlés...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Játék törlése</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Frissítések törlése</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>DLC-k törlése</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation type="unfinished">Delete Trophy</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation type="unfinished">Compatibility...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Hiba</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Játék</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Ehhez a játékhoz nem tartozik törlendő frissítés!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Frissítés</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Ehhez a játékhoz nem tartozik törlendő DLC!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation type="unfinished">DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation type="unfinished">Delete %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Biztosan törölni akarja a %1&apos;s %2 mappát?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation type="unfinished">Open Update Folder</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation type="unfinished">Delete Save Data</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation type="unfinished">This game has no update folder to open!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation type="unfinished">No log file found for this game!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation type="unfinished">This game has no save data to delete!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation type="unfinished">This game has no saved trophies to delete!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation type="unfinished">Save Data</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation type="unfinished">Trophy</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation type="unfinished">SFO Viewer for </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation type="unfinished">Remove from Favorites</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation type="unfinished">Add to Favorites</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation type="unfinished">Game-specific Settings...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation type="unfinished">Configure Game-specific Settings</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation type="unfinished">Create Game-specific Settings from Global Settings</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation type="unfinished">Delete Game-specific Settings</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation type="unfinished">Update Database</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation type="unfinished">View Report</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation type="unfinished">Submit a Report</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation type="unfinished">Confirm deletion</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation type="unfinished">Delete game-specific settings?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation type="unfinished">Launch...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation type="unfinished">Launch with game specific configs (default)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation type="unfinished">Launch with global config only</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation type="unfinished">Launch with default settings</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation type="unfinished">Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation type="unfinished">Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation type="unfinished">Info</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation type="unfinished">Create Shortcut for Selected Emulator Version</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation type="unfinished">Create Shortcut for Specified Emulator Version</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation type="unfinished">Create Shortcut</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation type="unfinished">Shortcut creation</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation type="unfinished">Shortcut created successfully!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation type="unfinished">Error creating shortcut!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation type="unfinished">Failed to convert icon.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation type="unfinished">Delete Shader Cache</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation type="unfinished">This game does not have any saved Shader Cache to delete!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation type="unfinished">Shader Cache</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation type="unfinished">This game has no save folder to open!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation type="unfinished">A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation type="unfinished">Quickstart</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation type="unfinished">FAQ</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation type="unfinished">Syntax</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation type="unfinished">Special Bindings</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation type="unfinished">Keybindings</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation type="unfinished">Customize Hotkeys</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation type="unfinished">Show FPS Counter</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation type="unfinished">unmapped</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation type="unfinished">Quit Emulation</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation type="unfinished">Reload Button Mappings</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation type="unfinished">Toggle Fullscreen</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation type="unfinished">Toggle Pause</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation type="unfinished">Toggle Mouse to Joystick Emulation</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation type="unfinished">Toggle Mouse to Gyro Emulation</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation type="unfinished">Tip: Up to three simultaneous inputs can be assigned for each hotkey</translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished">Save</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation type="unfinished">Apply</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation type="unfinished">Unable to Save</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation type="unfinished">Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation type="unfinished">Waiting for inputs</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation type="unfinished">Volume Up</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation type="unfinished">Volume Down</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation type="unfinished">Hotkeys</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation type="unfinished">Placeholder</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation type="unfinished">Capture Screenshot</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation type="unfinished">Capture Screenshot w/ Overlays</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation type="unfinished">Open Emulator Settings</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation type="unfinished">Could not find the emulator executable</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation type="unfinished">No game is running</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation type="unfinished">Configure Controls</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation type="unfinished">unmapped</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation type="unfinished">Left Analog Halfmode</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation type="unfinished">Config Selection</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation type="unfinished">Common Config</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation type="unfinished">Use per-game configs</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation type="unfinished">Text Editor</translation>
    </message>
    <message>
      <source>Help</source>
      <translation type="unfinished">Help</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation type="unfinished">Mouse to Joystick</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation type="unfinished">*press F7 ingame to activate</translation>
    </message>
    <message>
      <source>Options</source>
      <translation type="unfinished">Options</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation type="unfinished">Mouse Movement Parameters</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation type="unfinished">note: click Help Button/Special Keybindings for more information</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation type="unfinished">Triangle</translation>
    </message>
    <message>
      <source>Square</source>
      <translation type="unfinished">Square</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation type="unfinished">Circle</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation type="unfinished">Cross</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation type="unfinished">Right Analog Halfmode</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation type="unfinished">Speed Offset (def 0.125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation type="unfinished">Copy from Common Config</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation type="unfinished">Deadzone Offset (def 0.50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation type="unfinished">Speed Multiplier (def 1.0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation type="unfinished">Copy values from Common Config</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation type="unfinished">Do you want to overwrite existing mappings with the mappings from the Common Config?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation type="unfinished">Unable to Save</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation type="unfinished">Press a key</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation type="unfinished">Cannot set mapping</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation type="unfinished">Mousewheel cannot be mapped to stick outputs</translation>
    </message>
    <message>
      <source>Save</source>
      <translation type="unfinished">Save</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation type="unfinished">Apply</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation type="unfinished">Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation type="unfinished">Touchpad Left</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation type="unfinished">Touchpad Center</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation type="unfinished">Touchpad Right</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation type="unfinished">Tip: Unmap inputs with right-click</translation>
    </message>
    <message>
      <source>Output</source>
      <translation type="unfinished">Output</translation>
    </message>
    <message>
      <source>Input</source>
      <translation type="unfinished">Input</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation type="unfinished">Alternate Input 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation type="unfinished">Alternate Input 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation type="unfinished">Dpad Up</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation type="unfinished">Dpad Down</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation type="unfinished">Dpad Left</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation type="unfinished">Dpad Right</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation type="unfinished">Left Stick Up</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation type="unfinished">Left Stick Down</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation type="unfinished">Left Stick Left</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation type="unfinished">Left Stick Right</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation type="unfinished">Right Stick Up</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation type="unfinished">Right Stick Down</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation type="unfinished">Right Stick Left</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation type="unfinished">Right Stick Right</translation>
    </message>
    <message>
      <source>L1</source>
      <translation type="unfinished">L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation type="unfinished">R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation type="unfinished">L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation type="unfinished">R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation type="unfinished">L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation type="unfinished">R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation type="unfinished">Log Filter Presets</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation type="unfinished">Comment</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation type="unfinished">Filter</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Close</source>
      <translation type="unfinished">Close</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation type="unfinished">Add a new preset after the selected row</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation type="unfinished">Remove selected presets</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation type="unfinished">Load the selected preset</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>ELF Mappa Megnyitása/Hozzáadása</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Játék Indítása</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Frissítések keresése</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>A shadPS4-ről</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Konfigurálás...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Legutóbbi Játékok</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation type="unfinished">Open shadPS4 Folder</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Kilépés</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Kilépés a shadPS4-ből</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Lépjen ki a programból.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Játék Könyvtár Megjelenítése</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Játék Könyvtár Újratöltése</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Apró</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Kicsi</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Közepes</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Nagy</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Lista Nézet</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Rács Nézet</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Elf Nézegető</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Játék Telepítési Mappa</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Csalások / Javítások letöltése</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Játéklista Dumpolása</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation type="unfinished">Trophy Viewer</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation type="unfinished">No games found. Please add your games to your library first.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Keresés...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Fájl</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Nézet</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Játékkönyvtár Ikonok</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Játékkönyvtár Nézet</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Beállítások</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Segédeszközök</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Témák</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Segítség</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Sötét</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Világos</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Zöld</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Kék</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Ibolya</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Eszköztár</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Játéklista</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Csalások letöltése minden telepített játékhoz</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Javítások letöltése minden játékhoz</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Letöltés befejezve</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Minden elérhető csalás letöltődött az összes telepített játékhoz.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Javítások sikeresen letöltve!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Az összes játékhoz elérhető javítás letöltésre került.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Játékok: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>ELF fájlok (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Játék indító</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Csak egy fájl választható ki!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation type="unfinished">Run Game</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation type="unfinished">Eboot.bin file not found</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation type="unfinished">Game is already running!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation type="unfinished">shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation type="unfinished">Play</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation type="unfinished">Pause</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation type="unfinished">Stop</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation type="unfinished">Restart</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation type="unfinished">Full Screen</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation type="unfinished">Controllers</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation type="unfinished">Keyboard</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation type="unfinished">Refresh List</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation type="unfinished">Resume</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation type="unfinished">Show Labels Under Icons</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation type="unfinished">Customize Hotkeys</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation type="unfinished">Version Manager</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation type="unfinished">No Version Selected</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation type="unfinished">No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation type="unfinished">Could not find the emulator executable</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation type="unfinished">Run Emulator</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation type="unfinished">Emulator is already running!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation type="unfinished">Invalid game argument provided</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation type="unfinished">Manage Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation type="unfinished">Manage Infinity Figures</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation type="unfinished">Manage Dimensions Toypad</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation type="unfinished">Game Log</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation type="unfinished">Show Game Log</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation type="unfinished">Manage Cryptographic Keys</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation type="unfinished">Manage Users</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation type="unfinished">Drive Locked</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation type="unfinished">Drive %1: is locked. Please enter the BitLocker key to access it:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation type="unfinished">Incorrect recovery key. Please try again.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Beállítások</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Általános</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Rendszer</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>A Konzol Nyelvezete</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Alapértelmezett fül a beállítások megnyitásakor</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>A Discord Rich Presence engedélyezése</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation type="unfinished">Trophy</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation type="unfinished">Open the custom trophy images/sounds folder</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Naplózó</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Naplózási Típus</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Naplózási Filter</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Napló helyének megnyitása</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Bemenet</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Kurzor</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Kurzor elrejtése</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Kurzor inaktivitási időtúllépés</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation type="unfinished">Default Device</translation>
    </message>
    <message>
      <source>s</source>
      <translation type="unfinished">s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Kontroller</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafika</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Felhasználó</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Grafikai Eszköz</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Haladó</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Shader Dumpolás Engedélyezése</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>NULL GPU Engedélyezése</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation type="unfinished">Enable HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Útvonalak</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Játékmappák</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Hozzáadás...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Eltávolítás</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Debugolás</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Debug Dumpolás Engedélyezése</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Vulkan Validációs Rétegek Engedélyezése</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>RenderDoc Debugolás Engedélyezése</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation type="unfinished">Enable Crash Diagnostics</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation type="unfinished">Collect Shaders</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation type="unfinished">Copy GPU Buffers</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation type="unfinished">Host Debug Markers</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation type="unfinished">Guest Debug Markers</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation type="unfinished">Enable Readback Linear Images</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Frissítések keresése indításkor</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Mindig mutasd a változásnaplót</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Frissítések keresése</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation type="unfinished">Title Music</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation type="unfinished">Disable Trophy Notification</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation type="unfinished">Background Image</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation type="unfinished">Show Background Image</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation type="unfinished">Opacity</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Címzene lejátszása</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation type="unfinished">Update Compatibility Database On Startup</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation type="unfinished">Game Compatibility</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation type="unfinished">Display Compatibility Data</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation type="unfinished">Update Compatibility Database</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Hangerő</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Mentés</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Alkalmaz</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Alapértelmezett értékek visszaállítása</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Bezárás</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Helyezze az egérmutatót egy lehetőség fölé, hogy megjelenítse annak leírását.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Konzol nyelve:\nBeállítja a PS4 játék nyelvét.\nAjánlott a játék által támogatott nyelvre állítani, amely régiónként változhat.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Emulátor nyelve:\nBeállítja az emulátor felhasználói felületének nyelvét.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Indítóképernyő megjelenítése:\nMegjeleníti a játék indítóképernyőjét (különleges képet) a játék elindításakor.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>A Discord Rich Presence engedélyezése:\nMegjeleníti az emulator ikonját és a kapcsolódó információkat a Discord profilján.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation type="unfinished">Background Image:\nControl the opacity of the game background image.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Játék címzene lejátszása:\nHa a játék támogatja, engedélyezze egy speciális zene lejátszását, amikor a játékot kiválasztja a GUI-ban.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation type="unfinished">Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Kurzor elrejtése:\nVálassza ki, mikor tűnjön el az egérmutató:\nSoha: Az egér mindig látható.\nInaktív: Állítson be egy időt, amennyi idő mozdulatlanság után eltűnik.\nMindig: az egér mindig el lesz rejtve.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Állítson be egy időt, ami után egér inaktív állapotban eltűnik.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation type="unfinished">Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation type="unfinished">Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation type="unfinished">Update Compatibility Database:\nImmediately update the compatibility database.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Soha</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Inaktív</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Mindig</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Grafikus eszköz:\nTöbb GPU-s rendszereken válassza ki, melyik GPU-t használja az emulátor a legördülő listából,\nvagy válassza az &quot;Auto Select&quot; lehetőséget, hogy automatikusan kiválassza azt.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Szélesség/Magasság:\nBeállítja az emulátor ablakának méretét induláskor, amely a játék során átméretezhető.\nEz különbözik a játékbeli felbontástól.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation type="unfinished">Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Játék mappák:\nA mappák listája, ahol telepített játékok vannak.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Hozzáadás:\nHozzon létre egy mappát a listában.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Eltávolítás:\nTávolítson el egy mappát a listából.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Debug dumpolás engedélyezése:\nElmenti a futó PS4 program import- és exportszimbólumait, valamint a fájl fejlécinformációit egy könyvtárba.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>RenderDoc hibakeresés engedélyezése:\nHa engedélyezve van, az emulátor kompatibilitást biztosít a Renderdoc számára, hogy lehetővé tegye a jelenleg renderelt keret rögzítését és elemzését.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation type="unfinished">Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation type="unfinished">Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation type="unfinished">Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation type="unfinished">Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation type="unfinished">Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation type="unfinished">Set the volume of the background music.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation type="unfinished">Enable Motion Controls</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Böngészés</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation type="unfinished">Auto Select</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Mappa a játékok telepítésére</translation>
    </message>
    <message>
      <source>Video</source>
      <translation type="unfinished">Video</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation type="unfinished">Display Mode</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation type="unfinished">Windowed</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation type="unfinished">Fullscreen</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation type="unfinished">Fullscreen (Borderless)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation type="unfinished">Window Size</translation>
    </message>
    <message>
      <source>W:</source>
      <translation type="unfinished">W:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation type="unfinished">H:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation type="unfinished">Separate Log Files</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation type="unfinished">Separate Log Files:\nWrites a separate logfile for each game.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation type="unfinished">Trophy Notification Position</translation>
    </message>
    <message>
      <source>Left</source>
      <translation type="unfinished">Left</translation>
    </message>
    <message>
      <source>Right</source>
      <translation type="unfinished">Right</translation>
    </message>
    <message>
      <source>Top</source>
      <translation type="unfinished">Top</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation type="unfinished">Bottom</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation type="unfinished">Notification Duration</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation type="unfinished">Portable User Folder</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation type="unfinished">Create Portable User Folder from Common User Folder</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation type="unfinished">Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation type="unfinished">%1 already exists</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation type="unfinished">%1 successfully created.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation type="unfinished">Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation type="unfinished">Experimental Features</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation type="unfinished">WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation type="unfinished">Enable Background Controller Input</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation type="unfinished">Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation type="unfinished">Enable Logging</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation type="unfinished">Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation type="unfinished">Present Mode</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation type="unfinished">Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation type="unfinished">Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation type="unfinished">Immediate (No Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation type="unfinished">Select the DLC folder</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation type="unfinished">Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the DLC path.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation type="unfinished">FSR Settings</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation type="unfinished">Enable FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation type="unfinished">Enable RCAS (sharpening)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation type="unfinished">RCAS Attenuation:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation type="unfinished">Load Presets...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation type="unfinished">Log</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation type="unfinished">Open Log Location:\nOpen the folder where the log file is saved.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation type="unfinished">Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation type="unfinished">Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation type="unfinished">Default tab when opening settings:\nChoose which tab will open, the default is General.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation type="unfinished">Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation type="unfinished">Vblank Frequency</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation type="unfinished">Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation type="unfinished">Enable Direct Memory Access</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation type="unfinished">Enable Devkit Console Mode</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation type="unfinished">Set &quot;PSN signed-in&quot; to True</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation type="unfinished">Set &quot;Network Connected&quot; to True</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation type="unfinished">Miscellaneous</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation type="unfinished">Frontend</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation type="unfinished">Experimental</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation type="unfinished">Show Splash Screen When Launching Game</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation type="unfinished">General Frontend Settings</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation type="unfinished">Enable PS4 Neo Mode</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation type="unfinished">Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation type="unfinished">Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation type="unfinished">Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation type="unfinished">Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation type="unfinished">Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation type="unfinished">Audio Device (general)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation type="unfinished">Audio Device (DS4 speaker)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation type="unfinished">Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation type="unfinished">Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation type="unfinished">DLC Path:\nThe folder where game DLC is loaded from.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation type="unfinished">Additional DMem Allocation</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation type="unfinished">Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation type="unfinished">PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the sysmodules path.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation type="unfinished">Vulkan Validation (Requires Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation type="unfinished">Validation Layers</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation type="unfinished">Enable Core Validation</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation type="unfinished">Enable Sync Validation</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation type="unfinished">Enable GPU-Assisted Validation</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation type="unfinished">Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation type="unfinished">GUI Language</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation type="unfinished">GUI Updates</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation type="unfinished">DLC Path</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation type="unfinished">PS4 Sysmodules Path</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation type="unfinished">GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation type="unfinished">Cannot create portable launcher folder</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation type="unfinished">Portable launcherDir folder created</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation type="unfinished">USB Device</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation type="unfinished">Real USB Device</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation type="unfinished">Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation type="unfinished">Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation type="unfinished">Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation type="unfinished">USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation type="unfinished">Enable Shader Cache</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation type="unfinished">Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation type="unfinished">Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation type="unfinished">Readbacks Mode</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation type="unfinished">Disabled</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation type="unfinished">Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation type="unfinished">Relaxed</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation type="unfinished">Precise</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation type="unfinished">Select shadPS4 Home Path</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation type="unfinished">Select the system modules folder</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation type="unfinished">Home Folder Location (Saves, Inputs, Trophy Data)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation type="unfinished">Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation type="unfinished">Browse:\nBrowse for a folder to set as the home folder.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation type="unfinished">Audio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation type="unfinished">Audio Backend</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation type="unfinished">Mic Device</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation type="unfinished">Devices</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation type="unfinished">Camera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation type="unfinished">Log Sync</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation type="unfinished">Log Skip Duplicate</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation type="unfinished">Log Max Skip Duration</translation>
    </message>
    <message>
      <source> ms</source>
      <translation type="unfinished"> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation type="unfinished">Log Size Limit</translation>
    </message>
    <message>
      <source> B</source>
      <translation type="unfinished"> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation type="unfinished">Log Append</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation type="unfinished">wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation type="unfinished">msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation type="unfinished">Log Append:\nAppend to existing logs.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation type="unfinished">Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation type="unfinished">Log Size Limit:\nMaximum size of log files (bytes).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation type="unfinished">Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation type="unfinished">Log Sync:\nSwitch between sync (order) or async (performance).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation type="unfinished">Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation type="unfinished">Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation type="unfinished">Select Version</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation type="unfinished">Select version for shortcut creation</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation type="unfinished">No Version Selected</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation type="unfinished">Select a version first</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Trófeák Megtekintése</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation type="unfinished">Select Game:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation type="unfinished">Progress</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation type="unfinished">Show Earned Trophies</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation type="unfinished">Show Not Earned Trophies</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation type="unfinished">Show Hidden Trophies</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation type="unfinished">Select User:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation type="unfinished">User Manager</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation type="unfinished">&amp;Create User</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation type="unfinished">&amp;Delete User</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation type="unfinished">&amp;Rename User</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation type="unfinished">&amp;Set Default User</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation type="unfinished">&amp;Set Color</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation type="unfinished">&amp;Set Controller Port</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation type="unfinished">&amp;Close</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation type="unfinished">Cannot add more users.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation type="unfinished">Create New User</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation type="unfinished">New User ID: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation type="unfinished">Username (3–16 chars, letters, numbers, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation type="unfinished">Invalid Username</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation type="unfinished">Username must be 3–16 chars and valid.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation type="unfinished">Delete Confirmation</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation type="unfinished">Delete user ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation type="unfinished">Rename User</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation type="unfinished">Old Username: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation type="unfinished">Set User Color</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation type="unfinished">Select color:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation type="unfinished">Set Controller Port</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation type="unfinished">Assign port (1-4) to this user:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation type="unfinished">&amp;Open User Directory</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation type="unfinished">Version Manager</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation type="unfinished">Path to save versions</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation type="unfinished">Browse</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation type="unfinished">Installed</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation type="unfinished">Selected</translation>
    </message>
    <message>
      <source>Version</source>
      <translation type="unfinished">Version</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation type="unfinished">Codename</translation>
    </message>
    <message>
      <source>Date</source>
      <translation type="unfinished">Date</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation type="unfinished">Add Custom</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation type="unfinished">Delete</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation type="unfinished">Refresh List</translation>
    </message>
    <message>
      <source>Download</source>
      <translation type="unfinished">Download</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation type="unfinished">Check for Pre-release updates at startup</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation type="unfinished">Check for Pre-release Updates</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation type="unfinished">Select the folder where the emulator versions will be installed</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation type="unfinished">Select executable</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation type="unfinished">Executable (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation type="unfinished">Version name</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation type="unfinished">Enter the name of this version as it appears in the list.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation type="unfinished">Error</translation>
    </message>
    <message>
      <source>Success</source>
      <translation type="unfinished">Success</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation type="unfinished">Version added successfully.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation type="unfinished">Failed to determine the folder path.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation type="unfinished">Delete version</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation type="unfinished">Do you want to delete the version</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation type="unfinished">Version list update</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation type="unfinished">No news, the version list is already updated.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation type="unfinished">The latest versions have been added to the list for download.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation type="unfinished">Error accessing GitHub API</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation type="unfinished">First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation type="unfinished">Do you want to download the version</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation type="unfinished">No files available for this platform.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation type="unfinished">Downloading %1 , please wait...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation type="unfinished">Could not save file.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation type="unfinished">Version %1 has been downloaded and selected.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation type="unfinished">Failed to create zip extraction script</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation type="unfinished">The GitHub API response is not a valid JSON array.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation type="unfinished">Auto Updater - Emulator</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation type="unfinished">You already have the latest pre-release version.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation type="unfinished">Update Available (Emulator)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation type="unfinished">Current Version</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation type="unfinished">Latest Version</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation type="unfinished">Do you want to update?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation type="unfinished">Update</translation>
    </message>
    <message>
      <source>No</source>
      <translation type="unfinished">No</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation type="unfinished">Show Changelog</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation type="unfinished">Hide Changelog</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation type="unfinished">Network error while fetching changelog</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation type="unfinished">Changes</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation type="unfinished">No download URL found for the specified asset.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation type="unfinished">Network error while downloading</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation type="unfinished">Failed to save download file</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation type="unfinished">Complete installation</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation type="unfinished">Pre-release updated successfully</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation type="unfinished">Failed to create the update script file</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation type="unfinished">Always Show Changelog</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation type="unfinished">No version selected. Please choose one from the list to delete.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation type="unfinished">Confirm Download</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation type="unfinished">Extraction failure.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation type="unfinished">A version with that name already exists.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation type="unfinished">Local</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation type="unfinished">Failed to determine the folder to remove.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation type="unfinished">Failed to delete folder.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation type="unfinished">Unable to get hash of latest pre-release.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation type="unfinished">Downloading Pre-release (Nightly), please wait...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation type="unfinished">Dimensions Manager</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation type="unfinished">Active Dimensions Figures:</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Move</source>
      <translation type="unfinished">Move</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation type="unfinished">Select Dimensions File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation type="unfinished">Filter by Series:</translation>
    </message>
    <message>
      <source>All</source>
      <translation type="unfinished">All</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation type="unfinished">Series:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation type="unfinished">Series number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation type="unfinished">Failed to create figure file!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation type="unfinished">Failed to create figure file:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation type="unfinished">Infinity Manager</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation type="unfinished">Active Infinity Figures:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation type="unfinished">Play Set/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation type="unfinished">Power Disc Two</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation type="unfinished">Power Disc Three</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation type="unfinished">Player One</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation type="unfinished">Player One Ability One</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation type="unfinished">Player One Ability Two</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation type="unfinished">Player Two</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation type="unfinished">Player Two Ability One</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation type="unfinished">Player Two Ability Two</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation type="unfinished">Unknown Figure</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation type="unfinished">Select Infinity File</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation type="unfinished">Infinity Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation type="unfinished">Failed to open the figure file!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation type="unfinished">Failed to open the figure file(%1)!
File may already be in use on the base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation type="unfinished">Failed to read the figure file!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the figure file(%1)!
File was too small.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation type="unfinished">Figure Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation type="unfinished">Figure Number:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation type="unfinished">Figure number entered is invalid!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation type="unfinished">Create Figure File</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation type="unfinished">Dimensions Figure (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation type="unfinished">Failed to create minifig file!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation type="unfinished">Failed to create minifig file:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation type="unfinished">Figure Mover</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation type="unfinished">Move Here</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation type="unfinished">Pick up and Place</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation type="unfinished">Skylander Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation type="unfinished">--Unknown--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation type="unfinished">ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation type="unfinished">Variant:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation type="unfinished">Cancel</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation type="unfinished">Error converting value</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation type="unfinished">ID entered is invalid!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation type="unfinished">Variant entered is invalid!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation type="unfinished">Create Skylander File</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation type="unfinished">Skylander Object (*.sky);;All Files (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation type="unfinished">Failed to create skylander file!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation type="unfinished">Failed to create skylander file:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation type="unfinished">Skylanders Manager</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation type="unfinished">Active Portal Skylanders:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation type="unfinished">Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation type="unfinished">Clear</translation>
    </message>
    <message>
      <source>Create</source>
      <translation type="unfinished">Create</translation>
    </message>
    <message>
      <source>Load</source>
      <translation type="unfinished">Load</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation type="unfinished">Select Skylander File</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation type="unfinished">Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation type="unfinished">Failed to open the skylander file!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation type="unfinished">Failed to open the skylander file(%1)!
File may already be in use on the portal.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation type="unfinished">Failed to read the skylander file!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation type="unfinished">Failed to read the skylander file(%1)!
File was too small.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation type="unfinished">Unknown (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
  </context>
</TS>
