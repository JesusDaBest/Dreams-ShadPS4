<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About shadPS4</source>
        <translation>About shadPS4</translation>
    </message>
    <message>
        <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
        <translation>shadPS4 is an experimental open-source emulator for the PlayStation 4.</translation>
    </message>
    <message>
        <source>This software should not be used to play games you have not legally obtained.</source>
        <translation>This software should not be used to play games you have not legally obtained.</translation>
    </message>
</context>
<context>
    <name>CheatsPatches</name>
    <message>
        <source>Cheats / Patches for </source>
        <translation>Cheats / Patches for </translation>
    </message>
    <message>
        <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
        <translation>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</translation>
    </message>
    <message>
        <source>No Image Available</source>
        <translation>No Image Available</translation>
    </message>
    <message>
        <source>Serial: </source>
        <translation>Serial: </translation>
    </message>
    <message>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <source>Size: </source>
        <translation>Size: </translation>
    </message>
    <message>
        <source>Select Cheat File:</source>
        <translation>Select Cheat File:</translation>
    </message>
    <message>
        <source>Repository:</source>
        <translation>Repository:</translation>
    </message>
    <message>
        <source>Download Cheats</source>
        <translation>Download Cheats</translation>
    </message>
    <message>
        <source>Delete File</source>
        <translation>Delete File</translation>
    </message>
    <message>
        <source>No files selected.</source>
        <translation>No files selected.</translation>
    </message>
    <message>
        <source>You can delete the cheats you don&apos;t want after downloading them.</source>
        <translation>You can delete the cheats you don&apos;t want after downloading them.</translation>
    </message>
    <message>
        <source>Do you want to delete the selected file?\n%1</source>
        <translation>Do you want to delete the selected file?\n%1</translation>
    </message>
    <message>
        <source>Select Patch File:</source>
        <translation>Select Patch File:</translation>
    </message>
    <message>
        <source>Download Patches</source>
        <translation>Download Patches</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>Cheats</source>
        <translation>Cheats</translation>
    </message>
    <message>
        <source>Patches</source>
        <translation>Patches</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>No patch selected.</source>
        <translation>No patch selected.</translation>
    </message>
    <message>
        <source>Unable to open files.json for reading.</source>
        <translation>Unable to open files.json for reading.</translation>
    </message>
    <message>
        <source>No patch file found for the current serial.</source>
        <translation>No patch file found for the current serial.</translation>
    </message>
    <message>
        <source>Unable to open the file for reading.</source>
        <translation>Unable to open the file for reading.</translation>
    </message>
    <message>
        <source>Unable to open the file for writing.</source>
        <translation>Unable to open the file for writing.</translation>
    </message>
    <message>
        <source>Failed to parse XML: </source>
        <translation>Failed to parse XML: </translation>
    </message>
    <message>
        <source>Success</source>
        <translation>Success</translation>
    </message>
    <message>
        <source>Options saved successfully.</source>
        <translation>Options saved successfully.</translation>
    </message>
    <message>
        <source>Invalid Source</source>
        <translation>Invalid Source</translation>
    </message>
    <message>
        <source>The selected source is invalid.</source>
        <translation>The selected source is invalid.</translation>
    </message>
    <message>
        <source>File Exists</source>
        <translation>File Exists</translation>
    </message>
    <message>
        <source>File already exists. Do you want to replace it?</source>
        <translation>File already exists. Do you want to replace it?</translation>
    </message>
    <message>
        <source>Failed to save file:</source>
        <translation>Failed to save file:</translation>
    </message>
    <message>
        <source>Failed to download file:</source>
        <translation>Failed to download file:</translation>
    </message>
    <message>
        <source>Cheats Not Found</source>
        <translation>Cheats Not Found</translation>
    </message>
    <message>
        <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
        <translation>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</translation>
    </message>
    <message>
        <source>Cheats Downloaded Successfully</source>
        <translation>Cheats Downloaded Successfully</translation>
    </message>
    <message>
        <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
        <translation>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</translation>
    </message>
    <message>
        <source>Failed to save:</source>
        <translation>Failed to save:</translation>
    </message>
    <message>
        <source>Failed to download:</source>
        <translation>Failed to download:</translation>
    </message>
    <message>
        <source>Download Complete</source>
        <translation>Download Complete</translation>
    </message>
    <message>
        <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
        <translation>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</translation>
    </message>
    <message>
        <source>Failed to parse JSON data from HTML.</source>
        <translation>Failed to parse JSON data from HTML.</translation>
    </message>
    <message>
        <source>Failed to retrieve HTML page.</source>
        <translation>Failed to retrieve HTML page.</translation>
    </message>
    <message>
        <source>The game is in version: %1</source>
        <translation>The game is in version: %1</translation>
    </message>
    <message>
        <source>The downloaded patch only works on version: %1</source>
        <translation>The downloaded patch only works on version: %1</translation>
    </message>
    <message>
        <source>You may need to update your game.</source>
        <translation>You may need to update your game.</translation>
    </message>
    <message>
        <source>Incompatibility Notice</source>
        <translation>Incompatibility Notice</translation>
    </message>
    <message>
        <source>Failed to open file:</source>
        <translation>Failed to open file:</translation>
    </message>
    <message>
        <source>XML ERROR:</source>
        <translation>XML ERROR:</translation>
    </message>
    <message>
        <source>Failed to open files.json for writing</source>
        <translation>Failed to open files.json for writing</translation>
    </message>
    <message>
        <source>Author: </source>
        <translation>Author: </translation>
    </message>
    <message>
        <source>Directory does not exist:</source>
        <translation>Directory does not exist:</translation>
    </message>
    <message>
        <source>Failed to open files.json for reading.</source>
        <translation>Failed to open files.json for reading.</translation>
    </message>
    <message>
        <source>Name:</source>
        <translation>Name:</translation>
    </message>
    <message>
        <source>Can&apos;t apply cheats before the game is started</source>
        <translation>Can&apos;t apply cheats before the game is started.</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Close</translation>
    </message>
</context>
<context>
    <name>CheckUpdate</name>
    <message>
        <source>Auto Updater</source>
        <translation>Auto Updater</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Network error:</source>
        <translation>Network error:</translation>
    </message>
    <message>
        <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
        <translation>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</translation>
    </message>
    <message>
        <source>Failed to parse update information.</source>
        <translation>Failed to parse update information.</translation>
    </message>
    <message>
        <source>No pre-releases found.</source>
        <translation>No pre-releases found.</translation>
    </message>
    <message>
        <source>No download URL found for the specified asset.</source>
        <translation>No download URL found for the specified asset.</translation>
    </message>
    <message>
        <source>Your version is already up to date!</source>
        <translation>Your version is already up to date!</translation>
    </message>
    <message>
        <source>Current Version</source>
        <translation>Current Version</translation>
    </message>
    <message>
        <source>Latest Version</source>
        <translation>Latest Version</translation>
    </message>
    <message>
        <source>Do you want to update?</source>
        <translation>Do you want to update?</translation>
    </message>
    <message>
        <source>Show Changelog</source>
        <translation>Show Changelog</translation>
    </message>
    <message>
        <source>Check for Updates at Startup</source>
        <translation>Check for Updates at Startup</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Update</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Hide Changelog</source>
        <translation>Hide Changelog</translation>
    </message>
    <message>
        <source>Changes</source>
        <translation>Changes</translation>
    </message>
    <message>
        <source>Network error occurred while trying to access the URL</source>
        <translation>Network error occurred while trying to access the URL</translation>
    </message>
    <message>
        <source>Download Complete</source>
        <translation>Download Complete</translation>
    </message>
    <message>
        <source>The update has been downloaded, press OK to install.</source>
        <translation>The update has been downloaded, press OK to install.</translation>
    </message>
    <message>
        <source>Failed to save the update file at</source>
        <translation>Failed to save the update file at</translation>
    </message>
    <message>
        <source>Starting Update...</source>
        <translation>Starting Update...</translation>
    </message>
    <message>
        <source>Failed to create the update script file</source>
        <translation>Failed to create the update script file</translation>
    </message>
    <message>
        <source>Auto Updater - GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Available - GUI</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CompatibilityInfoClass</name>
    <message>
        <source>Fetching compatibility data, please wait</source>
        <translation>Fetching compatibility data, please wait</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Loading...</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Unable to update compatibility data! Try again later.</source>
        <translation>Unable to update compatibility data! Try again later.</translation>
    </message>
    <message>
        <source>Unable to open compatibility_data.json for writing.</source>
        <translation>Unable to open compatibility_data.json for writing.</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unknown</translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation>Nothing</translation>
    </message>
    <message>
        <source>Boots</source>
        <translation>Boots</translation>
    </message>
    <message>
        <source>Menus</source>
        <translation>Menus</translation>
    </message>
    <message>
        <source>Ingame</source>
        <translation>Ingame</translation>
    </message>
    <message>
        <source>Playable</source>
        <translation>Playable</translation>
    </message>
</context>
<context>
    <name>ControlSettings</name>
    <message>
        <source>Configure Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D-Pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished">Left</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished">Right</translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Config Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Common Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use per-game configs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Face Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color Adjustment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Override Lightbar Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Override Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot bind axis values more than once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>unmapped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Touchpad Left</source>
        <translation type="unfinished">Touchpad Left</translation>
    </message>
    <message>
        <source>Touchpad Center</source>
        <translation type="unfinished">Touchpad Center</translation>
    </message>
    <message>
        <source>Touchpad Right</source>
        <translation type="unfinished">Touchpad Right</translation>
    </message>
    <message>
        <source>Triangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press a button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move analog stick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L1 and L2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Gamepad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gamepad ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Gamepad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No default selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>n/a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Active Gamepad as Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Default Gamepad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R1 and R2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Controller Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active controller set as default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Controller Removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default controller setting removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RED</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GREEN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BLUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick Deadzone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min Deadzone (def:2 max:127)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max Deadzone (def:127 max:127)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick Deadzone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip: Unmap inputs with right-click</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CryptoManagerDialog</name>
    <message>
        <source>Crypto Key Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Trophy Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy Key:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status: Not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exponent1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exponent2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public Exponent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coefficient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prime 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prime 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Private Exponent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fake Keyset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug Rif Keyset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pkg Derived Key3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No key file found or failed to load.
Please enter your keys and save them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Success</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <source>Keys saved successfully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Failed to save keys!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status: All fields empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status: Invalid hex values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status: Incomplete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status: Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only JSON files are supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to open file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JSON Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid JSON format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keys successfully loaded from JSON!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy Key contains invalid hex or has odd length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 contains invalid hex or has odd length.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Key</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorDialog</name>
    <message>
        <source>Edit Keyboard + Mouse and Controller input bindings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Per-Game configs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Could not open the file for reading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open the file for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">Help</translation>
    </message>
    <message>
        <source>Do you want to reset your custom default config to the original default config?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to reset this config to your custom default config?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset to Default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ElfViewer</name>
    <message>
        <source>Open Folder</source>
        <translation>Open Folder</translation>
    </message>
</context>
<context>
    <name>GameInfoClass</name>
    <message>
        <source>Loading game list, please wait :3</source>
        <translation>Loading game list, please wait :3</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Loading...</translation>
    </message>
</context>
<context>
    <name>GameInstallDialog</name>
    <message>
        <source>shadPS4 - Choose directory</source>
        <translation>shadPS4 - Choose directory</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Browse</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Directory to install emulator versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory with your dumped games</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory with your dumped DLC&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory with games</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory with DLC&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GameListFrame</name>
    <message>
        <source>Icon</source>
        <translation>Icon</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Serial</source>
        <translation>Serial</translation>
    </message>
    <message>
        <source>Compatibility</source>
        <translation>Compatibility</translation>
    </message>
    <message>
        <source>Region</source>
        <translation>Region</translation>
    </message>
    <message>
        <source>Firmware</source>
        <translation>Firmware</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Size</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Path</translation>
    </message>
    <message>
        <source>Play Time</source>
        <translation>Play Time</translation>
    </message>
    <message>
        <source>Never Played</source>
        <translation>Never Played</translation>
    </message>
    <message>
        <source>h</source>
        <translation>h</translation>
    </message>
    <message>
        <source>m</source>
        <translation>m</translation>
    </message>
    <message>
        <source>s</source>
        <translation>s</translation>
    </message>
    <message>
        <source>Compatibility is untested</source>
        <translation>Compatibility is untested</translation>
    </message>
    <message>
        <source>Game does not initialize properly / crashes the emulator</source>
        <translation>Game does not initialize properly / crashes the emulator</translation>
    </message>
    <message>
        <source>Game boots, but only displays a blank screen</source>
        <translation>Game boots, but only displays a blank screen</translation>
    </message>
    <message>
        <source>Game displays an image but does not go past the menu</source>
        <translation>Game displays an image but does not go past the menu</translation>
    </message>
    <message>
        <source>Game has game-breaking glitches or unplayable performance</source>
        <translation>Game has game-breaking glitches or unplayable performance</translation>
    </message>
    <message>
        <source>Game can be completed with playable performance and no major glitches</source>
        <translation>Game can be completed with playable performance and no major glitches</translation>
    </message>
    <message>
        <source>Click to see details on github</source>
        <translation>Click to see details on GitHub</translation>
    </message>
    <message>
        <source>Last updated</source>
        <translation>Last updated</translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GameListUtils</name>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>GB</source>
        <translation>GB</translation>
    </message>
    <message>
        <source>TB</source>
        <translation>TB</translation>
    </message>
</context>
<context>
    <name>GuiContextMenus</name>
    <message>
        <source>Cheats / Patches</source>
        <translation>Cheats / Patches</translation>
    </message>
    <message>
        <source>SFO Viewer</source>
        <translation>SFO Viewer</translation>
    </message>
    <message>
        <source>Trophy Viewer</source>
        <translation>Trophy Viewer</translation>
    </message>
    <message>
        <source>Open Folder...</source>
        <translation>Open Folder...</translation>
    </message>
    <message>
        <source>Open Game Folder</source>
        <translation>Open Game Folder</translation>
    </message>
    <message>
        <source>Open Save Data Folder</source>
        <translation>Open Save Data Folder</translation>
    </message>
    <message>
        <source>Open Log Folder</source>
        <translation>Open Log Folder</translation>
    </message>
    <message>
        <source>Copy info...</source>
        <translation>Copy info...</translation>
    </message>
    <message>
        <source>Copy Name</source>
        <translation>Copy Name</translation>
    </message>
    <message>
        <source>Copy Serial</source>
        <translation>Copy Serial</translation>
    </message>
    <message>
        <source>Copy Version</source>
        <translation>Copy Version</translation>
    </message>
    <message>
        <source>Copy Size</source>
        <translation>Copy Size</translation>
    </message>
    <message>
        <source>Copy All</source>
        <translation>Copy All</translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation>Delete...</translation>
    </message>
    <message>
        <source>Delete Game</source>
        <translation>Delete Game</translation>
    </message>
    <message>
        <source>Delete Update</source>
        <translation>Delete Update</translation>
    </message>
    <message>
        <source>Delete DLC</source>
        <translation>Delete DLC</translation>
    </message>
    <message>
        <source>Delete Trophy</source>
        <translation>Delete Trophy</translation>
    </message>
    <message>
        <source>Compatibility...</source>
        <translation>Compatibility...</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Game</translation>
    </message>
    <message>
        <source>This game has no update to delete!</source>
        <translation>This game has no update to delete!</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Update</translation>
    </message>
    <message>
        <source>This game has no DLC to delete!</source>
        <translation>This game has no DLC to delete!</translation>
    </message>
    <message>
        <source>DLC</source>
        <translation>DLC</translation>
    </message>
    <message>
        <source>Delete %1</source>
        <translation>Delete %1</translation>
    </message>
    <message>
        <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
        <translation>Are you sure you want to delete %1&apos;s %2 directory?</translation>
    </message>
    <message>
        <source>Open Update Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Save Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This game has no update folder to open!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No log file found for this game!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This game has no save data to delete!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This game has no saved trophies to delete!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy</source>
        <translation type="unfinished">Trophy</translation>
    </message>
    <message>
        <source>SFO Viewer for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove from Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Game-specific Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure Game-specific Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Game-specific Settings from Global Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Game-specific Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit a Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm deletion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete game-specific settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch with game specific configs (default)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch with global config only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch with default settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Shortcut for Selected Emulator Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Shortcut for Specified Emulator Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shortcut created successfully!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error creating shortcut!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to convert icon.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Shader Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This game does not have any saved Shader Cache to delete!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shader Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This game has no save folder to open!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User</source>
        <translation type="unfinished">User</translation>
    </message>
    <message>
        <source>Add with Selected Emulator Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add with Specified Emulator Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Steam</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HelpDialog</name>
    <message>
        <source>Quickstart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FAQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Bindings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keybindings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Hotkeys</name>
    <message>
        <source>Customize Hotkeys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show FPS Counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unmapped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit Emulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload Button Mappings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Mouse to Joystick Emulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle Mouse to Gyro Emulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
        <source>Unable to Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waiting for inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tip: Unmap inputs with right-click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hotkeys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Placeholder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capture Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capture Screenshot w/ Overlays</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Emulator Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IpcClient</name>
    <message>
        <source>Could not find the emulator executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No game is running</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KBMSettings</name>
    <message>
        <source>Configure Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unmapped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Analog Halfmode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Config Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Common Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use per-game configs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">Help</translation>
    </message>
    <message>
        <source>Mouse to Joystick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*press F7 ingame to activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Movement Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>note: click Help Button/Special Keybindings for more information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Analog Halfmode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed Offset (def 0.125):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy from Common Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deadzone Offset (def 0.50):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed Multiplier (def 1.0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy values from Common Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press a key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mousewheel cannot be mapped to stick outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="unfinished">Save</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="unfinished">Apply</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation type="unfinished">Restore Defaults</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Touchpad Left</source>
        <translation type="unfinished">Touchpad Left</translation>
    </message>
    <message>
        <source>Touchpad Center</source>
        <translation type="unfinished">Touchpad Center</translation>
    </message>
    <message>
        <source>Touchpad Right</source>
        <translation type="unfinished">Touchpad Right</translation>
    </message>
    <message>
        <source>Tip: Unmap inputs with right-click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished">Input</translation>
    </message>
    <message>
        <source>Alternate Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alternate Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dpad Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dpad Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dpad Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dpad Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Stick Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Stick Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogPresetsDialog</name>
    <message>
        <source>Log Filter Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <source>Add a new preset after the selected row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load the selected preset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Open/Add Elf Folder</source>
        <translation>Open/Add Elf Folder</translation>
    </message>
    <message>
        <source>Boot Game</source>
        <translation>Boot Game</translation>
    </message>
    <message>
        <source>Check for Updates</source>
        <translation>Check for Updates</translation>
    </message>
    <message>
        <source>About shadPS4</source>
        <translation>About shadPS4</translation>
    </message>
    <message>
        <source>Configure...</source>
        <translation>Configure...</translation>
    </message>
    <message>
        <source>Recent Games</source>
        <translation>Recent Games</translation>
    </message>
    <message>
        <source>Open shadPS4 Folder</source>
        <translation>Open shadPS4 Folder</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Exit</translation>
    </message>
    <message>
        <source>Exit shadPS4</source>
        <translation>Exit shadPS4</translation>
    </message>
    <message>
        <source>Exit the application.</source>
        <translation>Exit the application.</translation>
    </message>
    <message>
        <source>Show Game List</source>
        <translation>Show Game List</translation>
    </message>
    <message>
        <source>Game List Refresh</source>
        <translation>Game List Refresh</translation>
    </message>
    <message>
        <source>Tiny</source>
        <translation>Tiny</translation>
    </message>
    <message>
        <source>Small</source>
        <translation>Small</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <source>Large</source>
        <translation>Large</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>List View</translation>
    </message>
    <message>
        <source>Grid View</source>
        <translation>Grid View</translation>
    </message>
    <message>
        <source>Elf Viewer</source>
        <translation>Elf Viewer</translation>
    </message>
    <message>
        <source>Game Install Directory</source>
        <translation>Game Install Directory</translation>
    </message>
    <message>
        <source>Download Cheats/Patches</source>
        <translation>Download Cheats / Patches</translation>
    </message>
    <message>
        <source>Dump Game List</source>
        <translation>Dump Game List</translation>
    </message>
    <message>
        <source>Trophy Viewer</source>
        <translation>Trophy Viewer</translation>
    </message>
    <message>
        <source>No games found. Please add your games to your library first.</source>
        <translation>No games found. Please add your games to your library first.</translation>
    </message>
    <message>
        <source>Search...</source>
        <translation>Search...</translation>
    </message>
    <message>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <source>View</source>
        <translation>View</translation>
    </message>
    <message>
        <source>Game List Icons</source>
        <translation>Game List Icons</translation>
    </message>
    <message>
        <source>Game List Mode</source>
        <translation>Game List Mode</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>Utils</source>
        <translation>Utils</translation>
    </message>
    <message>
        <source>Themes</source>
        <translation>Themes</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Dark</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Light</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Green</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Blue</translation>
    </message>
    <message>
        <source>Violet</source>
        <translation>Violet</translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation>toolBar</translation>
    </message>
    <message>
        <source>Game List</source>
        <translation>Game List</translation>
    </message>
    <message>
        <source>Download Cheats For All Installed Games</source>
        <translation>Download Cheats For All Installed Games</translation>
    </message>
    <message>
        <source>Download Patches For All Games</source>
        <translation>Download Patches For All Games</translation>
    </message>
    <message>
        <source>Download Complete</source>
        <translation>Download Complete</translation>
    </message>
    <message>
        <source>You have downloaded cheats for all the games you have installed.</source>
        <translation>You have downloaded cheats for all the games you have installed.</translation>
    </message>
    <message>
        <source>Patches Downloaded Successfully!</source>
        <translation>Patches Downloaded Successfully!</translation>
    </message>
    <message>
        <source>All Patches available for all games have been downloaded.</source>
        <translation>All Patches available for all games have been downloaded.</translation>
    </message>
    <message>
        <source>Games: </source>
        <translation>Games: </translation>
    </message>
    <message>
        <source>ELF files (*.bin *.elf *.oelf)</source>
        <translation>ELF files (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
        <source>Game Boot</source>
        <translation>Game Boot</translation>
    </message>
    <message>
        <source>Only one file can be selected!</source>
        <translation>Only one file can be selected!</translation>
    </message>
    <message>
        <source>Run Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eboot.bin file not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Game is already running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadPS4</source>
        <translation type="unfinished">shadPS4</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controllers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Labels Under Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customize Hotkeys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Version Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find the emulator executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run Emulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emulator is already running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid game argument provided</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <source>Manage Skylanders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Infinity Figures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Dimensions Toypad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Game Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Game Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Cryptographic Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manage Users</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Drive Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Incorrect recovery key. Please try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <source>Settings</source>
        <translation>Settings</translation>
    </message>
    <message>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <source>Console Language</source>
        <translation>Console Language</translation>
    </message>
    <message>
        <source>Default tab when opening settings</source>
        <translation>Default tab when opening settings</translation>
    </message>
    <message>
        <source>Enable Discord Rich Presence</source>
        <translation>Enable Discord Rich Presence</translation>
    </message>
    <message>
        <source>Trophy</source>
        <translation>Trophy</translation>
    </message>
    <message>
        <source>Open the custom trophy images/sounds folder</source>
        <translation>Open the custom trophy images/sounds folder</translation>
    </message>
    <message>
        <source>Logger</source>
        <translation>Logger</translation>
    </message>
    <message>
        <source>Log Type</source>
        <translation>Log Type</translation>
    </message>
    <message>
        <source>Log Filter</source>
        <translation>Log Filter</translation>
    </message>
    <message>
        <source>Open Log Location</source>
        <translation>Open Log Location</translation>
    </message>
    <message>
        <source>Input</source>
        <translation>Input</translation>
    </message>
    <message>
        <source>Cursor</source>
        <translation>Cursor</translation>
    </message>
    <message>
        <source>Hide Cursor</source>
        <translation>Hide Cursor</translation>
    </message>
    <message>
        <source>Hide Cursor Idle Timeout</source>
        <translation>Hide Cursor Idle Timeout</translation>
    </message>
    <message>
        <source>None</source>
        <translation>None</translation>
    </message>
    <message>
        <source>Default Device</source>
        <translation>Default Device</translation>
    </message>
    <message>
        <source>s</source>
        <translation>s</translation>
    </message>
    <message>
        <source>Controller</source>
        <translation>Controller</translation>
    </message>
    <message>
        <source>Graphics</source>
        <translation>Graphics</translation>
    </message>
    <message>
        <source>User</source>
        <translation>User</translation>
    </message>
    <message>
        <source>Graphics Device</source>
        <translation>Graphics Device</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Advanced</translation>
    </message>
    <message>
        <source>Enable Shaders Dumping</source>
        <translation>Enable Shaders Dumping</translation>
    </message>
    <message>
        <source>Enable NULL GPU</source>
        <translation>Enable NULL GPU</translation>
    </message>
    <message>
        <source>Enable HDR</source>
        <translation>Enable HDR</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Paths</translation>
    </message>
    <message>
        <source>Game Folders</source>
        <translation>Game Folders</translation>
    </message>
    <message>
        <source>Add...</source>
        <translation>Add...</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Remove</translation>
    </message>
    <message>
        <source>Debug</source>
        <translation>Debug</translation>
    </message>
    <message>
        <source>Enable Debug Dumping</source>
        <translation>Enable Debug Dumping</translation>
    </message>
    <message>
        <source>Enable Vulkan Validation Layers</source>
        <translation>Enable Vulkan Validation Layers</translation>
    </message>
    <message>
        <source>Enable RenderDoc Debugging</source>
        <translation>Enable RenderDoc Debugging</translation>
    </message>
    <message>
        <source>Enable Crash Diagnostics</source>
        <translation>Enable Crash Diagnostics</translation>
    </message>
    <message>
        <source>Collect Shaders</source>
        <translation>Collect Shaders</translation>
    </message>
    <message>
        <source>Copy GPU Buffers</source>
        <translation>Copy GPU Buffers</translation>
    </message>
    <message>
        <source>Host Debug Markers</source>
        <translation>Host Debug Markers</translation>
    </message>
    <message>
        <source>Guest Debug Markers</source>
        <translation>Guest Debug Markers</translation>
    </message>
    <message>
        <source>Enable Readback Linear Images</source>
        <translation>Enable Readback Linear Images</translation>
    </message>
    <message>
        <source>Check for Updates at Startup</source>
        <translation>Check for Updates at Startup</translation>
    </message>
    <message>
        <source>Always Show Changelog</source>
        <translation>Always Show Changelog</translation>
    </message>
    <message>
        <source>Check for Updates</source>
        <translation>Check for Updates</translation>
    </message>
    <message>
        <source>Title Music</source>
        <translation>Title Music</translation>
    </message>
    <message>
        <source>Disable Trophy Notification</source>
        <translation>Disable Trophy Notification</translation>
    </message>
    <message>
        <source>Background Image</source>
        <translation>Background Image</translation>
    </message>
    <message>
        <source>Show Background Image</source>
        <translation>Show Background Image</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Opacity</translation>
    </message>
    <message>
        <source>Play title music</source>
        <translation>Play title music</translation>
    </message>
    <message>
        <source>Update Compatibility Database On Startup</source>
        <translation>Update Compatibility Database On Startup</translation>
    </message>
    <message>
        <source>Game Compatibility</source>
        <translation>Game Compatibility</translation>
    </message>
    <message>
        <source>Display Compatibility Data</source>
        <translation>Display Compatibility Data</translation>
    </message>
    <message>
        <source>Update Compatibility Database</source>
        <translation>Update Compatibility Database</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Apply</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Restore Defaults</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Point your mouse at an option to display its description.</source>
        <translation>Point your mouse at an option to display its description.</translation>
    </message>
    <message>
        <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
        <translation>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</translation>
    </message>
    <message>
        <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
        <translation>Emulator Language:\nSets the language of the emulator&apos;s user interface.</translation>
    </message>
    <message>
        <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
        <translation>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</translation>
    </message>
    <message>
        <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
        <translation>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</translation>
    </message>
    <message>
        <source>Background Image:\nControl the opacity of the game background image.</source>
        <translation>Background Image:\nControl the opacity of the game background image.</translation>
    </message>
    <message>
        <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
        <translation>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</translation>
    </message>
    <message>
        <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
        <translation>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</translation>
    </message>
    <message>
        <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
        <translation>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</translation>
    </message>
    <message>
        <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
        <translation>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</translation>
    </message>
    <message>
        <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
        <translation>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</translation>
    </message>
    <message>
        <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
        <translation>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</translation>
    </message>
    <message>
        <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
        <translation>Update Compatibility Database:\nImmediately update the compatibility database.</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Never</translation>
    </message>
    <message>
        <source>Idle</source>
        <translation>Idle</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Always</translation>
    </message>
    <message>
        <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
        <translation>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</translation>
    </message>
    <message>
        <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
        <translation>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</translation>
    </message>
    <message>
        <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
        <translation>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</translation>
    </message>
    <message>
        <source>Game Folders:\nThe list of folders to check for installed games.</source>
        <translation>Game Folders:\nThe list of folders to check for installed games.</translation>
    </message>
    <message>
        <source>Add:\nAdd a folder to the list.</source>
        <translation>Add:\nAdd a folder to the list.</translation>
    </message>
    <message>
        <source>Remove:\nRemove a folder from the list.</source>
        <translation>Remove:\nRemove a folder from the list.</translation>
    </message>
    <message>
        <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
        <translation>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</translation>
    </message>
    <message>
        <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
        <translation>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</translation>
    </message>
    <message>
        <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
        <translation>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</translation>
    </message>
    <message>
        <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
        <translation>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</translation>
    </message>
    <message>
        <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
        <translation>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</translation>
    </message>
    <message>
        <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
        <translation>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</translation>
    </message>
    <message>
        <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
        <translation>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</translation>
    </message>
    <message>
        <source>Set the volume of the background music.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Motion Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Browse</translation>
    </message>
    <message>
        <source>Auto Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Directory to install games</source>
        <translation type="unfinished">Directory to install games</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Windowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fullscreen (Borderless)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Window Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>W:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>H:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separate Log Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trophy Notification Position</source>
        <translation>Trophy Notification Position</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Left</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Right</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Top</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Notification Duration</source>
        <translation>Notification Duration</translation>
    </message>
    <message>
        <source>Portable User Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Portable User Folder from Common User Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 successfully created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Experimental Features</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Background Controller Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Logging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Present Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mailbox (Vsync)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fifo (Vsync)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Immediate (No Vsync)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the DLC folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FSR Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable FSR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable RCAS (sharpening)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RCAS Attenuation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load Presets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vblank Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Direct Memory Access</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Devkit Console Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set &quot;Network Connected&quot; to True</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frontend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Experimental</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Splash Screen When Launching Game</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Frontend Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable PS4 Neo Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio Device (general)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio Device (DS4 speaker)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional DMem Allocation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vulkan Validation (Requires Vulkan SDK)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validation Layers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Core Validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Sync Validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable GPU-Assisted Validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GUI Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GUI Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLC Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PS4 Sysmodules Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot create portable launcher folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portable launcherDir folder created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USB Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Real USB Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skylander Portal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Infinity Base</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dimensions Toypad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Shader Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compress the Shader Cache files into a zip file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Readbacks Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relaxed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select shadPS4 Home Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the system modules folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse:\nBrowse for a folder to set as the home folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio Backend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mic Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Skip Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Max Skip Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Size Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Append</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>wincolor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>msvc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Append:\nAppend to existing logs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable shadNet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ShadNet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signaling Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable UPNP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebAPI Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>shadNet:\nA PSN server replacement.\nCompatibility is very limited at the moment.\nYou can register at https://www.shadps4.net/shadNet/register/.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutDialog</name>
    <message>
        <source>Select Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select version for shortcut creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Version Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a version first</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SteamShortcut</name>
    <message>
        <source>Steam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 is already in your Steam library.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Steam installation not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Steam user account found. Please log into Steam at least once.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Steam is Running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Steam is currently running. It will be closed and restarted to apply the shortcut. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Steam did not close in time. Shortcut was not added.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to add game to Steam.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Added to Steam successfully. Steam is restarting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Added to Steam successfully. Launch Steam to see the changes.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrophyViewer</name>
    <message>
        <source>Trophy Viewer</source>
        <translation>Trophy Viewer</translation>
    </message>
    <message>
        <source>Select Game:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Earned Trophies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Not Earned Trophies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Hidden Trophies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select User:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserManagerDialog</name>
    <message>
        <source>User Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Create User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Rename User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set Default User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Set Controller Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Cannot add more users.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create New User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New User ID: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username (3–16 chars, letters, numbers, _, -)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username must be 3–16 chars and valid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete user ID %1?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Old Username: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set User Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Controller Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assign port (1-4) to this user:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open User Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shad&amp;Net...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ShadNet Settings - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable ShadNet for this user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account ID (NPID)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Account ID (NPID):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shad&amp;Net Settings...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionDialog</name>
    <message>
        <source>Version Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path to save versions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished">Browse</translation>
    </message>
    <message>
        <source>Installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version</source>
        <translation type="unfinished">Version</translation>
    </message>
    <message>
        <source>Codename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for Pre-release updates at startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for Pre-release Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the folder where the emulator versions will be installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executable (*.exe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the name of this version as it appears in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Success</source>
        <translation type="unfinished">Success</translation>
    </message>
    <message>
        <source>Version added successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to determine the folder path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to delete the version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version list update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No news, the version list is already updated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The latest versions have been added to the list for download.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error accessing GitHub API</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to download the version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No files available for this platform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downloading %1 , please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not save file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version %1 has been downloaded and selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create zip extraction script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The GitHub API response is not a valid JSON array.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Updater - Emulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You already have the latest pre-release version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Available (Emulator)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Version</source>
        <translation type="unfinished">Current Version</translation>
    </message>
    <message>
        <source>Latest Version</source>
        <translation type="unfinished">Latest Version</translation>
    </message>
    <message>
        <source>Do you want to update?</source>
        <translation type="unfinished">Do you want to update?</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="unfinished">Update</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <source>Show Changelog</source>
        <translation type="unfinished">Show Changelog</translation>
    </message>
    <message>
        <source>Hide Changelog</source>
        <translation type="unfinished">Hide Changelog</translation>
    </message>
    <message>
        <source>Network error while fetching changelog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Changes</source>
        <translation type="unfinished">Changes</translation>
    </message>
    <message>
        <source>No download URL found for the specified asset.</source>
        <translation type="unfinished">No download URL found for the specified asset.</translation>
    </message>
    <message>
        <source>Network error while downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to save download file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Complete installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pre-release updated successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create the update script file</source>
        <translation type="unfinished">Failed to create the update script file</translation>
    </message>
    <message>
        <source>Always Show Changelog</source>
        <translation type="unfinished">Always Show Changelog</translation>
    </message>
    <message>
        <source>No version selected. Please choose one from the list to delete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extraction failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A version with that name already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to determine the folder to remove.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to delete folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to get hash of latest pre-release.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downloading Pre-release (Nightly), please wait...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dimensions_dialog</name>
    <message>
        <source>Dimensions Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Dimensions Figures:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown Figure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Dimensions File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dimensions Figure (*.bin);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the figure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the figure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the figure file(%1)!
File was too small.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>figure_creator_dialog</name>
    <message>
        <source>Figure Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter by Series:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--Unknown--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Figure Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Series:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>Error converting value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Figure number entered is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Series number entered is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Figure File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Infinity Figure (*.bin);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create figure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create figure file:
%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>infinity_dialog</name>
    <message>
        <source>Infinity Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Infinity Figures:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play Set/Power Disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power Disc Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power Disc Three</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player One Ability One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player One Ability Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player Two Ability One</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player Two Ability Two</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown Figure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Infinity File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Infinity Figure (*.bin);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the figure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the figure file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the figure file(%1)!
File was too small.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>minifig_creator_dialog</name>
    <message>
        <source>Figure Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--Unknown--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Figure Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>Error converting value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Figure number entered is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Figure File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dimensions Figure (*.bin);;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create minifig file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create minifig file:
%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>minifig_move_dialog</name>
    <message>
        <source>Figure Mover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">None</translation>
    </message>
    <message>
        <source>Move Here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick up and Place</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>skylander_creator_dialog</name>
    <message>
        <source>Skylander Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--Unknown--</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <source>Error converting value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ID entered is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variant entered is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create Skylander File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skylander Object (*.sky);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create skylander file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to create skylander file:
%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>skylander_dialog</name>
    <message>
        <source>Skylanders Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active Portal Skylanders:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skylander %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Skylander File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the skylander file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the skylander file!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to read the skylander file(%1)!
File was too small.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown (Id:%1 Var:%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished">None</translation>
    </message>
</context>
</TS>
