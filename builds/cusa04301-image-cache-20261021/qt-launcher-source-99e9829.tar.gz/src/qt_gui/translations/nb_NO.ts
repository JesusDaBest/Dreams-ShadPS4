<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="nb_NO" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>Om shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 er en eksperimentell åpen kildekode-emulator for PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Denne programvaren skal ikke brukes til å spille spill du ikke har fått lovlig.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Juks og programrettelser for </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Juks og programrettelser er eksperimentelle.\nBruk med forsiktighet.\n\nLast ned juks individuelt ved å velge pakkebrønn og trykke på nedlastingsknappen.\nPå fanen programrettelser kan du laste ned alle programrettelser samtidig, velg hvilke du ønsker å bruke, og lagre valget ditt.\n\nSiden vi ikke utvikler juks eller programrettelser,\nmeld fra om feil til jukse eller programrettelse utvikleren.\n\nHar du utviklet en ny juks? Besøk:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Ingen bilde tilgjengelig</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Serienummer: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Versjon: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Størrelse: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Velg juksefil:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Pakkebrønn:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Last ned juks</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Slett fil</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Ingen filer valgt.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Du kan slette juks du ikke ønsker etter å ha lastet dem ned.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Vil du slette den valgte fila?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Velg programrettelse-fila:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Last ned programrettelser</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Juks</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Programrettelser</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Ingen programrettelse valgt.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Klarte ikke åpne files.json for lesing.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Ingen programrettelse-fil funnet for det aktuelle serienummeret.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Klarte ikke åpne fila for lesing.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Klarte ikke åpne fila for skriving.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Klarte ikke tolke XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Vellykket</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Alternativer ble lagret.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Ugyldig kilde</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>Den valgte kilden er ugyldig.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Fila eksisterer</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Fila finnes allerede. Vil du erstatte den?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Klarte ikke lagre fila:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Klarte ikke laste ned fila:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Fant ikke juks</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Fant ingen juks for dette spillet i denne versjonen av den valgte pakkebrønnen, prøv en annen pakkebrønn eller en annen versjon av spillet.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Juks ble lastet ned</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Du har lastet ned juks for denne versjonen av spillet fra den valgte pakkebrønnen. Du kan prøve å laste ned fra en annen pakkebrønn, hvis det er tilgjengelig, vil det også være mulig å bruke det ved å velge fila fra lista.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Klarte ikke lagre:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Klarte ikke laste ned:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Nedlasting fullført</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Programrettelser ble lastet ned! Alle programrettelsene tilgjengelige for alle spill har blitt lastet ned, det er ikke nødvendig å laste dem ned individuelt for hvert spill som skjer med juks. Hvis programrettelsen ikke vises, kan det hende at den ikke finnes for den spesifikke serienummeret og versjonen av spillet.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Klarte ikke analysere JSON-data fra HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Klarte ikke hente HTML-siden.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Spillet er i versjon: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>Den nedlastede programrettelsen fungerer bare på versjon: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Du må kanskje oppdatere spillet ditt.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Inkompatibilitets-varsel</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Klarte ikke åpne fila:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>XML FEIL:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Kunne ikke åpne files.json for skriving</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Utvikler: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Mappa finnes ikke:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Klarte ikke åpne files.json for lesing.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Navn:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Kan ikke bruke juks før spillet er startet.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Lukk</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Automatisk oppdatering</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Nettverksfeil:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Den automatiske oppdateringen tillater opptil 60 oppdateringssjekker per time.\nDu har nådd denne grensen. Prøv igjen senere.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Klarte ikke analysere oppdateringsinformasjon.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Fant ingen forhåndsutgivelser.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Ingen nedlastings-URL funnet for den spesifiserte ressursen.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Din versjon er allerede oppdatert!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Gjeldende versjon</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Nyeste versjon</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Vil du oppdatere?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Vis endringslogg</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Se etter oppdateringer ved oppstart</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Oppdater</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Nei</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Skjul endringslogg</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Endringer</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Nettverksfeil oppstod mens vi prøvde å få tilgang til URL</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Nedlasting fullført</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>Oppdateringen er lastet ned, trykk OK for å installere.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Klarte ikke lagre oppdateringsfila på</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Starter oppdatering …</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Klarte ikke opprette oppdateringsskriptfila</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Automatisk oppdatering – grensesnitt</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Oppdatering tilgjengelig – grensesnitt</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Henter kompatibilitetsdata, vent litt.</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Laster …</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Klarte ikke oppdatere kompatibilitetsdata! Prøv igjen senere.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Klarte ikke åpne compatibility_data.json for skriving.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Ukjent</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Ingenting</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Starter opp</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menyene</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>I spill</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Spillbar</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Kontrolleroppsett</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Navigasjonsknapper</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Opp</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Venstre</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Høyre</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Ned</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Venstre analog</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Valg av oppsett</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Felles oppsett</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Bruk oppsett per spill</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Handlingsknapper</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Høyre analog</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Fargejustering</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Overstyr farge på lyslisten</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Overstyr farge</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Klarte ikke lagre</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Kan ikke tildele akseverdier mer enn en gang</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Bruk</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Gjenopprett standardinnstillinger</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ikke tildelt</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Venstre berøringsplate</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Midtre berøringsplate</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Høyre berøringsplate</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangel</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Firkant</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Sirkel</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Kryss</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Kan ikke tildele samme inndata mer enn én gang. Dupliserte inndata tildeles følgende taster:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Trykk på en knapp</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Flytt på analog stikke</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 og L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Kontroller i bruk</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>Kontroller-ID</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Standardkontroller</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Ingen standard valgt</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>Ikke tilgjengelig</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Bruk gjeldende kontroller som standard</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Fjern standardkontroller</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 og R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Standardkontroller valgt</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Gjeldende kontroller satt som standard</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Fjernet standardkontroller</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Fjernet instillinger for standardkontroller</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>RØD</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>GRØNN</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>BLÅ</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Venstre analog dødsone</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Minste dødsone (standard: 2, maks.: 127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Maks. dødsone (standard: 127, maks.: 127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Høyre analog dødsone</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tips: Fjern tildelinger med «høyre klikk»</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Kryptonøkkel-behandler</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Trofénøkkel: Brukes for dekryptering av trofeer.
Må være en gyldig sekskantede tekststreng med partallslengde.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Skriv inn trofénøkkel</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Trofénøkkel:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Status: Ikke lastet</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Trofénøkkel</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Skriv inn %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Eksponent 1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Eksponent 2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Offentlig eksponent</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Koeffisient</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Heltallsdivisjon</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Primtall 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Primtall 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Privat eksponent</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Falsk nøkkelsett</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-nøkkelkomponenter for falsk signering.
Alle felt må være en gyldig sekskantede tekststreng med partallslengde.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Feilsøking av Rif-nøkkelsett</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-nøkkelkomponenter for feilsøking av Rif-filer.
Alle felt må være en gyldig sekskantede tekststreng med partallslengde.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Pakkeavledet (pkg) nøkkel 3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>RSA-nøkkelkomponenter for dekryptering av pakker.
Alle felt må være en gyldig sekskantede tekststreng med partallslengde.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Lukk</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Advarsel</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>Klarte ikke laste nøkkelfila.
Skriv inn nøklene og lagre dem.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Feil ved validering</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Vellykket</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Lagret nøklene på vellykket vis!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Klarte ikke lagre nøklene.</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Status: Alle felt er tomme</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Status: Ugyldige sekskantede verdier</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Status: Ikke-fullført</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Status: Gyldig</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Ugyldig fil</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Støtter kun JSON-filer.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Klarte ikke åpne fila.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Feil ved JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Ugyldig JSON-format.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Lastet nøklene fra JSON-fila på vellykket vis!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>Trofénøkkelen inneholder ugyldig sekskantede tegn eller har oddetall lengde.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 inneholder ugyldig sekskantede tegn eller har oddetall lengde.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Last nøkkel</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Lagre nøkkel</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Rediger oppsett for tastatur, mus og kontroller</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Bruk oppsett per spill</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Klarte ikke åpne fila for lesing</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Klarte ikke åpne fila for skriving</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Lagre endringer</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Vil du lagre endringene?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Hjelp</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Vil du tilbakestille alle dine tilpassede innstillinger til standarden?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Vil du tilbakestille dette oppsettet til standard oppsett?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Tilbakestill</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Åpne mappe</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Laster spilliste, vent litt :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Laster …</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Velg mappe</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Bla gjennom</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Mappe for å installere emulatorversjoner</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Mappe med dine dumpede spill</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Mappe med dumpet nedlastbart innhold</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Mappe med spill</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Mappe med nedlastbart innhold</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Ikon</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Navn</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Serienummer</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Kompatibilitet</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Region</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Fastvare</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Størrelse</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versjon</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Sti</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Spilletid</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Aldri spilt</translation>
    </message>
    <message>
      <source>h</source>
      <translation>h</translation>
    </message>
    <message>
      <source>m</source>
      <translation>m</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>kompatibilitet er utestet</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Spillet initialiseres ikke riktig eller krasjer emulatoren</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Spillet starter, men viser bare en tom skjerm</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Spillet viser et bilde, men går ikke forbi menyen</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Spillet har spillbrytende feil eller uspillbar ytelse</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Spillet kan fullføres med spillbar ytelse og uten store feil</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Trykk for å se detaljer på GitHub</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Sist oppdatert</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Favoritter</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Juks og programrettelser</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>SFO-viser</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Troféviser</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Åpne mappe …</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Åpne spillmappa</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Åpne lagrede datamappa</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Åpne loggmappa</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Kopier info …</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Kopier navn</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Kopier serienummer</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Kopier versjon</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Kopier størrelse</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Kopier alt</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Slett …</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Slett spill</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Slett oppdatering</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Slett nedlastbart innhold</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Slett trofé</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Kompatibilitet …</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Spill</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Dette spillet har ingen oppdatering å slette!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Oppdater</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Dette spillet har intet nedlastbart innhold å slette!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>Nedlastbart innhold</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Slett %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Er du sikker på at du vil slette %1&apos;s %2 mappa?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Åpne oppdateringsmappa</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Slett lagret data</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Dette spillet har ingen oppdateringsmappe å åpne!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Fant ingen loggfil for dette spillet!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Dette spillet har ingen lagret data å slette!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Dette spillet har ingen lagrede trofeer å slette!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Lagret data</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofé</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>SFO-viser for </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Fjern fra favoritter</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Legg til i favoritter</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Innstillinger for enkeltspill …</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Sett opp innstillinger for enkeltspill</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Lag innstillinger for enkeltspill fra globale innstillinger</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Slett innstillinger for enkeltspill</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Oppdater database</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Vis rapport</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Send inn en rapport</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Bekreft sletting</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Slett innstillinger for enkeltspill?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Start …</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Start med spillspesifikke oppsett (standard)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Start kun med global oppsett</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Start med standardinnstillinger</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Klarte ikke sende rapport, fordi den nyeste loggen for spillet passerte ikke følgende kontroll, og derfor ville vært en ugyldig rapport:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Info</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Lag snarvei for valgte emulatorversjon</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Lag snarvei for bestemt emulatorversjon</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Lag snarvei</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Opprettelse av snarvei</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Snarvei opprettet på vellykket vis!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Feil ved opprettelse av snarvei!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Klarte ikke konvertere ikon.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Slett skyggelegger hurtiglager</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Dette spillet har ingen lagret skyggelegger hurtiglager å slette!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Skyggelegger hurtiglager</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Dette spillet har ingen lagret datamappe å åpne!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>En trofénøkkel er nødvendig for å bruke troféviseren. Du kan skrive inn dette ved å trykke «Innstillinger» → «Håndter kryptografiske nøkler».</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Hurtigstart</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Ofte stilte spørsmål</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Syntaks</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Spesielle hurtigtaster</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Hurtigtast</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Tilpass hurtigtaster</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Vis FPS-teller</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ikke tildelt</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Avslutt emulering</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Last knappeoppsett på nytt</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Slå av/på fullskjerm</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Sett av/på pause</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Slå av/på mus til styrespak emulering</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Slå av/på mus til gyro emulering</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Tips: Opptil tre inndata kan tildeles hver funksjon.</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Bruk</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Gjenopprett standardinnstillinger</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Klarte ikke lagre</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Kan ikke tildele samme inndata mer enn én gang. Dupliserte inndata tildeles følgende taster:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Venter på inndata</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tips: Fjern tildelinger med «høyre klikk»</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Øk lydstyrke</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Senk lydstyrke</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Hurtigtaster</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Plassholder</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Ta skjermbilde</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Ta skjermbilde med overlegg</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Åpne emulator-innstillinger</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Fant ikke emulator-programfila</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>Ingen spill kjører</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Tastaturoppsett</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>Ikke tildelt</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Venstre analog halvmodus</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Valg av oppsett</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Felles oppsett</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Bruk oppsett per spill</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Skriveprogram</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Hjelp</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Mus til styrespak</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>Trykk F7 i spillet for å bruke</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Oppsett av musebevegelse</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>Merk: Trykk på «Hjelp»-knappen for mer informasjon</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triangel</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Firkant</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Sirkel</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Kryss</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Høyre analog halvmodus</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Hastighetsforskyvning (def 0,125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Kopier fra felles oppsettet</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Dødsoneforskyvning (def 0,50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Hastighetsmultiplikator (def 1,0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Kopier verdier fra felles oppsettet</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Vil du overskrive eksisterende valg av oppsett med felles oppsettet?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Klarte ikke lagre</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Trykk på en tast</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Klarte ikke tildele</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>Musehjulet kan ikke tildeles analogstikkene</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Bruk</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Gjenopprett standardinnstillinger</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Kan ikke tildele samme inndata mer enn én gang. Dupliserte inndata tildeles følgende taster:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Venstre berøringsplate</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Midtre berøringsplate</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Høyre berøringsplate</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Tips: Fjern tildelinger med «høyre klikk»</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Utdata</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Inndata</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Alternativ inndata 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Alternativ inndata 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Navigasjonsknapp opp</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Navigasjonsknapp ned</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Navigasjonsknapp venstre</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Navigasjonsknapp høyre</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Venstre analog opp</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Venstre analog ned</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Venstre analog venstre</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Venstre analog høyre</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Høyre analog opp</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Høyre analog ned</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Høyre analog venstre</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Høyre analog høyre</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Forhåndsinnstillinger for loggfilter</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Kommentar</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filter</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Last</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Lukk</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Legg til ny forhåndsinnstilling etter den valgte raden</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Fjern valgte forhåndsinnstillinger</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Last inn den valgte forhåndsinnstillingen</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Åpne eller legg til Elf-mappe</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Start spill</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Se etter oppdateringer</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>Om shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Sett opp …</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Nylige spill</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Åpne shadPS4 mappa</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Avslutt</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Avslutt shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Avslutt programmet.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Vis spilliste</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Oppdater spillista</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Bitteliten</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Liten</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Middels</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Stor</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Listevisning</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Rutenettvisning</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Elf-visning</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Spillinstallasjons-mappe</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Last ned juks og programrettelser</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Dump spilliste</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Troféviser</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Fant ingen spill. Legg til spillene dine i biblioteket først.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Søk …</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Fil</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Oversikt</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Spilliste ikoner</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Spilliste modus</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Innstillinger</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Verktøy</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Tema</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Hjelp</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Mørk</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Lys</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Grønn</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Blå</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Lilla</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Verktøylinje</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Spilliste</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Last ned juks for alle installerte spill</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Last ned programrettelser for alle spill</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Nedlasting fullført</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Du har lastet ned juks for alle spillene du har installert.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Programrettelser ble lastet ned!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Programrettelser tilgjengelige for alle spill har blitt lastet ned.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Spill: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>ELF-filer (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Spilloppstart</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Kun én fil kan velges!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Kjør spill</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Klarte ikke finne Eboot.bin-fila</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Spillet kjører allerede!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Spill</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pause</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Stopp</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Start på nytt</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Fullskjerm</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Kontroller</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Tastatur</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Oppdater lista</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Gjenoppta</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Vis merkelapp under ikoner</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Tilpass hurtigtaster</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Versjonsbehandling</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Ingen versjon valgt</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Ingen emulatorversjon ble valgt.
Versjonsbehandling-menyen vil åpnes.
Velg en emulatorversjon fra høyre panel.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Fant ikke emulator-programfila</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Start emulator</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>Emulatoren kjører allerede!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Ugyldig spillargument oppgitt</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Håndter Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Håndter Infinity-figurer</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Håndter Dimensions-lekebase</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Spill logg</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Vis spill logg</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Håndter kryptografiske nøkler</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Håndter brukere</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Låst lagringsenhet</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>Lagringsenhet %1; er låst. Skriv inn BitLocker-nøkkel for tilgang:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>Feil gjenopprettingsnøkkel. Prøv på nytt.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Innstillinger</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Generelt</translation>
    </message>
    <message>
      <source>System</source>
      <translation>System</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Konsollspråk</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Standardfanen når innstillingene åpnes</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Bruk Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Trofé</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Åpne mappa med tilpassede bilder og lyder for trofé</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Loggføring</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Loggføringstype</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Loggfilter</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Åpne loggplassering</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Inndata</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Musepeker</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Skjul musepeker</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Skjul musepeker ved inaktivitet</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Standard enhet</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Kontroller</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Grafikk</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Bruker</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Grafikkenhet</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Avansert</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Bruk skyggeleggerdumping</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Bruk NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Bruk HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Mapper</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Spillmapper</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Legg til …</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Fjern</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Feilsøking</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Bruk feilsøkingsdumping</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Bruk Vulkan Validation Layers</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Bruk RenderDoc feilsøking</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Bruk krasjdiagnostikk</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Lagre skyggeleggere</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Kopier GPU-buffere</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Vertsfeilsøkingsmarkører</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Gjestefeilsøkingsmarkører</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Bruk tilbakelesninger av lineære bilder</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Se etter oppdateringer ved oppstart</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Vis alltid endringsloggen</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Se etter oppdateringer</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Tittelmusikk</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Slå av trofévarsler</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Bakgrunnsbilde</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Vis bakgrunnsbilde</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Synlighet</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Spill av tittelmusikk</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Oppdater database ved oppstart</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Spill kompatibilitet</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Vis kompatibilitets-data</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Oppdater kompatibilitets-database</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Lydstyrke</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Lagre</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Bruk</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Gjenopprett standardinnstillinger</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Lukk</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Pek musen over et alternativ for å vise beskrivelsen.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Konsollspråk:\nAngir språket som PS4-spillet bruker.\nDet anbefales å sette dette til et språk som spillet støtter, noe som kan variere avhengig av region.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Emulatorspråket:\nAngir språket for emulatorens brukergrensesnitt.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Vis velkomstbilde:\nViser spillets velkomstbilde (et spesialbilde) når spillet starter.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Bruk Discord Rich Presence:\nViser emulatorikonet og relevant informasjon på Discord-profilen din.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Bakgrunnsbilde:\nEndrer synligheten til spillets bakgrunnsbilde.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Spill av tittelmusikk:\nHvis et spill støtter det, så brukes det spesiell musikk når du velger spillet i menyen.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Slå av trofévarsler:\nFjerner trofévarsler i spillet. Troféfremgang kan fortsatt vises ved hjelp av troféviseren (høyreklikk på spillet i hovedvinduet).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Skjul musepeker:\nVelg når musepekeren skal forsvinne:\nAldri: Du vil alltid se musepekeren.\nInaktiv: Sett en tid for at den skal forsvinne etter å ha vært inaktiv.\nAlltid: du vil aldri se musepekeren.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Sett en tid for når musepekeren forsvinner etter å ha vært inaktiv.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Vis kompatibilitets-data:\nViser informasjon om spillkompatibilitet i tabellvisning. Bruk «Oppdater database ved oppstart» for oppdatert informasjon.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Oppdater database ved oppstart:\nOppdaterer kompatibilitets-databasen automatisk når shadPS4 starter.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Oppdater kompatibilitets-database:\nOppdater kompatibilitets-databasen nå.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Aldri</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Inaktiv</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Alltid</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Grafikkenhet:\nSystemer med flere GPU-er, kan emulatoren velge hvilken enhet som skal brukes fra rullegardinlista,\neller bruk «Velg automatisk».</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Bredde / Høyde:\nAngir størrelsen på emulatorvinduet ved oppstart, som kan endres under spillingen.\nDette er annerledes fra oppløsningen i spillet.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Bruk HDR:\nTillater bruk av HDR i spill som støtter det.\nSkjermen din må ha støtte for BT2020 PQ fargerom og RGB10A2 byttekjede-format.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Spillmapper:\nListe over mapper som brukes for å se etter installerte spill.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Legg til:\nLegg til en mappe til lista.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Fjern:\nFjern en mappe fra lista.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Bruk feilsøkingsdumping:\nLagrer import- og eksport-symbolene og filoverskrifts-informasjonen til det nåværende kjørende PS4-programmet i en mappe.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Bruk RenderDoc feilsøking:\nHvis brukt, vil emulatoren gi kompatibilitet med RenderDoc for å tillate opptak og analyse av det nåværende gjengitte bildet.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Lagre skyggeleggere:\nDu trenger dette for å redigere skyggeleggerne med feilsøkingsmenyen (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Bruk tilbakelesninger av lineære bilder:\nTar i bruk asynkron nedlasting av lineære bilder modifisert av GPU-en.\nKan rette feil i noen spill.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Kopier GPU-buffere:\nKommer rundt løpsforhold som involverer GPU-innsendinger.\nKan muligens hjelpe med PM4 type 0 krasj.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Vertsfeilsøkingsmarkører:\nSetter inn emulator-side informasjon som markører for spesifikke AMDGPU-kommandoer rundt Vulkan-kommandoer, i tillegg til å gi ressurser feilrettingsnavn.\nHvis dette brukes, burde du også bruke krasjdiagnostikk.\nNyttig for programmer som RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Gjestefeilsøkingsmarkører:\nSetter inn eventuelle feilsøkingsmarkører spillet selv har lagt til kommandobufferen.\nHvis dette brukes, burde du også bruke krasjdiagnostikk.\nNyttig for programmer som RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Sett volumet til bakgrunnsmusikken.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Bruk bevegelsesstyring</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Endre mappe</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Velg automatisk</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Mappe for installering av spill</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Video</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Skjermmodus</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>I vindu</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Fullskjerm</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Fullskjerm i vindu</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Vindustørrelse</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>B:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>H:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Separate loggfiler</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Separate loggfiler:\nOppretter en separat loggfil for hvert spill.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Trofévarsel plassering</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Venstre</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Høyre</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Øverst</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Nederst</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Varslingsvarighet</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Separat brukermappe</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Lag ny separat brukermappe fra fellesbrukermappa</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Separat brukermappe:\n Lagrer shadPS4-innstillinger og data som kun brukes til shadPS4 programmet i gjeldende mappe. Start programmet på nytt etter opprettelsen av mappa for å ta den i bruk.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 finnes allerede</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 opprettet.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Åpne mappa med tilpassede bilder og lyder for trofé:\nDu kan legge til tilpassede bilder til trofeer og en lyd.\nLegg filene til custom_trophy med følgende navn:\ntrophy.wav ELLER trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nMerk: Lyden avspilles kun i Qt-versjonen.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Eksperimentelle funksjoner</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>Advarsel: Disse funksjonene er eksperimentelle og bør ikke tas i bruk med mindre du har fått beskjed om, eller et spill krever det. Spør i shadPS4-Discord-serveren dersom du har spørsmål.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Bruk kontroller inndata ved mangel på fokus</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Bruk kontroller inndata ved mangel på fokus:\n Tillater shadPS4 å oppdage kontroller inndata når spillvinduet ikke er i fokus. Nyttig for flerskjerm-oppsett.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Krasjdiagnostikk:\nOppretter en .yaml-fil med informasjon om Vulkan-tilstanden ved krasj.\nNyttig for feilsøking &apos;Device lost&apos; feil. Hvis dette brukes, burde du aktivere vert OG gjestefeilsøkingsmarkører.\nDu trenger Vulkan Validation Layers og Vulkan SDK for at dette skal fungere.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Bruk loggføring</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Bruk loggføring:\nTar i bruk loggføring.\nIkke endre dette hvis du ikke vet hva du gjør!\nNår du spør om hjelp vær sikker på at denne innstillingen er «påslått».</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Presentasjonsmodus</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>«Mailbox» (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>«FIFO» (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Umiddelbart (Ingen Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Velg mappa for nedlastbart innhold</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Presentasjonsmodus:\nSetter opp hvordan video-utdata skal presenteres til skjermen.\n\n«Mailbox»: Bildene synkroniseres med skjermens oppdateringsfrekvens. Nye bilder erstatter gamle bilder i køen. Reduserer ventetid men kan hoppe over bilder hvis de er forsinket.\n«FIFO»: Bildene synkroniseres med skjermens oppdateringsfrekvens. Nye bilder settes i kø bak gamle bilder. Dette sikrer at alle bildene vises men kan øke ventetid.\nUmiddelbart: Bildene vises til skjermen med en gang når de er klare. Kan forutsake bilderiving.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Endre mappe:\nLet etter ei mappe for å angi den som stien for nedlastbart innhold.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>FSR-innstillinger</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Bruk FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>Bruk RCAS (tydeliggjøring)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>RCAS demping:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Last inn forhåndsinnstillinger …</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Logg</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Åpne loggplassering:\nÅpne mappa der loggfilen er lagret.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Mikrofon:\nIngen: Tar ikke mikrofonen i bruk.\nStandard enhet: Tar i bruk standardenheten som angitt av systemet.\nEller velg mikrofonen manuelt fra lista.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Lydstyrke:\nJuster volum for spill på et globalt nivå, skalaen går fra 0-500 %, standarden er 100 %.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Standardfanen når innstillingene åpnes:\nVelg hvilken fane som skal åpnes, standarden er «Generelt».</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Bruk bevegelsesstyring:\nNår i bruk, vil den bruke kontrollerens bevegelsesstyring hvis det støttes.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Vblank-frekvens</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Vblank-frekvens:\nBildehastigheten som emulatoren oppdaterer ved, (60 hz er standard, enten om spillet kjøres med 30 eller 60 fps). Endring av dette kan ha negative effekter, som å øke hastigheten av spillet, eller ødelegge kritisk spillfunksjonalitet som ikke forventer at dette endres!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Bruk direkte minnetilgang</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Bruk utvikler-konsollmodus</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Bruk emulering av PSN-tilgang</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Bruk emulering av nettverkstilgang</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Diverse</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Grensesnitt</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Eksperimentell</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Vis velkomstbilde ved oppstart av spill</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Grensesnitt-innstillinger</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>Bruk PS4 Neo-modus</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Bruk direkte minnetilgang:\nTar i bruk vilkårlig minnetilgang fra GPU-en til CPU-minne.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>Bruk PS4 Neo-modus:\nTar i bruk emulering av PS4 Pro-modus og økt minnestørrelse. Forårsaker for tiden ustabilitet i et stort antall testede spill.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Bruk utvikler-konsollmodus:\nTar i bruk økt minnekapasitet som i en utvikler-konsoll.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Bruk emulering av nettverkstilgang:\nTvinger spill å oppdage nettverkstilgang. Faktisk funksjonalitet støttes ikke.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Bruk emulering av PSN-tilgang:\nTvinger spill å oppdage PSN-tilgang. Faktisk funksjonalitet støttes ikke.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Bruk Vulkan Validation Layers:\nTar i bruk et system som bekrefter tilstanden til Vulkan-gjengiveren og loggfører informasjon om dens indre tilstand.\n Dette vil redusere ytelsen og sannsynligvis endre emulatorens atferd.\nDu trenger Vulkan SDK for at dette skal fungere.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Lydenhet (generelt)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Lydenhet (DS4-høyttaler)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Bruk skyggeleggerdumping:\nFor teknisk feilsøking lagrer skyggeleggerne fra spillet i en mappe mens de gjengis.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>Bruk Null GPU:\nFor teknisk feilsøking deaktiverer spillets-gjengivelse som om det ikke var noen grafikkort. Det vil ikke gjengis bilde til skjermen.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>Sti for nedlastbart innhold:\n Mappa hvor nedlastbart innhold for spillene lastes fra.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Ytterligere direkte-minne tildeling</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Ytterligere direkte-minne tildeling:\nTvinger gjennom tildeling av ytterligere mengde direkte-minne. Forårsaker krasj eller andre feil i noen spill.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>PS4 «Sysmodules»-mappe:\nMappa hvor PS4-systemmoduler lastes fra.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Endre mappe:\nLet etter ei mappe for å angi den som stien for systemmoduler.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Vulkan-validering (krever Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Valideringslag</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Bruk kjernevalidering</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Bruk synkroniseringsvalidering</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Bruk grafikkort assistert validering</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Bruk Vulkan synkroniseringsvalidering:\nTar i bruk et system som bekrefter frekvens tiden av Vulkan-gjengivelseoppgaver.\nDette vil redusere ytelsen og sannsynligvis endre emulatorens atferd.\nDu trenger Vulkan SDK for at dette skal fungere.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Bruk kjernevalidering:\nTar i bruk hoved API validerings funksjonene.\nDette vil redusere ytelsen og sannsynligvis endre emulatorens atferd.\nDu trenger Vulkan SDK for at dette skal fungere.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Bruk grafikkort assistert validering:\nForteller skyggeleggere gjennom kode som validerer om de gjengis riktig.\nDette vil redusere ytelsen og sannsynligvis endre emulatorens atferd.\nDu trenger Vulkan SDK for at dette skal fungere.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Grensesnittspråk</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Grensesnitt oppdateringer</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>Sti for nedlastbart innhold</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>PS4 «sys_modules»-mappe</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Grensesnitt oppdateringer:\nOffisiell: Stabile offisielle versjoner utgis hver måned, men kan være veldig utdaterte.\nNattlig: Ustabile utviklingsversjoner med alle de nyeste funksjonene og rettelsene, men kan inneholde feil.\n\nMerk: denne oppdateringen angår kun Qt-brukergrensesnittet. For oppdatering av selve emulatoren, bruk «Versjonsbehandling»-menyen.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>Klarte ikke opprette flyttbar startprogram-mappe</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>Opprettet flyttbar startprogram-mappe</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>USB-enhet</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Ekte USB-enhet</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Skylanders portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Infinity-base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Dimensions-lekebase</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>USB-enhet:\nEkte USB-enhet: Bruk en ekte USB-enhet tilkoblet systemet.\nSkylanders portal: Emuler en «Skylanders Portal of Power».\nInfinity-base: Emuler en Disney Infinity-base.\nDimensions-lekebase: Emuler en Lego Dimensions lekebase.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Bruk skyggelegger hurtiglager</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Komprimer skyggelegger hurtiglager-filer til en zip-fil</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Bruk skyggelegger hurtiglager:\nLagrer kompilerte skyggeleggere for å unngå gjenkompilasjoner, reduserer hakking.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Komprimer skyggelegger hurtiglager-filer til en zip-fil:\nskyggeleggerhurtiglager filene lagres i en zip-fil i stedet for flere separate filer.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Tilbakelesningsmodus</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Avslått</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Tilbakelesninger:\nTa i bruk tilbakelesninger og tilbakeskrivninger.\nDette kreves av noen spill for å fungere ordentlig.\nKan forårsake stabilitets- og/eller ytelsesproblemer.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Avslappet</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Nøyaktig</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Velg hjemmesti for shadPS4</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Velg sti for systemmoduler</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Hjemmemappe-plassering (lagret spilldata, inndata og trofédata)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Hjemmemappe-plassering\nMappa hvor lagret spilldata, troféfiler og inndataoppsett lagres for alle brukere.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Endre mappe:\nLet etter ei mappe for å angi den som stien for hjemmemappe.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Lyd</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Lydmotor</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Mikrofonenhet</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Enheter</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Kamera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Loggsynkronisering</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Logghopp over duplikat</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Maks. varighet for logghopping</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Grense for loggstørrelse</translation>
    </message>
    <message>
      <source> B</source>
      <translation> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Tilføy i logg</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Tilføy i logg:\nLegg til i eksisterende logger.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Maks. varighet for logghopping:\nIntervall uten å skrive samme linjer (ms) – bare hvis «Logghopp over duplikat» er i bruk.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Grense for loggstørrelse:\nMaksimal størrelse på loggfiler (byte).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Logghopp over duplikat:\nBevar lagringsplass ved å ikke loggføre samme linjer tekst.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Loggsynkronisering:\nBytt mellom synkron (sortering) eller asynkron (ytelse).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Loggføringstype:\nVelg mellom wincolor eller msvc loggtyper.\nwincolor: Standardloggføring for Windows\nmsvc: Loggføring for feilsøking.</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Loggfilter:\nFiltrerer loggen for å kun skrive ut spesifikk informasjon.\nEksempler: «Core:Debug» «Lib.Pad:Debug Common.Filesystem:Error» «*:Critical» \nNivåer: Trace, debug, info, warning, error, critical – i denne rekkefølgen, et spesifikt nivå demper alle tidligere nivåer i lista og loggfører alle nivåer etter det.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Velg versjon</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Velg versjon for opprettelse av snarvei</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Ingen versjon valgt</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Velg en versjon først</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Troféviser</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Velg spill:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Fremdrift</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Vis opptjente trofeer</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Vis ikke opptjente trofeer</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Vis skjulte trofeer</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Velg bruker:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Brukerbehandler</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>&amp;Opprett bruker</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>&amp;Slett bruker</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>&amp;Gi brukeren nytt navn</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Sett som standardbruker</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>&amp;Velg farge</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Velg kontroller-port</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Lukk</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>Klarte ikke legge til flere brukere.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Opprett ny bruker</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>Ny bruker-ID: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Brukernavn (3-16 tegn, bokstaver, tall, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Ugyldig brukernavn</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>Brukernavn må være mellom 3-16 tegn og gyldig.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Bekreftelse for sletting</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Slett bruker-ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Gi brukeren nytt navn</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Gammelt brukernavn: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Velg brukerfarge</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Velg farge:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Velg kontroller-port</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Gi port (1-4) til denne brukeren:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Åpne brukermappe</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Versjonsbehandling</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Sti for lagring av versjonene</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Bla gjennom</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Installert</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Valgt</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versjon</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Kodenavn</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Dato</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Legg til tilpasset</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Slett</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Oppdater lista</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Last ned</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Se etter forhåndsoppdateringer ved oppstart</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Se etter forhåndsoppdateringer</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Velg mappa hvor emulatorversjonene installeres</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Velg programfila</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Kjørbar (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Versjonsnavn</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Skriv inn navnet på denne versjonen slik det vises i lista.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Feil</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Vellykket</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>La til versjon på velykket vis.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Klarte ikke bestemme stien til mappa.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Slett versjon</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Vil du slette den valgte versjonen</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Oppdatering av versjonslista</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>Intet nytt, versjonslista er allerede oppdatert.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>De nyeste versjonene er lagt til lista for nedlasting.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Feil ved tilgang til GitHub-API-en</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Først må du velge en plassering å lagre versjonene i
«Sti for å lagre versjoner»</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Vil du laste ned versjonen</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Ingen filer tilgjengelig for denne plattformen.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Laster ned %1, vent litt …</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Klarte ikke lagre fila.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>Versjon %1 er lastet ned og valgt.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Klarte ikke opprette zip-utpakkingsskript</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>Svaret fra GitHub-API-en er ikke en gyldig JSON-matrise.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Automatisk oppdatering – emulator</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>Du har allerede den nyeste forhåndsutgivelsen.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Oppdatering tilgjengelig (emulator)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Gjeldende versjon</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Nyeste versjon</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Vil du oppdatere?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Oppdater</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Nei</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Vis endringslogg</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Skjul endringslogg</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Nettverksfeil ved henting av endringslogg</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Endringer</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Fant ingen nedlastings-URL for den valgte ressursen.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Nettverksfeil ved nedlasting</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Klarte ikke lagre nedlastingsfila</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Fullfør installasjonen</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>Oppdaterte forhåndsutgivelsen på vellykket vis</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Klarte ikke opprette oppdateringsskriptfila</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Vis alltid endringsloggen</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Ingen versjon valgt. Velg en fra lista for sletting.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Bekreft nedlasting</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Feil ved utpakking.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>En versjon med det navnet finnes allerede.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Lokal</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Klarte ikke bestemme mappa som skulle fjernes.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Klarte ikke slette mappa.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>Klarte ikke hente sjekksummen for forhåndsutgivelsen.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Laster ned forhåndsutgivelsen (Nightly), vent litt …</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Behandling av Dimensions</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Dimensions-figurer i bruk:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tøm</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Last</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Flytt</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Ukjent figur</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Velg Dimensions-fil</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Dimensions-figur (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Klarte ikke åpne figurfila!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Klarte ikke åpne figurfila: %1!
Fila kan allerede være i bruk på basen.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Klarte ikke lese figurfila!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Klarte ikke lese figurfila: %1!
Fila var for liten.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Opprettelse av figurer</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Filtrer etter serier:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Alle</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>–Ukjent–</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Figurnummer:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Serier:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Feil ved konvertering av verdi</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Det angitte figurnummeret er ugyldig!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>Det angitte serienummeret er ugyldig!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Opprett figurfil</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Infinity-figur (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Klarte ikke opprette figurfil!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Klarte ikke opprette figurfil:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Behandling av Infinity</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Infinity-figurer i bruk:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>«Play Set»/«Power Disc»</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>«Power Disc» to</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>«Power Disc» tre</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Spiller én</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Spiller én, egenskap en</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Spiller én, egenskap to</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Spiller to</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Spiller to, egenskap én</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Spiller to, egenskap to</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tøm</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Last</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Ukjent figur</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Velg Infinity-fil</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Infinity-figur (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Klarte ikke åpne figurfila!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Klarte ikke åpne figurfila: %1!
Fila kan allerede være i bruk på basen.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Klarte ikke lese figurfila!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Klarte ikke lese figurfila: %1!
Fila var for liten.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Opprettelse av figurer</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>–Ukjent–</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Figurnummer:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Feil ved konvertering av verdi</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Det angitte figurnummeret er ugyldig!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Opprett figurfil</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Dimensions-figur (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Klarte ikke opprette minifigurfil!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Klarte ikke opprette minifigurfil:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Flytting av figur</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Flytt her</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Plukk opp og plasser</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Opprettelse av Skylander</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>–Ukjent–</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Variant:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Avbryt</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Feil ved konvertering av verdi</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>ID-en er ugyldig!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>Varianten er ugyldig!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Opprett Skylander-fil</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Skylander-objekt (*.sky);;Alle filer (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Klarte ikke opprette Skylander-fil!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Klarte ikke opprette Skylander-fil:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Behandling av Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Portal Skylanders i bruk:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Tøm</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Opprett</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Last</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Velg Skylander-fil</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Alle filer (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Klarte ikke åpne Skylander-fila!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Klarte ikke åpne Skylander-fila: %1!
Fila kan allerede være i bruk på portalen.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Klarte ikke lese Skylander-fila!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Klarte ikke lese Skylander-fila: %1!
Fila var for liten.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Ukjent (ID: %1 Variant: %2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Ingen</translation>
    </message>
  </context>
</TS>
