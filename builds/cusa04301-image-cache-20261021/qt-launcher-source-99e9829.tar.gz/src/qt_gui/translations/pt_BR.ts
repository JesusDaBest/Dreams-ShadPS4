<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>Sobre o shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>O shadPS4 é um emulador experimental de código-fonte aberto para o PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Este programa não deve ser usado para executar jogos que tenham sido obtidos ilegalmente.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Trapaças / Modificações para </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>As Trapaças/Modificações são experimentais.\nUse com cautela.\n\nBaixe as trapaças individualmente selecionando o repositório e clicando no botão de baixar.\nNa aba Modificações, você pode baixar todas as modificações de uma vez, escolha qual deseja usar e salve a opção.\n\nComo não desenvolvemos as Trapaças/Modificações,\npor favor, reporte os problemas relacionados ao autor da trapaça.\n\nCriou uma nova trapaça? Visite:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Nenhuma Imagem Disponível</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Serial: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Versão: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Tamanho: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Selecione o Arquivo de Trapaça:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Repositório:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Baixar Trapaças</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Excluir Arquivo</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Nenhum arquivo selecionado.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Você pode excluir as trapaças que não deseja após baixá-las.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Deseja excluir o arquivo selecionado?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Selecione o Arquivo de Patch:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Baixar Modificações</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Trapaças</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Modificações</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Nenhum patch selecionado.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Não foi possível abrir files.json para leitura.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Nenhum arquivo de patch encontrado para o serial atual.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Não foi possível abrir o arquivo para leitura.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Não foi possível abrir o arquivo para gravação.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Falha ao analisar o XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Sucesso</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Opções salvas com sucesso.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Fonte Inválida</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>A fonte selecionada é inválida.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Arquivo já Existe</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>O arquivo já existe. Deseja substituí-lo?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Falha ao salvar o arquivo:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Falha ao baixar o arquivo:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Trapaças Não Encontradas</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Nenhuma trapaça encontrada para este jogo nesta versão do repositório selecionado, tente outro repositório ou uma versão diferente do jogo.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Trapaças Baixadas com Sucesso</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Você baixou as trapaças para esta versão do jogo do repositório selecionado com sucesso. É possível tentar baixar de outro repositório, se estiver disponível, também será possível utilizá-lo selecionando o arquivo da lista.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Falha ao salvar:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Falha ao baixar:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Download Concluído</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Modificações Baixados com Sucesso! Todos as modificações disponíveis para todos os jogos foram baixados, não é necessário baixá-los individualmente para cada jogo como acontece em trapaças. Se a modificação não aparecer, pode ser que ela não exista para o serial e versão específicas do jogo.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Falha ao analisar os dados JSON do HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Falha ao recuperar a página HTML.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>O jogo está na versão: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>O patch baixado só funciona na versão: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Talvez você precise atualizar seu jogo.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Aviso de Incompatibilidade</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Falha ao abrir o arquivo:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>ERRO DE XML:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Falha ao abrir files.json para gravação</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Autor: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>O Diretório não existe:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Falha ao abrir files.json para leitura.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Nome:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Não é possível aplicar trapaças antes de começar o jogo.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Fechar</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Atualização Automática</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Erro de rede:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>O Atualizador Automático permite até 60 verificações de atualização por hora.\nVocê atingiu esse limite. Por favor, tente novamente mais tarde.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Falha ao analisar as informações de atualização.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Nenhum Pre-Lançamento encontrado.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nenhuma URL de download encontrada para o recurso especificado.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Sua versão já está atualizada!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versão Atual</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Última Versão</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Deseja atualizar?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostrar Histórico de Alterações</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Verificar por Atualizações ao Iniciar</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Atualizar</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Não</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Ocultar Histórico de Alterações</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Alterações</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Ocorreu um erro de rede ao tentar acessar o URL</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Download Concluído</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>A atualização foi baixada, pressione OK para instalar.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Falha ao salvar o arquivo de atualização em</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Iniciando Atualização...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Falha ao criar o arquivo de script de atualização</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Atualização Automática - Interface (GUI)</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Atualização Disponível - Interface (GUI)</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Obtendo dados de compatibilidade, por favor aguarde</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Carregando...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Não foi possível atualizar os dados de compatibilidade! Tente novamente mais tarde.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Não foi possível abrir o compatibility_data.json para gravação.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Desconhecido</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Nada</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Inicializa</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>Menus</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>Em jogo</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Jogável</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configurar Controles</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Direcional</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Cima</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Esquerda</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Direita</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Baixo</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Seleção de Configuração</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configuração Comum</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Usar configurações por jogo</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Botões de Ação</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Analógico Direito</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Ajuste de Cores</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Substituir Cor da Barra de Luz</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Substituir a Cor</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Não foi possível salvar</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Não é possível vincular os valores do eixo mais de uma vez</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplicar</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaurar Padrões</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>não mapeado</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opções</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad Esquerdo</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Centro do Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad Direito</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triângulo</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrado</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Círculo</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Cruz</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Não é possível atribuir a mesma entrada mais de uma vez. Entradas duplicadas foram atribuídas aos seguintes botões:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Pressione um botão</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Mover analógico</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 e L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Controle Ativo</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>ID do controle</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Controle Padrão</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Nenhum selecionado como padrão</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>n/d</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Defina o Controle Ativo como Padrão</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Remover controle padrão</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 e R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID: </translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Controle Padrão Selecionado</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>O Controle ativo foi definido como padrão</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Controle Padrão Removido</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Configuração do controle padrão removida</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>VERMELHO</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>VERDE</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>AZUL</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Zona Morta do Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Zona Morta Minima (pad:2 max:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Zona Morta Máxima (pad:127 max:127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Zona Morta do Analógico Direito</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Dica: Desmapear entradas com botão direito</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Gerenciador de Chaves Criptográficas</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Chave de Troféu: Usada para descriptografar troféus.
Deve ser uma sequência hexadecimal válida com comprimento par.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Inserir Chave de Troféu</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Chave de Troféu:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Estado: Não carregado</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Chave de Troféu</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Inserir %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Expoente1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Expoente2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Expoente Público</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Coeficiente</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Módulo</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Primo 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Primo 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Expoente Privado</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Conjunto de Chaves Falsas</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>Componentes de chave RSA para assinatura falsa.
Todos os campos devem ser strings hexadecimais válidas com comprimento par.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Depurar Conjunto de Chaves Rif</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>Componentes de chave RSA para depurar arquivos RIF.
Todos os campos devem ser textos hexadecimais válidos com comprimento par.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Chave3 Derivada do Pkg</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>Componentes de chave RSA para pacotes de descriptografia.
Todos os campos devem ser textos hexadecimais válidos com comprimento par.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Fechar</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Aviso</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>Nenhum arquivo de chaves encontrado ou falhou ao carregar.
Por favor, digite suas chaves e salve-as.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Erro de Validação</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Sucesso</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Chaves salvas com sucesso!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Falha ao salvar as chaves!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Estado: Todos os campos vazios</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Estado: Valores hexadecimais inválidos</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Estado: Incompleto</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Estado: Válido</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Arquivo Inválido</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Somente arquivos JSON são suportados.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Não foi possível abrir o arquivo.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Erro de JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Formato do JSON inválido.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Chaves carregadas com sucesso do JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>A Chave do Troféu contém hexadecimal inválido ou possui comprimento ímpar.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 contém hexadecimal inválido ou tem comprimento ímpar.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Carregar Chave</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Salvar Chave</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Editar atalhos de entrada do Teclado + Mouse e do Controle</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Usar configurações por jogo</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Não foi possível abrir o arquivo para leitura</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Não foi possível abrir o arquivo para gravação</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Salvar Alterações</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Gostaria de salvar as alterações?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Você gostaria de redefinir sua configuração padrão personalizada de volta para a configuração padrão original?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Você gostaria de redefinir esta configuração para a sua configuração padrão personalizada?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Redefinir ao Padrão</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Abrir Pasta</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Carregando a lista de jogos, por favor aguarde :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Carregando...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Escolha de diretório</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Procurar</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Diretório para instalar as versões do emulador</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Diretório com seus jogos extraídos</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Diretório com suas DLC&apos;s extraídas</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Diretório com jogos</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Diretório com DLC&apos;s</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Ícone</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Nome</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Serial</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Compatibilidade</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Região</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Firmware</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Tamanho</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versão</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Diretório</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Tempo de Jogo</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Nunca Jogado</translation>
    </message>
    <message>
      <source>h</source>
      <translation>h</translation>
    </message>
    <message>
      <source>m</source>
      <translation>m</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Compatibilidade não testada</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>O jogo não inicializa corretamente ou trava o emulador</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>O jogo inicializa, mas exibe apenas uma tela vazia</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>O jogo exibe imagem mas não passa do menu</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>O jogo tem defeitos que interrompem o jogo ou desempenho injogável</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>O jogo pode ser concluído com desempenho jogável e sem grandes defeitos</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Clique para ver detalhes no github</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Última atualização</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Favorito</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>B</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>KB</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>MB</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>GB</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>TB</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Trapaças / Modificações</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>Visualizador de SFO</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizador de Troféus</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Abrir Pasta...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Abrir Pasta do Jogo</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Abrir Pasta de Dados Salvos</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Abrir Pasta de Log</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Copiar informação...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Copiar Nome</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Copiar Serial</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Copiar Versão</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Copiar Tamanho</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Copiar Tudo</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Excluir...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Excluir Jogo</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Excluir Atualização</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Excluir DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Excluir Troféu</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Compatibilidade...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Jogo</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>Este jogo não tem atualização para excluir!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Atualização</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>Este jogo não tem DLC para excluir!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Excluir %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Tem certeza de que deseja excluir o diretório do %2 %1?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Abrir Pasta da Atualização</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Excluir Dados Salvos</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>Este jogo não possui pasta de atualização para abrir!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Nenhum arquivo de registro foi encontrado para este jogo!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>Este jogo não tem dados salvos para excluir!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>Este jogo não tem troféus salvos para excluir!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Dados Salvos</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Troféus</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>Visualizador de SFO para </translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Remover dos Favoritos</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Adicionar aos Favoritos</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Configurações Específicas do Jogo...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Configurar Configurações Específicas do Jogo</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Criar Configurações Específicas do Jogo a partir das Configurações Globais</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Excluir Configurações Específicas do Jogo</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Atualizar Banco de Dados</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Ver Relatório</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Enviar um Relatório</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Confirmar a exclusão</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Excluir configurações específicas do jogo?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Iniciar...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Iniciar com as configurações específicas do jogo (padrão)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Iniciar apenas com as configurações globais</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Iniciar com as configurações padrão</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Não foi possível enviar o relatório, pois o log mais recente do jogo falhou na seguinte verificação e, portanto, seria um relatório inválido:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Informações</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Criar Atalho para a Versão Selecionada do Emulador</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Criar Atalho para uma Versão Específica do Emulador</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Criar Atalho</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Criação de atalho</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Atalho criado com sucesso!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Erro ao criar atalho!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Falha ao converter o ícone.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Apagar Cache de Shader</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>Este jogo não possui nenhum Cache de Shaders salvo para excluir!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Cache de Shader</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>Este jogo não possui pasta de jogo salvo para abrir!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>É necessária uma chave de troféu para usar o Visualizador de Troféus. Você pode inseri-la clicando em Configurações - Gerenciar Chaves Criptográficas.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Introdução</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>Perguntas frequentes</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Sintaxe</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Atalhos Especiais</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Combinação de Teclas</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalizar Teclas de Atalho</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Exibir Contador de FPS</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>não mapeado</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Sair da emulação</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Recarregar mapeamento de botões</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Alternar Tela Cheia</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Alternar Pausa</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Alternar o Mouse para Emulação do Analógico</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Alternar o Mouse para a Emulação do Giroscópio</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Dica: Até três entradas podem ser atribuídas para cada tecla de atalho</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplicar</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaurar Padrões</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Não foi possível salvar</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Não é possível atribuir a mesma entrada mais de uma vez. Entradas duplicadas foram atribuídas aos seguintes botões:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Aguardando por entradas</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Dica: Desmapear entradas com botão direito</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Aumentar Volume</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Diminuir Volume</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Teclas de Atalho</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Espaço Reservado</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Captura de Tela</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Capturar Tela com Sobreposições</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Abrir Configurações do Emulador</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Não foi possível encontrar o executável do emulador</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>Nenhum jogo em execução</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Configurar Controles</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>não mapeado</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Meio Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Seleção de Configuração</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Configuração Comum</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Usar configurações por jogo</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Editor de Texto</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Mouse para Analógico</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*Pressione F7 no jogo para ativar</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Opções</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Parâmetros de Movimento do Mouse</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>Nota: clique no botão de Ajuda e Atalhos Especiais para obter mais informações</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Triângulo</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Quadrado</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Círculo</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Cruz</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Meio Analógico Direito</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Deslocamento de Velocidade (Pad 0,125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Copiar da Configuração Comum</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Deslocamento da Zona Morta (Pad 0,50):</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Multiplicador de Velocidade (Pad 1,0):</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Copiar valores da Configuração Comum</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Você deseja substituir os mapeamentos existentes com os mapeamentos da Configuração Comum?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Não foi possível salvar</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Aperte uma tecla</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Não é possível definir o mapeamento</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>A rolagem do mouse não pode ser mapeada para saídas do analógico</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplicar</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaurar Padrões</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Não é possível atribuir a mesma entrada mais de uma vez. Entradas duplicadas foram atribuídas aos seguintes botões:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Touchpad Esquerdo</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Centro do Touchpad</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Touchpad Direito</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Dica: Desmapear entradas com botão direito</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Saída</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Entrada</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Entrada Alternativa 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Entrada Alternativa 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Para Cima no Direcional</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Para Baixo no Direcional</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Esquerda no Direcional</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Direita no Direcional</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Para Cima no Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Para Baixo no Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Esquerda no Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Direita no Analógico Esquerdo</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Para Cima no Analógico Direito</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Para Baixo no Analógico Direito</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Esquerda no Analógico Direito</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Direita no Analógico Direito</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Predefinições do Filtro do Log</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Comentário</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Filtro</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carregar</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Fechar</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Adicionar uma nova predefinição após a linha selecionada</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Remover predefinição selecionada</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Carregar a predefinição selecionada</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Abrir/Adicionar pasta Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Inicializar Jogo</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Verificar Atualizações</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>Sobre o shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Configurar...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Jogos Recentes</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Abrir Pasta do shadPS4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Sair</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Sair do shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Sair do aplicativo.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Mostrar Lista de Jogos</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Atualizar Lista de Jogos</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Muito pequeno</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Pequeno</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Médio</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Grande</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Visualização em Lista</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Visualização em Grade</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Visualizador de Elf</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Diretório de Instalação de Jogos</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Baixar Trapaças/Modificações</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Exportar Lista de Jogos</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizador de Troféus</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Nenhum jogo encontrado. Adicione seus jogos à sua biblioteca primeiro.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Pesquisar...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Arquivo</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Ver</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Ícones da Lista de Jogos</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Modo da Lista de Jogos</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Configurações</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Utilitários</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Temas</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Ajuda</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Escuro</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Claro</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Verde</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Azul</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Violeta</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Barra de Ferramentas</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Lista de Jogos</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Baixar Trapaças para Todos os Jogos Instalados</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Baixar Modificações para Todos os Jogos</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Download Concluído</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Você baixou trapaças para todos os jogos que instalou.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Modificações Baixadas com Sucesso!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Todos as modificações disponíveis para todos os jogos foram baixadas.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Jogos: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>Arquivos ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Inicialização do Jogo</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Apenas um arquivo pode ser selecionado!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Executar Jogo</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Arquivo Eboot.bin não encontrado</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>O jogo já está executando!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Jogar</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Pausar</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Parar</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Reiniciar</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Tela Cheia</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Controles</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Teclado</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Atualizar Lista</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Continuar</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Mostrar Rótulos Sob Ícones</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Personalizar Atalhos</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Gerenciador de Versões</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nenhuma Versão Selecionada</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Nenhuma versão do emulador foi selecionada.
O menu do Gerenciador de Versões irá abrir.
Selecione uma versão do emulador no painel direito.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Não foi possível encontrar o executável do emulador</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Executar emulador</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>O emulador já está sendo executado!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Argumento inválido do jogo</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Gerenciar Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Gerenciar Colecionáveis Infinity</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Gerenciar Toypad Dimensions</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Registro do Jogo</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Mostrar Registro do Jogo</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Gerenciar Chaves Criptográficas</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Gerenciar Usuários</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Unidade Bloqueada</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>Unidade %1: está bloqueada. Por favor, insira a chave BitLocker para acessá-la:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>Chave de recuperação incorreta. Tente novamente.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Configurações</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Geral</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Sistema</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Idioma do Console</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Aba padrão ao abrir as configurações</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Ativar Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Troféu</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Abrir a pasta de imagens e sons de troféus personalizados</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Log/Registro</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Tipo de Registro</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Filtro do Registro</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Abrir Local do Registro</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Entradas</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Cursor</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Ocultar Cursor</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Tempo de Inatividade para Ocultar Cursor</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Dispositivo Padrão</translation>
    </message>
    <message>
      <source>s</source>
      <translation>s</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Controle</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Gráficos</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Usuário</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Placa de Vídeo</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Avançado</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Ativar Exportação de Shaders</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Ativar GPU NULA</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Ativar HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Pastas</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Pastas de Jogos</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Adicionar...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Remover</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Depuração</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Ativar Exportação de Depuração</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Ativar Camadas de Validação do Vulkan</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Ativar Depuração por RenderDoc</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Ativar Diagnóstico de Falhas</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Coletar Shaders</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Copiar Buffers de GPU</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Marcadores de Depuração do Host</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Marcadores de Depuração do Convidado</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Ativar Readback Linear Images</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Verificar por Atualizações ao Iniciar</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Sempre Mostrar o Histórico de Alterações</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Verificar Atualizações</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Música no Menu</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Desativar Notificações de Troféu</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Imagem de Fundo</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Exibir Imagem de Fundo</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Transparência</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Reproduzir Música do Título</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Atualizar Banco de Dados de Compatibilidade ao Inicializar</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Compatibilidade dos Jogos</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Exibir Dados de Compatibilidade</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Atualizar Lista de Compatibilidade</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Volume</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Salvar</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Aplicar</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>Restaurar Padrões</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Fechar</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Passe o mouse sobre uma opção para exibir sua descrição.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Idioma do Console:\nDefine o idioma usado pelo jogo do PS4.\nRecomenda-se configurá-lo para um idioma que o jogo suporte, o que pode variar conforme a região.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Idioma do Emulador:\nDefine o idioma da interface do emulador.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Mostrar Tela Inicial:\nExibe a tela inicial do jogo (imagem especial) enquanto o jogo está iniciando.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Ativar Discord Rich Presence:\nExibe o ícone do emulador e informações relevantes no seu perfil do Discord.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Imagem de Fundo:\nControla a transparência da imagem de fundo do jogo.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Reproduzir Música do Título:\nSe o jogo suportar, ativa a reprodução de uma música especial ao selecionar o jogo na interface de usuário.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Desabilitar Pop-ups dos Troféus:\nDesabilite notificações de troféus em jogo. O progresso do troféu ainda pode ser rastreado usando o Visualizador de Troféus (clique com o botão direito do mouse no jogo na janela principal).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Ocultar Cursor:\nEscolha quando o cursor desaparecerá:\nNunca: Você sempre verá o mouse.\nParado: Defina um tempo para ele desaparecer após ficar inativo.\nSempre: Você nunca verá o mouse.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Tempo de Inatividade para Ocultar Cursor:\nDefina um tempo em segundos para o mouse desaparecer após ficar inativo.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Exibir Dados de Compatibilidade:\nExibe informações de compatibilidade dos jogos na visualização de tabela.\nAtive &quot;Atualizar Compatibilidade ao Inicializar&quot; para obter informações atualizadas.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Atualizar Compatibilidade ao Inicializar:\nAtualiza automaticamente o banco de dados de compatibilidade quando o shadPS4 é iniciado.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Atualizar Lista de Compatibilidade:\nAtualiza imediatamente o banco de dados de compatibilidade.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Nunca</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>Ocioso</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Sempre</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Placa de Vídeo:\nEm sistemas com múltiplas GPUs, escolha qual GPU o emulador utilizará da lista suspensa,\nou escolha &quot;Seleção Automática&quot; para escolher automaticamente o mesmo.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Largura/Altura:\nDefine o tamanho da janela do emulador na inicialização, que pode ser redimensionado enquanto joga.\nIsso difere da resolução do jogo.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Ativar HDR:\nAtiva o HDR em jogos que o suportem.\nSeu monitor deve possuir suporte para o espaço de cores BT2020 PQ e ao formato de swapchain RGB10A2.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Pastas de Jogos:\nLista de pastas para verificar por jogos instalados.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Adicionar:\nAdiciona uma pasta à lista.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Remover:\nRemove uma pasta da lista.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Ativar Exportação de Depuração:\nArmazena os símbolos de importação, exportação e informações do cabeçalho do arquivo do programa PS4 atual em um diretório.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Ativar Depuração por RenderDoc:\nSe habilitado, o emulador fornecerá compatibilidade com RenderDoc para permitir a captura e análise do quadro atualmente renderizado.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Coletar Shaders:\nVocê precisa dessa opção ativada para editar shaders com o menu de depuração (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Ativar Readback Linear Images:\nAtiva o download assíncrono de imagens lineares(Linear Images) modificadas pela GPU.\nPode corrigir problemas em alguns jogos.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Copiar Buffers de GPU:\nContorna condições de corrida envolvendo envios de GPU.\nPode ou não ajudar com travamentos do PM4 tipo 0.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcadores de Depuração do Host:\nInsere informações vindo do emulador como marcadores para comandos AMDGPU específicos em torno de comandos Vulkan, além de fornecer nomes de depuração aos recursos.\nSe isso estiver habilitado, ative os Diagnósticos de Falhas.\nÚtil para programas como o RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Marcadores de Depuração do Convidado:\nInsere quaisquer marcadores de depuração que o próprio jogo adicionou ao buffer de comando.\nSe isso estiver habilitado, ative os Diagnósticos de Falhas.\nÚtil para programas como o RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Defina o volume da música de fundo.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Ativar Controles de Movimento</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Procurar</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Seleção Automática</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Diretório para instalar jogos</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Vídeo</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Modo de Exibição</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>Em Janela</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Tela Cheia</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Tela Cheia (Sem Bordas)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Tamanho da Janela</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>L:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>A:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Separar Arquivos de Registro</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Separar Arquivos de Registro:\nGrava um arquivo de registro para cada jogo.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Posição da Notificação do Troféu</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Esquerda</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Direita</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Superior</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Inferior</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Duração da Notificação</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Pasta Portátil do Usuário</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Criar Pasta Portátil do Usuário a partir da Pasta Comum do Usuário</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Pasta Portátil do Usuário:\nArmazena as configurações e dados do shadPS4 que serão aplicados apenas à compilação do shadPS4 localizada na pasta atual. Reinicie o aplicativo após criar a pasta portátil do usuário para começar a usá-la.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 já existe</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 criado com sucesso.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Abrir a pasta de imagens e sons de troféus personalizados:\nVocê pode adicionar imagens personalizadas aos troféus e um áudio.\nAdicione os arquivos na pasta custom_trophy com os seguintes nomes:\ntrophy.wav OU trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nObservação: O som funcionará apenas em versões Qt.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Recursos Experimentais</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>AVISO: Esses recursos são experimentais e só devem ser ativados se você foi instruído a fazê-lo ou um jogo requer isso. Por favor, pergunte no servidor do Discord shadPS4 se você tiver alguma dúvida.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Ativar Controle em Segundo plano</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Ativar Controle em Segundo plano:\nPermitir que o shadPS4 detecte entradas do controle quando a janela do jogo não está em foco.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Diagnóstico de Falhas:\nCria um arquivo .yaml com informações sobre o estado do Vulkan no momento da falha.\nÚtil para depuração de erros de &apos;Device lost&apos;. Se isto estiver ativado, você deve habilitar os Marcadores de Depuração do Host E do Convidado.\nNão funciona em GPUs Intel.\nVocê precisa ter as Camadas de Validação do Vulkan habilitadas e o Vulkan SDK para que isso funcione.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Habilitar Log/Registro</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Habilitar Log/Registro:\nHabilita o registro de logs.\nNão altere esta opção se você não souber o que está fazendo!\nAo pedir ajuda, certifique-se de que esta configuração esteja HABILITADA.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Modo de Apresentação</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Immediate (Sem Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Selecionar pasta de DLC</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Modo de Apresentação:\nConfigura como a saída de vídeo será apresentada na sua tela.\n\nMailbox: Os quadros sincronizam com a taxa de atualização da sua tela. Novos quadros substituirão quaisquer quadros pendentes. Reduz a latência, mas pode pular quadros se o desempenho estiver atrasado.\nFifo: Os quadros sincronizam com a taxa de atualização da sua tela. Novos quadros serão colocados em fila atrás dos quadros pendentes. Garante que todos os quadros sejam apresentados, mas pode aumentar a latência.\nImmediate: Os quadros são apresentados imediatamente na sua tela quando estiverem prontos. Pode resultar em tearing (rasgos na imagem).</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Procurar:\nProcure uma pasta para definir como o caminho para a DLC.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>Configurações FSR</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Habilitar FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>Habilitar RCAS (nitidez)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>Atenuação do RCAS:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Carregar Predefinições...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Log</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Abrir Local do Registro:\nAbre a pasta onde o arquivo de log está salvo.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Microfone:\nNenhum: Não usa o microfone.\nDispositivo padrão: usará o dispositivo padrão definido no sistema.\nOu escolha manualmente o microfone que será usado na lista.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Volume:\nAjuste o volume para os jogos no nível global, o intervalo vai de 0-500% sendo o padrão 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Aba padrão ao abrir as configurações:\nEscolher qual aba irá abrir, o padrão é Geral.</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Ativar Controles de Movimento:\nQuando ativado usará o sensor de movimento do controle, se suportado.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Frequência Vblank</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Frequência Vblank:\nA taxa de atualização em que o emulador realiza a atualização da imagem (60 Hz é o padrão, independentemente do jogo rodar a 30 ou 60 fps). Alterar este valor pode causar efeitos adversos, como aumentar a velocidade do jogo ou quebrar funcionalidades críticas que não foram projetadas para lidar com essa mudança!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Habilitar Acesso Direto à Memória (DMA)</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Habilitar o Modo Console Devkit</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Definir &quot;PSN signed-in&quot; como Verdadeiro</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Definir &quot;Network Connected&quot; como Verdadeiro</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Diversos</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Interface</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Experimental</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Mostrar Tela de Abertura(Splash Screen) ao iniciar o Jogo</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Configurações gerais da Interface</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>Habilitar o Modo PS4 Neo</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Ativar Acesso Direto à Memória:\nPermite o acesso arbitrário à memória da GPU para a memória da CPU.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>Ativar Modo PS4 Neo:\nAdiciona suporte para emulação e tamanho de memória do PS4 Pro. Atualmente causa instabilidade em um grande número de jogos testados.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Ativar Modo Console Devkit:\nAdiciona suporte para o tamanho de memória do console Devkit.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Definir Network Connected como Verdadeiro:\nForça os jogos a detectarem uma conexão de rede ativa. Recursos online reais ainda não são suportados.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Definir PSN Signed-in como Verdadeiro:\nForça os jogos a detectarem um login ativo na PSN. Recursos reais da PSN não são suportados.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Ativar Camadas de Validação do Vulkan:\nAtiva um sistema que valida o estado do renderizador Vulkan e registra informações sobre seu estado interno.\nIsso diminuirá o desempenho e provavelmente mudará o comportamento da emulação.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Dispositivo de Áudio (geral)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Dispositivo de Áudio (alto-falante DS4)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Ativar Exportação de Shaders:\nArmazena os shaders do jogo em uma pasta durante a renderização para fins de depuração técnica.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>Ativar GPU NULA:\nDesativa a renderização do jogo para fins de depuração técnica, como se não houvesse placa de vídeo. A tela ficará preta.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>Pasta de DLC:\nA pasta de onde os conteúdos adicionais (DLC) do jogo são carregados.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Alocação Adicional de DMem</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Alocação Adicional de DMem:\nForça a alocação da quantidade especificada de DMem adicional. Causa travamentos ou problemas em alguns jogos.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>Pasta sysmodules do PS4:\nA pasta de onde será carregado os sysmodules do PS4.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Procurar:\nProcure uma pasta para definir o caminho para os sysmodules.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Validação Vulkan (Requer Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Camadas de Validação</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Habilitar Validação de Núcleo</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Habilitar Validação de Sincronização</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Ativar Validação Assistida por GPU</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Habilitar Camadas de Validação do Vulkan:\nAtiva um sistema que valida o estado do renderizador Vulkan e registra informações sobre seu estado interno.\nIsso diminuirá o desempenho e provavelmente mudará o comportamento da emulação.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Habilitar Camadas de Validação do Vulkan:\nAtiva um sistema que valida o estado do renderizador Vulkan e registra informações sobre seu estado interno.\nIsso diminuirá o desempenho e provavelmente mudará o comportamento da emulação.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Ativar Validação Assistida por GPU:\nInstrumenta os shaders com código que valida se eles estão se comportando corretamente.\nIsso reduzirá o desempenho e alterará provavelmente o comportamento da emulação.\nVocê precisa do Vulkan SDK para que isso funcione.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Idioma da Interface (GUI)</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Atualizações da interface (GUI)</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>Pasta de DLC</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>Pasta Sysmodules do PS4</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Atualizações da GUI:\nRelease: Versões oficiais lançadas todos os meses que podem estar muito desatualizadas, mas são mais confiáveis e testadas.\nNightly: Versões de desenvolvimento que possuem todos os recursos e correções mais recentes, mas podem conter bugs e são menos estáveis.\n\n*Esta atualização aplica-se apenas à interface de usuário Qt. Para atualizar o núcleo do emulador, por favor use o menu &apos;Gerenciador de Versões&apos;.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>Não é possível criar a pasta portátil do usuário</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>Pasta portátil do usuário criada</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>Dispositivo USB</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Dispositivo USB real</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>Dispositivo USB:\nDispositivo USB Real: Usa um dispositivo USB real conectado ao sistema.\nPortal Skylander: Emula um Portal do Poder de Skylander.\nBase Infinity: Emula uma Base Disney Infinity.\nToypad Dimensions: Emula um Toypad de Lego Dimensions.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Habilitar Cache de Shader</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Comprimir os arquivos de Cache de Shader em um arquivo zip</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Habilitar Cache de Shader:\nArmazenar shaders compilados para evitar recompilações, reduzir travamento.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Compacte os arquivos de Cache do Shader em um arquivo zip:\nOs arquivos de cache do shader são armazenados dentro de um único arquivo zip em vez de vários arquivos separados.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Modo Readbacks</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Desabilitado</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Redbacks:\nAtiva readbacks e writebacks de memória da GPU.\nIsto é necessário para o funcionamento correto em alguns jogos.\nPode causar problemas de estabilidade e/ou desempenho.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Atenuado</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Rigoroso</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Selecione a Pasta Raiz do shadPS4</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Selecione a pasta dos módulos do sistema</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Local da Pasta Raiz (Dados de Jogos Salvos, Entradas, Troféis)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Local da Pasta Raiz:\nA pasta onde os dados de jogos salvos, arquivos de troféu e configurações de entrada são armazenados para todos os usuários.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Procurar:\nProcura uma pasta para definir como pasta raiz.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Áudio</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Backend de Áudio</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Dispositivo de Microfone</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Dispositivos</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Câmera</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Sincronização de Registro</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Ignorar Registros Duplicados</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Duração Máxima para Ignorar Registros</translation>
    </message>
    <message>
      <source> ms</source>
      <translation> ms</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Tamanho Limite do Registro</translation>
    </message>
    <message>
      <source> B</source>
      <translation> B</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Anexar ao Registro</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Anexar ao Registro\nAdiciona aos registros existentes.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Duração Máxima para Ignorar Registros:\nIntervalo sem escrever as mesmas linhas (ms) - somente se &apos;Ignorar Registros Duplicados&apos; estiver ativado.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Tamanho Limite do Registro:\nTamanho máximo dos arquivos de registro (em bytes).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Ignorar Registros Duplicados: \nEconomize espaço de armazenamento evitando gravar registros idênticos.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Sincronização de Registro:\nAlternar entre síncrono (ordem) ou assíncrono (desempenho).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Tipo de Registro:\nEscolha entre os tipos de registro wincolor ou msvc.\nwincolor: Registro padrão para Windows\nmsvc: Registro para depuração</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Filtro do Registro:\nFiltra o registro para exibir apenas informações específicas.\nExemplos: &quot;Core:Trace&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nNíveis: trace, debug, info, warning, error, critical - nesta ordem, um nível específico silencia todos os níveis anteriores na lista e registra todos os níveis após este.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Selecionar Versão</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Selecione a versão para criação do atalho</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Nenhuma Versão Selecionada</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Primeiro selecione uma versão</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Visualizador de Troféus</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Selecionar Jogo:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Progresso</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Mostrar Troféus Conquistados</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Mostrar Troféus Não Conquistados</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Mostrar Troféus Ocultos</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Escolha o Usuário:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Gerenciador de Usuário</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>&amp;Criar Usuário</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>&amp;Excluir Usuário</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>&amp;Renomear Usuário</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Definir Usuário Padrão</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>&amp;Definir Cor</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Definir Porta do Controle</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Fechar</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>Não é possível adicionar mais usuários.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Criar Novo Usuário</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>Novo ID de Usuário: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Nome de usuário (de 3 a 16 caracteres, letras, números, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Nome de Usuário Inválido</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>Nome de usuário deve conter de 3 a 16 caracteres válidos.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Confirmação de Exclusão</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Excluir ID de usuário %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Renomear Usuário</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Usuário Anterior: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Definir Cor do Usuário</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Selecione a cor:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Definir Porta do Controle</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Atribuir porta (de 1 a 4) para este usuário:</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Abrir Diretório do Usuário</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Gerenciador de Versões</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Caminho para salvar as versões</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Procurar</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Instalado</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Selecionada</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Versão</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Codinome</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Data</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Adicionar Personalizado</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Excluir</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Atualizar Lista</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Baixar</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Verificar por Atualizações Pre-release ao Iniciar</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Verificar por Atualizações Pre-release</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Selecione a pasta onde as versões do emulador serão instaladas</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Selecionar executável</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Executável (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Nome da versão</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Digite o nome desta versão, como aparece na lista.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Erro</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Sucesso</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>Versão adicionada com sucesso.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Não foi possível determinar o caminho da pasta.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Excluir versão</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Deseja excluir a versão</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Atualização da Lista de Versões</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>Sem mudanças, a lista de versões já está atualizada.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>As versões mais recentes foram adicionadas à lista para download.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Erro ao acessar a API do GitHub</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Primeiro você precisa escolher um local para salvar as versões em
&apos;Caminho para salvar as versões&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Deseja baixar a versão</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Não há arquivos disponíveis para esse sistema.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Baixando %1 , por favor aguarde...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Não foi possível salvar o arquivo.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>A versão %1 foi baixada e selecionada.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Falha ao criar o script de extração zip</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>A resposta da API do GitHub não é uma array JSON válida.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Atualização Automática - Emulador</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>Você já tem a versão de Pre-release mais recente.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Atualização Disponível (Emulador)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Versão Atual</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Última Versão</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Deseja atualizar?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Atualizar</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Não</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Mostrar Histórico de Alterações</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Ocultar Histórico de Alterações</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Erro de rede ao obter o histórico de alterações</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Alterações</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Nenhuma URL de download encontrada para o recurso especificado.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Erro de rede durante o download</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Falha ao baixar o arquivo</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Instalação completa</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>Pre-release atualizado com sucesso</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Falha ao criar o arquivo de script de atualização</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Sempre Mostrar o Histórico de Alterações</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Nenhuma versão selecionada. Por favor, escolha uma da lista para excluir.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Confirmação de Download</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Falha na extração.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Já existe uma versão com esse nome.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Local</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Não foi possível determinar a pasta para remover.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Falha ao excluir pasta.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>Não foi possível obter o hash do pre-release mais recente.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Baixando a versão de Pre-release(Nightly), por favor aguarde...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Gerenciador de Dimensions</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Colecionáveis Dimensions Ativos:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Limpar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carregar</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Mover</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Colecionável Desconhecido</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Selecionar Arquivo de Dimensions</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Colecionável Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Falha ao abrir o arquivo de colecionável!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Falha ao abrir o arquivo de colecionável(%1)! 
O arquivo pode já estar em uso na base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Falha ao ler o arquivo de colecionável!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Falha ao ler o arquivo de colecionável(%1)! 
O arquivo é muito pequeno.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Criador de Colecionável</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Filtrar por Série:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Todos</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconhecido--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Número do Colecionável:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Série:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Erro ao converter valor</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>O número do colecionável inserido é inválido!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>O número da série inserido é inválido!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Criar Arquivo de Colecionável</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Colecionável Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Falha ao criar arquivo de colecionável!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Falha ao criar arquivo de boneco: 
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Gerenciador de Infinity</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Colecionáveis Infinity Ativos:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>Conjunto/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>Power Disc Dois</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>Power Disc Três</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Jogador Um</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Habilidade Um do Jogador Um</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Habilidade Dois do Jogador Um</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Jogador Dois</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Habilidade Um do Jogador Dois</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Habilidade Dois do Jogador Dois</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Limpar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carregar</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Colecionável Desconhecido</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Selecionar Arquivo Infinity</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Colecionável Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Falha ao abrir o arquivo de colecionável!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Falha ao abrir o arquivo de colecionável(%1)! 
O arquivo pode já estar em uso na base.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Falha ao ler o arquivo de colecionável!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Falha ao ler o arquivo de colecionável(%1)! 
O arquivo é muito pequeno.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Criador de Colecionável</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconhecido--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Número do Colecionável:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Erro ao converter o valor</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Número do colecionável inserido é inválido!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Criar Arquivo de Colecionável</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Boneco Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Falha ao criar arquivo de minifigura!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Falha ao criar arquivo de minifigura: 
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Transportador do Colecionável</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Mover Aqui</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Pegar e Posicionar</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Criador de Skylanders</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Desconhecido--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Variante:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Cancelar</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Erro ao converter o valor</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>O ID inserido é inválido!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>A variante inserida é inválida!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Criar Arquivo Skylander</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Objeto Skylander (*.sky);;Todos os Arquivos (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Falha ao criar arquivo skylander!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Falha ao criar arquivo skylander:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Gerenciador de Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Portal Skylanders Ativo:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Limpar</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Criar</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Carregar</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Selecionar arquivo Skylander</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Todos os Arquivos (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Falha ao criar arquivo skylander!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Falha ao abrir o arquivo skylander (%1)!
O arquivo pode já estar em uso no portal.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Falha ao ler o arquivo skylander!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Falha ao ler o arquivo skylander (%1)! 
O arquivo é muito pequeno.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Desconhecido (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Nenhum</translation>
    </message>
  </context>
</TS>
