<?xml version="1.0" encoding="utf-8"?>
<!-- SPDX-FileCopyrightText: Copyright 2025 shadPS4 Emulator Project
     SPDX-License-Identifier: GPL-2.0-or-later -->
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU" sourcelanguage="en">
  <context>
    <name>AboutDialog</name>
    <message>
      <source>About shadPS4</source>
      <translation>О shadPS4</translation>
    </message>
    <message>
      <source>shadPS4 is an experimental open-source emulator for the PlayStation 4.</source>
      <translation>shadPS4 - это экспериментальный эмулятор с открытым исходным кодом для PlayStation 4.</translation>
    </message>
    <message>
      <source>This software should not be used to play games you have not legally obtained.</source>
      <translation>Это программное обеспечение не должно использоваться для запуска игр, которые вы получили нелегально.</translation>
    </message>
  </context>
  <context>
    <name>CheatsPatches</name>
    <message>
      <source>Cheats / Patches for </source>
      <translation>Читы и патчи для </translation>
    </message>
    <message>
      <source>Cheats/Patches are experimental.\nUse with caution.\n\nDownload cheats individually by selecting the repository and clicking the download button.\nIn the Patches tab, you can download all patches at once, choose which ones you want to use, and save your selection.\n\nSince we do not develop the Cheats/Patches,\nplease report issues to the cheat author.\n\nCreated a new cheat? Visit:\n</source>
      <translation>Читы и патчи экспериментальны.\nИспользуйте с осторожностью.\n\nСкачивайте читы, выбрав репозиторий и нажав на кнопку загрузки.\nВо вкладке &quot;Патчи&quot; вы можете скачать все патчи сразу, выбирать какие вы хотите использовать, и сохранять выбор.\n\nПоскольку мы не разрабатываем читы/патчи,\nпожалуйста сообщайте о проблемах автору чита/патча.\n\nСоздали новый чит? Посетите:\n</translation>
    </message>
    <message>
      <source>No Image Available</source>
      <translation>Изображение недоступно</translation>
    </message>
    <message>
      <source>Serial: </source>
      <translation>Серийный номер: </translation>
    </message>
    <message>
      <source>Version: </source>
      <translation>Версия: </translation>
    </message>
    <message>
      <source>Size: </source>
      <translation>Размер: </translation>
    </message>
    <message>
      <source>Select Cheat File:</source>
      <translation>Выберите файл чита:</translation>
    </message>
    <message>
      <source>Repository:</source>
      <translation>Репозиторий:</translation>
    </message>
    <message>
      <source>Download Cheats</source>
      <translation>Скачать читы</translation>
    </message>
    <message>
      <source>Delete File</source>
      <translation>Удалить файл</translation>
    </message>
    <message>
      <source>No files selected.</source>
      <translation>Файлы не выбраны.</translation>
    </message>
    <message>
      <source>You can delete the cheats you don&apos;t want after downloading them.</source>
      <translation>Вы можете удалить ненужные читы после их скачивания.</translation>
    </message>
    <message>
      <source>Do you want to delete the selected file?\n%1</source>
      <translation>Вы хотите удалить выбранный файл?\n%1</translation>
    </message>
    <message>
      <source>Select Patch File:</source>
      <translation>Выберите файл патча:</translation>
    </message>
    <message>
      <source>Download Patches</source>
      <translation>Скачать патчи</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <source>Cheats</source>
      <translation>Читы</translation>
    </message>
    <message>
      <source>Patches</source>
      <translation>Патчи</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>No patch selected.</source>
      <translation>Патч не выбран.</translation>
    </message>
    <message>
      <source>Unable to open files.json for reading.</source>
      <translation>Не удалось открыть файл files.json для чтения.</translation>
    </message>
    <message>
      <source>No patch file found for the current serial.</source>
      <translation>Не найден файл патча для текущего серийного номера.</translation>
    </message>
    <message>
      <source>Unable to open the file for reading.</source>
      <translation>Не удалось открыть файл для чтения.</translation>
    </message>
    <message>
      <source>Unable to open the file for writing.</source>
      <translation>Не удалось открыть файл для записи.</translation>
    </message>
    <message>
      <source>Failed to parse XML: </source>
      <translation>Не удалось разобрать XML: </translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Успех</translation>
    </message>
    <message>
      <source>Options saved successfully.</source>
      <translation>Опции успешно сохранены.</translation>
    </message>
    <message>
      <source>Invalid Source</source>
      <translation>Неверный источник</translation>
    </message>
    <message>
      <source>The selected source is invalid.</source>
      <translation>Выбранный источник недействителен.</translation>
    </message>
    <message>
      <source>File Exists</source>
      <translation>Файл существует</translation>
    </message>
    <message>
      <source>File already exists. Do you want to replace it?</source>
      <translation>Файл уже существует. Хотите заменить его?</translation>
    </message>
    <message>
      <source>Failed to save file:</source>
      <translation>Не удалось сохранить файл:</translation>
    </message>
    <message>
      <source>Failed to download file:</source>
      <translation>Не удалось скачать файл:</translation>
    </message>
    <message>
      <source>Cheats Not Found</source>
      <translation>Читы не найдены</translation>
    </message>
    <message>
      <source>No Cheats found for this game in this version of the selected repository,try another repository or a different version of the game.</source>
      <translation>Читы не найдены для этой игры в выбранном репозитории. Попробуйте другой репозиторий или другую версию игры.</translation>
    </message>
    <message>
      <source>Cheats Downloaded Successfully</source>
      <translation>Читы успешно скачаны</translation>
    </message>
    <message>
      <source>You have successfully downloaded the cheats for this version of the game from the selected repository. You can try downloading from another repository, if it is available it will also be possible to use it by selecting the file from the list.</source>
      <translation>Вы успешно скачали читы для этой версии игры из выбранного репозитория. Вы можете попробовать скачать из другого репозитория. Если он доступен, его также можно будет использовать, выбрав файл из списка.</translation>
    </message>
    <message>
      <source>Failed to save:</source>
      <translation>Не удалось сохранить:</translation>
    </message>
    <message>
      <source>Failed to download:</source>
      <translation>Не удалось скачать:</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Скачивание завершено</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully! All Patches available for all games have been downloaded, there is no need to download them individually for each game as happens in Cheats. If the patch does not appear, it may be that it does not exist for the specific serial and version of the game.</source>
      <translation>Патчи успешно скачаны! Все доступные патчи для всех игр были скачаны, нет необходимости скачивать их по отдельности для каждой игры, как это происходит с читами. Если патч не появляется, возможно, его не существует для конкретного серийного номера и версии игры.</translation>
    </message>
    <message>
      <source>Failed to parse JSON data from HTML.</source>
      <translation>Не удалось разобрать данные JSON из HTML.</translation>
    </message>
    <message>
      <source>Failed to retrieve HTML page.</source>
      <translation>Не удалось получить HTML-страницу.</translation>
    </message>
    <message>
      <source>The game is in version: %1</source>
      <translation>Игра в версии: %1</translation>
    </message>
    <message>
      <source>The downloaded patch only works on version: %1</source>
      <translation>Скачанный патч работает только на версии: %1</translation>
    </message>
    <message>
      <source>You may need to update your game.</source>
      <translation>Вам может понадобиться обновить игру.</translation>
    </message>
    <message>
      <source>Incompatibility Notice</source>
      <translation>Уведомление о несовместимости</translation>
    </message>
    <message>
      <source>Failed to open file:</source>
      <translation>Не удалось открыть файл:</translation>
    </message>
    <message>
      <source>XML ERROR:</source>
      <translation>ОШИБКА XML:</translation>
    </message>
    <message>
      <source>Failed to open files.json for writing</source>
      <translation>Не удалось открыть файл files.json для записи</translation>
    </message>
    <message>
      <source>Author: </source>
      <translation>Автор: </translation>
    </message>
    <message>
      <source>Directory does not exist:</source>
      <translation>Каталог не существует:</translation>
    </message>
    <message>
      <source>Failed to open files.json for reading.</source>
      <translation>Не удалось открыть файл files.json для чтения.</translation>
    </message>
    <message>
      <source>Name:</source>
      <translation>Имя:</translation>
    </message>
    <message>
      <source>Can&apos;t apply cheats before the game is started</source>
      <translation>Невозможно применить читы до начала игры</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Закрыть</translation>
    </message>
  </context>
  <context>
    <name>CheckUpdate</name>
    <message>
      <source>Auto Updater</source>
      <translation>Автообновление</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Network error:</source>
      <translation>Сетевая ошибка:</translation>
    </message>
    <message>
      <source>The Auto Updater allows up to 60 update checks per hour.\nYou have reached this limit. Please try again later.</source>
      <translation>Автообновление позволяет выполнять до 60 проверок обновлений в час.\nВы достигли этого лимита. Пожалуйста, попробуйте позже.</translation>
    </message>
    <message>
      <source>Failed to parse update information.</source>
      <translation>Не удалось разобрать информацию об обновлении.</translation>
    </message>
    <message>
      <source>No pre-releases found.</source>
      <translation>Версий предрелиза не найдено.</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>Не найден URL для загрузки указанного ресурса.</translation>
    </message>
    <message>
      <source>Your version is already up to date!</source>
      <translation>Ваша версия уже обновлена!</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Текущая версия</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Последняя версия</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Вы хотите обновиться?</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Показать журнал изменений</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Проверка при запуске</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Обновить</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Скрыть журнал изменений</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Журнал изменений</translation>
    </message>
    <message>
      <source>Network error occurred while trying to access the URL</source>
      <translation>Произошла сетевая ошибка при попытке доступа к URL</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Скачивание завершено</translation>
    </message>
    <message>
      <source>The update has been downloaded, press OK to install.</source>
      <translation>Обновление загружено, нажмите OK для установки.</translation>
    </message>
    <message>
      <source>Failed to save the update file at</source>
      <translation>Не удалось сохранить файл обновления в</translation>
    </message>
    <message>
      <source>Starting Update...</source>
      <translation>Начинаем обновление...</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Не удалось создать файл скрипта обновления</translation>
    </message>
    <message>
      <source>Auto Updater - GUI</source>
      <translation>Автообновление - Интерфейс</translation>
    </message>
    <message>
      <source>Update Available - GUI</source>
      <translation>Доступно обновление - Интерфейс</translation>
    </message>
  </context>
  <context>
    <name>CompatibilityInfoClass</name>
    <message>
      <source>Fetching compatibility data, please wait</source>
      <translation>Загрузка данных о совместимости, пожалуйста, подождите</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Загрузка...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Unable to update compatibility data! Try again later.</source>
      <translation>Не удалось обновить данные совместимости! Повторите попытку позже.</translation>
    </message>
    <message>
      <source>Unable to open compatibility_data.json for writing.</source>
      <translation>Не удалось открыть файл compatibility_data.json для записи.</translation>
    </message>
    <message>
      <source>Unknown</source>
      <translation>Неизвестно</translation>
    </message>
    <message>
      <source>Nothing</source>
      <translation>Ничего</translation>
    </message>
    <message>
      <source>Boots</source>
      <translation>Запускается</translation>
    </message>
    <message>
      <source>Menus</source>
      <translation>В меню</translation>
    </message>
    <message>
      <source>Ingame</source>
      <translation>В игре</translation>
    </message>
    <message>
      <source>Playable</source>
      <translation>Играбельно</translation>
    </message>
  </context>
  <context>
    <name>ControlSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Настроить управление</translation>
    </message>
    <message>
      <source>D-Pad</source>
      <translation>Крестовина</translation>
    </message>
    <message>
      <source>Up</source>
      <translation>Вверх</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Влево</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Вправо</translation>
    </message>
    <message>
      <source>Down</source>
      <translation>Вниз</translation>
    </message>
    <message>
      <source>Left Stick</source>
      <translation>Левый стик</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Выбор конфига</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Общий конфиг</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Использовать настройки для каждой игры</translation>
    </message>
    <message>
      <source>Face Buttons</source>
      <translation>Кнопки действий</translation>
    </message>
    <message>
      <source>Right Stick</source>
      <translation>Правый стик</translation>
    </message>
    <message>
      <source>Color Adjustment</source>
      <translation>Настройка цвета</translation>
    </message>
    <message>
      <source>Override Lightbar Color</source>
      <translation>Заменить цвет световой панели</translation>
    </message>
    <message>
      <source>Override Color</source>
      <translation>Заменить цвет</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Не удаётся сохранить</translation>
    </message>
    <message>
      <source>Cannot bind axis values more than once</source>
      <translation>Невозможно привязать значения оси более одного раза</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Применить</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>По умолчанию</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>не назначено</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Тачпад слева</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Тачпад центр</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Тачпад справа</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Треугольник</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Квадрат</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Круг</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Крест</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Невозможно привязать уникальный ввод более одного раза. Дублированные вводы назначены на следующие кнопки:

%1</translation>
    </message>
    <message>
      <source>Press a button</source>
      <translation>Нажмите кнопку</translation>
    </message>
    <message>
      <source>Move analog stick</source>
      <translation>Двиньте аналоговый стик</translation>
    </message>
    <message>
      <source>L1 and L2</source>
      <translation>L1 и L2</translation>
    </message>
    <message>
      <source>Active Gamepad</source>
      <translation>Текущий геймпад</translation>
    </message>
    <message>
      <source>Gamepad ID</source>
      <translation>ID геймпада</translation>
    </message>
    <message>
      <source>Default Gamepad</source>
      <translation>Геймпад по умолчанию</translation>
    </message>
    <message>
      <source>No default selected</source>
      <translation>Не выбран по умолчанию</translation>
    </message>
    <message>
      <source>n/a</source>
      <translation>n/a</translation>
    </message>
    <message>
      <source>Set Active Gamepad as Default</source>
      <translation>Выбрать текущий геймпад по умолчанию</translation>
    </message>
    <message>
      <source>Remove Default Gamepad</source>
      <translation>Удалить геймпад по умолчанию</translation>
    </message>
    <message>
      <source>R1 and R2</source>
      <translation>R1 и R2</translation>
    </message>
    <message>
      <source>ID: </source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Default Controller Selected</source>
      <translation>Выбран контроллер по умолчанию</translation>
    </message>
    <message>
      <source>Active controller set as default</source>
      <translation>Текущий контроллер выбран по умолчанию</translation>
    </message>
    <message>
      <source>Default Controller Removed</source>
      <translation>Контроллер по умолчанию удалён</translation>
    </message>
    <message>
      <source>Default controller setting removed</source>
      <translation>Настройки геймпада по умолчанию удалены</translation>
    </message>
    <message>
      <source>RED</source>
      <translation>КРАСНЫЙ</translation>
    </message>
    <message>
      <source>GREEN</source>
      <translation>ЗЕЛЁНЫЙ</translation>
    </message>
    <message>
      <source>BLUE</source>
      <translation>СИНИЙ</translation>
    </message>
    <message>
      <source>Left Stick Deadzone</source>
      <translation>Мертвая зона левого джойстика</translation>
    </message>
    <message>
      <source>Min Deadzone (def:2 max:127)</source>
      <translation>Мин. мёртвая зона (по умолч:2 макс:127)</translation>
    </message>
    <message>
      <source>Max Deadzone (def:127 max:127)</source>
      <translation>Макс. мёртвая зона (по умолч:127 макс 127)</translation>
    </message>
    <message>
      <source>Right Stick Deadzone</source>
      <translation>Мертвая зона правого джойстика</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Совет: Уберите назначение правой кнопкой мыши</translation>
    </message>
  </context>
  <context>
    <name>CryptoManagerDialog</name>
    <message>
      <source>Crypto Key Manager</source>
      <translation>Менеджер криптоключей</translation>
    </message>
    <message>
      <source>Trophy Key: Used for trophy decryption.
Must be a valid hex string with even length.</source>
      <translation>Ключ трофеев: используется для расшифровки трофеев.
Должен представлять собой допустимую шестнадцатеричную строку четной длины.</translation>
    </message>
    <message>
      <source>Enter Trophy Key</source>
      <translation>Введите ключ трофея</translation>
    </message>
    <message>
      <source>Trophy Key:</source>
      <translation>Ключ трофеев:</translation>
    </message>
    <message>
      <source>Status: Not loaded</source>
      <translation>Статус: Не загружено</translation>
    </message>
    <message>
      <source>Trophy Key</source>
      <translation>Ключ трофеев</translation>
    </message>
    <message>
      <source>Enter %1</source>
      <translation>Ввод %1</translation>
    </message>
    <message>
      <source>Exponent1</source>
      <translation>Экспонента1</translation>
    </message>
    <message>
      <source>Exponent2</source>
      <translation>Экспонента2</translation>
    </message>
    <message>
      <source>Public Exponent</source>
      <translation>Открытая экспонента</translation>
    </message>
    <message>
      <source>Coefficient</source>
      <translation>Коэффициент</translation>
    </message>
    <message>
      <source>Modulus</source>
      <translation>Модуль</translation>
    </message>
    <message>
      <source>Prime 1</source>
      <translation>Простое число 1</translation>
    </message>
    <message>
      <source>Prime 2</source>
      <translation>Простое число 2</translation>
    </message>
    <message>
      <source>Private Exponent</source>
      <translation>Закрытая экспонента</translation>
    </message>
    <message>
      <source>Fake Keyset</source>
      <translation>Поддельный набор ключей</translation>
    </message>
    <message>
      <source>RSA key components for fake signing.
All fields must be valid hex strings with even length.</source>
      <translation>Компоненты ключа RSA для поддельной подписи.
Все поля должны быть допустимыми шестнадцатеричными строками четной длины.</translation>
    </message>
    <message>
      <source>Debug Rif Keyset</source>
      <translation>Набор ключей Debug Rif</translation>
    </message>
    <message>
      <source>RSA key components for debug RIF files.
All fields must be valid hex strings with even length.</source>
      <translation>Компоненты ключа RSA для отладочных RIF-файлов.
Все поля должны быть допустимыми шестнадцатеричными строками четной длины.</translation>
    </message>
    <message>
      <source>Pkg Derived Key3</source>
      <translation>Pkg Derived Key3</translation>
    </message>
    <message>
      <source>RSA key components for package decryption.
All fields must be valid hex strings with even length.</source>
      <translation>Компоненты ключа RSA для расшифровки пакета.
Все поля должны быть допустимыми шестнадцатеричными строками четной длины.</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Закрыть</translation>
    </message>
    <message>
      <source>Warning</source>
      <translation>Предупреждение</translation>
    </message>
    <message>
      <source>No key file found or failed to load.
Please enter your keys and save them.</source>
      <translation>Файл ключа не найден или не удалось загрузить.
Пожалуйста, введите ваши ключи и сохраните их.</translation>
    </message>
    <message>
      <source>Validation Error</source>
      <translation>Ошибка проверки</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Успех</translation>
    </message>
    <message>
      <source>Keys saved successfully!</source>
      <translation>Ключи успешно сохранены!</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Failed to save keys!</source>
      <translation>Не удалось сохранить ключи!</translation>
    </message>
    <message>
      <source>Status: All fields empty</source>
      <translation>Статус: Все поля пусты</translation>
    </message>
    <message>
      <source>Status: Invalid hex values</source>
      <translation>Статус: Недопустимые шестнадцатеричные значения</translation>
    </message>
    <message>
      <source>Status: Incomplete</source>
      <translation>Статус: Незавершено</translation>
    </message>
    <message>
      <source>Status: Valid</source>
      <translation>Статус: Действителен</translation>
    </message>
    <message>
      <source>Invalid File</source>
      <translation>Недействительный файл</translation>
    </message>
    <message>
      <source>Only JSON files are supported.</source>
      <translation>Поддерживаются только файлы JSON.</translation>
    </message>
    <message>
      <source>Unable to open file.</source>
      <translation>Не удалось открыть файл.</translation>
    </message>
    <message>
      <source>JSON Error</source>
      <translation>Ошибка JSON</translation>
    </message>
    <message>
      <source>Invalid JSON format.</source>
      <translation>Неверный формат JSON.</translation>
    </message>
    <message>
      <source>Keys successfully loaded from JSON!</source>
      <translation>Ключи успешно загружены из JSON!</translation>
    </message>
    <message>
      <source>Trophy Key contains invalid hex or has odd length.</source>
      <translation>Ключ трофеев содержит недопустимые шестнадцатеричные значения или имеет нечетную длину.</translation>
    </message>
    <message>
      <source>%1 contains invalid hex or has odd length.</source>
      <translation>%1 содержит недопустимое шестнадцатеричное значение или имеет нечетную длину.</translation>
    </message>
    <message>
      <source>Load Key</source>
      <translation>Загрузить ключ</translation>
    </message>
    <message>
      <source>Save Key</source>
      <translation>Сохранить ключ</translation>
    </message>
  </context>
  <context>
    <name>EditorDialog</name>
    <message>
      <source>Edit Keyboard + Mouse and Controller input bindings</source>
      <translation>Редактировать бинды клавиатуры + мыши и контроллера</translation>
    </message>
    <message>
      <source>Use Per-Game configs</source>
      <translation>Использовать настройки для каждой игры</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Could not open the file for reading</source>
      <translation>Не удалось открыть файл для чтения</translation>
    </message>
    <message>
      <source>Could not open the file for writing</source>
      <translation>Не удалось открыть файл для записи</translation>
    </message>
    <message>
      <source>Save Changes</source>
      <translation>Сохранить изменения</translation>
    </message>
    <message>
      <source>Do you want to save changes?</source>
      <translation>Хотите сохранить изменения?</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Помощь</translation>
    </message>
    <message>
      <source>Do you want to reset your custom default config to the original default config?</source>
      <translation>Хотите ли вы сбросить ваш пользовательский конфиг по умолчанию к первоначальному конфигу по умолчанию?</translation>
    </message>
    <message>
      <source>Do you want to reset this config to your custom default config?</source>
      <translation>Хотите ли вы сбросить этот конфиг к вашему пользовательскому конфигу по умолчанию?</translation>
    </message>
    <message>
      <source>Reset to Default</source>
      <translation>Сбросить по умолчанию</translation>
    </message>
  </context>
  <context>
    <name>ElfViewer</name>
    <message>
      <source>Open Folder</source>
      <translation>Открыть папку</translation>
    </message>
  </context>
  <context>
    <name>GameInfoClass</name>
    <message>
      <source>Loading game list, please wait :3</source>
      <translation>Загрузка списка игр, пожалуйста подождите :3</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Loading...</source>
      <translation>Загрузка...</translation>
    </message>
  </context>
  <context>
    <name>GameInstallDialog</name>
    <message>
      <source>shadPS4 - Choose directory</source>
      <translation>shadPS4 - Выберите папку</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Обзор</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Directory to install emulator versions</source>
      <translation>Каталог для установки версий эмулятора</translation>
    </message>
    <message>
      <source>Directory with your dumped games</source>
      <translation>Каталог с извлечёнными играми</translation>
    </message>
    <message>
      <source>Directory with your dumped DLC&apos;s</source>
      <translation>Каталог с извлечёнными DLC</translation>
    </message>
    <message>
      <source>Directory with games</source>
      <translation>Каталог с играми</translation>
    </message>
    <message>
      <source>Directory with DLC&apos;s</source>
      <translation>Каталог с DLC</translation>
    </message>
  </context>
  <context>
    <name>GameListFrame</name>
    <message>
      <source>Icon</source>
      <translation>Иконка</translation>
    </message>
    <message>
      <source>Name</source>
      <translation>Название</translation>
    </message>
    <message>
      <source>Serial</source>
      <translation>Серийный номер</translation>
    </message>
    <message>
      <source>Compatibility</source>
      <translation>Совместимость</translation>
    </message>
    <message>
      <source>Region</source>
      <translation>Регион</translation>
    </message>
    <message>
      <source>Firmware</source>
      <translation>Прошивка</translation>
    </message>
    <message>
      <source>Size</source>
      <translation>Размер</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Версия</translation>
    </message>
    <message>
      <source>Path</source>
      <translation>Путь</translation>
    </message>
    <message>
      <source>Play Time</source>
      <translation>Время в игре</translation>
    </message>
    <message>
      <source>Never Played</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>h</source>
      <translation>ч</translation>
    </message>
    <message>
      <source>m</source>
      <translation>м</translation>
    </message>
    <message>
      <source>s</source>
      <translation>с</translation>
    </message>
    <message>
      <source>Compatibility is untested</source>
      <translation>Совместимость не проверена</translation>
    </message>
    <message>
      <source>Game does not initialize properly / crashes the emulator</source>
      <translation>Игра не инициализируется правильно / эмулятор вылетает</translation>
    </message>
    <message>
      <source>Game boots, but only displays a blank screen</source>
      <translation>Игра запускается, но показывает только пустой экран</translation>
    </message>
    <message>
      <source>Game displays an image but does not go past the menu</source>
      <translation>Игра показывает картинку, но не проходит дальше меню</translation>
    </message>
    <message>
      <source>Game has game-breaking glitches or unplayable performance</source>
      <translation>Игра имеет ломающие игру глюки или плохую производительность</translation>
    </message>
    <message>
      <source>Game can be completed with playable performance and no major glitches</source>
      <translation>Игра может быть пройдена с хорошей производительностью и без серьезных сбоев</translation>
    </message>
    <message>
      <source>Click to see details on github</source>
      <translation>Нажмите, чтобы увидеть детали на GitHub</translation>
    </message>
    <message>
      <source>Last updated</source>
      <translation>Последнее обновление</translation>
    </message>
    <message>
      <source>Favorite</source>
      <translation>Избранное</translation>
    </message>
  </context>
  <context>
    <name>GameListUtils</name>
    <message>
      <source>B</source>
      <translation>Б</translation>
    </message>
    <message>
      <source>KB</source>
      <translation>КБ</translation>
    </message>
    <message>
      <source>MB</source>
      <translation>МБ</translation>
    </message>
    <message>
      <source>GB</source>
      <translation>ГБ</translation>
    </message>
    <message>
      <source>TB</source>
      <translation>ТБ</translation>
    </message>
  </context>
  <context>
    <name>GuiContextMenus</name>
    <message>
      <source>Cheats / Patches</source>
      <translation>Читы и патчи</translation>
    </message>
    <message>
      <source>SFO Viewer</source>
      <translation>Просмотр SFO</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Просмотр трофеев</translation>
    </message>
    <message>
      <source>Open Folder...</source>
      <translation>Открыть папку...</translation>
    </message>
    <message>
      <source>Open Game Folder</source>
      <translation>Открыть папку с игрой</translation>
    </message>
    <message>
      <source>Open Save Data Folder</source>
      <translation>Открыть папку сохранений</translation>
    </message>
    <message>
      <source>Open Log Folder</source>
      <translation>Открыть папку логов</translation>
    </message>
    <message>
      <source>Copy info...</source>
      <translation>Копировать информацию...</translation>
    </message>
    <message>
      <source>Copy Name</source>
      <translation>Копировать имя</translation>
    </message>
    <message>
      <source>Copy Serial</source>
      <translation>Копировать серийный номер</translation>
    </message>
    <message>
      <source>Copy Version</source>
      <translation>Скопировать версию</translation>
    </message>
    <message>
      <source>Copy Size</source>
      <translation>Скопировать размер</translation>
    </message>
    <message>
      <source>Copy All</source>
      <translation>Копировать всё</translation>
    </message>
    <message>
      <source>Delete...</source>
      <translation>Удалить...</translation>
    </message>
    <message>
      <source>Delete Game</source>
      <translation>Удалить игру</translation>
    </message>
    <message>
      <source>Delete Update</source>
      <translation>Удалить обновление</translation>
    </message>
    <message>
      <source>Delete DLC</source>
      <translation>Удалить DLC</translation>
    </message>
    <message>
      <source>Delete Trophy</source>
      <translation>Удалить трофеи</translation>
    </message>
    <message>
      <source>Compatibility...</source>
      <translation>Совместимость...</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Game</source>
      <translation>Игры</translation>
    </message>
    <message>
      <source>This game has no update to delete!</source>
      <translation>У этой игры нет обновлений для удаления!</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Обновления</translation>
    </message>
    <message>
      <source>This game has no DLC to delete!</source>
      <translation>У этой игры нет DLC для удаления!</translation>
    </message>
    <message>
      <source>DLC</source>
      <translation>DLC</translation>
    </message>
    <message>
      <source>Delete %1</source>
      <translation>Удалить %1</translation>
    </message>
    <message>
      <source>Are you sure you want to delete %1&apos;s %2 directory?</source>
      <translation>Вы уверены, что хотите удалить папку %2 %1?</translation>
    </message>
    <message>
      <source>Open Update Folder</source>
      <translation>Открыть папку обновлений</translation>
    </message>
    <message>
      <source>Delete Save Data</source>
      <translation>Удалить сохранения</translation>
    </message>
    <message>
      <source>This game has no update folder to open!</source>
      <translation>У этой игры нет папки обновлений, которую можно открыть!</translation>
    </message>
    <message>
      <source>No log file found for this game!</source>
      <translation>Не найден файл журнала для этой игры!</translation>
    </message>
    <message>
      <source>This game has no save data to delete!</source>
      <translation>У этой игры нет сохранений, которые можно удалить!</translation>
    </message>
    <message>
      <source>This game has no saved trophies to delete!</source>
      <translation>У этой игры нет сохраненных трофеев для удаления!</translation>
    </message>
    <message>
      <source>Save Data</source>
      <translation>Сохранения</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Трофей</translation>
    </message>
    <message>
      <source>SFO Viewer for </source>
      <translation>Просмотр SFO для</translation>
    </message>
    <message>
      <source>Remove from Favorites</source>
      <translation>Удалить из избранного</translation>
    </message>
    <message>
      <source>Add to Favorites</source>
      <translation>Добавить в избранное</translation>
    </message>
    <message>
      <source>Game-specific Settings...</source>
      <translation>Индивидуальная конфигурация...</translation>
    </message>
    <message>
      <source>Configure Game-specific Settings</source>
      <translation>Настроить индивидуальную конфигурацию</translation>
    </message>
    <message>
      <source>Create Game-specific Settings from Global Settings</source>
      <translation>Создать индивидуальную конфигурацию из глобальных настроек</translation>
    </message>
    <message>
      <source>Delete Game-specific Settings</source>
      <translation>Удалить индивидуальную конфигурацию</translation>
    </message>
    <message>
      <source>Update Database</source>
      <translation>Обновить базу данных</translation>
    </message>
    <message>
      <source>View Report</source>
      <translation>Посмотреть отчёт</translation>
    </message>
    <message>
      <source>Submit a Report</source>
      <translation>Отправить отчёт</translation>
    </message>
    <message>
      <source>Confirm deletion</source>
      <translation>Подтвердить удаление</translation>
    </message>
    <message>
      <source>Delete game-specific settings?</source>
      <translation>Удалить индивидуальную конфигурацию?</translation>
    </message>
    <message>
      <source>Launch...</source>
      <translation>Запустить...</translation>
    </message>
    <message>
      <source>Launch with game specific configs (default)</source>
      <translation>Запуск с индивидуальной конфигурацией (по умолчанию)</translation>
    </message>
    <message>
      <source>Launch with global config only</source>
      <translation>Запуск только с глобальными настройками</translation>
    </message>
    <message>
      <source>Launch with default settings</source>
      <translation>Запуск с настройками по умолчанию</translation>
    </message>
    <message>
      <source>Couldn&apos;t submit report, because the latest log for the game failed on the following check, and therefore would be an invalid report:</source>
      <translation>Не удалось отправить отчёт, потому что последний лог игры не прошёл следующую проверку, и поэтому отчёт является неверным:</translation>
    </message>
    <message>
      <source>Ok</source>
      <translation>Ok</translation>
    </message>
    <message>
      <source>Info</source>
      <translation>Инфо</translation>
    </message>
    <message>
      <source>Create Shortcut for Selected Emulator Version</source>
      <translation>Создать ярлык для выбранной версии эмулятора</translation>
    </message>
    <message>
      <source>Create Shortcut for Specified Emulator Version</source>
      <translation>Создать ярлык для определённой версии эмулятора</translation>
    </message>
    <message>
      <source>Create Shortcut</source>
      <translation>Создать ярлык</translation>
    </message>
    <message>
      <source>Shortcut creation</source>
      <translation>Создание ярлыка</translation>
    </message>
    <message>
      <source>Shortcut created successfully!</source>
      <translation>Ярлык успешно создан!</translation>
    </message>
    <message>
      <source>Error creating shortcut!</source>
      <translation>Ошибка создания ярлыка!</translation>
    </message>
    <message>
      <source>Failed to convert icon.</source>
      <translation>Не удалось преобразовать значок.</translation>
    </message>
    <message>
      <source>Delete Shader Cache</source>
      <translation>Удалить кэш шейдеров</translation>
    </message>
    <message>
      <source>This game does not have any saved Shader Cache to delete!</source>
      <translation>В этой игре нет сохраненного кэша шейдеров для удаления!</translation>
    </message>
    <message>
      <source>Shader Cache</source>
      <translation>Кэш шейдеров</translation>
    </message>
    <message>
      <source>This game has no save folder to open!</source>
      <translation>У этой игры нет папки сохранений, которую можно открыть!</translation>
    </message>
    <message>
      <source>A trophy key is required to use the Trophy Viewer. This can be inputted by clicking Settings - Manage Cryptographic keys.</source>
      <translation>Ключ трофеев требуется для просмотра трофеев. Это можно ввести, нажав Настройки - Управление криптографическими ключами.</translation>
    </message>
  </context>
  <context>
    <name>HelpDialog</name>
    <message>
      <source>Quickstart</source>
      <translation>Быстрый старт</translation>
    </message>
    <message>
      <source>FAQ</source>
      <translation>ЧАВО</translation>
    </message>
    <message>
      <source>Syntax</source>
      <translation>Синтаксис</translation>
    </message>
    <message>
      <source>Special Bindings</source>
      <translation>Специальные бинды</translation>
    </message>
    <message>
      <source>Keybindings</source>
      <translation>Бинды клавиш</translation>
    </message>
  </context>
  <context>
    <name>Hotkeys</name>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Настроить горячие клавиши</translation>
    </message>
    <message>
      <source>Show FPS Counter</source>
      <translation>Показать счетчик FPS</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>не назначено</translation>
    </message>
    <message>
      <source>Quit Emulation</source>
      <translation>Завершить эмуляцию</translation>
    </message>
    <message>
      <source>Reload Button Mappings</source>
      <translation>Перезагрузить назначения кнопок</translation>
    </message>
    <message>
      <source>Toggle Fullscreen</source>
      <translation>Переключить полноэкранный режим</translation>
    </message>
    <message>
      <source>Toggle Pause</source>
      <translation>Переключить паузу</translation>
    </message>
    <message>
      <source>Toggle Mouse to Joystick Emulation</source>
      <translation>Переключить мышь в эмуляцию джойстика</translation>
    </message>
    <message>
      <source>Toggle Mouse to Gyro Emulation</source>
      <translation>Переключить мышь в эмуляцию гироскопа</translation>
    </message>
    <message>
      <source>Tip: Up to three simultaneous inputs can be assigned for each hotkey</source>
      <translation>Подсказка: для каждой горячей клавиши может быть назначено до трёх одновремённых вводов</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Применить</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>По умолчанию</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Не удаётся сохранить</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Невозможно привязать уникальный ввод более одного раза. Дублированные вводы назначены на следующие кнопки:

%1</translation>
    </message>
    <message>
      <source>Waiting for inputs</source>
      <translation>Ожидание ввода</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Совет: Уберите назначение правой кнопкой мыши</translation>
    </message>
    <message>
      <source>Volume Up</source>
      <translation>Увеличить громкость</translation>
    </message>
    <message>
      <source>Volume Down</source>
      <translation>Уменьшить громкость</translation>
    </message>
    <message>
      <source>Hotkeys</source>
      <translation>Горячие клавиши</translation>
    </message>
    <message>
      <source>Placeholder</source>
      <translation>Заглушка</translation>
    </message>
    <message>
      <source>Capture Screenshot</source>
      <translation>Сделать скриншот</translation>
    </message>
    <message>
      <source>Capture Screenshot w/ Overlays</source>
      <translation>Сделать скриншот с оверлеями</translation>
    </message>
    <message>
      <source>Open Emulator Settings</source>
      <translation>Открыть настройки эмулятора</translation>
    </message>
  </context>
  <context>
    <name>IpcClient</name>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Не удалось найти исполняемый файл эмулятора</translation>
    </message>
    <message>
      <source>No game is running</source>
      <translation>Нет запущенной игры</translation>
    </message>
  </context>
  <context>
    <name>KBMSettings</name>
    <message>
      <source>Configure Controls</source>
      <translation>Настроить управление</translation>
    </message>
    <message>
      <source>unmapped</source>
      <translation>не назначено</translation>
    </message>
    <message>
      <source>Left Analog Halfmode</source>
      <translation>Левый стик вполовину</translation>
    </message>
    <message>
      <source>Config Selection</source>
      <translation>Выбор конфига</translation>
    </message>
    <message>
      <source>Common Config</source>
      <translation>Общий конфиг</translation>
    </message>
    <message>
      <source>Use per-game configs</source>
      <translation>Использовать настройки для каждой игры</translation>
    </message>
    <message>
      <source>Text Editor</source>
      <translation>Текстовый редактор</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Помощь</translation>
    </message>
    <message>
      <source>Mouse to Joystick</source>
      <translation>Мышь в джойстик</translation>
    </message>
    <message>
      <source>*press F7 ingame to activate</source>
      <translation>*нажмите F7 в игре для активации</translation>
    </message>
    <message>
      <source>Options</source>
      <translation>Options</translation>
    </message>
    <message>
      <source>Mouse Movement Parameters</source>
      <translation>Параметры движения мыши</translation>
    </message>
    <message>
      <source>note: click Help Button/Special Keybindings for more information</source>
      <translation>примечание: нажмите кнопку Помощь/Специальные бинды для получения дополнительной информации</translation>
    </message>
    <message>
      <source>Triangle</source>
      <translation>Треугольник</translation>
    </message>
    <message>
      <source>Square</source>
      <translation>Квадрат</translation>
    </message>
    <message>
      <source>Circle</source>
      <translation>Круг</translation>
    </message>
    <message>
      <source>Cross</source>
      <translation>Крест</translation>
    </message>
    <message>
      <source>Right Analog Halfmode</source>
      <translation>Правый стик вполовину</translation>
    </message>
    <message>
      <source>Speed Offset (def 0.125):</source>
      <translation>Смещение скорости (по умолч 0.125):</translation>
    </message>
    <message>
      <source>Copy from Common Config</source>
      <translation>Копировать из общего конфига</translation>
    </message>
    <message>
      <source>Deadzone Offset (def 0.50):</source>
      <translation>Смещение мёртвой зоны (по умолч 0.50)</translation>
    </message>
    <message>
      <source>Speed Multiplier (def 1.0):</source>
      <translation>Множитель скорости (по умолч 1.0)</translation>
    </message>
    <message>
      <source>Copy values from Common Config</source>
      <translation>Копировать значения из общего конфига</translation>
    </message>
    <message>
      <source>Do you want to overwrite existing mappings with the mappings from the Common Config?</source>
      <translation>Вы хотите перезаписать существующие настройки настройками из общего конфига?</translation>
    </message>
    <message>
      <source>Unable to Save</source>
      <translation>Не удаётся сохранить</translation>
    </message>
    <message>
      <source>Press a key</source>
      <translation>Нажмите кнопку</translation>
    </message>
    <message>
      <source>Cannot set mapping</source>
      <translation>Не удаётся задать настройки</translation>
    </message>
    <message>
      <source>Mousewheel cannot be mapped to stick outputs</source>
      <translation>Колесо не может быть назначено для вывода стиков</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Применить</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>По умолчанию</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Cannot bind any unique input more than once. Duplicate inputs mapped to the following buttons:

%1</source>
      <translation>Невозможно привязать уникальный ввод более одного раза. Дублированные вводы назначены на следующие кнопки:

%1</translation>
    </message>
    <message>
      <source>Touchpad Left</source>
      <translation>Тачпад слева</translation>
    </message>
    <message>
      <source>Touchpad Center</source>
      <translation>Тачпад центр</translation>
    </message>
    <message>
      <source>Touchpad Right</source>
      <translation>Тачпад справа</translation>
    </message>
    <message>
      <source>Tip: Unmap inputs with right-click</source>
      <translation>Совет: Уберите назначение правой кнопкой мыши</translation>
    </message>
    <message>
      <source>Output</source>
      <translation>Вывод</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Ввод</translation>
    </message>
    <message>
      <source>Alternate Input 1</source>
      <translation>Альтернативный ввод 1</translation>
    </message>
    <message>
      <source>Alternate Input 2</source>
      <translation>Альтернативный ввод 2</translation>
    </message>
    <message>
      <source>Dpad Up</source>
      <translation>Крестовина вверх</translation>
    </message>
    <message>
      <source>Dpad Down</source>
      <translation>Крестовина вниз</translation>
    </message>
    <message>
      <source>Dpad Left</source>
      <translation>Крестовина влево</translation>
    </message>
    <message>
      <source>Dpad Right</source>
      <translation>Крестовина вправо</translation>
    </message>
    <message>
      <source>Left Stick Up</source>
      <translation>Левый стик вверх</translation>
    </message>
    <message>
      <source>Left Stick Down</source>
      <translation>Левый стик вниз</translation>
    </message>
    <message>
      <source>Left Stick Left</source>
      <translation>Левый стик влево</translation>
    </message>
    <message>
      <source>Left Stick Right</source>
      <translation>Левый стик вправо</translation>
    </message>
    <message>
      <source>Right Stick Up</source>
      <translation>Правый стик вверх</translation>
    </message>
    <message>
      <source>Right Stick Down</source>
      <translation>Правый стик вниз</translation>
    </message>
    <message>
      <source>Right Stick Left</source>
      <translation>Правый стик влево</translation>
    </message>
    <message>
      <source>Right Stick Right</source>
      <translation>Правый стик вправо</translation>
    </message>
    <message>
      <source>L1</source>
      <translation>L1</translation>
    </message>
    <message>
      <source>R1</source>
      <translation>R1</translation>
    </message>
    <message>
      <source>L2</source>
      <translation>L2</translation>
    </message>
    <message>
      <source>R2</source>
      <translation>R2</translation>
    </message>
    <message>
      <source>L3</source>
      <translation>L3</translation>
    </message>
    <message>
      <source>R3</source>
      <translation>R3</translation>
    </message>
  </context>
  <context>
    <name>LogPresetsDialog</name>
    <message>
      <source>Log Filter Presets</source>
      <translation>Пресеты фильтров логов</translation>
    </message>
    <message>
      <source>Comment</source>
      <translation>Комментарий</translation>
    </message>
    <message>
      <source>Filter</source>
      <translation>Фильтр</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Закрыть</translation>
    </message>
    <message>
      <source>Add a new preset after the selected row</source>
      <translation>Добавить новый пресет после выбранной строки</translation>
    </message>
    <message>
      <source>Remove selected presets</source>
      <translation>Удалить выбранный пресет</translation>
    </message>
    <message>
      <source>Load the selected preset</source>
      <translation>Загрузить выбранный пресет</translation>
    </message>
  </context>
  <context>
    <name>MainWindow</name>
    <message>
      <source>Open/Add Elf Folder</source>
      <translation>Открыть/Добавить папку Elf</translation>
    </message>
    <message>
      <source>Boot Game</source>
      <translation>Запустить игру</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Проверить обновления</translation>
    </message>
    <message>
      <source>About shadPS4</source>
      <translation>О shadPS4</translation>
    </message>
    <message>
      <source>Configure...</source>
      <translation>Настроить...</translation>
    </message>
    <message>
      <source>Recent Games</source>
      <translation>Недавние игры</translation>
    </message>
    <message>
      <source>Open shadPS4 Folder</source>
      <translation>Открыть папку shadPS4</translation>
    </message>
    <message>
      <source>Exit</source>
      <translation>Выход</translation>
    </message>
    <message>
      <source>Exit shadPS4</source>
      <translation>Выйти из shadPS4</translation>
    </message>
    <message>
      <source>Exit the application.</source>
      <translation>Выйти из приложения.</translation>
    </message>
    <message>
      <source>Show Game List</source>
      <translation>Показать список игр</translation>
    </message>
    <message>
      <source>Game List Refresh</source>
      <translation>Обновить список игр</translation>
    </message>
    <message>
      <source>Tiny</source>
      <translation>Крошечный</translation>
    </message>
    <message>
      <source>Small</source>
      <translation>Маленький</translation>
    </message>
    <message>
      <source>Medium</source>
      <translation>Средний</translation>
    </message>
    <message>
      <source>Large</source>
      <translation>Большой</translation>
    </message>
    <message>
      <source>List View</source>
      <translation>Список</translation>
    </message>
    <message>
      <source>Grid View</source>
      <translation>Сетка</translation>
    </message>
    <message>
      <source>Elf Viewer</source>
      <translation>Исполняемый файл</translation>
    </message>
    <message>
      <source>Game Install Directory</source>
      <translation>Каталог установки игры</translation>
    </message>
    <message>
      <source>Download Cheats/Patches</source>
      <translation>Скачать читы или патчи</translation>
    </message>
    <message>
      <source>Dump Game List</source>
      <translation>Дамп списка игр</translation>
    </message>
    <message>
      <source>Trophy Viewer</source>
      <translation>Просмотр трофеев</translation>
    </message>
    <message>
      <source>No games found. Please add your games to your library first.</source>
      <translation>Не найдено ни одной игры. Пожалуйста, сначала добавьте игры в библиотеку.</translation>
    </message>
    <message>
      <source>Search...</source>
      <translation>Поиск...</translation>
    </message>
    <message>
      <source>File</source>
      <translation>Файл</translation>
    </message>
    <message>
      <source>View</source>
      <translation>Вид</translation>
    </message>
    <message>
      <source>Game List Icons</source>
      <translation>Размер иконок списка игр</translation>
    </message>
    <message>
      <source>Game List Mode</source>
      <translation>Вид списка игр</translation>
    </message>
    <message>
      <source>Settings</source>
      <translation>Настройки</translation>
    </message>
    <message>
      <source>Utils</source>
      <translation>Утилиты</translation>
    </message>
    <message>
      <source>Themes</source>
      <translation>Темы</translation>
    </message>
    <message>
      <source>Help</source>
      <translation>Помощь</translation>
    </message>
    <message>
      <source>Dark</source>
      <translation>Темная</translation>
    </message>
    <message>
      <source>Light</source>
      <translation>Светлая</translation>
    </message>
    <message>
      <source>Green</source>
      <translation>Зеленая</translation>
    </message>
    <message>
      <source>Blue</source>
      <translation>Синяя</translation>
    </message>
    <message>
      <source>Violet</source>
      <translation>Фиолетовая</translation>
    </message>
    <message>
      <source>toolBar</source>
      <translation>Панель инструментов</translation>
    </message>
    <message>
      <source>Game List</source>
      <translation>Список игр</translation>
    </message>
    <message>
      <source>Download Cheats For All Installed Games</source>
      <translation>Скачать читы для всех установленных игр</translation>
    </message>
    <message>
      <source>Download Patches For All Games</source>
      <translation>Скачать патчи для всех игр</translation>
    </message>
    <message>
      <source>Download Complete</source>
      <translation>Скачивание завершено</translation>
    </message>
    <message>
      <source>You have downloaded cheats for all the games you have installed.</source>
      <translation>Вы скачали читы для всех установленных игр.</translation>
    </message>
    <message>
      <source>Patches Downloaded Successfully!</source>
      <translation>Патчи успешно скачаны!</translation>
    </message>
    <message>
      <source>All Patches available for all games have been downloaded.</source>
      <translation>Все доступные патчи для всех игр были скачаны.</translation>
    </message>
    <message>
      <source>Games: </source>
      <translation>Игры: </translation>
    </message>
    <message>
      <source>ELF files (*.bin *.elf *.oelf)</source>
      <translation>Файлы ELF (*.bin *.elf *.oelf)</translation>
    </message>
    <message>
      <source>Game Boot</source>
      <translation>Запуск игры</translation>
    </message>
    <message>
      <source>Only one file can be selected!</source>
      <translation>Можно выбрать только один файл!</translation>
    </message>
    <message>
      <source>Run Game</source>
      <translation>Запустить игру</translation>
    </message>
    <message>
      <source>Eboot.bin file not found</source>
      <translation>Файл eboot.bin не найден</translation>
    </message>
    <message>
      <source>Game is already running!</source>
      <translation>Игра уже запущена!</translation>
    </message>
    <message>
      <source>shadPS4</source>
      <translation>shadPS4</translation>
    </message>
    <message>
      <source>Play</source>
      <translation>Играть</translation>
    </message>
    <message>
      <source>Pause</source>
      <translation>Пауза</translation>
    </message>
    <message>
      <source>Stop</source>
      <translation>Остановить</translation>
    </message>
    <message>
      <source>Restart</source>
      <translation>Перезапустить</translation>
    </message>
    <message>
      <source>Full Screen</source>
      <translation>Полный экран</translation>
    </message>
    <message>
      <source>Controllers</source>
      <translation>Контроллеры</translation>
    </message>
    <message>
      <source>Keyboard</source>
      <translation>Клавиатура</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Обновить список</translation>
    </message>
    <message>
      <source>Resume</source>
      <translation>Продолжить</translation>
    </message>
    <message>
      <source>Show Labels Under Icons</source>
      <translation>Показывать метки под значками</translation>
    </message>
    <message>
      <source>Customize Hotkeys</source>
      <translation>Настроить горячие клавиши</translation>
    </message>
    <message>
      <source>Version Manager</source>
      <translation>Менеджер версий</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Версия не выбрана</translation>
    </message>
    <message>
      <source>No emulator version was selected.
The Version Manager menu will then open.
Select an emulator version from the right panel.</source>
      <translation>Версия эмулятора не выбрана.
Откроется меню «Менеджер версий».
Выберите версию эмулятора на правой панели.</translation>
    </message>
    <message>
      <source>Could not find the emulator executable</source>
      <translation>Не удалось найти исполняемый файл эмулятора</translation>
    </message>
    <message>
      <source>Run Emulator</source>
      <translation>Запустить эмулятор</translation>
    </message>
    <message>
      <source>Emulator is already running!</source>
      <translation>Эмулятор уже запущен!</translation>
    </message>
    <message>
      <source>Invalid game argument provided</source>
      <translation>Предоставлен неверный аргумент игры</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Manage Skylanders</source>
      <translation>Управление Skylanders</translation>
    </message>
    <message>
      <source>Manage Infinity Figures</source>
      <translation>Управление фигурами Infinity</translation>
    </message>
    <message>
      <source>Manage Dimensions Toypad</source>
      <translation>Управление Dimensions Toypad</translation>
    </message>
    <message>
      <source>Game Log</source>
      <translation>Журнал игры</translation>
    </message>
    <message>
      <source>Show Game Log</source>
      <translation>Показать журнал игры</translation>
    </message>
    <message>
      <source>Manage Cryptographic Keys</source>
      <translation>Управление криптографическими ключами</translation>
    </message>
    <message>
      <source>Manage Users</source>
      <translation>Управление пользователями</translation>
    </message>
  </context>
  <context>
    <name>QObject</name>
    <message>
      <source>Drive Locked</source>
      <translation>Диск заблокирован</translation>
    </message>
    <message>
      <source>Drive %1: is locked. Please enter the BitLocker key to access it:</source>
      <translation>Диск %1: заблокирован. Пожалуйста, введите ключ BitLocker для доступа к нему:</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Incorrect recovery key. Please try again.</source>
      <translation>Неверный ключ восстановления. Попробуйте еще раз.</translation>
    </message>
  </context>
  <context>
    <name>SettingsDialog</name>
    <message>
      <source>Settings</source>
      <translation>Настройки</translation>
    </message>
    <message>
      <source>General</source>
      <translation>Общее</translation>
    </message>
    <message>
      <source>System</source>
      <translation>Система</translation>
    </message>
    <message>
      <source>Console Language</source>
      <translation>Язык консоли</translation>
    </message>
    <message>
      <source>Default tab when opening settings</source>
      <translation>Вкладка по умолчанию при открытии настроек</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence</source>
      <translation>Включить Discord Rich Presence</translation>
    </message>
    <message>
      <source>Trophy</source>
      <translation>Трофеи</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder</source>
      <translation>Открыть папку с пользовательскими изображениями/звуками трофеев</translation>
    </message>
    <message>
      <source>Logger</source>
      <translation>Логирование</translation>
    </message>
    <message>
      <source>Log Type</source>
      <translation>Тип логов</translation>
    </message>
    <message>
      <source>Log Filter</source>
      <translation>Фильтр логов</translation>
    </message>
    <message>
      <source>Open Log Location</source>
      <translation>Открыть местоположение журнала</translation>
    </message>
    <message>
      <source>Input</source>
      <translation>Ввод</translation>
    </message>
    <message>
      <source>Cursor</source>
      <translation>Курсор мыши</translation>
    </message>
    <message>
      <source>Hide Cursor</source>
      <translation>Скрывать курсор</translation>
    </message>
    <message>
      <source>Hide Cursor Idle Timeout</source>
      <translation>Время скрытия курсора при бездействии</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Default Device</source>
      <translation>Устройство по умолчанию</translation>
    </message>
    <message>
      <source>s</source>
      <translation>сек</translation>
    </message>
    <message>
      <source>Controller</source>
      <translation>Контроллер</translation>
    </message>
    <message>
      <source>Graphics</source>
      <translation>Графика</translation>
    </message>
    <message>
      <source>User</source>
      <translation>Пользователь</translation>
    </message>
    <message>
      <source>Graphics Device</source>
      <translation>Графическое устройство</translation>
    </message>
    <message>
      <source>Advanced</source>
      <translation>Продвинутые</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping</source>
      <translation>Включить дамп шейдеров</translation>
    </message>
    <message>
      <source>Enable NULL GPU</source>
      <translation>Включить NULL GPU</translation>
    </message>
    <message>
      <source>Enable HDR</source>
      <translation>Включить HDR</translation>
    </message>
    <message>
      <source>Paths</source>
      <translation>Пути</translation>
    </message>
    <message>
      <source>Game Folders</source>
      <translation>Игровые папки</translation>
    </message>
    <message>
      <source>Add...</source>
      <translation>Добавить...</translation>
    </message>
    <message>
      <source>Remove</source>
      <translation>Удалить</translation>
    </message>
    <message>
      <source>Debug</source>
      <translation>Отладка</translation>
    </message>
    <message>
      <source>Enable Debug Dumping</source>
      <translation>Включить отладочные дампы</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers</source>
      <translation>Включить слои валидации Vulkan</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging</source>
      <translation>Включить отладку RenderDoc</translation>
    </message>
    <message>
      <source>Enable Crash Diagnostics</source>
      <translation>Включить диагностику сбоев</translation>
    </message>
    <message>
      <source>Collect Shaders</source>
      <translation>Собирать шейдеры</translation>
    </message>
    <message>
      <source>Copy GPU Buffers</source>
      <translation>Копировать буферы GPU</translation>
    </message>
    <message>
      <source>Host Debug Markers</source>
      <translation>Маркеры отладки хоста</translation>
    </message>
    <message>
      <source>Guest Debug Markers</source>
      <translation>Маркеры отладки гостя</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images</source>
      <translation>Включить обратное чтение линейных изображений</translation>
    </message>
    <message>
      <source>Check for Updates at Startup</source>
      <translation>Проверка при запуске</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Всегда показывать журнал изменений</translation>
    </message>
    <message>
      <source>Check for Updates</source>
      <translation>Проверить обновления</translation>
    </message>
    <message>
      <source>Title Music</source>
      <translation>Заглавная музыка</translation>
    </message>
    <message>
      <source>Disable Trophy Notification</source>
      <translation>Отключить уведомления о трофее</translation>
    </message>
    <message>
      <source>Background Image</source>
      <translation>Фоновое изображение</translation>
    </message>
    <message>
      <source>Show Background Image</source>
      <translation>Показывать фоновое изображение</translation>
    </message>
    <message>
      <source>Opacity</source>
      <translation>Прозрачность</translation>
    </message>
    <message>
      <source>Play title music</source>
      <translation>Играть заглавную музыку</translation>
    </message>
    <message>
      <source>Update Compatibility Database On Startup</source>
      <translation>Обновлять базу совместимости при запуске</translation>
    </message>
    <message>
      <source>Game Compatibility</source>
      <translation>Совместимость игр</translation>
    </message>
    <message>
      <source>Display Compatibility Data</source>
      <translation>Показывать данные совместимости</translation>
    </message>
    <message>
      <source>Update Compatibility Database</source>
      <translation>Обновить базу совместимости</translation>
    </message>
    <message>
      <source>Volume</source>
      <translation>Громкость</translation>
    </message>
    <message>
      <source>Save</source>
      <translation>Сохранить</translation>
    </message>
    <message>
      <source>Apply</source>
      <translation>Применить</translation>
    </message>
    <message>
      <source>Restore Defaults</source>
      <translation>По умолчанию</translation>
    </message>
    <message>
      <source>Close</source>
      <translation>Закрыть</translation>
    </message>
    <message>
      <source>Point your mouse at an option to display its description.</source>
      <translation>Наведите указатель мыши на опцию, чтобы отобразить ее описание.</translation>
    </message>
    <message>
      <source>Console Language:\nSets the language that the PS4 game uses.\nIt&apos;s recommended to set this to a language the game supports, which will vary by region.</source>
      <translation>Язык консоли:\nУстанавливает язык, который будет использоваться в играх PS4.\nРекомендуется устанавливать язык, который поддерживается игрой, так как он может отличаться в зависимости от региона.</translation>
    </message>
    <message>
      <source>Emulator Language:\nSets the language of the emulator&apos;s user interface.</source>
      <translation>Язык эмулятора:\nУстанавливает язык пользовательского интерфейса эмулятора.</translation>
    </message>
    <message>
      <source>Show Splash Screen:\nShows the game&apos;s splash screen (a special image) while the game is starting.</source>
      <translation>Показывать заставку:\nОтображает заставку игры (специальное изображение) во время запуска.</translation>
    </message>
    <message>
      <source>Enable Discord Rich Presence:\nDisplays the emulator icon and relevant information on your Discord profile.</source>
      <translation>Включить Discord Rich Presence:\nОтображает значок эмулятора и соответствующую информацию в вашем профиле Discord.</translation>
    </message>
    <message>
      <source>Background Image:\nControl the opacity of the game background image.</source>
      <translation>Фоновое изображение:\nКонтролирует непрозрачность фона игры.</translation>
    </message>
    <message>
      <source>Play Title Music:\nIf a game supports it, enable playing special music when selecting the game in the GUI.</source>
      <translation>Играть заглавную музыку:\nВключает воспроизведение специальной музыки при выборе игры в списке, если она это поддерживает.</translation>
    </message>
    <message>
      <source>Disable Trophy Pop-ups:\nDisable in-game trophy notifications. Trophy progress can still be tracked using the Trophy Viewer (right-click the game in the main window).</source>
      <translation>Отключить уведомления о трофеях:\nОтключает внутриигровые уведомления о трофеях. Прогресс трофеев по-прежнему можно отслеживать в меню просмотра трофеев (правая кнопка мыши по игре в главном окне).</translation>
    </message>
    <message>
      <source>Hide Cursor:\nChoose when the cursor will disappear:\nNever: You will always see the mouse.\nidle: Set a time for it to disappear after being idle.\nAlways: you will never see the mouse.</source>
      <translation>Скрывать курсор:\nВыберите, когда курсор будет скрыт:\nНикогда: Вы всегда будете видеть курсор.\nПри бездействии: Установите время, через которое курсор будет скрыт при бездействии.\nВсегда: Курсор всегда будет скрыт.</translation>
    </message>
    <message>
      <source>Hide Idle Cursor Timeout:\nThe duration (seconds) after which the cursor that has been idle hides itself.</source>
      <translation>Время скрытия курсора при бездействии:\nВремя (в секундах), через которое курсор исчезнет при бездействии.</translation>
    </message>
    <message>
      <source>Display Compatibility Data:\nDisplays game compatibility information in table view. Enable &quot;Update Compatibility On Startup&quot; to get up-to-date information.</source>
      <translation>Показывать данные совместимости:\nПоказывает информацию о совместимости игр в таблице. Включите «Обновлять базу совместимости при запуске» для получения актуальной информации.</translation>
    </message>
    <message>
      <source>Update Compatibility On Startup:\nAutomatically update the compatibility database when shadPS4 starts.</source>
      <translation>Обновлять базу совместимости при запуске:\nАвтоматически обновлять базу данных совместимости при запуске shadPS4.</translation>
    </message>
    <message>
      <source>Update Compatibility Database:\nImmediately update the compatibility database.</source>
      <translation>Обновить базу совместимости:\nНемедленно обновить базу данных совместимости.</translation>
    </message>
    <message>
      <source>Never</source>
      <translation>Никогда</translation>
    </message>
    <message>
      <source>Idle</source>
      <translation>При бездействии</translation>
    </message>
    <message>
      <source>Always</source>
      <translation>Всегда</translation>
    </message>
    <message>
      <source>Graphics Device:\nOn multiple GPU systems, select the GPU the emulator will use from the drop down list,\nor select &quot;Auto Select&quot; to automatically determine it.</source>
      <translation>Графическое устройство:\nВ системах с несколькими GPU выберите тот, который будет использовать эмулятор.\nВыберите &quot;Автовыбор&quot;, чтобы определить GPU автоматически.</translation>
    </message>
    <message>
      <source>Width/Height:\nSets the size of the emulator window at launch, which can be resized during gameplay.\nThis is different from the in-game resolution.</source>
      <translation>Ширина/Высота:\nУстановите размер окна эмулятора при запуске, который может быть изменен во время игры.\nЭто отличается от разрешения в игре.</translation>
    </message>
    <message>
      <source>Enable HDR:\nEnables HDR in games that support it.\nYour monitor must have support for the BT2020 PQ color space and the RGB10A2 swapchain format.</source>
      <translation>Включить HDR:\nВключает HDR в играх, которые его поддерживают.\nВаш монитор должен иметь поддержку цветового пространства BT2020 PQ и формата цепочки буферов RGB10A2.</translation>
    </message>
    <message>
      <source>Game Folders:\nThe list of folders to check for installed games.</source>
      <translation>Игровые папки:\nСписок папок для проверки установленных игр.</translation>
    </message>
    <message>
      <source>Add:\nAdd a folder to the list.</source>
      <translation>Добавить:\nДобавить папку в список.</translation>
    </message>
    <message>
      <source>Remove:\nRemove a folder from the list.</source>
      <translation>Удалить:\nУдалить папку из списка.</translation>
    </message>
    <message>
      <source>Enable Debug Dumping:\nSaves the import and export symbols and file header information of the currently running PS4 program to a directory.</source>
      <translation>Включить отладочные дампы:\nСохраняет символы импорта, экспорта и информацию о заголовке файла текущей исполняемой программы PS4 в папку.</translation>
    </message>
    <message>
      <source>Enable RenderDoc Debugging:\nIf enabled, the emulator will provide compatibility with Renderdoc to allow capture and analysis of the currently rendered frame.</source>
      <translation>Включить отладку RenderDoc:\nЕсли включено, эмулятор обеспечит совместимость с RenderDoc, позволяя захватывать и анализировать текущие кадры во время рендеринга.</translation>
    </message>
    <message>
      <source>Collect Shaders:\nYou need this enabled to edit shaders with the debug menu (Ctrl + F10).</source>
      <translation>Собирать шейдеры:\nВам необходимо включить эту функцию для редактирования шейдеров с помощью меню отладки (Ctrl + F10).</translation>
    </message>
    <message>
      <source>Enable Readback Linear Images:\nEnables async downloading of GPU modified linear images.\nMight fix issues in some games.</source>
      <translation>Включить обратное чтение линейных изображений:\nВключает асинхронную загрузку изображений, модифицированных GPU.\nМожет исправить проблемы в некоторых играх.</translation>
    </message>
    <message>
      <source>Copy GPU Buffers:\nGets around race conditions involving GPU submits.\nMay or may not help with PM4 type 0 crashes.</source>
      <translation>Копировать буферы GPU:\nПозволяет обойти состояния гонки, связанные с отправками GPU.\nМожет помочь или не помочь при сбоях PM4 типа 0.</translation>
    </message>
    <message>
      <source>Host Debug Markers:\nInserts emulator-side information like markers for specific AMDGPU commands around Vulkan commands, as well as giving resources debug names.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Маркеры отладки хоста:\nДобавляет информацию на стороне эмулятора, например маркеры для определенных команд AMDGPU, вокруг команд Vulkan, а также присваивает ресурсам отладочные имена.\nЕсли эта функция включена, вам следует включить Диагностику сбоев.\nПолезно для таких программ, как RenderDoc.</translation>
    </message>
    <message>
      <source>Guest Debug Markers:\nInserts any debug markers the game itself has added to the command buffer.\nIf you have this enabled, you should enable Crash Diagnostics.\nUseful for programs like RenderDoc.</source>
      <translation>Маркеры отладки гостя:\nДобавляет любые отладочные маркеры, добавленные самой игрой, в буфер команд.\nЕсли эта функция включена, вам следует включить Диагностику сбоев.\nПолезно для таких программ, как RenderDoc.</translation>
    </message>
    <message>
      <source>Set the volume of the background music.</source>
      <translation>Установите громкость фоновой музыки.</translation>
    </message>
    <message>
      <source>Enable Motion Controls</source>
      <translation>Включить управление движением</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Обзор</translation>
    </message>
    <message>
      <source>Auto Select</source>
      <translation>Автовыбор</translation>
    </message>
    <message>
      <source>Directory to install games</source>
      <translation>Каталог для установки игр</translation>
    </message>
    <message>
      <source>Video</source>
      <translation>Видео</translation>
    </message>
    <message>
      <source>Display Mode</source>
      <translation>Режим отображения</translation>
    </message>
    <message>
      <source>Windowed</source>
      <translation>Оконный</translation>
    </message>
    <message>
      <source>Fullscreen</source>
      <translation>Полный экран</translation>
    </message>
    <message>
      <source>Fullscreen (Borderless)</source>
      <translation>Полный экран (без рамок)</translation>
    </message>
    <message>
      <source>Window Size</source>
      <translation>Размер окна</translation>
    </message>
    <message>
      <source>W:</source>
      <translation>Ш:</translation>
    </message>
    <message>
      <source>H:</source>
      <translation>В:</translation>
    </message>
    <message>
      <source>Separate Log Files</source>
      <translation>Отдельные файлы логов</translation>
    </message>
    <message>
      <source>Separate Log Files:\nWrites a separate logfile for each game.</source>
      <translation>Отдельные файлы логов:\nПишет отдельный файл логов для каждой игры.</translation>
    </message>
    <message>
      <source>Trophy Notification Position</source>
      <translation>Местоположение уведомления о трофее</translation>
    </message>
    <message>
      <source>Left</source>
      <translation>Слева</translation>
    </message>
    <message>
      <source>Right</source>
      <translation>Справа</translation>
    </message>
    <message>
      <source>Top</source>
      <translation>Сверху</translation>
    </message>
    <message>
      <source>Bottom</source>
      <translation>Снизу</translation>
    </message>
    <message>
      <source>Notification Duration</source>
      <translation>Продолжительность уведомления</translation>
    </message>
    <message>
      <source>Portable User Folder</source>
      <translation>Портативная папка пользователя</translation>
    </message>
    <message>
      <source>Create Portable User Folder from Common User Folder</source>
      <translation>Создать портативную папку пользователя из общей папки пользователя</translation>
    </message>
    <message>
      <source>Portable user folder:\nStores shadPS4 settings and data that will be applied only to the shadPS4 build located in the current folder. Restart the app after creating the portable user folder to begin using it.</source>
      <translation>Портативная папка пользователя:\nХранит настройки и данные shadPS4, которые будут применяться только к билду shadPS4, расположенному в этой папке. Перезагрузите приложение после создания портативной папки пользователя чтобы начать использовать её.</translation>
    </message>
    <message>
      <source>%1 already exists</source>
      <translation>%1 уже существует</translation>
    </message>
    <message>
      <source>%1 successfully created.</source>
      <translation>%1 успешно создано.</translation>
    </message>
    <message>
      <source>Open the custom trophy images/sounds folder:\nYou can add custom images to the trophies and an audio.\nAdd the files to custom_trophy with the following names:\ntrophy.wav OR trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nNote: The sound will only work in QT versions.</source>
      <translation>Открыть папку с пользовательскими изображениями/звуками трофеев:\nВы можете добавить пользовательские изображения к трофеям и аудио.\nДобавьте файлы в custom_trophy со следующими именами:\ntrophy.wav ИЛИ trophy.mp3, bronze.png, gold.png, platinum.png, silver.png\nПримечание: звук будет работать только в QT-версии.</translation>
    </message>
    <message>
      <source>Experimental Features</source>
      <translation>Экспериментальные функции</translation>
    </message>
    <message>
      <source>WARNING: These features are experimental and should not be enabled unless you were told to, or a game requires it. Please ask in the shadPS4 Discord server if you have any questions.</source>
      <translation>ВНИМАНИЕ: Эти функции являются экспериментальными и не должны включаться, если вы не знаете об обратном, или если этого не требует игра. Если у вас есть вопросы, задавайте их на Discord сервере shadPS4.</translation>
    </message>
    <message>
      <source>Enable Background Controller Input</source>
      <translation>Включить фоновый ввод контроллера</translation>
    </message>
    <message>
      <source>Enable Controller Background Input:\nAllow shadPS4 to detect controller inputs when the game window is not in focus.</source>
      <translation>Включить фоновый ввод контроллера:\nРазрешить shadPS4 определять ввод контроллера, когда окно игры не в фокусе.</translation>
    </message>
    <message>
      <source>Crash Diagnostics:\nCreates a .yaml file with info about the Vulkan state at the time of crashing.\nUseful for debugging &apos;Device lost&apos; errors. If you have this enabled, you should enable Host AND Guest Debug Markers.\nYou need Vulkan Validation Layers enabled and the Vulkan SDK for this to work.</source>
      <translation>Диагностика сбоев:\nСоздает .yaml-файл с информацией о состоянии Vulkan в момент падения.\nПолезно для отладки ошибок &apos;Device lost&apos;. Если эта функция включена, вам следует включить Маркеры отладки хоста и Гостя.\nДля работы вам необходимо включить Слои валидации Vulkan и установить Vulkan SDK.</translation>
    </message>
    <message>
      <source>Enable Logging</source>
      <translation>Включить ведение логов</translation>
    </message>
    <message>
      <source>Enable Logging:\nEnables logging.\nDo not change this if you do not know what you&apos;re doing!\nWhen asking for help, make sure this setting is ENABLED.</source>
      <translation>Включить ведение логов:\nВключает ведение логов.\nНе меняйте это, если вы не знаете, что делаете!\nПри запросе помощи, убедитесь, что эта настройка ВКЛЮЧЕНА.</translation>
    </message>
    <message>
      <source>Present Mode</source>
      <translation>Режим представления</translation>
    </message>
    <message>
      <source>Mailbox (Vsync)</source>
      <translation>Mailbox (Vsync)</translation>
    </message>
    <message>
      <source>Fifo (Vsync)</source>
      <translation>Fifo (Vsync)</translation>
    </message>
    <message>
      <source>Immediate (No Vsync)</source>
      <translation>Immediate (без Vsync)</translation>
    </message>
    <message>
      <source>Select the DLC folder</source>
      <translation>Выберите папку DLC</translation>
    </message>
    <message>
      <source>Present Mode:\nConfigures how video output will be presented to your screen.\n\nMailbox: Frames synchronize with your screen&apos;s refresh rate. New frames will replace any pending frames. Reduces latency but may skip frames if running behind.\nFifo: Frames synchronize with your screen&apos;s refresh rate. New frames will be queued behind pending frames. Ensures all frames are presented but may increase latency.\nImmediate: Frames immediately present to your screen when ready. May result in tearing.</source>
      <translation>Режим представления:\nНастраивает, как вывод видео будет предоставлен на экране.\n\nMailbox: Кадры синхронизируются с частотой обновления экрана. Новые кадры будут заменять ожидающие кадры. Уменьшает задержку, но может пропустить кадры, если отстаёт.\nFifo: Кадры синхронизируются с частотой обновления экрана. Новые кадры будут в очереди за ожидаемыми кадрами. Обеспечивает отображение всех кадров, но может увеличить задержку.\nImmediate: Кадры отображаются на экране сразу после готовности. Может приводить к разрывам.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the DLC path.</source>
      <translation>Обзор:\nНайдите папку, которую можно указать в качестве пути для DLC.</translation>
    </message>
    <message>
      <source>FSR Settings</source>
      <translation>Настройки FSR</translation>
    </message>
    <message>
      <source>Enable FSR</source>
      <translation>Включить FSR</translation>
    </message>
    <message>
      <source>Enable RCAS (sharpening)</source>
      <translation>Включить RCAS (резкость)</translation>
    </message>
    <message>
      <source>RCAS Attenuation:</source>
      <translation>Затухание RCAS:</translation>
    </message>
    <message>
      <source>Load Presets...</source>
      <translation>Загрузить пресеты...</translation>
    </message>
    <message>
      <source>Log</source>
      <translation>Лог</translation>
    </message>
    <message>
      <source>Open Log Location:\nOpen the folder where the log file is saved.</source>
      <translation>Открыть локацию лога:\nОткрыть папку, в которой сохраняется файл логов.</translation>
    </message>
    <message>
      <source>Microphone:\nNone: Does not use the microphone.\nDefault Device: Will use the default device defined in the system.\nOr manually choose the microphone to be used from the list.</source>
      <translation>Микрофон:\nНет: Не использует микрофон.\nУстройство по умолчанию: Будет использовать устройство по умолчанию в системе.\nИли вручную выберите микрофон из списка.</translation>
    </message>
    <message>
      <source>Volume:\nAdjust volume for games on a global level, range goes from 0-500% with the default being 100%.</source>
      <translation>Громкость:\nРегулирует громкость игр на глобальном уровне, диапазон может быть 0-500% со значением по умолчанию 100%.</translation>
    </message>
    <message>
      <source>Default tab when opening settings:\nChoose which tab will open, the default is General.</source>
      <translation>Вкладка по умолчанию при открытии настроек:\nВыберите, какая вкладка будет открыта, по умолчанию выбрано "Общее".</translation>
    </message>
    <message>
      <source>Enable Motion Controls:\nWhen enabled it will use the controller&apos;s motion control if supported.</source>
      <translation>Включить управление движением:\nКогда включено, будет использоваться управление движением, если оно поддерживается.</translation>
    </message>
    <message>
      <source>Vblank Frequency</source>
      <translation>Частота Vblank</translation>
    </message>
    <message>
      <source>Vblank Frequency:\nThe frame rate at which the emulator refreshes at (60hz is the baseline, whether the game runs at 30 or 60fps). Changing this may have adverse effects, such as increasing the game speed, or breaking critical game functionality that does not expect this to change!</source>
      <translation>Частота Vblank:\nЧастота кадров, с которой обновляется эмулятор (60 Гц является базовым значением, независимо от того, работает игра в 30 или 60 fps). Изменение этого параметра может иметь негативные последствия, такие как увеличение скорости игры или нарушение критических функций игры, которые этого не ожидают!</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access</source>
      <translation>Включить прямой доступ к памяти</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode</source>
      <translation>Включить режим консоли Devkit</translation>
    </message>
    <message>
      <source>Set &quot;PSN signed-in&quot; to True</source>
      <translation>Установить &quot;Авторизован в PSN&quot; на True</translation>
    </message>
    <message>
      <source>Set &quot;Network Connected&quot; to True</source>
      <translation>Установить &quot;Сеть подключена&quot; на True</translation>
    </message>
    <message>
      <source>Miscellaneous</source>
      <translation>Прочее</translation>
    </message>
    <message>
      <source>Frontend</source>
      <translation>Интерфейс</translation>
    </message>
    <message>
      <source>Experimental</source>
      <translation>Экспериментальное</translation>
    </message>
    <message>
      <source>Show Splash Screen When Launching Game</source>
      <translation>Показывать заставку при запуске игры</translation>
    </message>
    <message>
      <source>General Frontend Settings</source>
      <translation>Общие настройки интерфейса</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode</source>
      <translation>Включить режим PS4 Neo</translation>
    </message>
    <message>
      <source>Enable Direct Memory Access:\nEnables arbitrary memory access from the GPU to CPU memory.</source>
      <translation>Включить прямой доступ к памяти:\nВключает произвольный доступ к памяти из графического процессора в память центрального процессора.</translation>
    </message>
    <message>
      <source>Enable PS4 Neo Mode:\nAdds support for PS4 Pro emulation and memory size. Currently causes instability in a large number of tested games.</source>
      <translation>Включить режим PS4 Neo:\nДобавляет поддержку эмуляции PS4 Pro и размера памяти. В настоящее время вызывает нестабильность во многих протестированных играх.</translation>
    </message>
    <message>
      <source>Enable Devkit Console Mode:\nAdds support for Devkit console memory size.</source>
      <translation>Включить режим консоли Devkit:\nДобавляет поддержку размера памяти консоли Devkit.</translation>
    </message>
    <message>
      <source>Set Network Connected to True:\nForces games to detect an active network connection. Actual online capabilities are not yet supported.</source>
      <translation>Установить "Подключение к сети" на True:\nЗаставляет игры определять активное сетевое подключение. Фактические онлайн-возможности пока не поддерживаются.</translation>
    </message>
    <message>
      <source>Set PSN Signed-in to True:\nForces games to detect an active PSN sign-in. Actual PSN capabilities are not supported.</source>
      <translation>Установить "Авторизован в PSN" на True:\nЗаставляет игры определять активный вход в PSN. Фактические возможности PSN не поддерживаются.</translation>
    </message>
    <message>
      <source>Enable Vulkan Validation Layers:\nEnables a system that validates the state of the Vulkan renderer and logs information about its internal state.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Включить слои валидации Vulkan:\nВключает систему, которая проверяет состояние рендера Vulkan и логирует информацию о его внутреннем состоянии.\nЭто снизит производительность и, вероятно, изменит поведение эмуляции.\nДля этого вам нужен Vulkan SDK.</translation>
    </message>
    <message>
      <source>Audio Device (general)</source>
      <translation>Устройство аудио (основное)</translation>
    </message>
    <message>
      <source>Audio Device (DS4 speaker)</source>
      <translation>Устройство аудио (динамик DS4)</translation>
    </message>
    <message>
      <source>Enable Shaders Dumping:\nFor the sake of technical debugging, saves the game&apos;s shaders to a folder as they render.</source>
      <translation>Включить дамп шейдеров:\nДля технической отладки сохраняет шейдеры игр в папку во время рендеринга.</translation>
    </message>
    <message>
      <source>Enable Null GPU:\nFor the sake of technical debugging, disables game rendering as if there were no graphics card. The screen will be black.</source>
      <translation>Включить Null GPU:\nДля технической отладки отключает рендеринг игры так, как будто графической карты нет. Экран будет чёрным.</translation>
    </message>
    <message>
      <source>DLC Path:\nThe folder where game DLC is loaded from.</source>
      <translation>Путь к DLC:\nПапка, из которой загружаются DLC для игры.</translation>
    </message>
    <message>
      <source>Additional DMem Allocation</source>
      <translation>Дополнительное распределение DMem</translation>
    </message>
    <message>
      <source>Additional DMem Allocation:\nForces allocation of the specified amount of additional DMem. Crashes or causes issues in some games.</source>
      <translation>Дополнительное распределение DMem\nЗаставляет выделить определённое количество DMem. Вызывает вылеты или проблемы в некоторых играх.</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path:\nThe folder where PS4 sysmodules are loaded from.</source>
      <translation>Папка системных модулей PS4:\nПапка, из которой загружаются системные модули PS4.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the sysmodules path.</source>
      <translation>Обзор:\nНайдите папку, которую можно указать в качестве пути для системных модулей.</translation>
    </message>
    <message>
      <source>Vulkan Validation (Requires Vulkan SDK)</source>
      <translation>Проверка Vulkan (требуется Vulkan SDK)</translation>
    </message>
    <message>
      <source>Validation Layers</source>
      <translation>Уровни проверки</translation>
    </message>
    <message>
      <source>Enable Core Validation</source>
      <translation>Включить основную проверку</translation>
    </message>
    <message>
      <source>Enable Sync Validation</source>
      <translation>Включить проверку синхронизации</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation</source>
      <translation>Включить проверку с помощью GPU</translation>
    </message>
    <message>
      <source>Enable Sync Validation:\nEnables a system that validates the timing of Vulkan rendering tasks.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Включить проверку синхронизации:\nВключает систему, которая проверяет время выполнения задач рендеринга Vulkan.\nЭто снизит производительность и, вероятно, изменит поведение эмуляции.\nДля работы этого вам потребуется Vulkan SDK.</translation>
    </message>
    <message>
      <source>Enable Core Validation:\nEnables the main API validation functions.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Включить основную проверку:\nВключает основные функции проверки API.\nЭто снизит производительность и, вероятно, изменит поведение эмуляции.\nДля работы этого вам понадобится Vulkan SDK.</translation>
    </message>
    <message>
      <source>Enable GPU-Assisted Validation:\nInstruments shaders with code that validates if they are behaving correctly.\nThis will reduce performance and likely change the behavior of emulation.\nYou need the Vulkan SDK for this to work.</source>
      <translation>Включить проверку с помощью GPU:\nСнабжает шейдеры кодом, который проверяет, правильно ли они себя ведут.\nЭто снизит производительность и, вероятно, изменит поведение эмуляции.\nДля работы этого вам понадобится Vulkan SDK.</translation>
    </message>
    <message>
      <source>GUI Language</source>
      <translation>Язык интерфейса</translation>
    </message>
    <message>
      <source>GUI Updates</source>
      <translation>Обновления интерфейса</translation>
    </message>
    <message>
      <source>DLC Path</source>
      <translation>Путь DLC</translation>
    </message>
    <message>
      <source>PS4 Sysmodules Path</source>
      <translation>Путь системных модулей PS4</translation>
    </message>
    <message>
      <source>GUI Updates:\nRelease: Official versions released every month that may be very outdated, but are more reliable and tested.\nNightly: Development versions that have all the latest features and fixes, but may contain bugs and are less stable.\n\n*This update applies only to the Qt user interface. To update the emulator core, please use the &apos;Version Manager&apos; menu.</source>
      <translation>Обновления интерфейса:\nРелиз: Официальные версии, выпускаемые ежемесячно, которые могут быть очень устаревшими, но они более надежны и протестированы.\nNightly: Версии в разработке, имеющие все последние функции и исправления, но могут содержать ошибки и менее стабильные.\n\n*Это обновление применяется только к интерфейсу пользователя Qt. Чтобы обновить ядро эмулятора, используйте меню &apos;Менеджер версий&apos;.</translation>
    </message>
    <message>
      <source>Cannot create portable launcher folder</source>
      <translation>Невозможно создать портативную папку запуска</translation>
    </message>
    <message>
      <source>Portable launcherDir folder created</source>
      <translation>Портативная папка лаунчера создана</translation>
    </message>
    <message>
      <source>USB Device</source>
      <translation>USB-устройство</translation>
    </message>
    <message>
      <source>Real USB Device</source>
      <translation>Настоящее USB-устройство</translation>
    </message>
    <message>
      <source>Skylander Portal</source>
      <translation>Skylander Portal</translation>
    </message>
    <message>
      <source>Infinity Base</source>
      <translation>Infinity Base</translation>
    </message>
    <message>
      <source>Dimensions Toypad</source>
      <translation>Dimensions Toypad</translation>
    </message>
    <message>
      <source>USB Device:\nReal USB Device: Use a real USB Device attached to the system.\nSkylander Portal: Emulate a Skylander Portal of Power.\nInfinity Base: Emulate a Disney Infinity Base.\nDimensions Toypad: Emulate a Lego Dimensions Toypad.</source>
      <translation>Устройство USB:\nНастоящее USB-устройство: Использует настоящее USB-устройство, подключённое к системе.\nSkylander Portal: Эмулирует Skylander Portal of Power.\nInfinity Base: Эмулирует Disney Infinity Base.\nDimensions Toypad: Эмулирует Lego Dimensions Toypad.</translation>
    </message>
    <message>
      <source>Enable Shader Cache</source>
      <translation>Включить кэш шейдеров</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file</source>
      <translation>Сжать файлы кэша шейдеров в zip-файл</translation>
    </message>
    <message>
      <source>Enable Shader Cache:\nStoring compiled shaders to avoid recompilations, reduce stuttering.</source>
      <translation>Включить кэш шейдеров:\nХранить скомпилированные шейдеры, чтобы избежать перекомпиляции, уменьшить заглушение.</translation>
    </message>
    <message>
      <source>Compress the Shader Cache files into a zip file:\nThe shader cache files are stored within a single zip file instead of multiple separate files.</source>
      <translation>Сжать файлы кэша шейдеров в zip-файл:\nФайлы кэша шейдеров хранятся в одном zip-файле вместо нескольких отдельных файлов.</translation>
    </message>
    <message>
      <source>Readbacks Mode</source>
      <translation>Режим обратного чтения</translation>
    </message>
    <message>
      <source>Disabled</source>
      <translation>Выключено</translation>
    </message>
    <message>
      <source>Readbacks:\nEnable GPU memory readbacks and writebacks.\nThis is required for proper behavior in some games.\nMight cause stability and/or performance issues.</source>
      <translation>Обратное чтение:\nВключить обратное чтение и запись в память GPU.\nЭто требуется для правильного поведения в некоторых играх. \nМожет вызвать проблемы со стабильностью/производительностью.</translation>
    </message>
    <message>
      <source>Relaxed</source>
      <translation>Расслабленный</translation>
    </message>
    <message>
      <source>Precise</source>
      <translation>Точный</translation>
    </message>
    <message>
      <source>Select shadPS4 Home Path</source>
      <translation>Выберите путь к домашней папке shadPS4</translation>
    </message>
    <message>
      <source>Select the system modules folder</source>
      <translation>Выберите папку системных модулей</translation>
    </message>
    <message>
      <source>Home Folder Location (Saves, Inputs, Trophy Data)</source>
      <translation>Местоположение домашней папки (сохранения, входы, трофеи)</translation>
    </message>
    <message>
      <source>Home Folder Location:\nThe folder where save data, trophy files, and input configs are stored for all users.</source>
      <translation>Путь к домашней папке:\nПапка, в которой хранятся данные сохранений, файлы трофеев и конфигурации вводов для всех пользователей.</translation>
    </message>
    <message>
      <source>Browse:\nBrowse for a folder to set as the home folder.</source>
      <translation>Просмотр:\nВыберите папку, которую хотите установить в качестве домашней папки.</translation>
    </message>
    <message>
      <source>Audio</source>
      <translation>Аудио</translation>
    </message>
    <message>
      <source>Audio Backend</source>
      <translation>Бэкенд аудио</translation>
    </message>
    <message>
      <source>Mic Device</source>
      <translation>Устройство микрофона</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Устройства</translation>
    </message>
    <message>
      <source>Camera</source>
      <translation>Камера</translation>
    </message>
    <message>
      <source>Log Sync</source>
      <translation>Синхронизация логов</translation>
    </message>
    <message>
      <source>Log Skip Duplicate</source>
      <translation>Пропуск дубликатов логов</translation>
    </message>
    <message>
      <source>Log Max Skip Duration</source>
      <translation>Максимальная длительность пропуска логов</translation>
    </message>
    <message>
      <source> ms</source>
      <translation>мс</translation>
    </message>
    <message>
      <source>Log Size Limit</source>
      <translation>Лимит размера лога</translation>
    </message>
    <message>
      <source> B</source>
      <translation> Б</translation>
    </message>
    <message>
      <source>Log Append</source>
      <translation>Добавление к логам</translation>
    </message>
    <message>
      <source>wincolor</source>
      <translation>wincolor</translation>
    </message>
    <message>
      <source>msvc</source>
      <translation>msvc</translation>
    </message>
    <message>
      <source>Log Append:\nAppend to existing logs.</source>
      <translation>Добавление к логам:\nДобавление к существующим логам.</translation>
    </message>
    <message>
      <source>Log Max Skip Duration:\nInterval without writing same lines (ms) - only if &apos;Log Skip Duplicate&apos; enabled.</source>
      <translation>Максимальная длительность пропуска логов:\nИнтервал без записи одинаковых строк (мс) - только если включено &apos;Пропуск дубликатов логов&apos;.</translation>
    </message>
    <message>
      <source>Log Size Limit:\nMaximum size of log files (bytes).</source>
      <translation>Лимит размера лога:\nМаксимальный размер файлов лога (в байтах).</translation>
    </message>
    <message>
      <source>Log Skip Duplicate:\nSave storage by avoiding writing log that is identical.</source>
      <translation>Пропуск дубликатов логов:\nЭкономит место в хранилище, избегая записи идентичных логов.</translation>
    </message>
    <message>
      <source>Log Sync:\nSwitch between sync (order) or async (performance).</source>
      <translation>Синхронизация логов:\nПереключение между синхронизацией (порядок) или асинхронностью (производительность).</translation>
    </message>
    <message>
      <source>Log Type:\nChoose between wincolor or msvc log types.\nwincolor: Default logging for Windows\nmsvc: Logging for debugging</source>
      <translation>Тип логов:\nВыберите между типами логов wincolor или msvc.\nwincolor: Стандартное логирование для Windows\nmsvc: Логирование для отладки</translation>
    </message>
    <message>
      <source>Log Filter:\nFilters the log to only print specific information.\nExamples: &quot;Core:Debug&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nLevels: trace, debug, info, warning, error, critical, off - in this order, a specific level silences all levels preceding it in the list and logs every level after it.</source>
      <translation>Фильтр логов:\nФильтрует логи, чтобы показывать только определенную информацию.\nПримеры: &quot;Core:Trace&quot; &quot;Lib.Pad:Debug Common.Filesystem:Error&quot; &quot;*:Critical&quot;\nУровни: trace, debug, info, warning, error, critical, off - в этом порядке, конкретный уровень глушит все предыдущие уровни в списке и показывает все последующие уровни.</translation>
    </message>
  </context>
  <context>
    <name>ShortcutDialog</name>
    <message>
      <source>Select Version</source>
      <translation>Выбор версии</translation>
    </message>
    <message>
      <source>Select version for shortcut creation</source>
      <translation>Выберите версию для создания ярлыка</translation>
    </message>
    <message>
      <source>No Version Selected</source>
      <translation>Версия не выбрана</translation>
    </message>
    <message>
      <source>Select a version first</source>
      <translation>Сначала выберите версию</translation>
    </message>
  </context>
  <context>
    <name>TrophyViewer</name>
    <message>
      <source>Trophy Viewer</source>
      <translation>Просмотр трофеев</translation>
    </message>
    <message>
      <source>Select Game:</source>
      <translation>Выберите игру:</translation>
    </message>
    <message>
      <source>Progress</source>
      <translation>Прогресс</translation>
    </message>
    <message>
      <source>Show Earned Trophies</source>
      <translation>Показать заработанные трофеи</translation>
    </message>
    <message>
      <source>Show Not Earned Trophies</source>
      <translation>Показать не заработанные трофеи</translation>
    </message>
    <message>
      <source>Show Hidden Trophies</source>
      <translation>Показать скрытые трофеи</translation>
    </message>
    <message>
      <source>Select User:</source>
      <translation>Выбрать пользователя:</translation>
    </message>
  </context>
  <context>
    <name>UserManagerDialog</name>
    <message>
      <source>User Manager</source>
      <translation>Менеджер пользователей</translation>
    </message>
    <message>
      <source>&amp;Create User</source>
      <translation>&amp;Создать пользователя</translation>
    </message>
    <message>
      <source>&amp;Delete User</source>
      <translation>&amp;Удалить пользователя</translation>
    </message>
    <message>
      <source>&amp;Rename User</source>
      <translation>&amp;Переименовать пользователя</translation>
    </message>
    <message>
      <source>&amp;Set Default User</source>
      <translation>&amp;Установить пользователя по умолчанию</translation>
    </message>
    <message>
      <source>&amp;Set Color</source>
      <translation>&amp;Установить цвет</translation>
    </message>
    <message>
      <source>&amp;Set Controller Port</source>
      <translation>&amp;Установить порт контроллера</translation>
    </message>
    <message>
      <source>&amp;Close</source>
      <translation>&amp;Закрыть</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Cannot add more users.</source>
      <translation>Невозможно добавить новых пользователей.</translation>
    </message>
    <message>
      <source>Create New User</source>
      <translation>Создать нового пользователя</translation>
    </message>
    <message>
      <source>New User ID: %1</source>
      <translation>ID нового пользователя: %1</translation>
    </message>
    <message>
      <source>Username (3–16 chars, letters, numbers, _, -)</source>
      <translation>Имя пользователя (3–16 символов, буквы, цифры, _, -)</translation>
    </message>
    <message>
      <source>Invalid Username</source>
      <translation>Неверное имя пользователя</translation>
    </message>
    <message>
      <source>Username must be 3–16 chars and valid.</source>
      <translation>Имя пользователя должно состоять из 3–16 символов и быть действительным.</translation>
    </message>
    <message>
      <source>Delete Confirmation</source>
      <translation>Подтверждение удаления</translation>
    </message>
    <message>
      <source>Delete user ID %1?</source>
      <translation>Удалить пользователя с ID %1?</translation>
    </message>
    <message>
      <source>Rename User</source>
      <translation>Переименовать пользователя</translation>
    </message>
    <message>
      <source>Old Username: %1</source>
      <translation>Старое имя пользователя: %1</translation>
    </message>
    <message>
      <source>Set User Color</source>
      <translation>Установить цвет пользователя</translation>
    </message>
    <message>
      <source>Select color:</source>
      <translation>Выберите цвет:</translation>
    </message>
    <message>
      <source>Set Controller Port</source>
      <translation>Установить порт контроллера</translation>
    </message>
    <message>
      <source>Assign port (1-4) to this user:</source>
      <translation>Назначьте этому пользователю порт (1-4):</translation>
    </message>
    <message>
      <source>&amp;Open User Directory</source>
      <translation>&amp;Открыть каталог пользователей</translation>
    </message>
  </context>
  <context>
    <name>VersionDialog</name>
    <message>
      <source>Version Manager</source>
      <translation>Менеджер версий</translation>
    </message>
    <message>
      <source>Path to save versions</source>
      <translation>Путь к сохраненным версиям</translation>
    </message>
    <message>
      <source>Browse</source>
      <translation>Обзор</translation>
    </message>
    <message>
      <source>Installed</source>
      <translation>Установлено</translation>
    </message>
    <message>
      <source>Selected</source>
      <translation>Выбрано</translation>
    </message>
    <message>
      <source>Version</source>
      <translation>Версия</translation>
    </message>
    <message>
      <source>Codename</source>
      <translation>Кодовое имя</translation>
    </message>
    <message>
      <source>Date</source>
      <translation>Дата</translation>
    </message>
    <message>
      <source>Add Custom</source>
      <translation>Добавить стороннюю</translation>
    </message>
    <message>
      <source>Delete</source>
      <translation>Удалить</translation>
    </message>
    <message>
      <source>Refresh List</source>
      <translation>Обновить список</translation>
    </message>
    <message>
      <source>Download</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <source>Check for Pre-release updates at startup</source>
      <translation>Проверять обновления предрелиза при запуске</translation>
    </message>
    <message>
      <source>Check for Pre-release Updates</source>
      <translation>Проверить обновления предрелиза</translation>
    </message>
    <message>
      <source>Select the folder where the emulator versions will be installed</source>
      <translation>Выберите папку, в которую будут установлены версии эмулятора</translation>
    </message>
    <message>
      <source>Select executable</source>
      <translation>Выберите исполняемый файл</translation>
    </message>
    <message>
      <source>Executable (*.exe)</source>
      <translation>Исполняемый файл (*.exe)</translation>
    </message>
    <message>
      <source>Version name</source>
      <translation>Название версии</translation>
    </message>
    <message>
      <source>Enter the name of this version as it appears in the list.</source>
      <translation>Введите название этой версии, как оно указано в списке.</translation>
    </message>
    <message>
      <source>Error</source>
      <translation>Ошибка</translation>
    </message>
    <message>
      <source>Success</source>
      <translation>Успешно</translation>
    </message>
    <message>
      <source>Version added successfully.</source>
      <translation>Версия успешно добавлена.</translation>
    </message>
    <message>
      <source>Failed to determine the folder path.</source>
      <translation>Не удалось определить путь к папке.</translation>
    </message>
    <message>
      <source>Delete version</source>
      <translation>Удалить версию</translation>
    </message>
    <message>
      <source>Do you want to delete the version</source>
      <translation>Вы хотите удалить версию</translation>
    </message>
    <message>
      <source>Version list update</source>
      <translation>Обновление списка версий</translation>
    </message>
    <message>
      <source>No news, the version list is already updated.</source>
      <translation>Новых нет, список версий уже обновлен.</translation>
    </message>
    <message>
      <source>The latest versions have been added to the list for download.</source>
      <translation>Последние версии добавлены в список для загрузки.</translation>
    </message>
    <message>
      <source>Error accessing GitHub API</source>
      <translation>Ошибка доступа к API GitHub</translation>
    </message>
    <message>
      <source>First you need to choose a location to save the versions in
&apos;Path to save versions&apos;</source>
      <translation>Сначала вам нужно выбрать место для сохранения версий&apos;Путь для сохранения версий&apos;</translation>
    </message>
    <message>
      <source>Do you want to download the version</source>
      <translation>Желаете скачать версию</translation>
    </message>
    <message>
      <source>No files available for this platform.</source>
      <translation>Для этой платформы файлы недоступны.</translation>
    </message>
    <message>
      <source>Downloading %1 , please wait...</source>
      <translation>Загрузка %1, пожалуйста, подождите...</translation>
    </message>
    <message>
      <source>Could not save file.</source>
      <translation>Не удалось сохранить файл.</translation>
    </message>
    <message>
      <source>Version %1 has been downloaded and selected.</source>
      <translation>Версия %1 загружена и выбрана.</translation>
    </message>
    <message>
      <source>Failed to create zip extraction script</source>
      <translation>Не удалось создать скрипт извлечения zip-архива</translation>
    </message>
    <message>
      <source>The GitHub API response is not a valid JSON array.</source>
      <translation>Ответ API GitHub не является допустимым массивом JSON.</translation>
    </message>
    <message>
      <source>Auto Updater - Emulator</source>
      <translation>Автоматическое обновление - Эмулятор</translation>
    </message>
    <message>
      <source>You already have the latest pre-release version.</source>
      <translation>У вас уже установлена ​​последняя версия предрелиза.</translation>
    </message>
    <message>
      <source>Update Available (Emulator)</source>
      <translation>Доступно обновление (Эмулятор)</translation>
    </message>
    <message>
      <source>Current Version</source>
      <translation>Текущая версия</translation>
    </message>
    <message>
      <source>Latest Version</source>
      <translation>Последняя версия</translation>
    </message>
    <message>
      <source>Do you want to update?</source>
      <translation>Желаете обновить?</translation>
    </message>
    <message>
      <source>Update</source>
      <translation>Обновить</translation>
    </message>
    <message>
      <source>No</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Show Changelog</source>
      <translation>Показать журнал изменений</translation>
    </message>
    <message>
      <source>Hide Changelog</source>
      <translation>Скрыть журнал изменений</translation>
    </message>
    <message>
      <source>Network error while fetching changelog</source>
      <translation>Ошибка сети при загрузке журнала изменений</translation>
    </message>
    <message>
      <source>Changes</source>
      <translation>Изменения</translation>
    </message>
    <message>
      <source>No download URL found for the specified asset.</source>
      <translation>URL для загрузки указанного актива не найден.</translation>
    </message>
    <message>
      <source>Network error while downloading</source>
      <translation>Ошибка сети при загрузке</translation>
    </message>
    <message>
      <source>Failed to save download file</source>
      <translation>Не удалось сохранить загружаемый файл</translation>
    </message>
    <message>
      <source>Complete installation</source>
      <translation>Установка завершена</translation>
    </message>
    <message>
      <source>Pre-release updated successfully</source>
      <translation>Версия предрелиза успешно обновлена</translation>
    </message>
    <message>
      <source>Failed to create the update script file</source>
      <translation>Не удалось создать скрипт обновления</translation>
    </message>
    <message>
      <source>Always Show Changelog</source>
      <translation>Всегда показывать журнал изменений</translation>
    </message>
    <message>
      <source>No version selected. Please choose one from the list to delete.</source>
      <translation>Не выбрана версия. Пожалуйста, выберите одну из списка для удаления.</translation>
    </message>
    <message>
      <source>Confirm Download</source>
      <translation>Подтвердить загрузку</translation>
    </message>
    <message>
      <source>Extraction failure.</source>
      <translation>Ошибка извлечения.</translation>
    </message>
    <message>
      <source>A version with that name already exists.</source>
      <translation>Версия с таким названием уже существует.</translation>
    </message>
    <message>
      <source>Local</source>
      <translation>Локальная</translation>
    </message>
    <message>
      <source>Failed to determine the folder to remove.</source>
      <translation>Не удалось определить папку для удаления.</translation>
    </message>
    <message>
      <source>Failed to delete folder.</source>
      <translation>Не удалось удалить папку.</translation>
    </message>
    <message>
      <source>Unable to get hash of latest pre-release.</source>
      <translation>Не удалось получить хеш последней версии предрелиза.</translation>
    </message>
    <message>
      <source>Downloading Pre-release (Nightly), please wait...</source>
      <translation>Загрузка версии предрелиза (Nightly), пожалуйста, подождите...</translation>
    </message>
  </context>
  <context>
    <name>dimensions_dialog</name>
    <message>
      <source>Dimensions Manager</source>
      <translation>Менеджер Dimensions</translation>
    </message>
    <message>
      <source>Active Dimensions Figures:</source>
      <translation>Активные фигурки Dimensions:</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Очистить</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <source>Move</source>
      <translation>Переместить</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Неизвестная фигурка</translation>
    </message>
    <message>
      <source>Select Dimensions File</source>
      <translation>Выбрать файл Dimensions</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Фигурка Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Не удалось открыть файл фигурки!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Не удалось открыть файл фигурки(%1)!
Файл может уже использоваться на базе.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Не удалось прочитать файл фигурки!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Не удалось прочитать файл фигурки(%1)!
Файл был слишком маленьким.</translation>
    </message>
  </context>
  <context>
    <name>figure_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Создатель фигурок</translation>
    </message>
    <message>
      <source>Filter by Series:</source>
      <translation>Фильтр по серии:</translation>
    </message>
    <message>
      <source>All</source>
      <translation>Все</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Неизвестно--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Номер фигурки:</translation>
    </message>
    <message>
      <source>Series:</source>
      <translation>Серия:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Ошибка конвертации значения</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Введенный номер фигурки неверен!</translation>
    </message>
    <message>
      <source>Series number entered is invalid!</source>
      <translation>Введённый номер серии неверен!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Создать файл фигурки</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Фигурка Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create figure file!</source>
      <translation>Не удалось создать файл фигурки!</translation>
    </message>
    <message>
      <source>Failed to create figure file:
%1</source>
      <translation>Не удалось создать файл фигурки:
%1</translation>
    </message>
  </context>
  <context>
    <name>infinity_dialog</name>
    <message>
      <source>Infinity Manager</source>
      <translation>Менеджер Infinity</translation>
    </message>
    <message>
      <source>Active Infinity Figures:</source>
      <translation>Активные фигурки Infinity:</translation>
    </message>
    <message>
      <source>Play Set/Power Disc</source>
      <translation>Игровой набор/Power Disc</translation>
    </message>
    <message>
      <source>Power Disc Two</source>
      <translation>Power Disc 2</translation>
    </message>
    <message>
      <source>Power Disc Three</source>
      <translation>Power Disc 3</translation>
    </message>
    <message>
      <source>Player One</source>
      <translation>Первый игрок</translation>
    </message>
    <message>
      <source>Player One Ability One</source>
      <translation>Способность первого игрока 1</translation>
    </message>
    <message>
      <source>Player One Ability Two</source>
      <translation>Способность первого игрока 2</translation>
    </message>
    <message>
      <source>Player Two</source>
      <translation>Второй игрок</translation>
    </message>
    <message>
      <source>Player Two Ability One</source>
      <translation>Способность второго игрока 1</translation>
    </message>
    <message>
      <source>Player Two Ability Two</source>
      <translation>Способность 2 игрока 2</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Очистить</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <source>Unknown Figure</source>
      <translation>Неизвестная фигурка</translation>
    </message>
    <message>
      <source>Select Infinity File</source>
      <translation>Выберите файл Infinity</translation>
    </message>
    <message>
      <source>Infinity Figure (*.bin);;</source>
      <translation>Фигурка Infinity (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to open the figure file!</source>
      <translation>Не удалось открыть файл фигурки!</translation>
    </message>
    <message>
      <source>Failed to open the figure file(%1)!
File may already be in use on the base.</source>
      <translation>Не удалось открыть файл фигурки(%1)!
Файл может уже использоваться на базе.</translation>
    </message>
    <message>
      <source>Failed to read the figure file!</source>
      <translation>Не удалось прочитать файл фигурки!</translation>
    </message>
    <message>
      <source>Failed to read the figure file(%1)!
File was too small.</source>
      <translation>Не удалось прочитать файл фигурки(%1)!
Файл был слишком маленьким.</translation>
    </message>
  </context>
  <context>
    <name>minifig_creator_dialog</name>
    <message>
      <source>Figure Creator</source>
      <translation>Создатель фигурок</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Неизвестно--</translation>
    </message>
    <message>
      <source>Figure Number:</source>
      <translation>Номер фигурки:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Ошибка конвертации значения</translation>
    </message>
    <message>
      <source>Figure number entered is invalid!</source>
      <translation>Введённый номер фигурки неверен!</translation>
    </message>
    <message>
      <source>Create Figure File</source>
      <translation>Создать файл фигурки</translation>
    </message>
    <message>
      <source>Dimensions Figure (*.bin);;</source>
      <translation>Фигурка Dimensions (*.bin);;</translation>
    </message>
    <message>
      <source>Failed to create minifig file!</source>
      <translation>Не удалось создать файл минифигурки!</translation>
    </message>
    <message>
      <source>Failed to create minifig file:
%1</source>
      <translation>Не удалось создать файл минифигурки:
%1</translation>
    </message>
  </context>
  <context>
    <name>minifig_move_dialog</name>
    <message>
      <source>Figure Mover</source>
      <translation>Перемещение фигурки</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
    <message>
      <source>Move Here</source>
      <translation>Перейти сюда</translation>
    </message>
    <message>
      <source>Pick up and Place</source>
      <translation>Поднять и поставить</translation>
    </message>
  </context>
  <context>
    <name>skylander_creator_dialog</name>
    <message>
      <source>Skylander Creator</source>
      <translation>Skylander Creator</translation>
    </message>
    <message>
      <source>--Unknown--</source>
      <translation>--Неизвестно--</translation>
    </message>
    <message>
      <source>ID:</source>
      <translation>ID:</translation>
    </message>
    <message>
      <source>Variant:</source>
      <translation>Вариант:</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Cancel</source>
      <translation>Отмена</translation>
    </message>
    <message>
      <source>Error converting value</source>
      <translation>Ошибка конвертации значения</translation>
    </message>
    <message>
      <source>ID entered is invalid!</source>
      <translation>Введённый идентификатор неверен!</translation>
    </message>
    <message>
      <source>Variant entered is invalid!</source>
      <translation>Введённый вариант неверен!</translation>
    </message>
    <message>
      <source>Create Skylander File</source>
      <translation>Создать файл Skylander</translation>
    </message>
    <message>
      <source>Skylander Object (*.sky);;All Files (*)</source>
      <translation>Объект Skylander (*.sky);;Все файлы (*)</translation>
    </message>
    <message>
      <source>Failed to create skylander file!</source>
      <translation>Не удалось создать файл skylander!</translation>
    </message>
    <message>
      <source>Failed to create skylander file:
%1</source>
      <translation>Не удалось создать файл skylander:
%1</translation>
    </message>
  </context>
  <context>
    <name>skylander_dialog</name>
    <message>
      <source>Skylanders Manager</source>
      <translation>Менеджер Skylanders</translation>
    </message>
    <message>
      <source>Active Portal Skylanders:</source>
      <translation>Активные Portal Skylanders:</translation>
    </message>
    <message>
      <source>Skylander %1</source>
      <translation>Skylander %1</translation>
    </message>
    <message>
      <source>Clear</source>
      <translation>Очистить</translation>
    </message>
    <message>
      <source>Create</source>
      <translation>Создать</translation>
    </message>
    <message>
      <source>Load</source>
      <translation>Загрузить</translation>
    </message>
    <message>
      <source>Select Skylander File</source>
      <translation>Выберите файл Skylander</translation>
    </message>
    <message>
      <source>Skylander (*.sky *.bin *.dmp *.dump);;All Files (*)</source>
      <translation>Skylander (*.sky *.bin *.dmp *.dump);;Все файлы (*)</translation>
    </message>
    <message>
      <source>Failed to open the skylander file!</source>
      <translation>Не удалось открыть файл skylander!</translation>
    </message>
    <message>
      <source>Failed to open the skylander file(%1)!
File may already be in use on the portal.</source>
      <translation>Не удалось открыть файл skylander(%1)!
Файл уже используется на портале.</translation>
    </message>
    <message>
      <source>Failed to read the skylander file!</source>
      <translation>Не удалось прочитать файл skylander!</translation>
    </message>
    <message>
      <source>Failed to read the skylander file(%1)!
File was too small.</source>
      <translation>Не удалось прочитать файл skylander(%1)!
Файл был слишком маленьким.</translation>
    </message>
    <message>
      <source>Unknown (Id:%1 Var:%2)</source>
      <translation>Неизвестный (Id:%1 Var:%2)</translation>
    </message>
    <message>
      <source>None</source>
      <translation>Нет</translation>
    </message>
  </context>
</TS>
