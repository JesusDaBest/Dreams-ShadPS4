Dreams on shadPS4 - November 2, 2026 texture-write update

Extract the entire ZIP, open shadPS4QtLauncher.exe, add your own Dreams game
folder and click Play. The patched core and matching settings apply automatically.
No command prompt or separate setup script is needed.

This update makes definite CPU writes refresh single-mip textures without
comparing an older CPU snapshot. Multi-mip and shared-page checks remain.
Shader preloading and all other latest fixes are retained.

Press F10 to show or hide both FPS counters, in windowed or fullscreen mode.
Your choice is saved. You can also right-click the counter and choose Hide FPS.
The Dreams window title no longer displays missing build metadata.

The package uses your normal shadPS4 profile. It contains no games, firmware,
saves or creations. Keep the extracted folder together. Existing portable
profiles are not moved automatically.

If a tutorial blocks progress, close Dreams and open
tutorial-skip/Skip Dreams Tutorial.exe. Select your own CUSA04301/SYSTEM/
savedata.json. The helper makes a backup before changing progression flags.

Some rendering glitches and Tren slowdowns remain; no overall speedup is
claimed. Source changes and checksums accompany this update.
