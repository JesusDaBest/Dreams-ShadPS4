Dreams on shadPS4 - October 27, 2026 texture update

Extract the entire ZIP, open shadPS4QtLauncher.exe, add your own Dreams game
folder and click Play. The patched core and matching settings apply automatically.
No command prompt or separate setup script is needed.

This update retains the earlier fixes and adds checks for invalid mip chains,
reversed texture-array ranges and mismatched 3D texture depth during cache reuse.

The package uses your normal shadPS4 profile. It contains no games, firmware,
saves or creations. Keep the extracted folder together. Existing portable
profiles are not moved automatically.

If a tutorial blocks progress, close Dreams and open
tutorial-skip/Skip Dreams Tutorial.exe. Select your own CUSA04301/SYSTEM/
savedata.json. The helper makes a backup before changing progression flags.

Some rendering glitches and Tren slowdowns remain; no overall speedup is
claimed. Source changes and checksums accompany this update.
