"""Prepare separate Dreams runtime copies; never alter the installed profile."""
import hashlib
import json
import pathlib
import shutil
import datetime

base = pathlib.Path(__file__).resolve().parent / 'runtime-comparison-20260904'
profile = pathlib.Path(r'C:\Users\Jdura\AppData\Roaming\shadPS4')
core = pathlib.Path(r'C:\Users\Jdura\AppData\Roaming\shadPS4QtLauncher\versions\Dreams Fix\shadPS4.exe')
game = pathlib.Path(r'D:\Emulators\ShadPS4\Games\CUSA04301\CUSA04301\eboot.bin')
assert hashlib.sha256(core.read_bytes()).hexdigest() == '183d9914a395d8ad804428b418e13474d71172a6146386dd9e7d159f26ae14cc'
base.mkdir(exist_ok=True)
seed = base / 'profile-seed'
if seed.exists():
    raise RuntimeError('Seed already exists; inspect it instead of overwriting')
files = []
for name in ['config.json', 'users.json', 'keys.json', 'imgui.ini']:
    if (profile / name).is_file(): files.append(profile / name)
for name in ['home', 'input_config', 'custom_configs', 'custom_modules', 'game_data']:
    for path in (profile / name).rglob('*'):
        if path.is_file(): files.append(path)
total = sum(p.stat().st_size for p in files)
if total > 512 * 1024 * 1024: raise RuntimeError(f'Unexpectedly large seed: {total}')
manifest = []
for path in files:
    relative = path.relative_to(profile)
    dest = seed / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert hashlib.sha256(dest.read_bytes()).hexdigest() == digest
    manifest.append({'relative_path': str(relative), 'size': path.stat().st_size, 'sha256': digest})

for name, mode in [('relaxed', 1), ('precise', 2)]:
    runtime = base / name
    user = runtime / 'user'
    shutil.copytree(seed, user)
    shutil.copy2(core, runtime / 'shadPS4.exe')
    config = json.loads((user / 'config.json').read_text())
    # Firmware/font files are read from the existing installation; saves and all
    # writable runtime/cache paths are isolated in this new portable profile.
    config['General']['sys_modules_dir'] = str(profile / 'sys_modules')
    config['General']['font_dir'] = str(profile / 'fonts')
    config['General']['home_dir'] = ''
    config['GPU']['readbacks_mode'] = mode
    (user / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    custom_path = user / 'custom_configs/CUSA04301.json'
    custom = json.loads(custom_path.read_text())
    custom['GPU']['readbacks_mode'] = mode
    custom_path.write_text(json.dumps(custom, indent=2) + '\n')
    # Neither cache nor shader dumps are copied; both original configurations have
    # pipeline caching disabled, and no original cache files are changed.
    (runtime / 'runtime.json').write_text(json.dumps({
        'mode': mode, 'core': str(runtime / 'shadPS4.exe'), 'game': str(game),
        'cwd': str(runtime), 'portable_user': str(user), 'seed': str(seed),
        'seed_sha256': hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest(),
        'settings_changes_from_current': ['readbacks_mode' if mode == 2 else 'none',
                                          'firmware/font paths for portable isolation'],
    }, indent=2))
(base / 'seed-manifest.json').write_text(json.dumps({
    'created': datetime.datetime.now().astimezone().isoformat(),
    'original_profile': str(profile), 'files': manifest, 'bytes': total,
}, indent=2))
print(json.dumps({'base': str(base), 'seed_files': len(manifest), 'seed_bytes': total}))
