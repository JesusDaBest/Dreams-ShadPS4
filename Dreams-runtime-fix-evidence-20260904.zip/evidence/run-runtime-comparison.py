"""Bounded launch/watchdog for one prepared portable comparison runtime."""
import datetime
import json
import os
import pathlib
import subprocess
import sys
import time

base = pathlib.Path(__file__).resolve().parent / 'runtime-comparison-20260904'
name = sys.argv[1]
if name not in ['relaxed', 'precise']: raise RuntimeError('Expected relaxed or precise')
runtime = base / name
metadata = json.loads((runtime / 'runtime.json').read_text())
existing = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    'Get-CimInstance Win32_Process -Filter "Name = \'shadPS4.exe\'" | Select-Object -ExpandProperty ProcessId'],
    text=True).strip()
if existing: raise RuntimeError('A shadPS4 process is already running; do not overlap tests')
environment = {k: v for k, v in os.environ.items() if not k.upper().startswith('SHADPS4_')}
# Profiling mode1 does the same eager readback already used by mode1, with one
# aggregate timing line per second. Never enable it for mode2: it would force
# the readback back on and invalidate the A/B comparison.
if name == 'relaxed': environment['SHADPS4_DREAMS_CCA80_READBACK_PROFILE'] = '1'
begin = time.monotonic()
with (runtime / 'stdout.log').open('w') as stdout, (runtime / 'stderr.log').open('w') as stderr:
    process = subprocess.Popen([metadata['core'], '--game', metadata['game']],
        cwd=runtime, env=environment, stdout=stdout, stderr=stderr,
        creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
    record = dict(metadata, pid=process.pid,
        started=datetime.datetime.now().astimezone().isoformat(),
        environment={k: v for k, v in environment.items() if k.startswith('SHADPS4_')},
        deadline_seconds=240)
    (runtime / 'launch.json').write_text(json.dumps(record, indent=2))
    print(json.dumps({'pid': process.pid, 'runtime': str(runtime)}), flush=True)
    while process.poll() is None:
        if (runtime / 'stop.request').exists():
            record['stop_reason'] = 'comparison stop requested'
            process.terminate()
            break
        if time.monotonic() - begin > 240:
            record['stop_reason'] = 'four minute runtime bound'
            process.terminate()
            break
        time.sleep(2)
    process.wait(timeout=10)
    record['exit_code'] = process.returncode
    record['wall_seconds'] = time.monotonic() - begin
    (runtime / 'completion.json').write_text(json.dumps(record, indent=2))
    print(json.dumps({'exit_code': process.returncode, 'seconds': record['wall_seconds']}), flush=True)
