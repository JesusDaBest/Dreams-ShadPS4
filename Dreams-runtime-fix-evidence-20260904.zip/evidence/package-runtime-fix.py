"""Preserve the configuration correction and evidence without copying user saves into reports."""
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import statistics
import zipfile

workspace = pathlib.Path(__file__).resolve().parent.parent
work = workspace / 'work/runtime-comparison-20260904'
outputs = workspace / 'outputs'
repo = pathlib.Path(r'D:\Emulators\ShadPS4\Dreams Github\Dreams ShadPS4')
profile = pathlib.Path(r'C:\Users\Jdura\AppData\Roaming\shadPS4')
applied_path = outputs / 'Dreams-precise-readbacks-applied-20260904.json'
applied = json.loads(applied_path.read_text())
assert json.loads((profile / 'custom_configs/CUSA04301.json').read_text())['GPU']['readbacks_mode'] == 2
evidence = outputs / 'Dreams-runtime-fix-evidence-20260904'
evidence.mkdir(exist_ok=True)
normal_log = (profile / 'log/shad_log.txt').read_text(errors='replace')
assert 'cca80 eager readback skipped; precise=true explicit_disable=false finish_only=false' in normal_log
(evidence / 'normal-shad_log.txt').write_text(normal_log)
launcher_log = (profile / 'log/shadps4.log').read_text(errors='replace')
last_launch = launcher_log.rfind('[Debug] <Info> () main.cpp:154 main: Run:')
(evidence / 'normal-launcher-tail.log').write_text(launcher_log[last_launch:])
assert 'readbacks_mode ( 2 -> 1 )' not in launcher_log[last_launch:]

relaxed_log = (work / 'relaxed/user/log/shad_log.txt').read_text(errors='replace')
totals = [float(x) for x in re.findall(r'Dreams cca80 readback perf 1s .*?total_wall_ms=([0-9.]+)', relaxed_log)]
metrics = {'reports': len(totals), 'median_reported_wait_ms': statistics.median(totals),
           'min_reported_wait_ms': min(totals), 'max_reported_wait_ms': max(totals),
           'limit': 'Aggregate readback wait per reporting interval; not a matched-scene FPS benchmark or precise percentage of frame time.'}
for name in ['relaxed', 'precise']:
    for file in ['launch.json', 'completion.json', 'runtime.json']:
        shutil.copy2(work / name / file, evidence / (name + '-' + file))
    shutil.copy2(work / name / 'user/log/shad_log.txt', evidence / (name + '-shad_log.txt'))
backup = pathlib.Path(applied['backup']).parent
for name in ['CUSA04301.before.json', 'CUSA04301.after.json', 'applied.json']:
    shutil.copy2(backup / name, evidence / name)
for name in ['prepare-runtime-comparison.py', 'run-runtime-comparison.py',
             'apply-dreams-precise-readbacks.py', 'package-runtime-fix.py']:
    shutil.copy2(workspace / 'work' / name, evidence / name)
isolated_image = work / 'precise/user/screenshots/CUSA04301_20260904_180639_469_hud_000000.png'
normal_image = profile / 'screenshots/CUSA04301_20260904_181126_414_hud_000000.png'
shutil.copy2(isolated_image, outputs / 'Dreams-precise-isolated-20260904.png')
shutil.copy2(normal_image, outputs / 'Dreams-normal-launcher-restored-20260904.png')
applied['normal_launcher_verification'] = {
    'pid_at_check': 40064,
    'observed': 'Normal launcher session displayed tan patterned cube and 30 FPS; startup logged precise=true with eager readback skipped.',
    'left_running_for_user': True,
    'isolated_user_feedback': 'Yes: entered Edit Mode, smooth without sculpt jitter.',
    'normal_session_jitter_limit': 'Normal-session still images confirm rendering/FPS, not an independent measurement of jitter.',
    'isolated_screenshot': str(outputs / 'Dreams-precise-isolated-20260904.png'),
    'normal_screenshot': str(outputs / 'Dreams-normal-launcher-restored-20260904.png'),
}
applied['relaxed_readback_profile'] = metrics
applied_path.write_text(json.dumps(applied, indent=2) + '\n')
shutil.copy2(applied_path, evidence / applied_path.name)

report = f'''# Dreams patterned-cube behavior: configuration fix — September 4, 2026

**The Dreams-specific readback override was set to Relaxed (1), overriding the global Precise (2) setting. Changing it to Precise produced the tan patterned cube at30FPS in the isolated comparison, and the user confirmed smooth movement without sculpt jitter. The same setting is now applied to the normal launcher profile.**

The normal launcher subsequently started the preserved August29 executable, reached Homespace, and displayed the tan patterned cube with a30FPS overlay. Its startup log confirms `precise=true` and that the eager readback path was skipped. The normal session was left running for the user.

## Exact change

File: `C:\\Users\\Jdura\\AppData\\Roaming\\shadPS4\\custom_configs\\CUSA04301.json`

`GPU.readbacks_mode`: **1 → 2** (Relaxed → Precise).

This was the only setting changed in the normal profile. Immediate presentation, pipeline-cache disabled, shader-dump disabled and the saved executable were retained. Existing saves were not replaced. The original per-game JSON was copied and verified before the atomic replacement; backup: `{applied['backup']}`.

The executable remains SHA256 `183D9914A395D8AD804428B418E13474D71172A6146386DD9E7D159F26AE14CC`. No new emulator binary or GPU workaround was introduced by this correction.

## Test and observations

Two separate portable profiles were cloned from the current profile:179 files,11,905,223 bytes, copied and hash-verified. Their effective game setting differed only in readback mode. Firmware/font paths were redirected to the existing installation equally in both; writable saves, caches and logs remained separate. Both used the same183D executable, Immediate presentation and disk caching disabled.

The Relaxed run enabled only the existing narrow CCA80 readback timer. In Relaxed mode this instruments the readback the build already performs. The Precise run had no diagnostic environment flags: enabling that timer there would force the readback back on and spoil the comparison. Each isolated run had a four-minute limit and ended through that watchdog; recorded exit code1 is the deliberate watchdog termination, not evidence of a game crash.

In Relaxed mode, the live Homespace view was black apart from the imp, with low initial FPS; the pause menu later reached30FPS and showed ghosted/duplicated imp imagery. Readback profiling produced{metrics['reports']} reports with a median aggregate wait of{metrics['median_reported_wait_ms']:.3f}ms per reported interval. These values measure that path's wait overhead; they are not a controlled end-to-end performance benchmark.

The user navigated the Precise-mode clone into Edit Mode. The assistant observed the tan patterned cube/floor and30FPS, and the user answered **Yes** when asked whether it felt smooth without sculpt jitter. The setting was then applied to the normal profile, and the actual launcher startup and normal-session image were verified.

The two runs were not a scripted camera-identical benchmark, and a still image cannot prove absence of jitter. The user's movement feedback establishes the isolated-run experience. The normal-session image and logs establish that the corrected configuration is being used and the desired cube appearance/FPS returned. This is an observed configuration correction for this checkpoint, not proof that every Dreams scene or GPU instruction is correct.

## Why this setting matters in this build

The archived source has a Dreams-specific result-transfer path for shader`0xcca80e03`. With Relaxed readbacks it explicitly downloads GPU-written results, potentially fencing the Vulkan command stream. Precise mode uses the emulator's GPU-write tracking and skips that eager download. This is a concrete execution difference, and the current-setting run measured its overhead. The test does not separately establish the entire memory/timing chain that previously caused black/jittery surfaces.

Earlier checks correctly identified the saved executable but did not restore the successful behavior. A previous failed profile that already used Precise mode was not sufficient evidence to rule out a readback-setting correction in the current profile. The new isolated test and normal-launcher verification supersede the earlier unresolved-restoration reports for the observed cube result.

## Historical reference recovered

The original portable runtime still exists at `D:\\Downloads\\Dreams-shadPS4-Fix\\isolated-sphere-test-20260819`. It contains the older **test** creation, saved August29 at10:34:10PDT, whose cover visibly shows the patterned cube. Its current-profile replacement contains different scene data and a black cover, despite reusing the internal creation/version IDs.

The original cache contains a B1`_doc1.spv` written at10:32:16, just before the successful10:33 screenshot, and configuration backups show Precise readbacks/Mailbox/cache enabled. Some files changed later, so this is a close historical reference, not an exact frozen runtime snapshot. **Those old saves/cache files were not installed to obtain the successful current-profile result.** They are being preserved separately for future GPU work.

## Evidence

- `Dreams-precise-isolated-20260904.png`: user-confirmed isolated result.
- `Dreams-normal-launcher-restored-20260904.png`: actual normal-launcher result.
- `Dreams-precise-readbacks-applied-20260904.json`: exact change, backup and verification record.
- `Dreams-runtime-fix-evidence-20260904.zip`: bounded logs, configurations, scripts and manifests; no user save data or game executable.
'''
report_path = outputs / 'Dreams-runtime-setting-fix-20260904.md'
report_path.write_text(report, encoding='utf-8')
manifest = [{'file': p.name, 'size': p.stat().st_size,
             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(evidence.iterdir()) if p.is_file() and p.name != 'manifest.json']
(evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2))
zip_path = outputs / 'Dreams-runtime-fix-evidence-20260904.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(report_path, report_path.name)
    for p in evidence.iterdir():
        if p.is_file(): archive.write(p, 'evidence/' + p.name)
    for name in ['Dreams-precise-isolated-20260904.png', 'Dreams-normal-launcher-restored-20260904.png']:
        archive.write(outputs / name, name)
for path in [report_path, applied_path, zip_path]: shutil.copy2(path, repo / path.name)

state_path = workspace / 'work/ORDERED_COUNT_STATE.md'
state = state_path.read_text(encoding='utf-8')
heading = '## September4 runtime correction: user-confirmed smooth patterned cube\n'
if heading not in state:
    update = f'''{heading}
This supersedes previous statements that the good cube behavior remains unreproduced. New isolated current-profile A/B: readbacks1(Relaxed) showed blackHomespace andreadbackwaitoverhead; readbacks2(Precise), otherwise sameprofile/exe/Immediate/cachefalse, showed tanpatternedcube/floor30FPS. UsernavigatedintoEditMode andexplicitlyansweredYes tosmooth/no sculptjitter. RootappliedonlyGPU.readbacks_mode1→2 in normalRoaming custom_configs/CUSA04301.json afterverifiedbackup. NormalQtlauncher thenstartedcorePID40064, source183Dunchanged, currentlogprecise=true+eagerreadbackskipped, normalcapture shows tanpatternedcube30FPS. Normalgame+launcherleft runningforuser; do notkillasdiagnostic. Checkfreshprocessstate. Originalsavesnotreplaced; currentusercanplay/save normally afterlaunch.

Evidence: outputs/Dreams-runtime-setting-fix-20260904.md, Dreams-precise-readbacks-applied-20260904.json, runtime-fix-evidenceZIP andtwoPNGs. Configbackup{applied['backup']}. Keepnormalprofilemode2; prior historicalmode2failedprofile didnotruleoutthisfixincurrentprofile. NoGPUimplementationchanged; nofullDreamscorrectnessclaim. Isolatedruns241seconds eachendedbyexplicitfour-minutewatchdog, notcrash. BaselinehadCCA80PROFILE=1 only, Precisehadnone (profilerenablesextraeagerreadbackevenunderPrecise, so neveruseitfornormalmode2perf).

Recovered originalportableuser at D:/Downloads/Dreams-shadPS4-Fix/isolated-sphere-test-20260819: oldtestQuicksaveAug29 10:34:10 withpatternedcubecover; referencedthreeblobsallpresent. OldcacheB1doc1timestamp10:32:16; closehistoricalreferencebutlaterwrites. Oldcache/profile notneededforcurrentfix/notinstalled. Recoverypreservedseparatelywork/recovered-good-runtime-20260904; inspectmanifestwhencomplete. Currentmotionblur1 vsold0 remainsfutureoptionalquestion, notchangedandnotneededforthisuserconfirmedresult.

'''
    state = state.replace('## User clarification:', update + '## User clarification:', 1)
    state_path.write_text(state, encoding='utf-8')
restored_path = outputs / 'Dreams-best-build-restored-20260904.json'
restored = json.loads(restored_path.read_text())
restored['later_configuration_fix'] = {
    'readbacks_mode': 2, 'user_confirmed_smooth_patterned_cube_in_isolated_test': True,
    'normal_launcher_patterned_cube_30fps_observed': True,
    'report': str(report_path),
    'note': 'Earlier user_report and previous_good_rendering_reproduced fields describe the initial restoration before this fix.'}
restored_path.write_text(json.dumps(restored, indent=2) + '\n')
print(json.dumps({'report': str(report_path), 'evidence_zip': str(zip_path), 'readback_profile': metrics}, indent=2))
