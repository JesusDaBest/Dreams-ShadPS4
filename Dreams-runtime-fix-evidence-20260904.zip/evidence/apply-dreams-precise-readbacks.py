"""Apply the single per-game setting validated in the isolated comparison."""
import datetime
import hashlib
import json
import os
import pathlib
import shutil

workspace = pathlib.Path(__file__).resolve().parent.parent
config = pathlib.Path(r'C:\Users\Jdura\AppData\Roaming\shadPS4\custom_configs\CUSA04301.json')
raw = config.read_bytes()
before = json.loads(raw)
if before['GPU']['readbacks_mode'] != 1:
    raise RuntimeError('Current setting changed; recheck before applying')
stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
backup = workspace / 'work/runtime-comparison-20260904' / ('applied-' + stamp)
backup.mkdir()
shutil.copy2(config, backup / 'CUSA04301.before.json')
assert (backup / 'CUSA04301.before.json').read_bytes() == raw
after = json.loads(raw)
after['GPU']['readbacks_mode'] = 2
check = json.loads(json.dumps(after))
check['GPU']['readbacks_mode'] = 1
assert check == before
if config.read_bytes() != raw:
    raise RuntimeError('Config changed during backup')
staging = config.with_name('CUSA04301.precise-staged.json')
staging.write_text(json.dumps(after, indent=2) + '\n')
os.replace(staging, config)
assert json.loads(config.read_text()) == after
shutil.copy2(config, backup / 'CUSA04301.after.json')
record = {
    'applied_at': datetime.datetime.now().astimezone().isoformat(),
    'config': str(config), 'backup': str(backup / 'CUSA04301.before.json'),
    'only_setting_changed': 'GPU.readbacks_mode', 'before': 1, 'after': 2,
    'before_sha256': hashlib.sha256(raw).hexdigest(),
    'after_sha256': hashlib.sha256(config.read_bytes()).hexdigest(),
    'user_confirmation': 'User answered Yes to navigating isolated Precise-mode test into Edit Mode and smooth behavior without sculpt jitter.',
    'isolated_visual_observation': 'Tan patterned cube and floor visible; FPS overlay 30.',
    'saves_changed_by_setting_application': False,
    'executable_replaced': False,
}
(workspace / 'outputs/Dreams-precise-readbacks-applied-20260904.json').write_text(json.dumps(record, indent=2) + '\n')
(backup / 'applied.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
