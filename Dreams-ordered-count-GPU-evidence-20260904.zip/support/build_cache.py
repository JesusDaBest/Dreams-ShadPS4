import hashlib
import json
import os
import pathlib
import subprocess
import tempfile
import threading
import time


def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def write_if_changed(path, data):
    path = pathlib.Path(path)
    data = data.encode('utf-8') if isinstance(data, str) else data
    if path.is_file() and path.read_bytes() == data:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
        temporary = pathlib.Path(stream.name)
        stream.write(data)
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)
    return True


def read_json(path):
    try:
        return json.loads(pathlib.Path(path).read_text())
    except (OSError, ValueError):
        return {}


def parse_dependencies(path, cwd):
    data = pathlib.Path(path).read_text(encoding='utf-8')
    if not data.startswith('deps:'):
        raise ValueError('Expected the compiler dependency target deps:')
    data = data[5:]
    words, word = [], []
    index = 0
    while index < len(data):
        char = data[index]
        if char == '\\' and index + 1 < len(data):
            following = data[index + 1]
            if following == '\n':
                index += 2
                continue
            if following == '\r' and data[index + 2:index + 3] == '\n':
                index += 3
                continue
            if following in ' \t#':
                word.append(following)
                index += 2
                continue
        if char == '$' and data[index + 1:index + 2] == '$':
            word.append('$')
            index += 2
            continue
        if char.isspace():
            if word:
                words.append(''.join(word))
                word = []
        else:
            word.append(char)
        index += 1
    if word:
        words.append(''.join(word))
    result = set()
    for word in words:
        dependency = pathlib.Path(word)
        if not dependency.is_absolute():
            dependency = pathlib.Path(cwd) / dependency
        result.add(str(dependency.resolve()))
    if not result:
        raise ValueError('Compiler dependency output is empty')
    return sorted(result)


class FileHashes:
    def __init__(self):
        self.values = {}
        self.lock = threading.Lock()

    def __call__(self, path):
        path = pathlib.Path(path).resolve()
        stat = path.stat()
        stamp = (stat.st_mtime_ns, stat.st_ctime_ns, stat.st_size)
        with self.lock:
            cached = self.values.get(str(path))
            if cached is not None and cached[0] == stamp:
                return cached[1]
        value = digest(path)
        if path.stat().st_mtime_ns != stat.st_mtime_ns:
            raise RuntimeError('Input changed while hashing: ' + str(path))
        with self.lock:
            self.values[str(path)] = (stamp, value)
        return value


class DependencyCache:
    format_version = 1

    def __init__(self, path, cwd, creationflags=0):
        self.path = pathlib.Path(path)
        self.cwd = pathlib.Path(cwd).resolve()
        self.creationflags = creationflags
        self.entries = read_json(path)
        self.hash_file = FileHashes()

    def command_signature(self, command):
        command = [str(arg) for arg in command]
        if any(arg.startswith('@') for arg in command[1:]):
            raise ValueError('Expand compiler response files before using DependencyCache')
        environment = {name: os.environ.get(name) for name in
                       ['INCLUDE', 'CL', '_CL_', 'CPATH', 'CPLUS_INCLUDE_PATH', 'C_INCLUDE_PATH']}
        return hashlib.sha256(json.dumps({
            'format': self.format_version, 'command': command, 'cwd': str(self.cwd),
            'compiler_sha256': self.hash_file(command[0]), 'environment': environment,
        }, sort_keys=True).encode()).hexdigest()

    def current(self, key, command, source, object_path):
        entry = self.entries.get(key)
        if not isinstance(entry, dict) or entry.get('format') != self.format_version:
            return False
        entry = read_json(entry.get('record', ''))
        try:
            dependencies = entry['dependencies']
            if not dependencies or str(pathlib.Path(source).resolve()) not in dependencies:
                return False
            return (entry['command_signature'] == self.command_signature(command) and
                    entry['object_sha256'] == self.hash_file(object_path) and
                    all(self.hash_file(path) == value for path, value in dependencies.items()))
        except (OSError, KeyError, TypeError):
            return False

    def invalidate(self, keys):
        for key in keys:
            self.entries.pop(key, None)
        self.save()

    def save(self):
        write_if_changed(self.path, json.dumps(self.entries, indent=2, sort_keys=True))

    def store(self, key, entry):
        records = self.path.with_suffix('.records')
        record = records / (hashlib.sha256(key.encode()).hexdigest() + '.json')
        write_if_changed(record, json.dumps(entry, indent=2, sort_keys=True))
        self.entries[key] = {'format': self.format_version, 'record': str(record)}
        self.save()

    def compile(self, command, source, object_path, depfile, log):
        command = [str(arg) for arg in command]
        depfile = pathlib.Path(depfile).resolve()
        depfile.parent.mkdir(parents=True, exist_ok=True)
        depfile.unlink(missing_ok=True)
        command_signature = self.command_signature(command)
        tracked_command = [*command, '/clang:-MD', '/clang:-MF', '/clang:' + str(depfile),
                           '/clang:-MT', '/clang:deps']
        started_ns = time.time_ns()
        with pathlib.Path(log).open('w', encoding='utf-8') as stream:
            result = subprocess.run(tracked_command, cwd=self.cwd, stdout=stream,
                                    stderr=subprocess.STDOUT, creationflags=self.creationflags)
        if result.returncode:
            raise RuntimeError(f'Compilation failed ({result.returncode}); log={log}')
        paths = parse_dependencies(depfile, self.cwd)
        source = str(pathlib.Path(source).resolve())
        if source not in paths:
            raise RuntimeError('Compiler dependency output omits the source: ' + source)
        dependencies = {}
        for path in paths:
            if pathlib.Path(path).stat().st_mtime_ns > started_ns:
                raise RuntimeError('Input changed during compilation; retry: ' + path)
            dependencies[path] = self.hash_file(path)
        return {'format': self.format_version, 'command_signature': command_signature,
                'dependencies': dependencies, 'object_sha256': self.hash_file(object_path),
                'depfile': str(depfile), 'dependency_command': tracked_command}


class GenerationCache:
    def __init__(self, path):
        self.path = pathlib.Path(path)
        self.entries = read_json(path)
        self.hash_file = FileHashes()

    def run(self, key, command, inputs, outputs, generate):
        inputs = {str(pathlib.Path(path).resolve()): self.hash_file(path) for path in inputs}
        signature = hashlib.sha256(json.dumps({'command': [str(arg) for arg in command],
                                               'inputs': inputs}, sort_keys=True).encode()).hexdigest()
        entry = self.entries.get(key, {})
        outputs = [pathlib.Path(path) for path in outputs]
        if (entry.get('signature') == signature and
                all(path.is_file() and entry.get('outputs', {}).get(str(path)) == digest(path)
                    for path in outputs)):
            return False
        self.entries.pop(key, None)
        write_if_changed(self.path, json.dumps(self.entries, indent=2, sort_keys=True))
        with tempfile.TemporaryDirectory(dir=self.path.parent, prefix='generation-') as temporary:
            staged = [pathlib.Path(temporary) / path.name for path in outputs]
            if len(set(staged)) != len(staged):
                raise ValueError('Generated output basenames must be distinct')
            for path in staged:
                path.parent.mkdir(parents=True, exist_ok=True)
            generate(staged)
            for target, staged_path in zip(outputs, staged, strict=True):
                write_if_changed(target, staged_path.read_bytes())
        self.entries[key] = {'signature': signature,
                             'outputs': {str(path): digest(path) for path in outputs}}
        write_if_changed(self.path, json.dumps(self.entries, indent=2, sort_keys=True))
        return True
