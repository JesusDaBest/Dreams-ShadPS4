@echo off
setlocal
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b %errorlevel%
"C:\Users\Jdura\AppData\Local\Programs\Python\Python312\python.exe" "%~dp0build.py" %*
exit /b %errorlevel%
