#include "fixture_shader.hpp"

#include <cstdio>

#include "shader_recompiler/backend/spirv/emit_spirv.h"
#include "shader_recompiler/dreams_compat.h"
#include "shader_recompiler/info.h"
#include "shader_recompiler/ir/basic_block.h"
#include "shader_recompiler/ir/ir_emitter.h"
#include "shader_recompiler/ir/passes/ir_passes.h"
#include "shader_recompiler/ir/post_order.h"
#include "shader_recompiler/ir/program.h"
#include "shader_recompiler/profile.h"
#include "shader_recompiler/recompiler.h"

namespace ordered_fixture {

std::vector<std::uint32_t> BuildOrderedFixtureSpirv() {
    using namespace Shader;
    const auto mark = [](const char* stage) {
        std::fprintf(stderr, "ordered fixture emitter: %s\n", stage);
        std::fflush(stderr);
    };
    mark("metadata");

    static_assert(kCounterIndex == DreamsCompat::B1SeedWriterOrderedCounterIndex);
    static_assert(kScratchBaseDword == DreamsCompat::B1SeedWriterOrderedScratchBaseDword);
    static_assert(kEntryDwords == DreamsCompat::OrderedEntryDwords);
    static_assert(kLanesPerGroup == DreamsCompat::B1SeedWriterOrderedLanesPerWorkgroup);
    static_assert(kPhaseSpecId == DreamsCompat::OrderedPhaseSpecId);
    static_assert(kCollectPhase == DreamsCompat::OrderedPhaseCollect);
    static_assert(kReplayPhase == DreamsCompat::OrderedPhaseReplay);
    static_assert(DreamsCompat::B1SeedWriterOrderedControl == 0x0004000c);

    Info info{};
    info.stage = Stage::Compute;
    info.l_stage = LogicalStage::Compute;
    // Selecting this hash deliberately exercises the existing production B1
    // lowering. No original game code or source is represented by the fixture.
    info.pgm_hash = DreamsCompat::B1SeedWriterShader;
    for (u32 binding = 0; binding < 5; ++binding) {
        const u32 dwords = binding == 0 ? kGroupCount
                          : binding == 4 ? kScratchBaseDword + kGroupCount * kEntryDwords
                                         : kInvocationCount;
        info.buffers.push_back({
            .sharp_idx = 0,
            .used_types = IR::Type::U32,
            // Null() has zero records and is false in GetSharp(), which would
            // read absent flattened guest user data. A nonempty inline descriptor
            // keeps this synthetic backend input independent of guest memory.
            .inline_cbuf = AmdGpu::Buffer::Placeholder(dwords * sizeof(u32)),
            .buffer_type = binding == 4 ? BufferType::GdsBuffer : BufferType::Guest,
            .is_written = binding != 0,
        });
    }

    Profile profile{};
    profile.supported_spirv = 0x00010600;
    profile.subgroup_size = kLanesPerGroup;
    // All buffer addresses below are already dword indexes. The runner binds
    // every buffer at offset zero, so production byte-offset push data is unused.
    profile.needs_buffer_offsets = false;

    RuntimeInfo runtime_info{};
    runtime_info.Initialize(Stage::Compute);
    runtime_info.cs_info.workgroup_size = {kLanesPerGroup, 1, 1};

    Pools pools{};
    IR::Program program{info};
    IR::Block* block = pools.block_pool.Create(pools.inst_pool);
    program.blocks.push_back(block);
    program.syntax_list.emplace_back();
    program.syntax_list.back().type = IR::AbstractSyntaxNode::Type::Block;
    program.syntax_list.back().data.block = block;
    program.syntax_list.emplace_back();
    program.syntax_list.back().type = IR::AbstractSyntaxNode::Type::Return;
    program.post_order_blocks = IR::PostOrder(program.syntax_list.front());

    IR::IREmitter ir{*block};
    mark("IR construction");
    ir.Prologue();
    const IR::U32 group = ir.GetAttributeU32(IR::Attribute::WorkgroupIndex);
    const IR::U32 lane = ir.GetAttributeU32(IR::Attribute::LocalInvocationId, 0);
    const IR::U32 invocation =
        ir.IAdd(ir.IMul(group, ir.Imm32(kLanesPerGroup)), lane);
    const IR::U32 count{ir.LoadBufferU32(1, ir.Imm32(0), group, {})};

    IR::U32 proof = ir.BitwiseXor(
        count, ir.IMul(ir.IAdd(group, ir.Imm32(1)), ir.Imm32(0x9e3779b9U)));
    for (u32 round = 0; round < kProofRounds; ++round) {
        proof = ir.IAdd(
            ir.IMul(ir.BitwiseXor(proof, ir.ShiftRightLogical(proof, ir.Imm32(13))),
                    ir.Imm32(1664525U)),
            ir.Imm32(1013904223U + round));
    }

    const IR::U32 token = ir.ShiftLeftLogical(group, ir.Imm32(6));
    const IR::U32 reservation = ir.DataOrderedCount(
        ir.Imm32(kCounterIndex), count, token, DreamsCompat::B1SeedWriterOrderedControl);

    ir.StoreBufferU32(1, ir.Imm32(1), invocation, reservation, {});
    (void)ir.BufferAtomicIAdd(ir.Imm32(2), invocation, ir.Imm32(1), {});
    ir.StoreBufferU32(1, ir.Imm32(3), invocation, ir.BitwiseXor(proof, lane), {});

    // Resource tracking is intentionally skipped: descriptors, DOC handle and
    // dword addresses above are already in the production backend's input form.
    mark("optimization");
    Optimization::IdentityRemovalPass(program.blocks);
    Optimization::ConstantPropagationPass(program.blocks);
    Optimization::DeadCodeEliminationPass(program);
    mark("shader info collection");
    Optimization::CollectShaderInfoPass(program, profile);
    // These subgroup operations are emitted internally by DataOrderedCount,
    // rather than being visible as ordinary IR instructions in this fixture.
    info.uses_lane_id = true;
    info.uses_group_ballot = true;

    Backend::Bindings bindings{};
    mark("production SPIR-V emission");
    auto spirv = Backend::SPIRV::EmitSPIRV(profile, runtime_info, program, bindings);
    mark("emission complete");
    return spirv;
}

} // namespace ordered_fixture
