#pragma once

#include <cstdint>
#include <vector>

namespace ordered_fixture {

inline constexpr std::uint32_t kGroupCount = 24;
inline constexpr std::uint32_t kLanesPerGroup = 64;
inline constexpr std::uint32_t kInvocationCount = kGroupCount * kLanesPerGroup;
inline constexpr std::uint32_t kCounterSeed = 17;
inline constexpr std::uint32_t kCounterIndex = 0x79;
inline constexpr std::uint32_t kScratchBaseDword = 16384;
inline constexpr std::uint32_t kEntryDwords = 4;
inline constexpr std::uint32_t kPhaseSpecId = 0;
inline constexpr std::uint32_t kCollectPhase = 1;
inline constexpr std::uint32_t kReplayPhase = 2;
inline constexpr std::uint32_t kProofRounds = 64;

// All arithmetic is unsigned modulo 2^32. The shader computes this bounded,
// input-dependent chain before DOC in its IR and writes the result after DOC.
// It is a replay-input check, not a guarantee of different GPU arrival times:
// a driver may schedule independent arithmetic around DOC.
constexpr std::uint32_t ExpectedProof(std::uint32_t group, std::uint32_t lane,
                                      std::uint32_t count) {
    std::uint32_t value = count ^ ((group + 1U) * 0x9e3779b9U);
    for (std::uint32_t round = 0; round < kProofRounds; ++round) {
        value = (value ^ (value >> 13U)) * 1664525U + 1013904223U + round;
    }
    return value ^ lane;
}

// Synthetic post-resource-tracking IR using the unmodified production B1
// collector/replay lowering. This is not an extracted Dreams shader and does
// not test the guest decoder, GDS address conversion or PS4 token generation.
//
// Descriptor set 0, storage buffers of uint32_t, dword addressing:
//   binding 0: one count per workgroup [24], read only;
//   binding 1: reservation returned to every invocation [24 * 64];
//   binding 2: atomic hit counts per invocation [24 * 64], initialize to zero;
//   binding 3: ExpectedProof(group, lane, count[group]) [24 * 64];
//   binding 4: GDS, including counter 0x79 and scratch [16384, 16384 + 24 * 4).
// No shader push-constant inputs are used. The pipeline layout may retain the
// production PushData range. Require an actual subgroup size of 64.
//
// Dispatch collect (SpecId 0 = 1), run the production prefix pass, then dispatch
// replay (SpecId 0 = 2), always 24 x 1 x 1 groups with local size 64 x 1 x 1.
// Each scratch entry contains count, assigned prefix, stipulated token group<<6,
// and one untouched dword. Collect must not change bindings 1, 2 or 3.
// After replay every hit count must be 1. The expected reservation for every
// lane of group g is 17 + sum(count[h], h < g), modulo 2^32.
std::vector<std::uint32_t> BuildOrderedFixtureSpirv();

} // namespace ordered_fixture
