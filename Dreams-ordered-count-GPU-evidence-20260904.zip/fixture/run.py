"""Run the bounded production-shader fixture after offline SPIR-V validation."""
import hashlib
import json
import pathlib
import subprocess
import sys
import time

root = pathlib.Path(__file__).resolve().parent
exe = root / 'ordered-count-fixture.exe'
validator = pathlib.Path(r'C:\VulkanSDK\1.4.350.0\Bin\spirv-val.exe')
started = time.monotonic()
record = {'steps': [], 'scope': 'Synthetic production B1 GPU fixture, not a Dreams gameplay test'}

def run(name, arguments, timeout=30):
    log = root / (name + '.log')
    begin = time.monotonic()
    with log.open('w', encoding='utf-8') as out:
        try:
            result = subprocess.run([str(a) for a in arguments], cwd=root, stdout=out,
                                    stderr=subprocess.STDOUT, timeout=timeout,
                                    creationflags=subprocess.BELOW_NORMAL_PRIORITY_CLASS)
            code = result.returncode
        except subprocess.TimeoutExpired:
            code = 124
    record['steps'].append({'name': name, 'arguments': [str(a) for a in arguments],
                            'exit_code': code, 'seconds': time.monotonic() - begin,
                            'log': str(log)})
    print(log.read_text(encoding='utf-8', errors='replace')[-16000:], flush=True)
    if code:
        raise RuntimeError(f'{name} failed with exit code {code}')

try:
    run('emit', [exe, '--emit-only'])
    for file in ['fixture.spv', 'prefix.spv']:
        run('validate-' + file, [validator, '--target-env', 'vulkan1.3', root / file])
    # GPU execution cannot start until both modules pass the independent validator.
    run('gpu-run', [exe, root / 'prefix.spv'])
    record['passed'] = True
except Exception as error:
    record['passed'] = False
    record['error'] = str(error)
    print(str(error), flush=True)
finally:
    record['seconds'] = time.monotonic() - started
    record['sha256'] = {}
    for name in ['ordered-count-fixture.exe', 'fixture.spv', 'prefix.spv', 'fixture_shader.cpp',
                 'fixture_shader.hpp', 'gpu_driver.cpp', 'gpu_driver.hpp', 'main.cpp',
                 'build.py', 'run.py', 'build-provenance.json', 'results.json']:
        path = root / name
        if path.exists():
            record['sha256'][name] = hashlib.sha256(path.read_bytes()).hexdigest()
    (root / 'run-provenance.json').write_text(json.dumps(record, indent=2) + '\n')
sys.exit(0 if record['passed'] else 1)
