#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <vector>

namespace ordered_fixture {
using Buffers = std::array<std::vector<std::uint32_t>, 5>;
struct GpuResult {
    // GPU readbacks after collect, prefix, and replay, respectively.
    std::array<Buffers, 3> stages;
};
class GpuDriver {
public:
    GpuDriver(std::span<const std::uint32_t> guest, std::span<const std::uint32_t> prefix);
    ~GpuDriver();
    GpuDriver(const GpuDriver&) = delete;
    GpuDriver& operator=(const GpuDriver&) = delete;
    GpuResult Run(const Buffers& initial, bool omit_prefix = false);
    std::string DeviceDescription() const;
    std::uint32_t ValidationErrors() const;
    std::uint32_t ValidationWarnings() const;
private:
    struct State;
    std::unique_ptr<State> state;
};
}
