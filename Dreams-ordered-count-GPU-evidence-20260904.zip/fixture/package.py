"""Preserve the successful bounded test and update the investigation checkpoint."""
import hashlib
import json
import pathlib
import shutil
import zipfile

work = pathlib.Path(__file__).resolve().parent
workspace = work.parent.parent
outputs = workspace / 'outputs'
repo = pathlib.Path(r'D:\Emulators\ShadPS4\Dreams Github\Dreams ShadPS4')
source = pathlib.Path(r'D:\CodexData\Worktrees\Dreams-ShadPS4\3c77544')
results = json.loads((work / 'results.json').read_text())
run = json.loads((work / 'run-provenance.json').read_text())
assert results['passed'] and run['passed']
assert len(results['cases']) == 6 and all(c['passed'] for c in results['cases'])
assert results['validation_errors'] == 0 and results['negative_control']['detected']
core = pathlib.Path(r'C:\Users\Jdura\AppData\Roaming\shadPS4QtLauncher\versions\Dreams Fix\shadPS4.exe')
core_hash = hashlib.sha256(core.read_bytes()).hexdigest().upper()
assert core_hash == '183D9914A395D8AD804428B418E13474D71172A6146386DD9E7D159F26AE14CC'

report = f'''# Dreams: production ordered-count GPU test — September 4, 2026

The existing B1 collect → prefix → replay implementation passed a small GPU test on this PC. This is new execution evidence for an existing implementation, not a new game fix. Dreams' black/jittery sculpts and severe lag remain unresolved.

## What ran

The standalone fixture uses the current research tree's **actual production SPIR-V lowering** for B1 (`EmitDataOrderedCount`, hash selector `4ebeffd2`) and the **unaltered production `dreams_ordered_prefix.comp`** shader. Synthetic post-resource-tracking IR supplies known inputs; no game shader is claimed to have been executed.

- AMD Radeon 8060S; subgroup size 64 explicitly required and capability checked.
- 24 workgroups × 64 invocations, GDS counter dword `0x79` initially 17, scratch base 16384 and stride 4.
- Collect and replay use production specialization ID 0, values 1 and 2.
- Six patterns: all zero, one per wave, 64 per wave, varied zero-to-64 counts, their reversal, and sparse contributions at the beginning/middle/end.
- Full buffer comparisons after each phase cover every reservation returned to every lane, the final counter, stored counts/tokens, unchanged inputs, untouched memory and exactly-once per-invocation output writes.

## Results

All six cases passed **381,456 dword comparisons** without a mismatch. The final counters were 17, 41, 1553, 601, 601 and 89 respectively.

Omitting the prefix pass deliberately caused **1,586 mismatches**, which the same checker detected. Both modules passed the SDK's independent SPIR-V validator before GPU execution.

Vulkan validation reported **0 errors and 3 warnings**. The warnings concern duplicate OBS hook registration and two Overwolf layers advertising Vulkan 1.2 while the fixture requests 1.3; they are retained in the evidence log.

The seven-case GPU fixture, including device/pipeline setup and readbacks, took **{results['gpu_fixture_wall_seconds']:.3f} seconds wall time**. This is not a GPU timestamp measurement or a Dreams performance claim. The first dependency build compiled 79 small production/stub/Sirit units in 55.2 seconds with three low-priority workers; subsequent builds reuse objects only after checking compiler dependencies and hashes.

An initial harness-only crash was corrected before the successful run: empty inline descriptors tried to read an absent synthetic user-data buffer. Nonempty fixture descriptors resolved it. Production emulator code was not changed for this test.

## What this establishes, and what remains

The tested production lowering and prefix shader agree with the fixture's **stipulated workgroup-index order** on this GPU. This is a useful, fast test platform for further implementation work.

It does not establish PS4 wave-creation/token order or result-lane semantics. The production prefix shader walks workgroup indices and does not use stored tokens to determine order. Full active waves and synthetic tokens were supplied here.

It also does not yet test the first failing `cbac06d2` shader's two ordered-count operations, the guest decoder/resource tracking, original shader eligibility, or reservation-dependent compacted output addressing and alias safety. Output hit counters cover fixture invocations, not actual Dreams output records.

The standalone harness dispatches the real prefix GLSL directly. It does not invoke the production host helper. Separate submissions and fence waits between phases provide stronger synchronization than the live renderer, so this does not validate production barriers or scratch reuse across game dispatches. Bounded input-dependent arithmetic checks repeated input computation; it does not force or measure different wave arrival orders.

## Recommended next step

Keep pursuing genuine fixes using this fast test platform. Extend it to two independent reservations and compare the real `cbac06d2` shader's dependencies and side effects before adapting the execution path. Only then use a bounded Dreams launch to test whether that specific change advances the game. Treat later rendering defects as separate failures to isolate, rather than assuming ordered count explains them all.

Physical PS4 measurements would still strengthen the ordering and lane-behavior evidence, but these bounded implementation tests can proceed now.

## Reproduce and preserve

Original harness directory: `{work}`.

Run `build.cmd`, then `C:\\Users\\Jdura\\AppData\\Local\\Programs\\Python\\Python312\\python.exe run.py` from that directory. The builder uses the existing research checkout and local compiler/Vulkan SDK paths. The ZIP includes the harness, shader modules, executable, logs and build/run provenance; it is an evidence bundle, not a complete standalone source distribution of shadPS4. Each GPU fence has a five-second limit; the runner also bounds its subprocesses.

No emulator was launched or installed for this fixture. The selected restored August 29 core remains SHA256 `{core_hash}`. No settings or saves were changed.

Fixture executable SHA256: `{run['sha256']['ordered-count-fixture.exe']}`.
Production-lowered SPIR-V SHA256: `{run['sha256']['fixture.spv']}`.
Production prefix SPIR-V SHA256: `{run['sha256']['prefix.spv']}`.
'''
report_path = outputs / 'Dreams-ordered-count-GPU-test-20260904.md'
report_path.write_text(report, encoding='utf-8')
json_path = outputs / 'Dreams-ordered-count-GPU-test-20260904.json'
shutil.copy2(work / 'results.json', json_path)
names = ['fixture_shader.hpp', 'fixture_shader.cpp', 'gpu_driver.hpp', 'gpu_driver.cpp',
         'main.cpp', 'build.py', 'build.cmd', 'run.py', 'package.py', 'prefix.spv', 'fixture.spv',
         'ordered-count-fixture.exe', 'results.json', 'build-provenance.json', 'run-provenance.json',
         'emit.log', 'validate-fixture.spv.log', 'validate-prefix.spv.log', 'gpu-run.log']
zip_path = outputs / 'Dreams-ordered-count-GPU-evidence-20260904.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(report_path, report_path.name)
    for name in names:
        archive.write(work / name, 'fixture/' + name)
    archive.write(work.parent / 'upstream-core-build/build_cache.py', 'support/build_cache.py')
    for relative in ['src/shader_recompiler/backend/spirv/emit_spirv_atomic.cpp',
                     'src/shader_recompiler/backend/spirv/spirv_emit_context.cpp',
                     'src/shader_recompiler/dreams_compat.h',
                     'src/video_core/host_shaders/dreams_ordered_prefix.comp']:
        archive.write(source / relative, 'production-reference/' + relative)
for path in [report_path, json_path, zip_path]:
    shutil.copy2(path, repo / path.name)

state_path = work.parent / 'ORDERED_COUNT_STATE.md'
state = state_path.read_text(encoding='utf-8')
marker = '## Production B1 GPU fixture completed — later September 4\n'
if marker not in state:
    paragraph = f'''{marker}
The planned actual production B1 collect/prefix/replay fixture has now run successfully. See outputs/Dreams-ordered-count-GPU-test-20260904.md/.json and evidence ZIP (also mirrored to research repo). Work files are in work/ordered-count-gpu. Six24x64 cases with GDSseed17 passed381456 dword comparisons across all5buffers/all3phases; omitted-prefix negative control detected1586mismatches. Exact production B1 SPIR-V lowering and unaltered production prefix GLSL were used. Independent SPIR-V validation passed; Vulkan0errors/3OBS-Overwolf layer warnings. Test run walltime{results['gpu_fixture_wall_seconds']:.3f}s. No game launched, install/settings/saves unchanged; activecore still183D9914... . Initial synthetic-descriptor harness crash fixed before successful run; no production code fix made.

Scope is stipulated workgroup-index order, fullwaves, synthetic post-resource-tracking IR. This does NOT prove PS4ordering/lane semantics, cbac twoDOC behavior, guest decoding, live renderer barriers/scratchreuse, or compacted output alias safety. Separate phase submissions/fences are stronger than live synchronization. Proof arithmetic did not force/measure varied arrival order. Next extend focused test to two reservations and audit real cbac dependencies/side effects before choosing safe execution adaptation. Do not rerun broad B1 arithmetic audits as if execution remained untested.

'''
    state = state.replace('## User-requested gameplay restoration', paragraph + '## User-requested gameplay restoration', 1)
    state_path.write_text(state, encoding='utf-8')
print(json.dumps({'report': str(report_path), 'evidence': str(zip_path),
                  'zip_bytes': zip_path.stat().st_size, 'mirrored_to': str(repo)}, indent=2))
