// Small standalone Vulkan harness. Production shader lowering and prefix GLSL are
// exercised, but this harness intentionally does not instantiate the game renderer.
#include "gpu_driver.hpp"
#include <vulkan/vulkan.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <stdexcept>

namespace ordered_fixture {
namespace {
void Check(VkResult result, const char* action) {
    if (result != VK_SUCCESS) {
        throw std::runtime_error(std::string(action) + ": Vulkan result " + std::to_string(result));
    }
}
struct Buffer {
    VkDevice device{};
    VkBuffer buffer{};
    VkDeviceMemory memory{};
    void* mapped{};
    std::size_t size{};
    ~Buffer() {
        if (mapped) vkUnmapMemory(device, memory);
        if (buffer) vkDestroyBuffer(device, buffer, nullptr);
        if (memory) vkFreeMemory(device, memory, nullptr);
    }
};
struct PrefixPush {
    std::uint32_t streams[5][4]{};
    std::uint32_t stream_count = 1;
    std::uint32_t entry_stride = 4;
    std::uint32_t group_count_from_gds_mask{};
    std::uint32_t matrix_group_count{};
    std::uint32_t matrix_stream_count{};
    std::uint32_t matrix_counter_base{};
    std::uint32_t matrix_counter_row_stride{};
    std::uint32_t matrix_counter_columns{};
    std::uint32_t matrix_scratch_base{};
    std::uint32_t matrix_scratch_stream_stride{};
};
static_assert(sizeof(PrefixPush) == 120);
}

struct GpuDriver::State {
    VkInstance instance{};
    VkDebugUtilsMessengerEXT debug{};
    VkPhysicalDevice physical{};
    VkDevice device{};
    VkQueue queue{};
    std::uint32_t family{};
    VkCommandPool pool{};
    VkCommandBuffer command{};
    VkFence fence{};
    VkDescriptorPool descriptors{};
    std::array<VkDescriptorSetLayout, 2> set_layouts{};
    std::array<VkPipelineLayout, 2> layouts{};
    std::array<VkDescriptorSet, 2> sets{};
    std::array<VkPipeline, 3> pipelines{};
    std::string description;
    std::atomic<std::uint32_t> errors{}, warnings{};

    static VKAPI_ATTR VkBool32 VKAPI_CALL Debug(
        VkDebugUtilsMessageSeverityFlagBitsEXT severity, VkDebugUtilsMessageTypeFlagsEXT,
        const VkDebugUtilsMessengerCallbackDataEXT* data, void* user) {
        auto& self = *static_cast<State*>(user);
        if (severity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT) ++self.errors;
        if (severity & VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT) ++self.warnings;
        std::fprintf(stderr, "VALIDATION: %s\n", data->pMessage);
        return VK_FALSE;
    }
    ~State() {
        // Every submitted dispatch has a bounded fence wait below. A timeout exits
        // the process, avoiding an unbounded waitIdle during error cleanup.
        if (device) {
            for (auto p : pipelines) if (p) vkDestroyPipeline(device, p, nullptr);
            for (auto p : layouts) if (p) vkDestroyPipelineLayout(device, p, nullptr);
            if (descriptors) vkDestroyDescriptorPool(device, descriptors, nullptr);
            for (auto s : set_layouts) if (s) vkDestroyDescriptorSetLayout(device, s, nullptr);
            if (fence) vkDestroyFence(device, fence, nullptr);
            if (pool) vkDestroyCommandPool(device, pool, nullptr);
            vkDestroyDevice(device, nullptr);
        }
        if (debug) {
            auto destroy = reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(
                vkGetInstanceProcAddr(instance, "vkDestroyDebugUtilsMessengerEXT"));
            if (destroy) destroy(instance, debug, nullptr);
        }
        if (instance) vkDestroyInstance(instance, nullptr);
    }
    void Initialize(std::span<const std::uint32_t> guest, std::span<const std::uint32_t> prefix) {
        std::uint32_t count{};
        Check(vkEnumerateInstanceLayerProperties(&count, nullptr), "enumerate layers");
        std::vector<VkLayerProperties> layers(count);
        Check(vkEnumerateInstanceLayerProperties(&count, layers.data()), "enumerate layers");
        if (std::none_of(layers.begin(), layers.end(), [](const auto& p) {
                return std::strcmp(p.layerName, "VK_LAYER_KHRONOS_validation") == 0;
            })) throw std::runtime_error("Vulkan validation layer is required for this fixture");
        const char* layer = "VK_LAYER_KHRONOS_validation";
        const char* extension = VK_EXT_DEBUG_UTILS_EXTENSION_NAME;
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        app.pApplicationName = "Dreams production ordered-count fixture";
        app.apiVersion = VK_API_VERSION_1_3;
        VkDebugUtilsMessengerCreateInfoEXT debug_info{VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT};
        debug_info.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                                     VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
        debug_info.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                                 VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT |
                                 VK_DEBUG_UTILS_MESSAGE_TYPE_PERFORMANCE_BIT_EXT;
        debug_info.pfnUserCallback = Debug;
        debug_info.pUserData = this;
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ici.pNext = &debug_info;
        ici.pApplicationInfo = &app;
        ici.enabledLayerCount = 1;
        ici.ppEnabledLayerNames = &layer;
        ici.enabledExtensionCount = 1;
        ici.ppEnabledExtensionNames = &extension;
        Check(vkCreateInstance(&ici, nullptr, &instance), "create instance");
        auto create_debug = reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(
            vkGetInstanceProcAddr(instance, "vkCreateDebugUtilsMessengerEXT"));
        if (!create_debug) throw std::runtime_error("debug utils entry point missing");
        Check(create_debug(instance, &debug_info, nullptr, &debug), "create debug messenger");
        Check(vkEnumeratePhysicalDevices(instance, &count, nullptr), "enumerate devices");
        std::vector<VkPhysicalDevice> devices(count);
        Check(vkEnumeratePhysicalDevices(instance, &count, devices.data()), "enumerate devices");
        for (auto candidate : devices) {
            VkPhysicalDeviceSubgroupSizeControlProperties sizes{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_SIZE_CONTROL_PROPERTIES};
            VkPhysicalDeviceSubgroupProperties subgroup{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_PROPERTIES};
            subgroup.pNext = &sizes;
            VkPhysicalDeviceProperties2 props{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2};
            props.pNext = &subgroup;
            vkGetPhysicalDeviceProperties2(candidate, &props);
            const auto required_ops = VK_SUBGROUP_FEATURE_BASIC_BIT | VK_SUBGROUP_FEATURE_BALLOT_BIT;
            if (props.properties.apiVersion < VK_API_VERSION_1_3 || sizes.minSubgroupSize > 64 ||
                sizes.maxSubgroupSize < 64 || !(sizes.requiredSubgroupSizeStages & VK_SHADER_STAGE_COMPUTE_BIT) ||
                !(subgroup.supportedStages & VK_SHADER_STAGE_COMPUTE_BIT) ||
                (subgroup.supportedOperations & required_ops) != required_ops ||
                props.properties.limits.maxPushConstantsSize < 128 ||
                props.properties.limits.maxPerStageDescriptorStorageBuffers < 5) continue;
            VkPhysicalDeviceVulkan13Features v13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};
            VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
            features.pNext = &v13;
            vkGetPhysicalDeviceFeatures2(candidate, &features);
            if (!v13.subgroupSizeControl || !v13.computeFullSubgroups || !v13.synchronization2) continue;
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &count, nullptr);
            std::vector<VkQueueFamilyProperties> families(count);
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &count, families.data());
            for (std::uint32_t i = 0; i < count; ++i) {
                if (families[i].queueCount && (families[i].queueFlags & VK_QUEUE_COMPUTE_BIT)) {
                    physical = candidate;
                    family = i;
                    description = std::string(props.properties.deviceName) + "; driver=" +
                        std::to_string(props.properties.driverVersion) + "; subgroup=64 required";
                    break;
                }
            }
            if (physical) break;
        }
        if (!physical) throw std::runtime_error("No Vulkan 1.3 compute device with required subgroup64 features");
        VkPhysicalDeviceVulkan13Features v13{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_3_FEATURES};
        VkPhysicalDeviceVulkan12Features v12{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_2_FEATURES};
        VkPhysicalDeviceVulkan11Features v11{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_VULKAN_1_1_FEATURES};
        VkPhysicalDeviceFeatures2 features{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};
        features.pNext = &v11; v11.pNext = &v12; v12.pNext = &v13;
        vkGetPhysicalDeviceFeatures2(physical, &features);
        // Enable only queried-supported core features. The production backend may
        // declare 8/16/64-bit capabilities even when this fixture uses U32 values.
        float priority = 0.25f;
        VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        qci.queueFamilyIndex = family; qci.queueCount = 1; qci.pQueuePriorities = &priority;
        VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        dci.pNext = &features; dci.queueCreateInfoCount = 1; dci.pQueueCreateInfos = &qci;
        Check(vkCreateDevice(physical, &dci, nullptr, &device), "create device");
        vkGetDeviceQueue(device, family, 0, &queue);
        VkCommandPoolCreateInfo pool_info{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        pool_info.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        pool_info.queueFamilyIndex = family;
        Check(vkCreateCommandPool(device, &pool_info, nullptr, &pool), "create command pool");
        VkCommandBufferAllocateInfo alloc{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        alloc.commandPool = pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; alloc.commandBufferCount = 1;
        Check(vkAllocateCommandBuffers(device, &alloc, &command), "allocate command buffer");
        VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        Check(vkCreateFence(device, &fci, nullptr, &fence), "create fence");
        for (std::uint32_t i = 0; i < 2; ++i) {
            std::array<VkDescriptorSetLayoutBinding, 5> bindings{};
            for (std::uint32_t b = 0; b < (i == 0 ? 5u : 1u); ++b) {
                bindings[b] = {b, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1, VK_SHADER_STAGE_COMPUTE_BIT, nullptr};
            }
            VkDescriptorSetLayoutCreateInfo slci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
            slci.bindingCount = i == 0 ? 5 : 1; slci.pBindings = bindings.data();
            Check(vkCreateDescriptorSetLayout(device, &slci, nullptr, &set_layouts[i]), "create set layout");
            VkPushConstantRange push{VK_SHADER_STAGE_COMPUTE_BIT, 0, i == 0 ? 128u : 120u};
            VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
            plci.setLayoutCount = 1; plci.pSetLayouts = &set_layouts[i];
            plci.pushConstantRangeCount = 1; plci.pPushConstantRanges = &push;
            Check(vkCreatePipelineLayout(device, &plci, nullptr, &layouts[i]), "create pipeline layout");
        }
        VkDescriptorPoolSize pool_size{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 6};
        VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
        dpci.maxSets = 2; dpci.poolSizeCount = 1; dpci.pPoolSizes = &pool_size;
        Check(vkCreateDescriptorPool(device, &dpci, nullptr, &descriptors), "create descriptor pool");
        VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
        dsai.descriptorPool = descriptors; dsai.descriptorSetCount = 2; dsai.pSetLayouts = set_layouts.data();
        Check(vkAllocateDescriptorSets(device, &dsai, sets.data()), "allocate descriptor sets");
        for (std::uint32_t i = 0; i < 3; ++i) {
            const auto code = i == 1 ? prefix : guest;
            VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
            smci.codeSize = code.size_bytes(); smci.pCode = code.data();
            VkShaderModule module{};
            Check(vkCreateShaderModule(device, &smci, nullptr, &module), "create shader module");
            std::uint32_t phase = i == 0 ? 1 : 2;
            VkSpecializationMapEntry mapping{0, 0, sizeof(phase)};
            VkSpecializationInfo specialization{1, &mapping, sizeof(phase), &phase};
            VkPipelineShaderStageRequiredSubgroupSizeCreateInfo subgroup{VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_REQUIRED_SUBGROUP_SIZE_CREATE_INFO};
            subgroup.requiredSubgroupSize = 64;
            VkComputePipelineCreateInfo ci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
            ci.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
            ci.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
            ci.stage.module = module; ci.stage.pName = "main";
            ci.stage.pNext = i == 1 ? nullptr : &subgroup;
            ci.stage.flags = i == 1 ? 0 : VK_PIPELINE_SHADER_STAGE_CREATE_REQUIRE_FULL_SUBGROUPS_BIT;
            ci.stage.pSpecializationInfo = i == 1 ? nullptr : &specialization;
            ci.layout = layouts[i == 1 ? 1 : 0];
            const auto result = vkCreateComputePipelines(device, VK_NULL_HANDLE, 1, &ci, nullptr, &pipelines[i]);
            vkDestroyShaderModule(device, module, nullptr);
            Check(result, "create compute pipeline");
        }
        if (errors) throw std::runtime_error("Vulkan validation errors during initialization");
    }

    std::unique_ptr<Buffer> Allocate(std::span<const std::uint32_t> words) {
        auto result = std::make_unique<Buffer>();
        result->device = device; result->size = words.size_bytes();
        VkBufferCreateInfo ci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        ci.size = result->size; ci.usage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
        ci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        Check(vkCreateBuffer(device, &ci, nullptr, &result->buffer), "create buffer");
        VkMemoryRequirements requirements{};
        vkGetBufferMemoryRequirements(device, result->buffer, &requirements);
        VkPhysicalDeviceMemoryProperties memory{};
        vkGetPhysicalDeviceMemoryProperties(physical, &memory);
        std::uint32_t type = memory.memoryTypeCount;
        const auto flags = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        for (std::uint32_t i = 0; i < memory.memoryTypeCount; ++i) {
            if ((requirements.memoryTypeBits & (1u << i)) &&
                (memory.memoryTypes[i].propertyFlags & flags) == flags) { type = i; break; }
        }
        if (type == memory.memoryTypeCount) throw std::runtime_error("Host-coherent memory missing");
        VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        mai.allocationSize = requirements.size; mai.memoryTypeIndex = type;
        Check(vkAllocateMemory(device, &mai, nullptr, &result->memory), "allocate buffer memory");
        Check(vkBindBufferMemory(device, result->buffer, result->memory, 0), "bind buffer memory");
        Check(vkMapMemory(device, result->memory, 0, result->size, 0, &result->mapped), "map buffer memory");
        std::memcpy(result->mapped, words.data(), words.size_bytes());
        return result;
    }
    GpuResult Run(const Buffers& initial, bool omit_prefix) {
        std::array<std::unique_ptr<Buffer>, 5> buffers;
        std::array<VkDescriptorBufferInfo, 5> infos{};
        std::array<VkWriteDescriptorSet, 6> writes{};
        for (std::uint32_t b = 0; b < 5; ++b) {
            buffers[b] = Allocate(initial[b]);
            infos[b] = {buffers[b]->buffer, 0, buffers[b]->size};
            writes[b].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
            writes[b].dstSet = sets[0]; writes[b].dstBinding = b;
            writes[b].descriptorCount = 1; writes[b].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            writes[b].pBufferInfo = &infos[b];
        }
        writes[5] = writes[4]; writes[5].dstSet = sets[1]; writes[5].dstBinding = 0;
        vkUpdateDescriptorSets(device, 6, writes.data(), 0, nullptr);
        GpuResult result;
        for (std::uint32_t stage = 0; stage < 3; ++stage) {
            Check(vkResetFences(device, 1, &fence), "reset fence");
            Check(vkResetCommandBuffer(command, 0), "reset command buffer");
            VkCommandBufferBeginInfo begin{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            Check(vkBeginCommandBuffer(command, &begin), "begin command buffer");
            VkMemoryBarrier2 before{VK_STRUCTURE_TYPE_MEMORY_BARRIER_2};
            before.srcStageMask = VK_PIPELINE_STAGE_2_HOST_BIT | VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
            before.srcAccessMask = VK_ACCESS_2_HOST_WRITE_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT;
            before.dstStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
            before.dstAccessMask = VK_ACCESS_2_SHADER_STORAGE_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT;
            VkDependencyInfo dependency{VK_STRUCTURE_TYPE_DEPENDENCY_INFO};
            dependency.memoryBarrierCount = 1; dependency.pMemoryBarriers = &before;
            vkCmdPipelineBarrier2(command, &dependency);
            const auto layout_index = stage == 1 ? 1 : 0;
            vkCmdBindPipeline(command, VK_PIPELINE_BIND_POINT_COMPUTE, pipelines[stage]);
            vkCmdBindDescriptorSets(command, VK_PIPELINE_BIND_POINT_COMPUTE, layouts[layout_index],
                                    0, 1, &sets[layout_index], 0, nullptr);
            if (stage == 1) {
                PrefixPush push;
                push.streams[0][0] = 24; push.streams[0][1] = 0x79;
                push.streams[0][2] = 16384;
                vkCmdPushConstants(command, layouts[1], VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(push), &push);
            } else {
                std::array<std::uint32_t, 32> push{};
                vkCmdPushConstants(command, layouts[0], VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(push), push.data());
            }
            if (!(stage == 1 && omit_prefix)) vkCmdDispatch(command, stage == 1 ? 1 : 24, 1, 1);
            VkMemoryBarrier2 after{VK_STRUCTURE_TYPE_MEMORY_BARRIER_2};
            after.srcStageMask = VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
            after.srcAccessMask = VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT;
            after.dstStageMask = VK_PIPELINE_STAGE_2_HOST_BIT | VK_PIPELINE_STAGE_2_COMPUTE_SHADER_BIT;
            after.dstAccessMask = VK_ACCESS_2_HOST_READ_BIT | VK_ACCESS_2_SHADER_STORAGE_READ_BIT |
                                  VK_ACCESS_2_SHADER_STORAGE_WRITE_BIT;
            dependency.pMemoryBarriers = &after;
            vkCmdPipelineBarrier2(command, &dependency);
            Check(vkEndCommandBuffer(command), "end command buffer");
            VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            submit.commandBufferCount = 1; submit.pCommandBuffers = &command;
            Check(vkQueueSubmit(queue, 1, &submit, fence), "submit command buffer");
            auto wait = vkWaitForFences(device, 1, &fence, VK_TRUE, 5'000'000'000ull);
            if (wait == VK_TIMEOUT) {
                std::fprintf(stderr, "GPU fence timed out after five seconds; exiting fixture\n");
                std::fflush(nullptr);
                std::_Exit(124);
            }
            Check(wait, "wait for GPU fence");
            for (std::uint32_t b = 0; b < 5; ++b) {
                result.stages[stage][b].resize(initial[b].size());
                std::memcpy(result.stages[stage][b].data(), buffers[b]->mapped, buffers[b]->size);
            }
        }
        if (errors) throw std::runtime_error("Vulkan validation reported an error");
        return result;
    }
};
GpuDriver::GpuDriver(std::span<const std::uint32_t> guest, std::span<const std::uint32_t> prefix)
    : state(std::make_unique<State>()) { state->Initialize(guest, prefix); }
GpuDriver::~GpuDriver() = default;
GpuResult GpuDriver::Run(const Buffers& initial, bool omit_prefix) { return state->Run(initial, omit_prefix); }
std::string GpuDriver::DeviceDescription() const { return state->description; }
std::uint32_t GpuDriver::ValidationErrors() const { return state->errors.load(); }
std::uint32_t GpuDriver::ValidationWarnings() const { return state->warnings.load(); }
}
