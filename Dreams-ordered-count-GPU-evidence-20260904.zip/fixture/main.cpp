#include "fixture_shader.hpp"
#include "gpu_driver.hpp"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>

using namespace ordered_fixture;
using Json = nlohmann::json;
namespace {
constexpr std::uint32_t sentinel = 0xa5c3e197U;
std::vector<std::uint32_t> ReadSpirv(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary | std::ios::ate);
    if (!stream || stream.tellg() <= 0 || stream.tellg() % 4) throw std::runtime_error("Invalid SPIR-V file");
    std::vector<std::uint32_t> words(static_cast<std::size_t>(stream.tellg()) / 4);
    stream.seekg(0);
    stream.read(reinterpret_cast<char*>(words.data()), words.size() * 4);
    if (!stream || words[0] != 0x07230203) throw std::runtime_error("SPIR-V read/magic failed");
    return words;
}
void WriteSpirv(const std::filesystem::path& path, std::span<const std::uint32_t> words) {
    std::ofstream stream(path, std::ios::binary);
    stream.write(reinterpret_cast<const char*>(words.data()), words.size_bytes());
    if (!stream) throw std::runtime_error("Unable to write fixture SPIR-V");
}
Buffers Seed(const std::vector<std::uint32_t>& counts) {
    Buffers buffers;
    buffers[0].assign(kGroupCount + 16, sentinel);
    std::copy(counts.begin(), counts.end(), buffers[0].begin());
    for (std::uint32_t b = 1; b <= 3; ++b) buffers[b].assign(kInvocationCount + 16, sentinel);
    std::fill_n(buffers[2].begin(), kInvocationCount, 0);
    buffers[4].assign(kScratchBaseDword + kGroupCount * kEntryDwords + 16, sentinel);
    buffers[4][kCounterIndex] = kCounterSeed;
    return buffers;
}
std::array<Buffers, 3> Expected(const Buffers& initial) {
    std::array<Buffers, 3> expected;
    expected[0] = initial;
    for (std::uint32_t group = 0; group < kGroupCount; ++group) {
        const auto index = kScratchBaseDword + group * kEntryDwords;
        expected[0][4][index] = initial[0][group];
        expected[0][4][index + 2] = group << 6;
    }
    expected[1] = expected[0];
    std::uint32_t running = kCounterSeed;
    for (std::uint32_t group = 0; group < kGroupCount; ++group) {
        expected[1][4][kScratchBaseDword + group * kEntryDwords + 1] = running;
        running += initial[0][group];
    }
    expected[1][4][kCounterIndex] = running;
    expected[2] = expected[1];
    for (std::uint32_t group = 0; group < kGroupCount; ++group) {
        for (std::uint32_t lane = 0; lane < kLanesPerGroup; ++lane) {
            const auto invocation = group * kLanesPerGroup + lane;
            expected[2][1][invocation] = expected[1][4][kScratchBaseDword + group * kEntryDwords + 1];
            expected[2][2][invocation] = 1;
            expected[2][3][invocation] = ExpectedProof(group, lane, initial[0][group]);
        }
    }
    return expected;
}
Json Compare(const std::array<Buffers, 3>& expected, const GpuResult& actual) {
    Json result;
    std::size_t mismatches = 0, checked = 0;
    result["first_mismatches"] = Json::array();
    for (std::uint32_t stage = 0; stage < 3; ++stage) {
        std::size_t stage_mismatches = 0;
        for (std::uint32_t binding = 0; binding < 5; ++binding) {
            const auto& e = expected[stage][binding];
            const auto& a = actual.stages[stage][binding];
            if (a.size() != e.size()) throw std::runtime_error("GPU result size mismatch");
            for (std::size_t i = 0; i < e.size(); ++i) {
                ++checked;
                if (a[i] == e[i]) continue;
                ++mismatches; ++stage_mismatches;
                if (result["first_mismatches"].size() < 12) {
                    result["first_mismatches"].push_back({{"stage", stage}, {"binding", binding},
                        {"dword", i}, {"expected", e[i]}, {"actual", a[i]}});
                }
            }
        }
        result["stage_mismatches"].push_back(stage_mismatches);
    }
    result["compared_dwords"] = checked;
    result["mismatches"] = mismatches;
    result["passed"] = mismatches == 0;
    return result;
}
}
int main(int argc, char** argv) {
    Json report;
    report["scope"] = "Synthetic post-resource-tracking IR using unmodified production B1 collect/replay lowering and unmodified production prefix GLSL; stipulated workgroup-index order, not PS4 hardware equivalence.";
    report["groups"] = kGroupCount;
    report["lanes_per_group"] = kLanesPerGroup;
    report["counter_seed"] = kCounterSeed;
    report["host_helper_under_test"] = false;
    report["variable_arrival_order_measured"] = false;
    try {
        const auto spirv = BuildOrderedFixtureSpirv();
        WriteSpirv("fixture.spv", spirv);
        std::cout << "Emitted production-lowered fixture: " << spirv.size() * 4 << " bytes\n" << std::flush;
        if (argc > 1 && std::string(argv[1]) == "--emit-only") return 0;
        const auto prefix = ReadSpirv(argc > 1 ? argv[1] : "prefix.spv");
        const auto started = std::chrono::steady_clock::now();
        GpuDriver driver(spirv, prefix);
        report["device"] = driver.DeviceDescription();
        std::cout << report["device"].get<std::string>() << '\n' << std::flush;
        std::vector<std::pair<std::string, std::vector<std::uint32_t>>> cases;
        cases.emplace_back("all_zero", std::vector<std::uint32_t>(kGroupCount, 0));
        cases.emplace_back("one_each", std::vector<std::uint32_t>(kGroupCount, 1));
        cases.emplace_back("full_wave_counts", std::vector<std::uint32_t>(kGroupCount, 64));
        auto& mixed = cases.emplace_back("mixed_zero_to_64", std::vector<std::uint32_t>(kGroupCount)).second;
        for (std::uint32_t i = 0; i < kGroupCount; ++i) mixed[i] = i % 5 == 0 ? 0 : (i * 17 + 3) % 65;
        auto reversed = mixed;
        std::reverse(reversed.begin(), reversed.end());
        cases.emplace_back("reversed_mixed", reversed);
        auto sparse = std::vector<std::uint32_t>(kGroupCount, 0);
        sparse[0] = 64; sparse[11] = 7; sparse[23] = 1;
        cases.emplace_back("sparse_endpoints", sparse);
        bool passed = true;
        for (const auto& [name, counts] : cases) {
            const auto initial = Seed(counts);
            const auto actual = driver.Run(initial);
            auto test = Compare(Expected(initial), actual);
            test["name"] = name;
            test["counts"] = counts;
            test["counter_after_replay"] = actual.stages[2][4][kCounterIndex];
            test["reservations"] = Json::array();
            for (std::uint32_t g = 0; g < kGroupCount; ++g) {
                test["reservations"].push_back(actual.stages[2][1][g * kLanesPerGroup]);
            }
            passed &= test["passed"].get<bool>();
            std::cout << name << ": " << (test["passed"].get<bool>() ? "PASS" : "FAIL")
                      << ", mismatches=" << test["mismatches"] << '\n' << std::flush;
            report["cases"].push_back(std::move(test));
        }
        // Deliberately omit the prefix pass while leaving real collector/replay
        // shaders intact. The same independent expected-results checker must fail.
        const auto initial = Seed(reversed);
        auto negative = Compare(Expected(initial), driver.Run(initial, true));
        negative["name"] = "omit_prefix_pass";
        negative["detected"] = !negative["passed"].get<bool>();
        passed &= negative["detected"].get<bool>();
        report["negative_control"] = negative;
        std::cout << "omit_prefix_pass negative control: "
                  << (negative["detected"].get<bool>() ? "DETECTED" : "MISSED") << '\n' << std::flush;
        report["validation_errors"] = driver.ValidationErrors();
        report["validation_warnings"] = driver.ValidationWarnings();
        passed &= driver.ValidationErrors() == 0;
        report["passed"] = passed;
        report["gpu_fixture_wall_seconds"] = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - started).count();
        std::ofstream("results.json") << report.dump(2) << '\n';
        return passed ? 0 : 1;
    } catch (const std::exception& error) {
        report["passed"] = false;
        report["error"] = error.what();
        std::cerr << "Fixture error: " << error.what() << '\n';
        std::ofstream("results.json") << report.dump(2) << '\n';
        return 2;
    }
}
