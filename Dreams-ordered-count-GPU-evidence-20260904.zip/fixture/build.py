"""Build the bounded GPU fixture from current research emitters, without running it.

Each locally compiled object, including Sirit, is reusable only when its compiler,
command, object bytes, and compiler-reported source/header dependencies match.
The larger unrelated static support libraries are recorded as prebuilt inputs.
"""

import argparse
import concurrent.futures
import ctypes
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(r'D:\CodexData\Worktrees\Dreams-ShadPS4\3c77544')
VENDOR_BUILD = ROOT / 'Build/x64-Clang-Tests'
LLVM = pathlib.Path(r'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\Llvm\x64\bin')
COMPILER = LLVM / 'clang-cl.exe'
LINKER = LLVM / 'lld-link.exe'
SDK = pathlib.Path(r'C:\VulkanSDK\1.4.350.0')
GLSLANG = SDK / 'Bin/glslangValidator.exe'
CACHE_MODULE = OUT.parent / 'upstream-core-build/build_cache.py'
sys.path.insert(0, str(CACHE_MODULE.parent))
from build_cache import DependencyCache, GenerationCache, digest, read_json, write_if_changed


def get_field(block, name):
    found = re.search(r'^  ' + re.escape(name) + r' = (.*)$', block, re.M)
    return found.group(1).strip() if found else ''


def fields(block):
    # CMake's current paths contain no spaces. Reject quoted fields rather than
    # silently misparse a future configure with different directory names.
    text = ' '.join(get_field(block, name) for name in ['DEFINES', 'FLAGS', 'INCLUDES'])
    if '"' in text or '$' in text:
        raise RuntimeError('Unexpected quoted or expanded compiler flags in build.ninja')
    return text.split()


def run(command, log, priority):
    command = [str(item) for item in command]
    with log.open('w', encoding='utf-8') as stream:
        result = subprocess.run(command, cwd=OUT, stdout=stream,
                                stderr=subprocess.STDOUT, creationflags=priority)
    if result.returncode:
        print(log.read_text(encoding='utf-8', errors='replace')[-6000:], flush=True)
        raise RuntimeError(f'Command failed ({result.returncode}); log={log}')


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dependencies-only', action='store_true',
                        help='Compile production/stub/Sirit dependencies and prefix GLSL only')
    parser.add_argument('--jobs', type=int, choices=range(1, 4), default=3)
    args = parser.parse_args()
    if not os.environ.get('INCLUDE') or not os.environ.get('LIB'):
        raise RuntimeError('Use build.cmd to initialize the VS x64 compiler environment')

    priority = subprocess.BELOW_NORMAL_PRIORITY_CLASS
    ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), priority)
    for name in ['objects', 'dependencies', 'logs']:
        (OUT / name).mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    cmake_path = ROOT / 'tests/CMakeLists.txt'
    ninja_path = VENDOR_BUILD / 'build.ninja'
    cmake = cmake_path.read_text()
    ninja = ninja_path.read_text()
    body = cmake.split('set(GCN_TEST_SOURCES', 1)[1].split('\n)', 1)[0]
    excluded = {'gcn/gcn_test_runner.cpp', 'gcn/translator.cpp', 'gcn/test_gcn_instructions.cpp'}
    sources = []
    for line in body.splitlines():
        line = line.strip()
        if not line.endswith('.cpp') or line in excluded:
            continue
        sources.append(pathlib.Path(line.replace('${CMAKE_SOURCE_DIR}', str(ROOT)))
                       if '${CMAKE_SOURCE_DIR}' in line else ROOT / 'tests' / line)
    if len(sources) != 60:
        raise RuntimeError(f'GCN target source list changed: expected 60 dependency units, got {len(sources)}')

    pattern = r'^build ([^\n]+): CXX_COMPILER__(shadps4_gcn_test|sirit)_unscanned_Release (.+?) \|\|[^\n]*\n((?:  [^\n]*\n)+)'
    blocks = re.findall(pattern, ninja, re.M)
    recipes = {}
    sirit_sources = []
    template = None
    for _, target, source, block in blocks:
        source = pathlib.Path(source.replace('$:', ':')).resolve()
        recipes[source] = block
        if target == 'sirit':
            sirit_sources.append(source)
        elif template is None:
            template = block
    if template is None or not sirit_sources:
        raise RuntimeError('Missing GCN or Sirit compiler recipes in research build.ninja')
    sources.extend(sirit_sources)
    if not args.dependencies_only:
        sources.extend(OUT / name for name in ['fixture_shader.cpp', 'gpu_driver.cpp', 'main.cpp'])

    cache_path = OUT / 'compile_cache.json'
    cache = DependencyCache(cache_path, OUT, priority)
    generation = GenerationCache(OUT / 'generation_cache.json')
    manifest = {
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'mode': 'dependencies-only' if args.dependencies_only else 'full',
        'source_root': str(ROOT), 'source_commit': git('rev-parse', 'HEAD'),
        'source_status': git('status', '--porcelain'),
        'cmake': {'path': str(cmake_path), 'sha256': digest(cmake_path)},
        'ninja': {'path': str(ninja_path), 'sha256': digest(ninja_path)},
        'builder_sha256': digest(__file__), 'cache_module_sha256': digest(CACHE_MODULE),
        'compiler': {'path': str(COMPILER), 'sha256': digest(COMPILER)},
        'linker': {'path': str(LINKER), 'sha256': digest(LINKER)},
        'dependency_cache': str(cache_path), 'parallel_jobs': args.jobs,
        'priority': 'BelowNormal', 'production_and_stub_units': 60,
        'research_sirit_units': len(sirit_sources), 'sources': [],
        'prebuilt_support_library_note': 'Support libraries are hashed inputs; no research emitter or Sirit objects are reused from another build.',
    }
    manifest_path = OUT / ('dependencies-provenance.json' if args.dependencies_only else 'build-provenance.json')
    jobs = []
    objects = []
    for source in sources:
        relative = (source.relative_to(ROOT).as_posix() if source.is_relative_to(ROOT)
                    else 'fixture/' + source.relative_to(OUT).as_posix())
        key = relative.replace('/', '__')
        obj = OUT / 'objects' / (key + '.obj')
        objects.append(obj)
        command = [str(COMPILER), '/nologo', '-TP', *fields(recipes.get(source, template)),
                   '-I' + str(OUT), '/c', str(source), '/Fo' + str(obj)]
        record = {'cache_key': key, 'source': str(source), 'sha256': digest(source), 'object': str(obj),
                  'command': command, 'compile_signature': cache.command_signature(command)}
        record['cache_hit'] = cache.current(key, command, source, obj)
        manifest['sources'].append(record)
        if not record['cache_hit']:
            jobs.append((key, source, obj, command))
    write_if_changed(manifest_path, json.dumps(manifest, indent=2))
    cached_count = len(sources) - len(jobs)
    print(f'Compile {len(jobs)} units; {cached_count} dependency-validated cached; '
          f'{args.jobs} BelowNormal workers; production source={ROOT}', flush=True)
    cache.invalidate(job[0] for job in jobs)
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        futures = {}
        pending = iter(jobs)

        def submit_next():
            try:
                key, source, obj, command = next(pending)
            except StopIteration:
                return False
            future = pool.submit(cache.compile, command, source, obj,
                                 OUT / 'dependencies' / (key + '.d'),
                                 OUT / 'logs' / (key + '.log'))
            futures[future] = key
            return True

        for _ in range(args.jobs):
            submit_next()
        completed = 0
        while futures:
            done, _ = concurrent.futures.wait(futures, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                key = futures.pop(future)
                # Save cache records from this main thread only.
                cache.store(key, future.result())
                completed += 1
                print(f'[{completed}/{len(jobs)}] {key}', flush=True)
                submit_next()

    prefix_source = ROOT / 'src/video_core/host_shaders/dreams_ordered_prefix.comp'
    prefix_output = OUT / 'prefix.spv'
    prefix_command = [GLSLANG, '-V', '--target-env', 'vulkan1.3', '-S', 'comp',
                      '-o', prefix_output, prefix_source]
    generated = generation.run('production-prefix', prefix_command,
                               [GLSLANG, prefix_source], [prefix_output],
                               lambda staged: run([*prefix_command[:7], staged[0], prefix_source],
                                                  OUT / 'logs/prefix.log', priority))
    manifest['prefix'] = {'source': str(prefix_source), 'source_sha256': digest(prefix_source),
                          'output': str(prefix_output), 'output_sha256': digest(prefix_output),
                          'compiler': str(GLSLANG), 'compiler_sha256': digest(GLSLANG),
                          'command': [str(item) for item in prefix_command], 'regenerated': generated}
    for record in manifest['sources']:
        if not cache.current(record['cache_key'], record['command'],
                             record['source'], record['object']):
            raise RuntimeError('Dependency changed during build; retry: ' + record['source'])
        record['sha256'] = digest(record['source'])
        record['object_sha256'] = digest(record['object'])
    manifest['compiled_count'] = len(jobs)
    manifest['cached_count'] = cached_count

    if not args.dependencies_only:
        link_block = ninja.split(': CXX_EXECUTABLE_LINKER__shadps4_gcn_test_Release', 1)[1]
        libraries = []
        prebuilt = {}
        for name in get_field(link_block, 'LINK_LIBRARIES').split():
            # The standalone main needs neither gtest_main nor gtest; matching
            # Sirit is linked from the freshly dependency-checked source objects.
            if name in {'lib\\gtest_main.lib', 'lib\\gtest.lib', 'externals\\sirit\\src\\sirit.lib'}:
                continue
            if '\\' in name or '/' in name:
                path = (VENDOR_BUILD / name).resolve()
            else:
                candidates = [OUT / name, *[pathlib.Path(folder) / name
                                           for folder in os.environ['LIB'].split(';') if folder]]
                path = next((candidate.resolve() for candidate in candidates if candidate.is_file()), None)
                if path is None:
                    raise RuntimeError('Cannot resolve link library: ' + name)
            library = str(path)
            if library not in libraries:
                libraries.append(library)
            prebuilt[str(path)] = digest(path)
        # C API Vulkan calls are linked through the SDK loader import library.
        vulkan_library = SDK / 'Lib/vulkan-1.lib'
        libraries.append(str(vulkan_library))
        prebuilt[str(vulkan_library)] = digest(vulkan_library)
        exe = OUT / 'ordered-count-fixture.exe'
        link_command = [LINKER, *get_field(link_block, 'LINK_FLAGS').split(),
                        '/out:' + str(exe), *objects, *libraries]
        link_inputs = [LINKER, *objects, *[pathlib.Path(path) for path in prebuilt]]
        # LIB affects compiler-embedded default libraries as well as explicit inputs.
        link_identity = [*link_command, 'environment:LIB=' + os.environ['LIB']]
        linked = generation.run('fixture-executable', link_identity, link_inputs, [exe],
                                lambda staged: run([LINKER, *get_field(link_block, 'LINK_FLAGS').split(),
                                                    '/out:' + str(staged[0]), *objects, *libraries],
                                                   OUT / 'logs/link.log', priority))
        manifest['prebuilt_support_libraries'] = prebuilt
        manifest['link_environment_lib'] = os.environ['LIB']
        manifest['link_command'] = [str(item) for item in link_command]
        manifest['executable'] = {'path': str(exe), 'sha256': digest(exe), 'relinked': linked}

    manifest['elapsed_seconds'] = round(time.monotonic() - started, 3)
    manifest['complete'] = True
    write_if_changed(manifest_path, json.dumps(manifest, indent=2))
    print(f'Build complete in {manifest["elapsed_seconds"]} seconds; '
          f'provenance={manifest_path}; fixture was not executed.', flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(f'BUILD FAILED: {error}', file=sys.stderr, flush=True)
        raise
